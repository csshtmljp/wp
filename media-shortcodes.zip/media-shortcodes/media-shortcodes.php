<?php
/**
 * Plugin Name:       Media Shortcodes
 * Description:       メディアライブラリの各ファイルに個別のショートコード [media_file id="…"] を用意し、一覧と詳細画面からコピーできるようにします。画像・音声・動画・PDF・その他のファイルを種類に合わせて表示します。
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Media Shortcodes
 * License:           GPL-2.0-or-later
 * Text Domain:       media-shortcodes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Media_Shortcodes {

	const TAG = 'media_file';

	public static function init() {
		$self = new self();
		add_shortcode( self::TAG, array( $self, 'shortcode' ) );

		add_filter( 'manage_media_columns', array( $self, 'add_column' ) );
		add_action( 'manage_media_custom_column', array( $self, 'render_column' ), 10, 2 );
		add_filter( 'attachment_fields_to_edit', array( $self, 'add_field' ), 10, 2 );
		add_filter( 'media_row_actions', array( $self, 'row_action' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( $self, 'admin_assets' ) );
	}

	/** そのファイル用のショートコード文字列 */
	public static function code( $id ) {
		return '[' . self::TAG . ' id="' . (int) $id . '"]';
	}

	/* ------------------------------------------------------------------
	 * ショートコード本体
	 * ---------------------------------------------------------------- */

	/**
	 * [media_file id="123"]
	 *
	 * 共通:   class="…"  type="auto|link|url"
	 * 画像:   size="large"  link="none|file|page"  caption="1"  alt="…"
	 * 動画:   width="640" height="360"
	 * PDF:    embed="1" height="600"
	 * リンク: text="…"  meta="0"  download="1"  newtab="1"
	 */
	public function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id'       => 0,
				'type'     => 'auto',
				'class'    => '',
				'size'     => 'large',
				'link'     => 'none',
				'caption'  => '0',
				'alt'      => '',
				'width'    => '',
				'height'   => '',
				'embed'    => '0',
				'text'     => '',
				'meta'     => '1',
				'download' => '0',
				'newtab'   => '0',
			),
			$atts,
			self::TAG
		);

		$id   = absint( $atts['id'] );
		$post = $id ? get_post( $id ) : null;
		if ( ! $post || 'attachment' !== $post->post_type ) {
			return '';
		}
		$url = wp_get_attachment_url( $id );
		if ( ! $url ) {
			return '';
		}

		$class = implode( ' ', array_filter( array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $atts['class'] ) ) ) );
		$mime  = (string) get_post_mime_type( $id );
		$type  = strtolower( (string) $atts['type'] );

		if ( 'url' === $type ) {
			return esc_url( $url );
		}
		if ( 'link' === $type ) {
			return $this->link_html( $id, $url, $atts, $class );
		}

		if ( wp_attachment_is_image( $id ) ) {
			return $this->image_html( $id, $url, $atts, $class );
		}
		if ( 0 === strpos( $mime, 'audio/' ) ) {
			$html = wp_audio_shortcode( array( 'src' => $url ) );
			return '<div class="' . esc_attr( trim( 'media-file media-file-audio ' . $class ) ) . '">' . $html . '</div>';
		}
		if ( 0 === strpos( $mime, 'video/' ) ) {
			$args = array( 'src' => $url );
			if ( absint( $atts['width'] ) ) {
				$args['width'] = absint( $atts['width'] );
			}
			if ( absint( $atts['height'] ) ) {
				$args['height'] = absint( $atts['height'] );
			}
			$html = wp_video_shortcode( $args );
			return '<div class="' . esc_attr( trim( 'media-file media-file-video ' . $class ) ) . '">' . $html . '</div>';
		}
		if ( 'application/pdf' === $mime && '1' === (string) $atts['embed'] ) {
			$height = absint( $atts['height'] ) ? absint( $atts['height'] ) : 600;
			return sprintf(
				'<div class="%1$s"><object data="%2$s" type="application/pdf" style="width:100%%;height:%3$dpx">%4$s</object></div>',
				esc_attr( trim( 'media-file media-file-pdf ' . $class ) ),
				esc_url( $url ),
				$height,
				$this->link_html( $id, $url, $atts, '' )
			);
		}

		return $this->link_html( $id, $url, $atts, $class );
	}

	private function image_html( $id, $url, $atts, $class ) {
		$size = sanitize_key( $atts['size'] );
		$attr = array( 'class' => trim( 'media-file media-file-image ' . $class ) );
		if ( '' !== $atts['alt'] ) {
			$attr['alt'] = sanitize_text_field( $atts['alt'] );
		}
		$html = wp_get_attachment_image( $id, $size ? $size : 'large', false, $attr );
		if ( ! $html ) {
			return '';
		}

		$link = strtolower( (string) $atts['link'] );
		if ( 'file' === $link ) {
			$html = '<a href="' . esc_url( $url ) . '">' . $html . '</a>';
		} elseif ( 'page' === $link ) {
			$html = '<a href="' . esc_url( get_attachment_link( $id ) ) . '">' . $html . '</a>';
		}

		if ( '1' === (string) $atts['caption'] ) {
			$caption = wp_get_attachment_caption( $id );
			if ( $caption ) {
				$html = '<figure class="media-file-figure">' . $html . '<figcaption>' . esc_html( $caption ) . '</figcaption></figure>';
			}
		}
		return $html;
	}

	private function link_html( $id, $url, $atts, $class ) {
		$label = sanitize_text_field( $atts['text'] );
		if ( '' === $label ) {
			$label = get_the_title( $id );
		}
		if ( '' === $label ) {
			$label = wp_basename( $url );
		}

		$meta = '';
		if ( '0' !== (string) $atts['meta'] ) {
			$parts = array();
			$ext   = strtoupper( pathinfo( wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
			if ( $ext ) {
				$parts[] = $ext;
			}
			$path = get_attached_file( $id );
			if ( $path && file_exists( $path ) ) {
				$parts[] = size_format( filesize( $path ), 1 );
			}
			if ( $parts ) {
				$meta = ' <span class="media-file-meta">(' . esc_html( implode( ', ', $parts ) ) . ')</span>';
			}
		}

		$extra = '';
		if ( '1' === (string) $atts['download'] ) {
			$extra .= ' download';
		}
		if ( '1' === (string) $atts['newtab'] ) {
			$extra .= ' target="_blank" rel="noopener"';
		}

		return sprintf(
			'<a class="%1$s" href="%2$s"%3$s>%4$s%5$s</a>',
			esc_attr( trim( 'media-file media-file-link ' . $class ) ),
			esc_url( $url ),
			$extra,
			esc_html( $label ),
			$meta
		);
	}

	/* ------------------------------------------------------------------
	 * 管理画面: ショートコードの表示とコピー
	 * ---------------------------------------------------------------- */

	private function copy_box( $id ) {
		$code = self::code( $id );
		return sprintf(
			'<span class="msc-box"><input type="text" class="msc-code" readonly value="%1$s" aria-label="ショートコード" size="%2$d"> <button type="button" class="button button-small msc-copy" data-code="%1$s">コピー</button></span>',
			esc_attr( $code ),
			strlen( $code ) + 1
		);
	}

	public function add_column( $columns ) {
		$columns['msc_shortcode'] = 'ショートコード';
		return $columns;
	}

	public function render_column( $column, $id ) {
		if ( 'msc_shortcode' === $column ) {
			echo $this->copy_box( $id ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}

	/** 添付ファイルの詳細(グリッド表示のモーダルと編集画面)に欄を追加 */
	public function add_field( $fields, $post ) {
		$fields['msc_shortcode'] = array(
			'label' => 'ショートコード',
			'input' => 'html',
			'html'  => $this->copy_box( $post->ID ),
			'helps' => '投稿や固定ページに貼り付けると、このファイルが表示されます。',
		);
		return $fields;
	}

	public function row_action( $actions, $post ) {
		$actions['msc_copy'] = '<button type="button" class="button-link msc-copy" data-code="' . esc_attr( self::code( $post->ID ) ) . '">ショートコードをコピー</button>';
		return $actions;
	}

	public function admin_assets() {
		wp_register_script( 'msc-admin', false, array(), '1.0.0', true );
		wp_enqueue_script( 'msc-admin' );
		wp_add_inline_script( 'msc-admin', $this->script() );

		wp_register_style( 'msc-admin', false, array(), '1.0.0' );
		wp_enqueue_style( 'msc-admin' );
		wp_add_inline_style(
			'msc-admin',
			'.msc-box{display:inline-flex;flex-wrap:wrap;gap:4px;align-items:center;max-width:100%}'
			. '.msc-box .msc-code{font-family:Consolas,Monaco,monospace;font-size:12px;max-width:100%;min-height:26px;padding:0 6px;background:#f6f7f7}'
			. '.column-msc_shortcode{width:230px}'
			. '.compat-field-msc_shortcode .msc-code{width:100%}'
		);
	}

	private function script() {
		return <<<'JS'
(function(){
	function done(btn, ok){
		var old = btn.getAttribute('data-label') || btn.textContent;
		btn.setAttribute('data-label', old);
		btn.textContent = ok ? 'コピーしました' : 'コピーできませんでした';
		setTimeout(function(){ btn.textContent = old; }, 1600);
	}
	function fallback(code){
		var ta = document.createElement('textarea');
		ta.value = code;
		ta.setAttribute('readonly', '');
		ta.style.position = 'fixed';
		ta.style.left = '-9999px';
		document.body.appendChild(ta);
		ta.select();
		var ok = false;
		try { ok = document.execCommand('copy'); } catch (e) {}
		document.body.removeChild(ta);
		return ok;
	}
	document.addEventListener('click', function(e){
		var t = e.target;
		if (!t || !t.classList) { return; }
		if (t.classList.contains('msc-code')) { t.select(); return; }
		if (!t.classList.contains('msc-copy')) { return; }
		e.preventDefault();
		var code = t.getAttribute('data-code');
		if (navigator.clipboard && window.isSecureContext) {
			navigator.clipboard.writeText(code).then(function(){ done(t, true); }, function(){ done(t, fallback(code)); });
		} else {
			done(t, fallback(code));
		}
	});
})();
JS;
	}
}

Media_Shortcodes::init();
