<?php
/**
 * Plugin Name: Recipe Shelf
 * Description: レシピとレシピ集を作成し、ショートコードで固定ページや投稿にレシピ集とレシピ動画を並べて表示します。
 * Version: 1.0.0
 * Author: Recipe Shelf
 * License: GPL-2.0-or-later
 * Text Domain: recipe-shelf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RCS_VERSION', '1.0.0' );
define( 'RCS_POST_TYPE', 'rcs_recipe' );
define( 'RCS_TAXONOMY', 'rcs_collection' );

/* -------------------------------------------------------------------------
 * 1. 投稿タイプ「レシピ」とタクソノミー「レシピ集」
 * ---------------------------------------------------------------------- */
function rcs_register_types() {
	register_post_type(
		RCS_POST_TYPE,
		array(
			'labels'       => array(
				'name'          => 'レシピ',
				'singular_name' => 'レシピ',
				'add_new'       => '新規追加',
				'add_new_item'  => 'レシピを追加',
				'edit_item'     => 'レシピを編集',
				'new_item'      => '新しいレシピ',
				'view_item'     => 'レシピを表示',
				'search_items'  => 'レシピを検索',
				'not_found'     => 'レシピが見つかりません',
				'all_items'     => 'レシピ一覧',
				'menu_name'     => 'レシピ',
			),
			'public'       => true,
			'has_archive'  => true,
			'show_in_rest' => true,
			'menu_icon'    => 'dashicons-carrot',
			'menu_position' => 5,
			'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
			'rewrite'      => array( 'slug' => 'recipe' ),
		)
	);

	register_taxonomy(
		RCS_TAXONOMY,
		RCS_POST_TYPE,
		array(
			'labels'            => array(
				'name'          => 'レシピ集',
				'singular_name' => 'レシピ集',
				'add_new_item'  => 'レシピ集を追加',
				'edit_item'     => 'レシピ集を編集',
				'search_items'  => 'レシピ集を検索',
				'all_items'     => 'すべてのレシピ集',
				'parent_item'   => '親レシピ集',
				'menu_name'     => 'レシピ集',
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'rewrite'           => array( 'slug' => 'recipe-collection' ),
		)
	);
}
add_action( 'init', 'rcs_register_types' );

function rcs_activate() {
	rcs_register_types();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'rcs_activate' );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

/* -------------------------------------------------------------------------
 * 2. レシピ情報の入力欄（メタボックス）
 * ---------------------------------------------------------------------- */
function rcs_fields() {
	return array(
		'_rcs_time'        => array( 'label' => '調理時間', 'type' => 'text', 'placeholder' => '例：20分' ),
		'_rcs_servings'    => array( 'label' => '分量', 'type' => 'text', 'placeholder' => '例：2人分' ),
		'_rcs_video'       => array( 'label' => '動画URL', 'type' => 'url', 'placeholder' => 'YouTube / Vimeo のURL、または mp4 ファイルのURL' ),
		'_rcs_ingredients' => array( 'label' => '材料（1行に1つ）', 'type' => 'textarea', 'placeholder' => "玉ねぎ 1個\n鶏もも肉 300g" ),
		'_rcs_steps'       => array( 'label' => '作り方（1行に1手順）', 'type' => 'textarea', 'placeholder' => "玉ねぎを薄切りにする。\n鶏肉を一口大に切る。" ),
	);
}

function rcs_add_meta_box() {
	add_meta_box( 'rcs_recipe_meta', 'レシピ情報', 'rcs_render_meta_box', RCS_POST_TYPE, 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'rcs_add_meta_box' );

function rcs_render_meta_box( $post ) {
	wp_nonce_field( 'rcs_save_meta', 'rcs_meta_nonce' );
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( rcs_fields() as $key => $field ) {
		$value = get_post_meta( $post->ID, $key, true );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td>';
		if ( 'textarea' === $field['type'] ) {
			printf(
				'<textarea id="%1$s" name="%1$s" rows="7" class="large-text" placeholder="%2$s">%3$s</textarea>',
				esc_attr( $key ),
				esc_attr( $field['placeholder'] ),
				esc_textarea( $value )
			);
		} else {
			printf(
				'<input type="%4$s" id="%1$s" name="%1$s" value="%3$s" class="large-text" placeholder="%2$s" />',
				esc_attr( $key ),
				esc_attr( $field['placeholder'] ),
				esc_attr( $value ),
				esc_attr( $field['type'] )
			);
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
	echo '<p class="description">このレシピ単体を埋め込むショートコード：<code>[recipe id="' . (int) $post->ID . '"]</code></p>';
}

function rcs_save_meta( $post_id ) {
	if ( ! isset( $_POST['rcs_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['rcs_meta_nonce'] ), 'rcs_save_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( rcs_fields() as $key => $field ) {
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$raw = wp_unslash( $_POST[ $key ] );
		if ( 'textarea' === $field['type'] ) {
			$value = sanitize_textarea_field( $raw );
		} elseif ( 'url' === $field['type'] ) {
			$value = esc_url_raw( trim( $raw ) );
		} else {
			$value = sanitize_text_field( $raw );
		}
		if ( '' === $value ) {
			delete_post_meta( $post_id, $key );
		} else {
			update_post_meta( $post_id, $key, $value );
		}
	}
}
add_action( 'save_post_' . RCS_POST_TYPE, 'rcs_save_meta' );

/* -------------------------------------------------------------------------
 * 3. 管理画面：一覧にショートコード列、レシピ集にもショートコード表示
 * ---------------------------------------------------------------------- */
function rcs_term_columns( $columns ) {
	$columns['rcs_shortcode'] = 'ショートコード';
	return $columns;
}
add_filter( 'manage_edit-' . RCS_TAXONOMY . '_columns', 'rcs_term_columns' );

function rcs_term_column_content( $content, $column, $term_id ) {
	if ( 'rcs_shortcode' === $column ) {
		$term = get_term( $term_id, RCS_TAXONOMY );
		if ( $term && ! is_wp_error( $term ) ) {
			$content = '<code>[recipe_showcase collection="' . esc_html( urldecode( $term->slug ) ) . '"]</code>';
		}
	}
	return $content;
}
add_filter( 'manage_' . RCS_TAXONOMY . '_custom_column', 'rcs_term_column_content', 10, 3 );

function rcs_help_page() {
	add_submenu_page(
		'edit.php?post_type=' . RCS_POST_TYPE,
		'ショートコードの使い方',
		'使い方',
		'edit_posts',
		'rcs-help',
		'rcs_render_help_page'
	);
}
add_action( 'admin_menu', 'rcs_help_page' );

function rcs_render_help_page() {
	?>
	<div class="wrap">
		<h1>Recipe Shelf ショートコードの使い方</h1>
		<table class="widefat striped" style="max-width:960px">
			<thead><tr><th>ショートコード</th><th>表示内容</th></tr></thead>
			<tbody>
				<tr><td><code>[recipe_showcase collection="スラッグ"]</code></td><td>レシピ集（左）とレシピ動画（右）を並べて表示</td></tr>
				<tr><td><code>[recipe_collection collection="スラッグ"]</code></td><td>レシピ集のカード一覧のみ</td></tr>
				<tr><td><code>[recipe_videos collection="スラッグ"]</code></td><td>レシピ動画の一覧のみ</td></tr>
				<tr><td><code>[recipe id="123"]</code></td><td>レシピ1件（材料・作り方・動画）</td></tr>
			</tbody>
		</table>
		<h2>指定できる属性</h2>
		<ul style="list-style:disc;padding-left:1.5em">
			<li><code>collection</code>：レシピ集のスラッグ。カンマ区切りで複数指定可。省略すると全レシピ。</li>
			<li><code>count</code>：表示件数（recipe_showcase は <code>count</code> がレシピ数、<code>video_count</code> が動画数）</li>
			<li><code>columns</code>：列数 1〜4（recipe_showcase は <code>columns</code> と <code>video_columns</code>）</li>
			<li><code>orderby</code>：<code>date</code> / <code>title</code> / <code>rand</code> / <code>menu_order</code>、<code>order</code>：<code>ASC</code> / <code>DESC</code></li>
			<li><code>layout</code>（recipe_showcase のみ）：<code>side</code>＝左右に並べる（既定）、<code>stack</code>＝上下に並べる、<code>reverse</code>＝動画を左に</li>
			<li><code>title</code> / <code>video_title</code>：見出しの文言。空にすると見出しなし。</li>
		</ul>
	</div>
	<?php
}

/* -------------------------------------------------------------------------
 * 4. 表示用ヘルパー
 * ---------------------------------------------------------------------- */
function rcs_register_assets() {
	wp_register_style( 'recipe-shelf', plugins_url( 'assets/style.css', __FILE__ ), array(), RCS_VERSION );
}
add_action( 'wp_enqueue_scripts', 'rcs_register_assets' );

function rcs_lines( $text ) {
	$lines = preg_split( '/\r\n|\r|\n/', (string) $text );
	return array_values( array_filter( array_map( 'trim', $lines ), 'strlen' ) );
}

/** 動画URLを埋め込みHTMLへ変換 */
function rcs_video_html( $url ) {
	$url = esc_url_raw( $url );
	if ( '' === $url ) {
		return '';
	}
	$path = (string) wp_parse_url( $url, PHP_URL_PATH );
	if ( preg_match( '/\.(mp4|m4v|webm|ogv|mov)$/i', $path ) ) {
		$html = '<video controls preload="metadata" playsinline src="' . esc_url( $url ) . '"></video>';
	} else {
		$html = wp_oembed_get( $url, array( 'width' => 640 ) );
		if ( ! $html ) {
			return '<p class="rcs-video-link"><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">動画を見る</a></p>';
		}
	}
	return '<div class="rcs-video-frame">' . $html . '</div>';
}

/** ショートコード共通のクエリを組み立てる */
function rcs_build_query( $atts, $count, $video_only = false ) {
	$allowed_orderby = array( 'date', 'title', 'rand', 'menu_order', 'modified' );
	$orderby         = in_array( $atts['orderby'], $allowed_orderby, true ) ? $atts['orderby'] : 'date';
	$order           = 'ASC' === strtoupper( $atts['order'] ) ? 'ASC' : 'DESC';

	$args = array(
		'post_type'           => RCS_POST_TYPE,
		'post_status'         => 'publish',
		'posts_per_page'      => (int) $count ? (int) $count : -1,
		'orderby'             => $orderby,
		'order'               => $order,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);

	if ( '' !== trim( $atts['collection'] ) ) {
		$slugs = array_filter( array_map( 'trim', explode( ',', $atts['collection'] ) ) );
		$slugs = array_map( 'sanitize_title', $slugs );
		$args['tax_query'] = array(
			array(
				'taxonomy' => RCS_TAXONOMY,
				'field'    => 'slug',
				'terms'    => $slugs,
			),
		);
	}

	if ( $video_only ) {
		$args['meta_query'] = array(
			array(
				'key'     => '_rcs_video',
				'value'   => '',
				'compare' => '!=',
			),
		);
	}

	return new WP_Query( $args );
}

function rcs_columns( $value, $default ) {
	$n = (int) $value;
	return ( $n >= 1 && $n <= 4 ) ? $n : $default;
}

function rcs_default_atts() {
	return array(
		'collection' => '',
		'count'      => 12,
		'columns'    => 3,
		'orderby'    => 'date',
		'order'      => 'DESC',
		'title'      => '',
	);
}

/** レシピカード一覧のHTML */
function rcs_render_cards( $atts ) {
	$query = rcs_build_query( $atts, $atts['count'] );
	if ( ! $query->have_posts() ) {
		return '<p class="rcs-empty">レシピがまだありません。</p>';
	}
	$out = '<div class="rcs-grid rcs-cols-' . rcs_columns( $atts['columns'], 3 ) . '">';
	while ( $query->have_posts() ) {
		$query->the_post();
		$id   = get_the_ID();
		$time = get_post_meta( $id, '_rcs_time', true );
		$serv = get_post_meta( $id, '_rcs_servings', true );

		$out .= '<article class="rcs-card"><a class="rcs-card-link" href="' . esc_url( get_permalink() ) . '">';
		$out .= '<div class="rcs-card-thumb">';
		$out .= has_post_thumbnail() ? get_the_post_thumbnail( $id, 'medium_large', array( 'loading' => 'lazy' ) ) : '<span class="rcs-noimage" aria-hidden="true"></span>';
		if ( get_post_meta( $id, '_rcs_video', true ) ) {
			$out .= '<span class="rcs-badge">動画あり</span>';
		}
		$out .= '</div>';
		$out .= '<h4 class="rcs-card-title">' . esc_html( get_the_title() ) . '</h4>';
		if ( $time || $serv ) {
			$out .= '<p class="rcs-card-meta">' . esc_html( implode( ' ／ ', array_filter( array( $time, $serv ) ) ) ) . '</p>';
		}
		$out .= '</a></article>';
	}
	wp_reset_postdata();
	return $out . '</div>';
}

/** 動画一覧のHTML */
function rcs_render_videos( $atts ) {
	$query = rcs_build_query( $atts, $atts['count'], true );
	if ( ! $query->have_posts() ) {
		return '<p class="rcs-empty">レシピ動画がまだありません。</p>';
	}
	$out = '<div class="rcs-grid rcs-video-grid rcs-cols-' . rcs_columns( $atts['columns'], 2 ) . '">';
	while ( $query->have_posts() ) {
		$query->the_post();
		$out .= '<figure class="rcs-video">';
		$out .= rcs_video_html( get_post_meta( get_the_ID(), '_rcs_video', true ) );
		$out .= '<figcaption><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></figcaption>';
		$out .= '</figure>';
	}
	wp_reset_postdata();
	return $out . '</div>';
}

/** レシピ詳細（材料・作り方・動画）のHTML */
function rcs_render_detail( $post_id, $with_video = true ) {
	$time  = get_post_meta( $post_id, '_rcs_time', true );
	$serv  = get_post_meta( $post_id, '_rcs_servings', true );
	$ings  = rcs_lines( get_post_meta( $post_id, '_rcs_ingredients', true ) );
	$steps = rcs_lines( get_post_meta( $post_id, '_rcs_steps', true ) );
	$video = get_post_meta( $post_id, '_rcs_video', true );

	$out = '<div class="rcs-detail">';
	if ( $time || $serv ) {
		$out .= '<ul class="rcs-facts">';
		if ( $time ) {
			$out .= '<li><span>調理時間</span>' . esc_html( $time ) . '</li>';
		}
		if ( $serv ) {
			$out .= '<li><span>分量</span>' . esc_html( $serv ) . '</li>';
		}
		$out .= '</ul>';
	}
	if ( $with_video && $video ) {
		$out .= rcs_video_html( $video );
	}
	if ( $ings ) {
		$out .= '<h3 class="rcs-heading">材料</h3><ul class="rcs-ingredients">';
		foreach ( $ings as $line ) {
			$out .= '<li>' . esc_html( $line ) . '</li>';
		}
		$out .= '</ul>';
	}
	if ( $steps ) {
		$out .= '<h3 class="rcs-heading">作り方</h3><ol class="rcs-steps">';
		foreach ( $steps as $line ) {
			$out .= '<li>' . esc_html( $line ) . '</li>';
		}
		$out .= '</ol>';
	}
	return $out . '</div>';
}

function rcs_section_title( $title ) {
	return '' !== trim( $title ) ? '<h3 class="rcs-section-title">' . esc_html( $title ) . '</h3>' : '';
}

/* -------------------------------------------------------------------------
 * 5. ショートコード
 * ---------------------------------------------------------------------- */

/** [recipe_collection] レシピ集のカード一覧 */
function rcs_sc_collection( $atts ) {
	$atts = shortcode_atts( rcs_default_atts(), $atts, 'recipe_collection' );
	wp_enqueue_style( 'recipe-shelf' );
	return '<div class="rcs-wrap">' . rcs_section_title( $atts['title'] ) . rcs_render_cards( $atts ) . '</div>';
}
add_shortcode( 'recipe_collection', 'rcs_sc_collection' );

/** [recipe_videos] レシピ動画の一覧 */
function rcs_sc_videos( $atts ) {
	$defaults            = rcs_default_atts();
	$defaults['count']   = 6;
	$defaults['columns'] = 2;
	$atts                = shortcode_atts( $defaults, $atts, 'recipe_videos' );
	wp_enqueue_style( 'recipe-shelf' );
	return '<div class="rcs-wrap">' . rcs_section_title( $atts['title'] ) . rcs_render_videos( $atts ) . '</div>';
}
add_shortcode( 'recipe_videos', 'rcs_sc_videos' );

/** [recipe_showcase] レシピ集とレシピ動画を並べて表示 */
function rcs_sc_showcase( $atts ) {
	$defaults = array_merge(
		rcs_default_atts(),
		array(
			'count'         => 6,
			'columns'       => 2,
			'title'         => 'レシピ集',
			'video_count'   => 3,
			'video_columns' => 1,
			'video_title'   => 'レシピ動画',
			'layout'        => 'side',
		)
	);
	$atts   = shortcode_atts( $defaults, $atts, 'recipe_showcase' );
	$layout = in_array( $atts['layout'], array( 'side', 'stack', 'reverse' ), true ) ? $atts['layout'] : 'side';
	wp_enqueue_style( 'recipe-shelf' );

	$video_atts            = $atts;
	$video_atts['count']   = $atts['video_count'];
	$video_atts['columns'] = rcs_columns( $atts['video_columns'], 1 );

	$out  = '<div class="rcs-wrap rcs-showcase rcs-layout-' . esc_attr( $layout ) . '">';
	$out .= '<section class="rcs-pane rcs-pane-recipes">' . rcs_section_title( $atts['title'] ) . rcs_render_cards( $atts ) . '</section>';
	$out .= '<section class="rcs-pane rcs-pane-videos">' . rcs_section_title( $atts['video_title'] ) . rcs_render_videos( $video_atts ) . '</section>';
	return $out . '</div>';
}
add_shortcode( 'recipe_showcase', 'rcs_sc_showcase' );

/** [recipe id="123"] レシピ1件 */
function rcs_sc_recipe( $atts ) {
	$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'recipe' );
	$post = get_post( (int) $atts['id'] );
	if ( ! $post || RCS_POST_TYPE !== $post->post_type || 'publish' !== $post->post_status ) {
		return '';
	}
	wp_enqueue_style( 'recipe-shelf' );

	$out = '<div class="rcs-wrap rcs-single">';
	$out .= '<h3 class="rcs-single-title"><a href="' . esc_url( get_permalink( $post ) ) . '">' . esc_html( get_the_title( $post ) ) . '</a></h3>';
	if ( has_post_thumbnail( $post ) && ! get_post_meta( $post->ID, '_rcs_video', true ) ) {
		$out .= '<div class="rcs-single-thumb">' . get_the_post_thumbnail( $post, 'large' ) . '</div>';
	}
	if ( $post->post_excerpt ) {
		$out .= '<p class="rcs-single-excerpt">' . esc_html( $post->post_excerpt ) . '</p>';
	}
	return $out . rcs_render_detail( $post->ID ) . '</div>';
}
add_shortcode( 'recipe', 'rcs_sc_recipe' );

/* -------------------------------------------------------------------------
 * 6. レシピ個別ページの本文に材料・作り方・動画を自動追加
 * ---------------------------------------------------------------------- */
function rcs_append_detail( $content ) {
	if ( is_singular( RCS_POST_TYPE ) && in_the_loop() && is_main_query() ) {
		wp_enqueue_style( 'recipe-shelf' );
		$content .= '<div class="rcs-wrap">' . rcs_render_detail( get_the_ID() ) . '</div>';
	}
	return $content;
}
add_filter( 'the_content', 'rcs_append_detail' );
