<?php
/**
 * Plugin Name: 本棚Flip dn
 * Description: PDF・EPUB・DOCX・Markdown・TXTを本棚に並べ、Flip形式で閲覧できます。複数登録、表紙、説明文に対応。
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: dn
 * License: GPL-3.0-or-later
 * Text Domain: bookshelf-flip-dn
 */
if (!defined('ABSPATH')) { exit; }

final class Bookshelf_Flip_Dn {
    const VERSION = '1.0.0';
    const TYPE = 'bookshelf_flip_dn';
    const MAX_BYTES = 52428800;
    const EXT = array('pdf', 'epub', 'docx', 'md', 'txt');

    public static function boot() {
        add_action('init', array(__CLASS__, 'register'));
        add_action('add_meta_boxes', array(__CLASS__, 'boxes'));
        add_action('save_post_' . self::TYPE, array(__CLASS__, 'save'), 10, 2);
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_notices', array(__CLASS__, 'notice'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'admin_assets'));
        add_action('wp_ajax_bfdn_import', array(__CLASS__, 'import_book'));
        add_action('admin_post_bfdn_file', array(__CLASS__, 'serve'));
        add_action('admin_post_nopriv_bfdn_file', array(__CLASS__, 'serve'));
        add_filter('upload_mimes', array(__CLASS__, 'mimes'));
        add_filter('wp_check_filetype_and_ext', array(__CLASS__, 'check_mime'), 10, 5);
        add_shortcode('bookshelf_dn', array(__CLASS__, 'shortcode'));
        add_filter('manage_' . self::TYPE . '_posts_columns', array(__CLASS__, 'columns'));
        add_action('manage_' . self::TYPE . '_posts_custom_column', array(__CLASS__, 'column'), 10, 2);
    }
    public static function register() {
        $caps = array();
        foreach (array('edit_post','read_post','delete_post','edit_posts','edit_others_posts','publish_posts','read_private_posts','delete_posts','delete_private_posts','delete_published_posts','delete_others_posts','edit_private_posts','edit_published_posts','create_posts') as $c) { $caps[$c] = 'manage_options'; }
        register_post_type(self::TYPE, array(
            'labels'=>array('name'=>'本棚Flip dn','singular_name'=>'本','add_new'=>'本を追加','add_new_item'=>'本を追加','edit_item'=>'本を編集','all_items'=>'本の一覧','search_items'=>'本を検索','not_found'=>'本がありません'),
            'public'=>false,'show_ui'=>true,'show_in_rest'=>false,'publicly_queryable'=>false,'rewrite'=>false,'query_var'=>false,
            'menu_icon'=>'dashicons-book-alt','supports'=>array('title','page-attributes'),'capabilities'=>$caps,'map_meta_cap'=>false,
        ));
    }
    public static function id($v) { return is_scalar($v) && preg_match('/^[1-9][0-9]{0,9}$/D', (string)$v) ? (int)$v : 0; }
    private static function val($key) { return isset($_POST[$key]) && is_string($_POST[$key]) ? wp_unslash($_POST[$key]) : ''; }
    private static function meta($id, $key) { return get_post_meta($id, '_bfdn_' . $key, true); }
    public static function extension($id) {
        if (get_post_type($id) !== 'attachment') { return ''; }
        $path = get_attached_file($id, true);
        $ext = strtolower(pathinfo((string)$path, PATHINFO_EXTENSION));
        return in_array($ext, self::EXT, true) ? $ext : '';
    }
    public static function local_file($id) {
        if (!self::extension($id)) { return false; }
        $raw = get_attached_file($id, true);
        if (!$raw || strpos($raw, '://') !== false) { return false; }
        $uploads = wp_get_upload_dir();
        $base = realpath($uploads['basedir']); $path = realpath($raw);
        if (!$base || !$path || !is_file($path) || !is_readable($path)) { return false; }
        $prefix = trailingslashit(wp_normalize_path($base));
        if (strpos(wp_normalize_path($path), $prefix) !== 0) { return false; }
        $size = filesize($path);
        return $size !== false && $size > 0 && $size <= self::MAX_BYTES ? $path : false;
    }
    public static function mimes($m) {
        if (current_user_can('manage_options') && current_user_can('upload_files')) {
            $m['epub'] = 'application/epub+zip'; $m['md'] = 'text/plain';
            $m['pdf'] = 'application/pdf'; $m['txt'] = 'text/plain';
            $m['docx'] = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        }
        return $m;
    }
    public static function check_mime($data, $file, $filename, $mimes, $real_mime = false) {
        if (!current_user_can('manage_options') || !current_user_can('upload_files') || !is_file($file)) { return $data; }
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (!empty($data['ext'])) { return $data; }
        // WordPress may identify these formats as text/plain or application/zip.
        if ($ext === 'md' && isset($mimes['md']) && in_array($real_mime, array('text/plain','text/markdown','text/x-markdown','application/x-empty'), true)) {
            $data['ext'] = 'md'; $data['type'] = $mimes['md']; $data['proper_filename'] = false;
        }
        if ($ext === 'epub' && isset($mimes['epub']) && in_array($real_mime, array('application/zip','application/epub+zip','application/x-zip-compressed'), true)) {
            $h = fopen($file, 'rb'); $sig = $h ? fread($h, 4) : ''; if ($h) { fclose($h); }
            if ($sig === "PK\x03\x04") { $data['ext']='epub'; $data['type']=$mimes['epub']; $data['proper_filename']=false; }
        }
        return $data;
    }
    public static function boxes() { add_meta_box('bfdn-settings','本の設定',array(__CLASS__,'box'),self::TYPE,'normal','high'); }
    public static function box($post) {
        $id = self::id(self::meta($post->ID,'file')); $cover = self::id(self::meta($post->ID,'cover'));
        wp_nonce_field('bfdn_save_' . $post->ID, 'bfdn_nonce'); ?>
        <div class="bfdn-admin">
            <p>PDF・EPUB・DOCX・MD・TXTに対応します。1冊50MBまで（サーバーのアップロード上限が優先されます）。</p>
            <p><strong>一般公開する本を登録してください。</strong>メディアの元ファイルURLは、下書きに戻してもアクセスできる場合があります。</p>
            <input type="hidden" id="bfdn-file" name="bfdn_file" value="<?php echo esc_attr($id); ?>">
            <button type="button" class="button button-primary" id="bfdn-select-file">本のファイルを選択・アップロード</button>
            <p id="bfdn-selected" role="status"><?php echo esc_html($id ? wp_basename((string)get_attached_file($id,true)) : '未選択'); ?></p>
            <?php if ($id && !self::local_file($id)): ?><p>ファイルを読み込めません。削除・容量・サーバー内への保存状況を確認して選び直してください。</p><?php endif; ?>
            <p><label>著者（任意）<br><input class="widefat" name="bfdn_author" value="<?php echo esc_attr(self::meta($post->ID,'author')); ?>" maxlength="160"></label></p>
            <p><label>本の下に表示する説明文<br><textarea class="widefat" name="bfdn_description" rows="5" maxlength="3000"><?php echo esc_textarea(self::meta($post->ID,'description')); ?></textarea></label></p>
            <input type="hidden" id="bfdn-cover" name="bfdn_cover" value="<?php echo esc_attr($cover); ?>">
            <p><button type="button" class="button" id="bfdn-select-cover">表紙画像を選ぶ</button> <button type="button" class="button" id="bfdn-clear-cover">表紙を解除</button></p>
            <div id="bfdn-cover-preview"><?php if ($cover) { echo wp_get_attachment_image($cover,'thumbnail'); } ?></div>
            <p>表紙未設定の場合は、タイトル入りの表紙を自動表示します。</p>
            <p>固定ページの「ショートコード」ブロックに <code>[bookshelf_dn]</code> を入力すると公開済みの本が並びます。</p>
        </div><?php
    }
    public static function save($id, $post) {
        if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($id) || !current_user_can('manage_options') || !current_user_can('edit_post',$id) || !wp_verify_nonce(self::val('bfdn_nonce'),'bfdn_save_' . $id)) { return; }
        $file = self::id(self::val('bfdn_file')); $cover = self::id(self::val('bfdn_cover'));
        if (!$file || self::local_file($file)) { update_post_meta($id,'_bfdn_file',$file); }
        else { add_filter('redirect_post_location', function($url) { return add_query_arg('bfdn_file_error','1',$url); }); }
        update_post_meta($id,'_bfdn_cover', $cover && wp_attachment_is_image($cover) ? $cover : 0);
        update_post_meta($id,'_bfdn_author',wp_html_excerpt(sanitize_text_field(self::val('bfdn_author')),160,''));
        update_post_meta($id,'_bfdn_description',wp_html_excerpt(sanitize_textarea_field(self::val('bfdn_description')),3000,''));
    }
    public static function menu() { add_submenu_page('edit.php?post_type=' . self::TYPE,'一括登録・使い方','一括登録・使い方','manage_options','bfdn-import',array(__CLASS__,'bulk_page')); }
    public static function notice() {
        $screen=get_current_screen();
        if ($screen && $screen->post_type===self::TYPE && isset($_GET['bfdn_file_error']) && current_user_can('manage_options')) {
            echo '<div class="notice notice-error"><p>本のファイルを保存できませんでした。PDF・EPUB・DOCX・MD・TXT、50MB以内、メディアがサイト内に保存されていることを確認して選び直してください。以前のファイル設定は保持しています。</p></div>';
        }
    }
    public static function admin_assets() {
        $screen = get_current_screen();
        if (!$screen || $screen->post_type !== self::TYPE) { return; }
        wp_enqueue_media();
        wp_enqueue_script('bfdn-admin',plugins_url('assets/admin-dn.js',__FILE__),array('jquery','media-views'),self::VERSION,true);
        wp_localize_script('bfdn-admin','BFDNAdmin',array('url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('bfdn_import')));
        wp_enqueue_style('bfdn-admin',plugins_url('assets/admin-dn.css',__FILE__),array(),self::VERSION);
    }
    public static function bulk_page() {
        if (!current_user_can('manage_options')) { return; } ?>
        <div class="wrap bfdn-admin"><h1>本棚Flip dn ― 一括登録</h1>
        <p>ファイルをまとめてアップロードし、複数をチェックして選択できます。各ファイルのタイトル・著者・説明文を編集して登録してください。</p>
        <p><button type="button" class="button button-primary" id="bfdn-bulk-select">複数の本を選択・アップロード</button></p>
        <div id="bfdn-bulk-list"></div>
        <p><label>登録時の状態 <select id="bfdn-status"><option value="draft">下書き</option><option value="publish">公開</option></select></label>
        <button type="button" class="button button-primary" id="bfdn-bulk-save" disabled>選択した本を登録</button></p>
        <p id="bfdn-bulk-message" role="status" aria-live="polite"></p>
        <h2>本棚を表示する方法</h2><ol><li>本を登録し、公開します。</li><li>固定ページのショートコードブロックに <code>[bookshelf_dn]</code> を入力します。</li><li>固定ページを公開すると、本棚からFlip形式で読めます。</li></ol>
        <p><code>[bookshelf_dn title="私の本棚" columns="4"]</code>　列数は2〜6列。スマートフォンでは自動調整します。</p>
        <p><code>[bookshelf_dn ids="12,34,56"]</code>　指定した本の投稿IDだけを表示します。</p>
        <p>1回の一括登録は50冊まで。同じファイルの登録済みの本は上書きせず、編集リンクを表示します。</p>
        <p>PDFは元のページを表示します。EPUB・DOCX・MD・TXTは読みやすい横書きに組み直します。DRM付きEPUB・旧形式DOC・複雑なWordレイアウトの完全再現には対応していません。</p>
        <p>閲覧位置を読む人のブラウザー内に保存します。削除した本の元ファイルはメディアライブラリに残ります。</p></div><?php
    }
    public static function import_book() {
        if (!current_user_can('manage_options') || !current_user_can('upload_files')) { wp_send_json_error(array('message'=>'権限がありません。'),403); }
        check_ajax_referer('bfdn_import','nonce');
        $file = self::id(self::val('file'));
        if (!self::local_file($file)) { wp_send_json_error(array('message'=>'対応形式・50MB以内・サイト内保存のファイルを選んでください。'),400); }
        $existing = get_posts(array('post_type'=>self::TYPE,'post_status'=>array('publish','draft','pending','private','future'),'meta_key'=>'_bfdn_file','meta_value'=>$file,'numberposts'=>1,'fields'=>'ids'));
        if ($existing) { wp_send_json_success(array('id'=>$existing[0],'url'=>get_edit_post_link($existing[0],'raw'),'existing'=>true)); }
        $title = wp_html_excerpt(sanitize_text_field(self::val('title')),250,'');
        if ($title === '') { $title = pathinfo(get_attached_file($file,true), PATHINFO_FILENAME); }
        $id = wp_insert_post(array('post_type'=>self::TYPE,'post_title'=>$title,'post_status'=>self::val('status') === 'publish' ? 'publish' : 'draft','meta_input'=>array(
            '_bfdn_file'=>$file, '_bfdn_author'=>wp_html_excerpt(sanitize_text_field(self::val('author')),160,''),
            '_bfdn_description'=>wp_html_excerpt(sanitize_textarea_field(self::val('description')),3000,''),
        )),true);
        if (is_wp_error($id)) { wp_send_json_error(array('message'=>'登録できませんでした。'),500); }
        wp_send_json_success(array('id'=>$id,'url'=>get_edit_post_link($id,'raw'),'existing'=>false));
    }
    public static function columns($c) { $c['bfdn_format']='形式'; $c['bfdn_id']='本のID'; return $c; }
    public static function column($key,$id) { if ($key==='bfdn_format') { echo esc_html(strtoupper(self::extension(self::id(self::meta($id,'file'))))); } if ($key==='bfdn_id') { echo (int)$id; } }
    public static function serve() {
        $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
        if (!in_array($method,array('GET','HEAD'),true)) { header('Allow: GET, HEAD'); wp_die('Method not allowed','',array('response'=>405)); }
        $id = self::id(isset($_GET['id']) ? $_GET['id'] : 0); $post=get_post($id);
        if (!$post || $post->post_type!==self::TYPE || $post->post_status!=='publish' || post_password_required($post)) { wp_die('公開されている本が見つかりません。','',array('response'=>404)); }
        $file=self::id(self::meta($id,'file')); $path=self::local_file($file);
        if (!$path) { wp_die('元ファイルが見つからないか、容量上限を超えています。','',array('response'=>404)); }
        $handle=fopen($path,'rb'); if (!$handle) { wp_die('ファイルを開けません。','',array('response'=>500)); }
        while (ob_get_level()) { if (!@ob_end_clean()) { break; } }
        if (headers_sent()) { fclose($handle); exit; }
        @ini_set('zlib.output_compression','0');
        nocache_headers(); header('Cache-Control: no-store, no-transform');
        header('Content-Type: application/octet-stream'); header('X-Content-Type-Options: nosniff');
        header('Content-Length: '.filesize($path));
        header("Content-Disposition: attachment; filename=\"book-dn.".self::extension($file)."\"; filename*=UTF-8''".rawurlencode(wp_basename($path)));
        if ($method==='GET') { while (!feof($handle) && !connection_aborted()) { $chunk=fread($handle,1048576); if ($chunk===false) { break; } echo $chunk; flush(); } }
        fclose($handle); exit;
    }
    public static function shortcode($atts) {
        $atts=shortcode_atts(array('title'=>'私の本棚','columns'=>'4','ids'=>''),$atts,'bookshelf_dn');
        $columns=max(2,min(6,(int)$atts['columns']));
        $args=array('post_type'=>self::TYPE,'post_status'=>'publish','posts_per_page'=>-1,'orderby'=>array('menu_order'=>'ASC','title'=>'ASC'),'has_password'=>false,'no_found_rows'=>true);
        if ($atts['ids']!=='') { $ids=array_filter(array_map('absint',explode(',',$atts['ids']))); if (!$ids) { return ''; } $args['post__in']=$ids; $args['orderby']='post__in'; }
        $query=new WP_Query($args);
        wp_enqueue_style('bfdn-shelf',plugins_url('assets/bookshelf-dn.css',__FILE__),array(),self::VERSION);
        wp_enqueue_script('bfdn-core',plugins_url('assets/core-dn.js',__FILE__),array(),self::VERSION,true);
        wp_enqueue_script('bfdn-reader',plugins_url('assets/reader-dn.js',__FILE__),array('bfdn-core'),self::VERSION,true);
        $instance=wp_unique_id('bfdn-');
        ob_start(); ?>
        <section class="bfdn-shelf" data-vendor="<?php echo esc_url(plugins_url('assets/vendor/',__FILE__)); ?>" style="--bfdn-columns:<?php echo (int)$columns; ?>" aria-label="<?php echo esc_attr($atts['title']); ?>">
        <header class="bfdn-shelf-header"><span class="bfdn-eyebrow">BOOKSHELF / dn</span><h2><?php echo esc_html($atts['title']); ?></h2><p>一冊を開いて、ページをめくる時間。</p></header>
        <div class="bfdn-filters"><label>本を探す<input type="search" class="bfdn-search" placeholder="タイトル・著者・説明文" aria-label="本を探す"></label><label>ファイル形式<select class="bfdn-format"><option value="">すべての形式</option><?php foreach(self::EXT as $ext) { echo '<option value="'.esc_attr($ext).'">'.esc_html(strtoupper($ext)).'</option>'; } ?></select></label><span class="bfdn-count" role="status"></span></div>
        <div class="bfdn-grid">
        <?php foreach($query->posts as $book):
            $id=$book->ID; $file=self::id(self::meta($id,'file')); $ext=self::extension($file); if (!$ext) { continue; }
            $author=self::meta($id,'author'); $description=self::meta($id,'description');
            $cover=wp_get_attachment_image_url(self::id(self::meta($id,'cover')),'medium_large');
            $url=add_query_arg(array('action'=>'bfdn_file','id'=>$id),admin_url('admin-post.php'));
            $config=array('id'=>$id,'title'=>get_the_title($book),'type'=>$ext,'url'=>$url,'modified'=>$book->post_modified_gmt);
        ?>
        <article class="bfdn-card" data-type="<?php echo esc_attr($ext); ?>" data-search="<?php echo esc_attr(get_the_title($book).' '.$author.' '.$description); ?>">
        <button type="button" class="bfdn-open" data-book="<?php echo esc_attr(wp_json_encode($config)); ?>" aria-label="<?php echo esc_attr(get_the_title($book).'を読む'); ?>">
        <span class="bfdn-cover bfdn-color-<?php echo (int)($id%6); ?>"><?php if($cover): ?><img src="<?php echo esc_url($cover); ?>" alt="" loading="lazy"><?php else: ?><span class="bfdn-cover-line"></span><span class="bfdn-cover-title"><?php echo esc_html(get_the_title($book)); ?></span><span class="bfdn-cover-author"><?php echo esc_html($author ?: 'BOOKSHELF dn'); ?></span><?php endif; ?><span class="bfdn-format-badge"><?php echo esc_html(strtoupper($ext)); ?></span></span>
        <span class="bfdn-card-title"><?php echo esc_html(get_the_title($book)); ?></span><span class="bfdn-read-label">開いて読む <span aria-hidden="true">↗</span></span></button>
        <?php if($author): ?><p class="bfdn-author"><?php echo esc_html($author); ?></p><?php endif; ?>
        <?php if($description): ?><p class="bfdn-description"><?php echo nl2br(esc_html($description)); ?></p><?php endif; ?>
        </article><?php endforeach; ?></div><p class="bfdn-empty" hidden>該当する本はありません。</p>
        <noscript>Flip閲覧にはJavaScriptを有効にしてください。</noscript></section><?php
        return ob_get_clean();
    }
}
Bookshelf_Flip_Dn::boot();
