/* Book parsers. Uploaded markup is always sanitized before joining the page DOM. */
(function () {
  'use strict';
  const MAX=50*1024*1024, TEXT_MAX=4*1024*1024, cache=new Map();
  function dependency(base, path, globalName) {
    const url=new URL(path,base).href;
    if(!cache.has(url)) cache.set(url,new Promise((resolve,reject)=>{
      const previous=window[globalName], script=document.createElement('script'); script.src=url;
      script.onload=()=>{const result=window[globalName]; if(previous!==undefined) window[globalName]=previous; else delete window[globalName]; result?resolve(result):reject(new Error('閲覧ライブラリを読み込めません。'));};
      script.onerror=()=>{cache.delete(url);reject(new Error('閲覧ライブラリを読み込めません。キャッシュを削除して再度お試しください。'));};
      document.head.appendChild(script);
    }));
    return cache.get(url);
  }
  async function fetchBytes(url,signal) {
    const response=await fetch(url,{credentials:'same-origin',signal,cache:'no-store'});
    if(!response.ok) throw new Error('本のファイルを取得できません（HTTP '+response.status+'）。公開状態と元ファイルを確認してください。');
    if(Number(response.headers.get('content-length'))>MAX) throw new Error('50MBを超える本は開けません。');
    if(!response.body?.getReader){const b=await response.arrayBuffer();if(b.byteLength>MAX)throw new Error('50MB上限を超えています。');return b;}
    const reader=response.body.getReader(),chunks=[];let size=0;
    try {for(;;){const r=await reader.read();if(r.done)break;size+=r.value.length;if(size>MAX){await reader.cancel();throw new Error('50MB上限を超えています。');}chunks.push(r.value);}}
    finally {reader.releaseLock();}
    if(!size) throw new Error('ファイルが空です。');
    const bytes=new Uint8Array(size); let at=0;for(const c of chunks){bytes.set(c,at);at+=c.length;}return bytes.buffer;
  }
  function decode(bytes) {
    if(bytes.byteLength>TEXT_MAX) throw new Error('テキストは4MB以内に分割してください。');
    const a=new Uint8Array(bytes);
    if(a[0]===0xff&&a[1]===0xfe)return new TextDecoder('utf-16le').decode(bytes);
    if(a[0]===0xfe&&a[1]===0xff)return new TextDecoder('utf-16be').decode(bytes);
    try{return new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch(_){return new TextDecoder('shift_jis').decode(bytes);}
  }
  function preflightZip(buffer) {
    const d=new DataView(buffer); let end=-1;
    for(let n=d.byteLength-22;n>=Math.max(0,d.byteLength-65557);n--){if(d.getUint32(n,true)===0x06054b50){end=n;break;}}
    if(end<0)throw new Error('ZIP構造を読み込めません。元のEPUB / DOCXを確認してください。');
    const count=d.getUint16(end+10,true),offset=d.getUint32(end+16,true);
    if(d.getUint16(end+4,true)!==0||d.getUint16(end+6,true)!==0||count>5000||count===65535)throw new Error('分割ZIPや大規模な書籍には対応していません。');
    let pos=offset,total=0;
    for(let i=0;i<count;i++) {
      if(pos+46>end||d.getUint32(pos,true)!==0x02014b50)throw new Error('書籍のZIP構造が不正です。');
      const size=d.getUint32(pos+24,true);total+=size;
      if(size>16*1024*1024||total>64*1024*1024)throw new Error('展開後の容量が大きすぎます。画像を圧縮するか本を分割してください。');
      if(d.getUint16(pos+8,true)&1)throw new Error('暗号化された書籍には対応していません。');
      pos+=46+d.getUint16(pos+28,true)+d.getUint16(pos+30,true)+d.getUint16(pos+32,true);
    }
    if(pos>end)throw new Error('ZIP構造が不正です。');
    return total;
  }
  const tags=['p','br','hr','h1','h2','h3','h4','h5','h6','strong','em','b','i','u','s','small','sub','sup','blockquote','pre','code','ul','ol','li','dl','dt','dd','table','thead','tbody','tr','td','th','caption','div','span','section','article','a','img','figure','figcaption','ruby','rt','rp'];
  async function clean(html,base) {
    if(html.length>12*1024*1024)throw new Error('本文が大きすぎます。本を分割してください。');
    const purifier=await dependency(base,'dompurify/dist/purify.min.js','DOMPurify');
    const fragment=purifier.sanitize(html,{RETURN_DOM_FRAGMENT:true,ALLOWED_TAGS:tags,ALLOWED_ATTR:['href','src','alt','title','colspan','rowspan'],ALLOW_DATA_ATTR:false,ALLOW_ARIA_ATTR:false,FORBID_TAGS:['style','script','svg','math','iframe','form','input','video','audio','object','embed']});
    if(fragment.querySelectorAll('*').length>30000)throw new Error('本文が複雑すぎます。本を分割してください。');
    for(const img of fragment.querySelectorAll('img')) {
      if(!/^data:image\/(png|jpe?g|gif|webp);base64,[a-z0-9+/=\s]+$/i.test(img.getAttribute('src')||'')) {img.replaceWith(document.createTextNode(img.getAttribute('alt')||''));}
      else {img.setAttribute('decoding','async');}
    }
    for(const link of fragment.querySelectorAll('a')) {const href=link.getAttribute('href')||'';if(/^https?:\/\//i.test(href)){link.setAttribute('target','_blank');link.setAttribute('rel','noopener noreferrer');}else{link.removeAttribute('href');}}
    const wrap=document.createElement('div');wrap.append(fragment);return wrap.innerHTML;
  }
  function xml(text) {const doc=new DOMParser().parseFromString(text,'application/xml');if(doc.getElementsByTagName('parsererror').length)throw new Error('EPUBの構成情報を読み込めません。');return doc;}
  function elements(doc,name){return Array.from(doc.getElementsByTagNameNS('*',name));}
  function resolvePath(base,href) {
    if(!href||/^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(href))return null;
    try{const u=new URL(href,'https://book.invalid/'+base);return decodeURIComponent(u.pathname.slice(1));}catch(_){return null;}
  }
  async function epub(buffer,base) {
    preflightZip(buffer);
    const JSZip=await dependency(base,'jszip/dist/jszip.min.js','JSZip'); const zip=await JSZip.loadAsync(buffer);
    const container=zip.file('META-INF/container.xml');if(!container)throw new Error('EPUBのcontainer.xmlが見つかりません。');
    if(zip.file('META-INF/encryption.xml')) {const enc=xml(await zip.file('META-INF/encryption.xml').async('string'));const alg=elements(enc,'EncryptionMethod').map(e=>e.getAttribute('Algorithm')||'');if(alg.some(a=>!['http://www.idpf.org/2008/embedding','http://ns.adobe.com/pdf/enc#RC'].includes(a)))throw new Error('DRM付きEPUBには対応していません。');}
    const packagePath=elements(xml(await container.async('string')),'rootfile')[0]?.getAttribute('full-path');
    const packageFile=packagePath&&zip.file(packagePath);if(!packageFile)throw new Error('EPUBのパッケージが見つかりません。');
    const pack=xml(await packageFile.async('string')),manifest=new Map(elements(pack,'item').map(e=>[e.getAttribute('id'),{href:e.getAttribute('href'),type:e.getAttribute('media-type')}]));
    const spine=elements(pack,'itemref').filter(e=>e.getAttribute('linear')!=='no');if(spine.length>600)throw new Error('章が多すぎます。600章以内に分割してください。');
    const mimeByPath=new Map();manifest.forEach(item=>mimeByPath.set(resolvePath(packagePath,item.href),item.type));
    const images=new Map();let html='',textBytes=0,imageBytes=0;
    for(const ref of spine) {
      const item=manifest.get(ref.getAttribute('idref'));if(!item)continue;
      const path=resolvePath(packagePath,item.href),file=path&&zip.file(path);if(!file)throw new Error('EPUBの本文ファイルが見つかりません。');
      const source=await file.async('string');textBytes+=source.length;if(textBytes>TEXT_MAX)throw new Error('EPUB本文が4MBを超えています。本を分割してください。');
      // DOMParser creates an inert document; disallow all remote resources before insertion.
      const doc=new DOMParser().parseFromString(source,'application/xhtml+xml');
      if(doc.querySelector('parsererror'))throw new Error('EPUB本文のXHTML形式が不正です。');
      for(const img of doc.querySelectorAll('img')) {
        const src=resolvePath(path,img.getAttribute('src')),mime=mimeByPath.get(src),entry=src&&zip.file(src);
        if(!entry||!/^image\/(png|jpe?g|gif|webp)$/.test(mime||'')){img.removeAttribute('src');continue;}
        if(!images.has(src)){const data=await entry.async('uint8array');imageBytes+=data.byteLength;if(imageBytes>12*1024*1024)throw new Error('EPUB内の画像を12MB以内に圧縮してください。');images.set(src,'data:'+mime+';base64,'+await entry.async('base64'));}
        img.setAttribute('src',images.get(src));
      }
      html+='<section>'+new XMLSerializer().serializeToString(doc.documentElement)+'</section>';
    }
    if(!html)throw new Error('EPUBに表示できる本文がありません。');return clean(html,base);
  }
  async function parse(buffer,type,base) {
    if(buffer.byteLength>MAX)throw new Error('50MB上限を超えています。');
    if(type==='epub')return epub(buffer,base);
    if(type==='docx') {
      preflightZip(buffer);const mammoth=await dependency(base,'mammoth/mammoth.browser.min.js','mammoth');
      const result=await mammoth.convertToHtml({arrayBuffer:buffer},{externalFileAccess:false,ignoreEmptyParagraphs:false});return clean(result.value,base);
    }
    if(type==='md'){const marked=await dependency(base,'marked/lib/marked.umd.js','marked');return clean(marked.parse(decode(buffer),{gfm:true,breaks:true}),base);}
    if(type==='txt'){const node=document.createElement('div');decode(buffer).split(/\n\s*\n/).forEach(line=>{const p=document.createElement('p');p.textContent=line;node.append(p);});return clean(node.innerHTML,base);}
    throw new Error('このファイル形式には対応していません。');
  }
  window.BFDNCore={fetchBytes,decode,preflightZip,clean,resolvePath,parse,dependency};
})();
