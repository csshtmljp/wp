(function () {
  'use strict';
  let active=null;
  const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
  const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  class Reader {
    constructor(book,base,trigger) {
      this.book=book;this.base=base;this.trigger=trigger;this.controller=new AbortController();this.closed=false;this.busy=false;this.index=0;this.total=1;this.turns=0;this.pageCount=1;this.font=18;this.mode='auto';this.html='';this.pdf=null;this.loadingTask=null;
      this.key='bfdn:'+location.origin+':'+book.id+':'+book.modified;
      try{this.saved=JSON.parse(localStorage.getItem(this.key)||'null');}catch(_){}
      this.dialog=el('dialog','bfdn-reader');this.dialog.setAttribute('aria-label',book.title+' ― 閲覧画面');
      this.dialog.innerHTML='<header class="bfdn-toolbar"><div class="bfdn-book-heading"><span class="bfdn-eyebrow">FLIP READER / dn</span><h2></h2></div><button type="button" class="bfdn-close" aria-label="本を閉じる">✕</button></header><div class="bfdn-options"><label>表示 <select class="bfdn-mode"><option value="auto">自動</option><option value="1">1ページ</option><option value="2">見開き</option></select></label><label class="bfdn-font-label">文字 <select class="bfdn-font"><option value="16">小</option><option value="18" selected>標準</option><option value="21">大</option><option value="24">特大</option></select></label><button class="bfdn-fullscreen" type="button">全画面</button><a class="bfdn-original" download>元ファイルを保存</a></div><div class="bfdn-stage"><div class="bfdn-spread"></div><p class="bfdn-loading" role="status" aria-live="polite">本を開いています…</p></div><footer class="bfdn-controls"><button type="button" class="bfdn-prev" aria-label="前のページ">← 前へ</button><label class="bfdn-page-jump"><input type="number" min="1" value="1" aria-label="移動するページ番号"><span class="bfdn-total">/ 1</span></label><button type="button" class="bfdn-next" aria-label="次のページ">次へ →</button></footer><p class="bfdn-hint" aria-live="polite">左右にスワイプ、または矢印ボタンでページをめくれます。</p>';
      const q=s=>this.dialog.querySelector(s);this.q=q;this.stage=q('.bfdn-stage');this.spread=q('.bfdn-spread');this.loading=q('.bfdn-loading');
      q('h2').textContent=book.title;q('.bfdn-original').href=book.url;
      document.body.append(this.dialog);this.oldOverflow=document.body.style.overflow;document.body.style.overflow='hidden';
      if(this.dialog.showModal)this.dialog.showModal();else this.dialog.setAttribute('open','');
      q('.bfdn-close').focus();q('.bfdn-close').onclick=()=>this.close();this.dialog.addEventListener('cancel',e=>{e.preventDefault();this.close();});
      q('.bfdn-next').onclick=()=>this.navigate(this.pageCount);q('.bfdn-prev').onclick=()=>this.navigate(-this.pageCount);
      q('.bfdn-page-jump input').onchange=e=>{const n=Number(e.target.value);if(!Number.isInteger(n)){this.update();return;}this.navigate(Math.max(0,Math.min(this.total-1,n-1))-this.index);};
      q('.bfdn-font').onchange=e=>{this.font=Number(e.target.value);this.layout();};
      q('.bfdn-mode').onchange=e=>{this.mode=e.target.value;this.layout();};
      q('.bfdn-fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else if(this.dialog.requestFullscreen)await this.dialog.requestFullscreen();else this.hint('このブラウザーでは全画面操作を利用できません。');}catch(_){this.hint('全画面表示を開始できませんでした。');}};
      this.dialog.addEventListener('keydown',e=>this.keyboard(e));
      let start=null;
      this.stage.addEventListener('pointerdown',e=>{if(e.isPrimary&&e.button===0&&!e.target.closest('a'))start={x:e.clientX,y:e.clientY};});
      this.stage.addEventListener('pointerup',e=>{if(!start)return;const dx=e.clientX-start.x,dy=e.clientY-start.y;start=null;if(Math.abs(dx)>55&&Math.abs(dx)>Math.abs(dy)*1.7){const selection=window.getSelection();if(selection&&!selection.isCollapsed)return;this.navigate(dx<0?this.pageCount:-this.pageCount);}});
      this.stage.addEventListener('pointercancel',()=>{start=null;});
      this.resize=()=>{clearTimeout(this.resizeTimer);this.resizeTimer=setTimeout(()=>this.layout(),180);};
      window.addEventListener('resize',this.resize);
      this.dialog.addEventListener('fullscreenchange',this.resize);
    }
    hint(message){this.q('.bfdn-hint').textContent=message;}
    status(message){this.loading.textContent=message;this.loading.hidden=!message;}
    async open() {
      this.busy=true;this.update();
      try {
        const bytes=await BFDNCore.fetchBytes(this.book.url,this.controller.signal);if(this.closed)return;
        if(this.book.type==='pdf') {
          const root=new URL('pdfjs-dist/',this.base).href;
          const pdfjs=await import(root+'legacy/build/pdf-dn.js');if(this.closed)return;
          pdfjs.GlobalWorkerOptions.workerSrc=root+'legacy/build/pdf.worker-dn.js';
          this.loadingTask=pdfjs.getDocument({data:bytes,cMapUrl:root+'cmaps/',cMapPacked:true,standardFontDataUrl:root+'standard_fonts/',wasmUrl:root+'wasm/',iccUrl:root+'iccs/',isEvalSupported:false,enableXfa:false});
          this.loadingTask.onPassword=()=>{this.status('パスワード付きPDFは未対応です。保護を解除したPDFを登録してください。');this.loadingTask.destroy();};
          this.pdf=await this.loadingTask.promise;this.total=this.pdf.numPages;this.q('.bfdn-font-label').hidden=true;
        } else {this.html=await BFDNCore.parse(bytes,this.book.type,this.base);}
        if(this.closed)return;this.ready=true;this.busy=false;await this.layout(true);
      } catch(e){if(!this.closed&&e.name!=='AbortError'){this.status(e.message||'本を開けませんでした。');this.hint('本を閉じて再度お試しください。');}}
      finally {if(!this.closed){this.busy=false;this.update();}}
    }
    dimensions() {
      const width=Math.max(210,this.stage.clientWidth-24),height=Math.max(160,this.stage.clientHeight-24);
      this.pageCount=(this.mode==='2'&&width>=540)||(this.mode==='auto'&&width>=850)?2:1;
      this.width=Math.floor(Math.min(width/this.pageCount,620));this.height=Math.floor(height);
      this.innerWidth=this.width-48;this.innerHeight=this.height-58;
      this.spread.style.width=(this.width*this.pageCount)+'px';this.spread.style.height=this.height+'px';
      this.spread.style.setProperty('--bfdn-page-width',this.width+'px');this.spread.style.setProperty('--bfdn-page-height',this.height+'px');
      this.spread.style.setProperty('--bfdn-inner-width',this.innerWidth+'px');this.spread.style.setProperty('--bfdn-inner-height',this.innerHeight+'px');
      this.spread.style.setProperty('--bfdn-font',this.font+'px');this.spread.dataset.pages=String(this.pageCount);
    }
    textPage(n) {
      const page=el('div','bfdn-page'),clip=el('div','bfdn-clip'),flow=el('div','bfdn-flow');
      flow.innerHTML=this.html;flow.style.transform='translateX(-'+n*this.innerWidth+'px)';clip.append(flow);page.append(clip);
      const number=el('span','bfdn-page-number',String(n+1));page.append(number);return page;
    }
    async layout(initial=false) {
      if(!this.ready||this.closed)return;
      if(this.busy){this.layoutPending=true;return;}
      this.busy=true;this.update();this.status('ページを整えています…');
      let ratio=this.total>1?this.index/(this.total-1):0;
      if(initial&&Number.isFinite(this.saved?.ratio))ratio=Math.max(0,Math.min(1,this.saved.ratio));
      try {
        this.dimensions();
        if(!this.pdf) {
          const measure=this.textPage(0);measure.classList.add('bfdn-measure');this.spread.replaceChildren(measure);
          await Promise.all(Array.from(measure.querySelectorAll('img')).map(img=>img.decode?img.decode().catch(()=>{}):Promise.resolve()));
          if(document.fonts?.ready)await document.fonts.ready;if(this.closed)return;
          const flow=measure.querySelector('.bfdn-flow');this.total=Math.max(1,Math.ceil((flow.scrollWidth-1)/this.innerWidth));
        }
        if(this.pdf&&initial&&Number.isInteger(this.saved?.page))this.index=Math.max(0,Math.min(this.total-1,this.saved.page));
        else if(!this.pdf)this.index=Math.round(ratio*(this.total-1));
        this.index=Math.max(0,Math.min(this.total-1,this.index));await this.render();this.status('');this.remember();
      } catch(e){if(!this.closed)this.status(e.message||'ページを表示できません。');}
      finally {this.busy=false;this.update();if(this.layoutPending&&!this.closed){this.layoutPending=false;this.layout();}}
    }
    async pdfPage(n) {
      const paper=el('div','bfdn-page bfdn-pdf-page');if(n>=this.total)return paper;
      const page=await this.pdf.getPage(n+1);if(this.closed)return paper;
      const raw=page.getViewport({scale:1});const scale=Math.min((this.width-20)/raw.width,(this.height-36)/raw.height),viewport=page.getViewport({scale});
      const canvas=el('canvas');const dpr=Math.min(window.devicePixelRatio||1,2);canvas.width=Math.ceil(viewport.width*dpr);canvas.height=Math.ceil(viewport.height*dpr);canvas.style.width=viewport.width+'px';canvas.style.height=viewport.height+'px';canvas.setAttribute('role','img');canvas.setAttribute('aria-label',this.book.title+' '+(n+1)+'ページ');paper.append(canvas);
      await page.render({canvasContext:canvas.getContext('2d'),viewport,transform:dpr===1?null:[dpr,0,0,dpr,0,0]}).promise;
      paper.append(el('span','bfdn-page-number',String(n+1)));return paper;
    }
    async render() {
      const nodes=[];
      for(let i=0;i<this.pageCount;i++){const n=this.index+i;nodes.push(n>=this.total?el('div','bfdn-page bfdn-blank'):(this.pdf?await this.pdfPage(n):this.textPage(n)));}
      if(!this.closed)this.spread.replaceChildren(...nodes);
    }
    async navigate(delta) {
      if(this.busy||!this.ready||this.closed||!delta)return;
      const next=Math.max(0,Math.min(this.total-1,this.index+delta));if(next===this.index){this.update();return;}
      this.busy=true;this.update();const oldIndex=this.index;let overlay=null;
      try {
        const source=delta>0?this.spread.lastElementChild:this.spread.firstElementChild;
        if(source&&!matchMedia('(prefers-reduced-motion: reduce)').matches) {
          overlay=source.cloneNode(true);overlay.classList.add('bfdn-turn');overlay.setAttribute('aria-hidden','true');overlay.inert=true;
          const before=source.querySelector('canvas'),after=overlay.querySelector('canvas');if(before&&after){after.width=before.width;after.height=before.height;after.getContext('2d').drawImage(before,0,0);}
          overlay.style.left=(delta>0?(this.pageCount-1)*this.width:0)+'px';
        }
        this.index=next;await this.render();if(this.closed)return;
        if(overlay){overlay.style.transformOrigin=delta>0?'left center':'right center';this.spread.append(overlay);if(overlay.animate){const animation=overlay.animate([{transform:'rotateY(0deg)',filter:'brightness(1)'},{transform:'rotateY('+(delta>0?'-':'')+'90deg)',filter:'brightness(.65)'}],{duration:320,easing:'ease-in',fill:'forwards'});await animation.finished.catch(()=>{});}else await pause(80);overlay.remove();}
        this.turns++;this.remember();
      }catch(e){this.index=oldIndex;if(!this.closed)this.status(e.message||'ページをめくれませんでした。');}
      finally{if(overlay)overlay.remove();this.busy=false;this.update();if(this.layoutPending&&!this.closed){this.layoutPending=false;this.layout();}}
    }
    update() {
      if(this.closed)return;
      this.q('.bfdn-prev').disabled=this.busy||!this.ready||this.index===0;
      this.q('.bfdn-next').disabled=this.busy||!this.ready||this.index+this.pageCount>=this.total;
      const jump=this.q('.bfdn-page-jump input');jump.value=this.index+1;jump.max=this.total;jump.disabled=this.busy||!this.ready;
      this.q('.bfdn-total').textContent='/ '+this.total;this.q('.bfdn-font').disabled=this.busy;this.q('.bfdn-mode').disabled=this.busy;
      if(this.ready)this.hint((this.index+1)+(this.pageCount===2&&this.index+1<this.total?'–'+Math.min(this.total,this.index+2):'')+' / '+this.total+'ページ　左右スワイプ・矢印キーでめくれます。');
    }
    remember(){try{localStorage.setItem(this.key,JSON.stringify({page:this.index,ratio:this.total>1?this.index/(this.total-1):0}));}catch(_) {}}
    keyboard(e) {
      if(e.key==='Tab'){
        const nodes=Array.from(this.dialog.querySelectorAll('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled)')).filter(n=>n.getClientRects().length);
        if(!nodes.length)return;const first=nodes[0],last=nodes[nodes.length-1];
        if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
      }
      if(e.target.closest('input,select,textarea,a'))return;
      if(e.key==='ArrowRight'){e.preventDefault();this.navigate(this.pageCount);}
      if(e.key==='ArrowLeft'){e.preventDefault();this.navigate(-this.pageCount);}
      if(e.key==='Escape'){e.preventDefault();this.close();}
    }
    close() {
      if(this.closed)return;this.closed=true;this.controller.abort();clearTimeout(this.resizeTimer);window.removeEventListener('resize',this.resize);
      if(this.loadingTask)this.loadingTask.destroy().catch(()=>{});
      if(this.dialog.close)this.dialog.close();this.dialog.remove();document.body.style.overflow=this.oldOverflow;this.trigger.focus();if(active===this)active=null;
    }
  }
  document.querySelectorAll('.bfdn-shelf').forEach(shelf=>{
    const cards=Array.from(shelf.querySelectorAll('.bfdn-card')),search=shelf.querySelector('.bfdn-search'),format=shelf.querySelector('.bfdn-format');
    const filter=()=>{let count=0;const needle=search.value.trim().toLocaleLowerCase();cards.forEach(card=>{const show=(!format.value||card.dataset.type===format.value)&&card.dataset.search.toLocaleLowerCase().includes(needle);card.hidden=!show;if(show)count++;});shelf.querySelector('.bfdn-count').textContent=count+'冊';shelf.querySelector('.bfdn-empty').hidden=count!==0;};
    search.addEventListener('input',filter);format.addEventListener('change',filter);filter();
    shelf.addEventListener('click',e=>{const button=e.target.closest('.bfdn-open');if(!button)return;try{const book=JSON.parse(button.dataset.book);if(active)active.close();active=new Reader(book,shelf.dataset.vendor,button);active.open();}catch(_){window.alert('本の設定を読み込めませんでした。');}});
  });
})();
