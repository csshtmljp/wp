(function ($) {
  'use strict';
  const valid = /\.(pdf|epub|docx|md|txt)$/i;
  function pick(options, callback) {
    const frame = wp.media({title:options.image ? '表紙を選択' : '本を選択（PDF / EPUB / DOCX / MD / TXT）', button:{text:'選択したファイルを使う'}, multiple:options.multiple ? 'toggle' : false, ...(options.image ? {library:{type:'image'}} : {})});
    frame.on('select', function () { callback(frame.state().get('selection').toJSON()); });
    frame.open();
  }
  $('#bfdn-select-file').on('click', function () {
    pick({}, items => { const f=items[0]; if (!f || !valid.test(f.filename || f.url || '') || f.filesizeInBytes>52428800) { window.alert('PDF・EPUB・DOCX・MD・TXT（50MB以内）を選択してください。'); return; }
      $('#bfdn-file').val(f.id); $('#bfdn-selected').text(f.filename || f.title);
    });
  });
  $('#bfdn-select-cover').on('click', function () { pick({image:true}, items => { const f=items[0]; if (!f) return; $('#bfdn-cover').val(f.id); $('#bfdn-cover-preview').empty().append($('<img>').attr({src:(f.sizes?.thumbnail?.url || f.url),alt:''})); }); });
  $('#bfdn-clear-cover').on('click',function () { $('#bfdn-cover').val(''); $('#bfdn-cover-preview').empty(); });
  const list=$('#bfdn-bulk-list'), message=$('#bfdn-bulk-message'); let saving=false;
  $('#bfdn-bulk-select').on('click', function () {
    if (saving) return;
    pick({multiple:true}, items => {
      let invalid=0;
      items.forEach(f=>{
        if (!valid.test(f.filename || f.url || '') || f.filesizeInBytes>52428800) { invalid++; return; }
        if (list.find('[data-id="'+Number(f.id)+'"]').length) return;
        if (list.children().length>=50) { invalid++; return; }
        const row=$('<section class="bfdn-import-row">').attr('data-id',Number(f.id));
        row.append($('<strong>').text(f.filename || f.title));
        row.append($('<label>タイトル</label>').append($('<input class="widefat bfdn-import-title" maxlength="250">').val(f.title || (f.filename || '').replace(/\.[^.]+$/,''))));
        row.append($('<label>著者</label>').append($('<input class="widefat bfdn-import-author" maxlength="160">')));
        row.append($('<label>説明文（本の下に表示）</label>').append($('<textarea class="widefat bfdn-import-description" rows="3" maxlength="3000">')));
        row.append($('<button type="button" class="button bfdn-remove">選択から外す</button>').on('click',()=>{if(!saving){row.remove();$('#bfdn-bulk-save').prop('disabled',!list.children().length);}}));
        row.append($('<p class="bfdn-row-result" role="status">')); list.append(row);
      });
      message.text(invalid ? invalid+'件は形式・容量・50冊上限のため追加できませんでした。' : '内容を確認して登録してください。');
      $('#bfdn-bulk-save').prop('disabled',!list.children().length);
    });
  });
  $('#bfdn-bulk-save').on('click',async function () {
    if(saving) return; saving=true; $('#bfdn-bulk-select,#bfdn-bulk-save,#bfdn-status').prop('disabled',true);
    list.find('input,textarea,button').prop('disabled',true); let ok=0,failed=0;
    for(const el of list.children().toArray()) {
      const row=$(el); if(row.data('done')) {ok++;continue;}
      row.find('.bfdn-row-result').text('登録中…');
      try {
        const response=await $.post(BFDNAdmin.url,{action:'bfdn_import',nonce:BFDNAdmin.nonce,file:row.attr('data-id'),title:row.find('.bfdn-import-title').val(),author:row.find('.bfdn-import-author').val(),description:row.find('.bfdn-import-description').val(),status:$('#bfdn-status').val()});
        if(!response.success) throw new Error(response.data?.message || '登録できませんでした。');
        row.data('done',true); ok++;
        row.find('.bfdn-row-result').empty().append(document.createTextNode(response.data.existing?'登録済みです（内容は変更していません）。 ':'登録しました。 ')).append($('<a>').attr({href:response.data.url,target:'_blank',rel:'noopener'}).text('この本を編集'));
      } catch(e) { failed++; row.find('.bfdn-row-result').text(e.responseJSON?.data?.message || e.message || '通信エラーです。再登録をお試しください。'); }
      message.text(ok+'冊登録済み / '+failed+'冊エラー');
    }
    saving=false; $('#bfdn-bulk-select,#bfdn-status').prop('disabled',false); $('#bfdn-bulk-save').prop('disabled',failed===0);
    list.children().each(function(){if(!$(this).data('done')) $(this).find('input,textarea,button').prop('disabled',false);});
  });
})(jQuery);
