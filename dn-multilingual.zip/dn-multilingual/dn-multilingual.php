<?php
/**
 * Plugin Name: DN Multilingual — 記事・固定ページの多言語対応
 * Description: 投稿・固定ページの翻訳を関連付け、言語切り替え・翻訳用下書き・言語別一覧・hreflangを提供します。外部API不要。
 * Version: 1.0.0
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Author: DN
 * License: GPL-2.0-or-later
 * Text Domain: dn-multilingual
 */
if (!defined('ABSPATH')) { exit; }
define('DNML_VERSION', '1.0.0');
define('DNML_FILE', __FILE__);
require_once __DIR__ . '/includes/class-dnml-core.php';
require_once __DIR__ . '/includes/class-dnml-admin.php';
require_once __DIR__ . '/includes/class-dnml-front.php';
register_activation_hook(__FILE__, array('DNML_Core', 'activate'));
add_action('plugins_loaded', function () {
    DNML_Core::boot();
    new DNML_Admin();
    new DNML_Front();
});
