<?php
/** Intentional preservation: uninstalling must not destroy editorial work. */
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// Posts, translations, settings and relationships are retained for reinstallation.
