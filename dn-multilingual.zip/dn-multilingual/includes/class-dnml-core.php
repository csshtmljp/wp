<?php
if (!defined('ABSPATH')) { exit; }

final class DNML_Core {
    const OPTION = 'dnml_settings';
    const LANG = '_dnml_language';
    const GROUP = '_dnml_group';

    public static function defaults() {
        $languages = array(
            'ja' => array('label' => '日本語', 'dir' => 'ltr'),
            'en' => array('label' => 'English', 'dir' => 'ltr'),
            'ko' => array('label' => '한국어', 'dir' => 'ltr'),
            'zh-Hans' => array('label' => '简体中文', 'dir' => 'ltr'),
            'zh-Hant' => array('label' => '繁體中文', 'dir' => 'ltr'),
            'fr' => array('label' => 'Français', 'dir' => 'ltr'),
            'de' => array('label' => 'Deutsch', 'dir' => 'ltr'),
            'es' => array('label' => 'Español', 'dir' => 'ltr'),
            'pt' => array('label' => 'Português', 'dir' => 'ltr'),
            'it' => array('label' => 'Italiano', 'dir' => 'ltr'),
            'vi' => array('label' => 'Tiếng Việt', 'dir' => 'ltr'),
            'ar' => array('label' => 'العربية', 'dir' => 'rtl'),
        );
        $locale = str_replace('_', '-', get_locale());
        $base = strtolower(explode('-', $locale)[0]);
        if ('zh' === $base) { $base = false !== stripos($locale, 'TW') ? 'zh-Hant' : 'zh-Hans'; }
        if (!isset($languages[$base])) { $languages[$base] = array('label' => $locale, 'dir' => is_rtl() ? 'rtl' : 'ltr'); }
        return array('languages' => $languages, 'base' => $base, 'default' => $base, 'position' => 'top', 'archives' => 1, 'hreflang' => 1);
    }
    public static function activate() { add_option(self::OPTION, self::defaults(), '', false); }
    public static function settings() { return wp_parse_args(get_option(self::OPTION, array()), self::defaults()); }
    public static function languages() { return self::settings()['languages']; }
    public static function boot() {
        // Private metadata is intentionally not exposed for REST writes.
        foreach (array('post', 'page') as $type) {
            register_post_meta($type, self::LANG, array('type' => 'string', 'single' => true, 'show_in_rest' => false));
            register_post_meta($type, self::GROUP, array('type' => 'string', 'single' => true, 'show_in_rest' => false));
        }
    }
    public static function supported($post) {
        return $post instanceof WP_Post && in_array($post->post_type, array('post', 'page'), true);
    }
    public static function language($id) {
        $lang = get_post_meta($id, self::LANG, true);
        return $lang ?: self::settings()['base'];
    }
    public static function group($id) { return get_post_meta($id, self::GROUP, true) ?: 'post-' . absint($id); }
    public static function members($id) {
        $post = get_post($id);
        if (!self::supported($post)) { return array(); }
        $group = self::group($id);
        $members = get_posts(array(
            'post_type' => $post->post_type, 'post_status' => array('publish', 'future', 'draft', 'pending', 'private', 'trash'),
            'numberposts' => -1, 'orderby' => 'ID', 'order' => 'ASC',
            'meta_key' => self::GROUP, 'meta_value' => $group,
            'suppress_filters' => true, 'dnml_skip' => true,
        ));
        $by_id = array();
        foreach ($members as $member) { $by_id[$member->ID] = $member; }
        $by_id[$post->ID] = $post;
        if (preg_match('/^post-([0-9]+)$/D', $group, $match)) {
            $root = get_post((int) $match[1]);
            if (self::supported($root) && $root->post_type === $post->post_type && self::group($root->ID) === $group) { $by_id[$root->ID] = $root; }
        }
        return array_values($by_id);
    }
    public static function translations($id, $public_only = true) {
        $result = array();
        foreach (self::members($id) as $post) {
            if ($public_only && ('publish' !== $post->post_status || '' !== $post->post_password)) { continue; }
            $lang = self::language($post->ID);
            if (isset(self::languages()[$lang])) { $result[$lang] = $post; }
        }
        return $result;
    }
    public static function conflict($id, $lang, $except = 0) {
        foreach (self::members($id) as $member) {
            if ($member->ID !== (int) $except && self::language($member->ID) === $lang) { return true; }
        }
        return false;
    }
    public static function lock($group) {
        $key = 'dnml_lock_' . md5($group);
        // Option uniqueness provides an atomic lock. Stale locks expire after five minutes.
        if (add_option($key, time(), '', false)) { return $key; }
        $then = (int) get_option($key);
        if ($then && $then < time() - 300) { delete_option($key); }
        return new WP_Error('busy', '同じ翻訳グループを処理中です。少し待って再実行してください。');
    }
    public static function assign($id, $lang, $reference = 0, $detach = false) {
        $post = get_post($id);
        if (!self::supported($post) || !current_user_can('edit_post', $id) || !isset(self::languages()[$lang])) {
            return new WP_Error('invalid', '言語または編集権限を確認してください。');
        }
        if ($reference && $detach) { return new WP_Error('both', '関連付けと解除は同時に指定できません。'); }
        $target = $reference ? get_post($reference) : $post;
        if (!self::supported($target) || $target->post_type !== $post->post_type || !current_user_can('edit_post', $target->ID) || in_array($target->post_status, array('trash', 'auto-draft'), true)) {
            return new WP_Error('target', '同じ種類の、編集できる記事・固定ページのIDを指定してください。');
        }
        if ($reference && self::group($id) !== self::group($reference) && count(self::members($id)) > 1) {
            return new WP_Error('linked', '先に「このページだけ関連付けを解除」を保存してから、新しいグループへ関連付けてください。');
        }
        $group = $detach ? wp_generate_uuid4() : self::group($target->ID);
        $lock = self::lock($group);
        if (is_wp_error($lock)) { return $lock; }
        try {
            if (!$detach && self::conflict($target->ID, $lang, $id)) {
                return new WP_Error('duplicate', 'このグループには同じ言語の翻訳が存在します（ゴミ箱も含みます）。言語設定は変更していません。');
            }
            update_post_meta($id, self::LANG, $lang);
            update_post_meta($id, self::GROUP, $group);
        } finally { delete_option($lock); }
        return true;
    }
    public static function create_translation($source_id, $lang) {
        $source = get_post($source_id);
        if (!self::supported($source) || !current_user_can('edit_post', $source_id) || !isset(self::languages()[$lang]) || in_array($source->post_status, array('trash', 'auto-draft'), true)) {
            return new WP_Error('permission', '翻訳元または編集権限を確認してください。');
        }
        $type = get_post_type_object($source->post_type);
        if (!current_user_can($type->cap->create_posts)) { return new WP_Error('permission', '下書きを作成する権限がありません。'); }
        $group = self::group($source_id);
        $lock = self::lock($group);
        if (is_wp_error($lock)) { return $lock; }
        try {
            if (self::conflict($source_id, $lang)) { return new WP_Error('exists', 'この言語の翻訳は既にあります。編集リンクを開いてください。'); }
            $id = wp_insert_post(wp_slash(array(
                'post_type' => $source->post_type, 'post_status' => 'draft', 'post_author' => get_current_user_id(),
                'post_title' => $source->post_title . ' [' . $lang . ']', 'post_content' => $source->post_content,
                'post_excerpt' => $source->post_excerpt, 'post_password' => $source->post_password,
                'comment_status' => $source->comment_status, 'ping_status' => $source->ping_status,
                'menu_order' => $source->menu_order,
                'meta_input' => array(self::LANG => $lang, self::GROUP => $group),
            )), true);
            if (is_wp_error($id)) { return $id; }
            $thumb = get_post_thumbnail_id($source_id);
            if ($thumb) { set_post_thumbnail($id, $thumb); }
            $template = get_post_meta($source_id, '_wp_page_template', true);
            if ($template) { update_post_meta($id, '_wp_page_template', $template); }
            // Copy standard classifications; taxonomy names themselves are not translated.
            if ('post' === $source->post_type) {
                foreach (array('category', 'post_tag') as $tax) {
                    $terms = wp_get_object_terms($source_id, $tax, array('fields' => 'ids'));
                    if (!is_wp_error($terms)) { wp_set_object_terms($id, array_map('intval', $terms), $tax); }
                }
            }
            if ($source->post_parent) {
                $parents = self::translations($source->post_parent, false);
                if (isset($parents[$lang]) && 'trash' !== $parents[$lang]->post_status) { wp_update_post(array('ID' => $id, 'post_parent' => $parents[$lang]->ID)); }
            }
            return $id;
        } finally { delete_option($lock); }
    }
    public static function language_clause($lang) {
        $equal = array('key' => self::LANG, 'value' => $lang);
        if ($lang !== self::settings()['base']) { return $equal; }
        return array('relation' => 'OR', $equal, array('key' => self::LANG, 'compare' => 'NOT EXISTS'), array('key' => self::LANG, 'value' => ''));
    }
}
