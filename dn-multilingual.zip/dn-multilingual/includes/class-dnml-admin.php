<?php
if (!defined('ABSPATH')) { exit; }

final class DNML_Admin {
    public function __construct() {
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_post_dnml_settings', array($this, 'save_settings'));
        add_action('admin_post_dnml_create', array($this, 'create'));
        add_action('add_meta_boxes', array($this, 'boxes'));
        add_action('save_post', array($this, 'save'), 20, 2);
        add_action('admin_notices', array($this, 'notices'));
        add_action('restrict_manage_posts', array($this, 'filter_select'));
        add_action('pre_get_posts', array($this, 'filter_query'));
        add_action('admin_enqueue_scripts', array($this, 'assets'));
        foreach (array('post', 'page') as $type) {
            add_filter('manage_' . $type . 's_columns', array($this, 'columns'));
            add_action('manage_' . $type . 's_custom_column', array($this, 'column'), 10, 2);
        }
        add_filter('plugin_action_links_' . plugin_basename(DNML_FILE), array($this, 'action_links'));
    }
    private function input($key, $method = 'post') {
        $data = 'get' === $method ? $_GET : $_POST;
        return isset($data[$key]) && is_string($data[$key]) ? sanitize_text_field(wp_unslash($data[$key])) : '';
    }
    private function notice($text) { set_transient('dnml_notice_' . get_current_user_id(), $text, 120); }
    public function notices() {
        $key = 'dnml_notice_' . get_current_user_id();
        $message = get_transient($key);
        if ($message) { echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html($message) . '</p></div>'; delete_transient($key); }
        if (defined('POLYLANG_VERSION') || defined('ICL_SITEPRESS_VERSION') || defined('TRP_PLUGIN_VERSION')) {
            echo '<div class="notice notice-warning"><p>DN Multilingual：ほかの多言語プラグインが有効です。URL・言語情報の重複を避けるため、多言語プラグインはどれか1つを使用してください。</p></div>';
        }
    }
    public function action_links($links) {
        array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=dnml')) . '">設定</a>');
        return $links;
    }
    public function assets($hook) {
        if (in_array($hook, array('post.php', 'post-new.php', 'edit.php', 'settings_page_dnml'), true)) {
            wp_enqueue_style('dnml-admin', plugins_url('assets/admin.css', DNML_FILE), array(), DNML_VERSION);
        }
    }
    public function menu() { add_options_page('DN Multilingual', 'DN 多言語', 'manage_options', 'dnml', array($this, 'settings_page')); }
    public function settings_page() {
        if (!current_user_can('manage_options')) { return; }
        $s = DNML_Core::settings();
        $lines = array();
        foreach ($s['languages'] as $code => $lang) { $lines[] = $code . '|' . $lang['label'] . '|' . $lang['dir']; }
        ?>
        <div class="wrap dnml-admin">
            <div class="dnml-hero"><span class="dnml-eyebrow">DN MULTILINGUAL / 1.0.0</span><h1>ひとつの記事を、世界の言葉で。</h1><p>投稿と固定ページに、翻訳・言語切り替えを追加します。</p></div>
            <div class="dnml-card"><h2>はじめの3ステップ</h2><ol><li>元の記事を保存し、編集画面の「言語と翻訳」で言語を選びます。</li><li>希望する言語の「下書きを作成」を押して、タイトル・本文を翻訳します。</li><li>翻訳を公開すると、元記事と翻訳に言語切り替えが表示されます。</li></ol><p><strong>手動翻訳方式です。</strong>下書きには元の本文がコピーされます。自動翻訳・外部通信・API料金はありません。</p></div>
            <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" class="dnml-card">
                <input type="hidden" name="action" value="dnml_settings"><?php wp_nonce_field('dnml_settings'); ?>
                <h2>表示と言語の設定</h2>
                <table class="form-table" role="presentation"><tbody>
                <tr><th scope="row"><label for="dnml-languages">利用する言語</label></th><td><textarea id="dnml-languages" name="languages" rows="13" class="large-text code" spellcheck="false"><?php echo esc_textarea(implode("\n", $lines)); ?></textarea><p class="description">1行に <code>言語コード|表示名|ltr または rtl</code>。例：<code>th|ไทย|ltr</code>、<code>en-GB|English (UK)|ltr</code>。最大50言語。使用中の言語は削除できません。</p></td></tr>
                <tr><th scope="row"><label for="dnml-default">一覧の既定言語</label></th><td><select id="dnml-default" name="default"><?php foreach ($s['languages'] as $code => $lang) { echo '<option value="' . esc_attr($code) . '" ' . selected($s['default'], $code, false) . '>' . esc_html($lang['label']) . '</option>'; } ?></select><p class="description">言語未設定の記事は、導入時のサイト言語（<?php echo esc_html($s['base']); ?>）として扱います。この設定変更では記事の言語は変わりません。</p></td></tr>
                <tr><th scope="row"><label for="dnml-position">切り替えの自動表示</label></th><td><select id="dnml-position" name="position"><?php foreach (array('top' => '本文の上', 'bottom' => '本文の下', 'both' => '本文の上下', 'off' => '自動表示しない') as $value => $label) { echo '<option value="' . esc_attr($value) . '" ' . selected($s['position'], $value, false) . '>' . esc_html($label) . '</option>'; } ?></select></td></tr>
                <tr><th scope="row">言語別の一覧</th><td><label><input type="checkbox" name="archives" value="1" <?php checked($s['archives']); ?>> ホームの投稿一覧・アーカイブ・検索のメイン一覧を言語で絞り込む</label><p class="description">例：<code><?php echo esc_html(add_query_arg('dnml_lang', 'en', home_url('/'))); ?></code>。ページキャッシュでは dnml_lang をキャッシュキーに含めてください。</p></td></tr>
                <tr><th scope="row">検索エンジン向け情報</th><td><label><input type="checkbox" name="hreflang" value="1" <?php checked($s['hreflang']); ?>> 公開済みの翻訳に hreflang と x-default を出力する</label></td></tr>
                </tbody></table><?php submit_button('設定を保存'); ?>
            </form>
            <div class="dnml-card"><h2>好きな場所に言語切り替えを置く</h2><p>「ショートコード」ブロック、または対応するウィジェットに次のコードを追加してください。</p><p><code>[dn_language_switcher]</code></p><p>特定の記事の切り替え：<code>[dn_language_switcher post_id="123"]</code></p><p>翻訳がない言語や未公開の翻訳は表示されません。公開翻訳が2言語以上あると表示されます。アーカイブ・検索では利用言語を表示します。</p><h2>対応範囲</h2><p>投稿・固定ページ、ブロックエディター／クラシックエディター、独立したURL、本文のRTL方向に対応します。テーマのメニュー名・カテゴリ名・ウィジェット・ショップ商品・SEOプラグイン固有の項目は自動翻訳しません。非継承のクエリーループや独自の関連記事一覧は言語絞り込みの対象外です。</p><p>固定フロントページの翻訳は、そのページの通常URLで表示します。言語ごとの専用ドメインや /en/ 接頭辞は作成しません。無効化・削除後も投稿・翻訳の本文と言語メタデータは残ります。</p></div>
        </div>
        <?php
    }
    public function save_settings() {
        if (!current_user_can('manage_options')) { wp_die('権限がありません。', '', array('response' => 403)); }
        check_admin_referer('dnml_settings');
        $old = DNML_Core::settings();
        $raw = isset($_POST['languages']) && is_string($_POST['languages']) ? wp_unslash($_POST['languages']) : '';
        $languages = array(); $error = '';
        foreach (preg_split('/\r\n|\r|\n/', $raw) as $line) {
            if ('' === trim($line)) { continue; }
            $parts = array_map('trim', explode('|', $line));
            if (3 !== count($parts) || !preg_match('/^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8}){0,3}$/D', $parts[0]) || !in_array($parts[2], array('ltr', 'rtl'), true)) { $error = '言語は「en|English|ltr」の形式で入力してください。'; break; }
            $code = $parts[0]; $label = sanitize_text_field($parts[1]);
            if ('' === $label || strlen($label) > 160 || isset($languages[$code]) || in_array(strtolower($code), array_map('strtolower', array_keys($languages)), true)) { $error = '言語コードの重複、空の表示名、または長すぎる表示名があります。'; break; }
            $languages[$code] = array('label' => $label, 'dir' => $parts[2]);
        }
        $default = $this->input('default');
        if (!$languages || count($languages) > 50 || !isset($languages[$default], $languages[$old['base']])) { $error = '既定言語と導入時の言語を残し、1〜50言語を登録してください。'; }
        foreach (array_diff(array_keys($old['languages']), array_keys($languages)) as $removed) {
            $used = get_posts(array('post_type' => array('post', 'page'), 'post_status' => array('publish', 'future', 'private', 'draft', 'pending', 'trash'), 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => DNML_Core::LANG, 'meta_value' => $removed, 'suppress_filters' => true));
            if ($used) { $error = '使用中の言語は削除できません：' . $removed; break; }
        }
        if ($error) { $this->notice('設定は保存されませんでした。' . $error); }
        else {
            $position = $this->input('position');
            update_option(DNML_Core::OPTION, array('languages' => $languages, 'base' => $old['base'], 'default' => $default, 'position' => in_array($position, array('top', 'bottom', 'both', 'off'), true) ? $position : 'top', 'archives' => '1' === $this->input('archives') ? 1 : 0, 'hreflang' => '1' === $this->input('hreflang') ? 1 : 0), false);
            $this->notice('多言語の設定を保存しました。');
        }
        wp_safe_redirect(admin_url('options-general.php?page=dnml')); exit;
    }
    public function boxes() {
        foreach (array('post', 'page') as $type) { add_meta_box('dnml-translations', '言語と翻訳 — DN Multilingual', array($this, 'box'), $type, 'side', 'high', array('__block_editor_compatible_meta_box' => true)); }
    }
    public function box($post) {
        wp_nonce_field('dnml_save_' . $post->ID, 'dnml_nonce');
        $current = DNML_Core::language($post->ID);
        echo '<p><label for="dnml-language"><strong>この記事の言語</strong></label></p><select id="dnml-language" name="dnml_language" class="widefat">';
        foreach (DNML_Core::languages() as $code => $lang) { echo '<option value="' . esc_attr($code) . '" ' . selected($current, $code, false) . '>' . esc_html($lang['label'] . ' (' . $code . ')') . '</option>'; }
        echo '</select><p class="description">言語の変更後は、記事を保存してください。</p>';
        if ('auto-draft' === $post->post_status) { echo '<p>最初に下書きを保存すると、翻訳を追加できます。</p>'; return; }
        echo '<p class="description">記事ID：' . esc_html($post->ID) . ' / 複製される内容は最後に保存した本文です。</p><ul class="dnml-translations">';
        $translations = DNML_Core::translations($post->ID, false);
        foreach (DNML_Core::languages() as $code => $lang) {
            echo '<li><span>' . esc_html($lang['label']) . '</span> ';
            if (isset($translations[$code])) {
                $item = $translations[$code];
                if ($item->ID === $post->ID) { echo '<strong>編集中</strong>'; }
                elseif ('trash' === $item->post_status) { echo '<span>ゴミ箱</span>'; }
                elseif (current_user_can('edit_post', $item->ID)) {
                    $status = get_post_status_object($item->post_status);
                    echo '<a href="' . esc_url(get_edit_post_link($item->ID, 'raw')) . '">編集（' . esc_html($status ? $status->label : $item->post_status) . '）</a>';
                } else { echo '<span>登録済み</span>'; }
            } else {
                $url = wp_nonce_url(add_query_arg(array('action' => 'dnml_create', 'source' => $post->ID, 'language' => $code), admin_url('admin-post.php')), 'dnml_create_' . $post->ID);
                echo '<a href="' . esc_url($url) . '">下書きを作成</a>';
            }
            echo '</li>';
        }
        echo '</ul><details><summary>既存記事の関連付け・解除</summary><p><label for="dnml-reference">同じ翻訳グループにする記事ID</label><input type="number" min="1" step="1" class="widefat" id="dnml-reference" name="dnml_reference" value=""></p><p class="description">同じ種類の投稿／固定ページを指定します。空欄なら現在の関連付けを維持します。</p><p><label><input type="checkbox" name="dnml_detach" value="1"> このページだけ関連付けを解除</label></p><p class="description">記事を更新すると反映されます。</p></details>';
    }
    public function save($id, $post) {
        if (!DNML_Core::supported($post) || wp_is_post_revision($id) || wp_is_post_autosave($id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) { return; }
        $nonce = $this->input('dnml_nonce');
        if (!$nonce || !wp_verify_nonce($nonce, 'dnml_save_' . $id) || !current_user_can('edit_post', $id)) { return; }
        $result = DNML_Core::assign($id, $this->input('dnml_language'), absint($this->input('dnml_reference')), '1' === $this->input('dnml_detach'));
        if (is_wp_error($result)) { $this->notice($result->get_error_message()); }
    }
    public function create() {
        $source = absint($this->input('source', 'get'));
        check_admin_referer('dnml_create_' . $source);
        $result = DNML_Core::create_translation($source, $this->input('language', 'get'));
        if (is_wp_error($result)) { wp_die(esc_html($result->get_error_message()), '翻訳用下書き', array('response' => 400, 'back_link' => true)); }
        $this->notice('翻訳用の下書きを作成しました。コピーされたタイトル・本文を翻訳してから公開してください。');
        wp_safe_redirect(get_edit_post_link($result, 'raw')); exit;
    }
    public function columns($columns) { $columns['dnml_language'] = '言語 / 翻訳'; return $columns; }
    public function column($column, $id) {
        if ('dnml_language' !== $column) { return; }
        $lang = DNML_Core::language($id);
        $languages = DNML_Core::languages();
        echo '<strong>' . esc_html(isset($languages[$lang]) ? $languages[$lang]['label'] : $lang) . '</strong><br>';
        foreach (DNML_Core::translations($id, false) as $code => $post) {
            if ($post->ID !== (int) $id && 'trash' !== $post->post_status && current_user_can('edit_post', $post->ID)) { echo '<a class="dnml-tag" href="' . esc_url(get_edit_post_link($post->ID, 'raw')) . '">' . esc_html($code) . '</a> '; }
        }
    }
    public function filter_select($post_type) {
        if (!in_array($post_type, array('post', 'page'), true)) { return; }
        $selected = $this->input('dnml_admin_language', 'get');
        echo '<label class="screen-reader-text" for="dnml-admin-language">言語で絞り込み</label><select id="dnml-admin-language" name="dnml_admin_language"><option value="">すべての言語</option>';
        foreach (DNML_Core::languages() as $code => $lang) { echo '<option value="' . esc_attr($code) . '" ' . selected($selected, $code, false) . '>' . esc_html($lang['label']) . '</option>'; }
        echo '</select>';
    }
    public function filter_query($query) {
        if (!is_admin() || !$query->is_main_query()) { return; }
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || 'edit' !== $screen->base || !in_array($screen->post_type, array('post', 'page'), true)) { return; }
        $lang = $this->input('dnml_admin_language', 'get');
        if (isset(DNML_Core::languages()[$lang])) {
            $existing = $query->get('meta_query');
            $query->set('meta_query', $existing ? array('relation' => 'AND', $existing, DNML_Core::language_clause($lang)) : array(DNML_Core::language_clause($lang)));
        }
    }
}
