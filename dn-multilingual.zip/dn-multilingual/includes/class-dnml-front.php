<?php
if (!defined('ABSPATH')) { exit; }

final class DNML_Front {
    public function __construct() {
        // Read dnml_lang directly from the request. Registering it as a public
        // query var prevents WordPress from resolving a static front page.
        add_shortcode('dn_language_switcher', array($this, 'shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'assets'));
        add_action('pre_get_posts', array($this, 'filter_query'));
        add_action('template_redirect', array($this, 'redirect_language'), 5);
        add_filter('language_attributes', array($this, 'attributes'), 20, 2);
        add_action('wp_head', array($this, 'hreflang'), 3);
        add_filter('the_content', array($this, 'content'), 20);
        add_filter('get_search_form', array($this, 'search_form'));
        add_filter('get_pagenum_link', array($this, 'pagination'));
    }
    public function assets() { wp_enqueue_style('dnml-front', plugins_url('assets/front.css', DNML_FILE), array(), DNML_VERSION); }
    public static function requested() {
        $value = isset($_GET['dnml_lang']) && is_string($_GET['dnml_lang']) ? sanitize_text_field(wp_unslash($_GET['dnml_lang'])) : '';
        return isset(DNML_Core::languages()[$value]) ? $value : '';
    }
    public static function current() {
        if (is_singular(array('post', 'page'))) { return DNML_Core::language(get_queried_object_id()); }
        return self::requested() ?: DNML_Core::settings()['default'];
    }
    public function filter_query($query) {
        if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST) || !$query->is_main_query() || $query->is_singular() || $query->get('dnml_skip') || !DNML_Core::settings()['archives']) { return; }
        if (!$query->is_home() && !$query->is_archive() && !$query->is_search()) { return; }
        $types = $query->get('post_type');
        if ($types && 'any' !== $types && array_diff((array) $types, array('post', 'page'))) { return; }
        if ($query->is_search() && (!$types || 'any' === $types)) { $query->set('post_type', array('post', 'page')); }
        $lang = self::requested() ?: DNML_Core::settings()['default'];
        // Core can inject sticky posts after the main SQL query. Exclude other
        // languages there as well, while preserving same-language sticky posts.
        if ($query->is_home()) {
            $excluded = (array) $query->get('post__not_in');
            foreach ((array) get_option('sticky_posts', array()) as $sticky) {
                if (DNML_Core::language($sticky) !== $lang) { $excluded[] = (int) $sticky; }
            }
            $query->set('post__not_in', array_values(array_unique(array_map('absint', $excluded))));
        }
        $clause = DNML_Core::language_clause($lang);
        $existing = $query->get('meta_query');
        $query->set('meta_query', $existing ? array('relation' => 'AND', $existing, $clause) : array($clause));
    }
    public function redirect_language() {
        if (!is_singular(array('post', 'page')) || is_preview() || !self::requested() || !in_array(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET', array('GET', 'HEAD'), true)) { return; }
        $id = get_queried_object_id();
        $translations = DNML_Core::translations($id);
        $requested = self::requested();
        // An unpublished or absent translation never becomes a public redirect target.
        $target = isset($translations[$requested]) ? $translations[$requested]->ID : $id;
        if ('publish' !== get_post_status($target)) { return; }
        wp_safe_redirect(get_permalink($target), 302, 'DN Multilingual'); exit;
    }
    public function attributes($output, $doctype) {
        if (is_admin() || is_404() || is_attachment() || is_singular() && !is_singular(array('post', 'page')) || is_post_type_archive()) { return $output; }
        $lang = self::current(); $languages = DNML_Core::languages();
        if (!isset($languages[$lang])) { return $output; }
        $output = preg_replace('/(?:^|\s)(?:xml:lang|lang|dir)\s*=\s*(?:"[^"]*"|\x27[^\x27]*\x27)/i', '', $output);
        return trim($output . ' lang="' . esc_attr($lang) . '" dir="' . esc_attr($languages[$lang]['dir']) . '"' . ('xhtml' === $doctype ? ' xml:lang="' . esc_attr($lang) . '"' : ''));
    }
    public function hreflang() {
        if (!DNML_Core::settings()['hreflang'] || !is_singular(array('post', 'page')) || is_preview()) { return; }
        $id = get_queried_object_id();
        if ('publish' !== get_post_status($id) || get_post_field('post_password', $id)) { return; }
        $translations = DNML_Core::translations($id);
        if (count($translations) < 2) { return; }
        foreach ($translations as $lang => $post) { echo '<link rel="alternate" hreflang="' . esc_attr($lang) . '" href="' . esc_url(get_permalink($post)) . '" />' . "\n"; }
        $default = DNML_Core::settings()['default'];
        if (isset($translations[$default])) { echo '<link rel="alternate" hreflang="x-default" href="' . esc_url(get_permalink($translations[$default])) . '" />' . "\n"; }
    }
    public function shortcode($atts = array()) {
        $atts = shortcode_atts(array('post_id' => 0), is_array($atts) ? $atts : array(), 'dn_language_switcher');
        $id = absint($atts['post_id']);
        if (!$id && is_singular(array('post', 'page'))) { $id = get_queried_object_id(); }
        return $this->switcher($id);
    }
    public function switcher($id = 0) {
        $items = array();
        $current = $id ? DNML_Core::language($id) : self::current();
        if ($id) {
            // Do not reveal the group of a private or draft post through a guessed shortcode ID.
            if (!DNML_Core::supported(get_post($id)) || 'publish' !== get_post_status($id) || get_post_field('post_password', $id)) { return ''; }
            $translations = DNML_Core::translations($id);
            foreach (DNML_Core::languages() as $lang => $settings) {
                if (isset($translations[$lang])) { $items[$lang] = get_permalink($translations[$lang]); }
            }
            if (count($items) < 2) { return ''; }
        } else {
            if (is_admin() || is_404() || is_singular() || !DNML_Core::settings()['archives']) { return ''; }
            $base_url = remove_query_arg(array('dnml_lang', 'paged', 'page'), get_pagenum_link(1, false));
            foreach (DNML_Core::languages() as $lang => $settings) { $items[$lang] = add_query_arg('dnml_lang', $lang, $base_url); }
        }
        $html = '<nav class="dnml-switcher" aria-label="Language / 言語"><span class="dnml-switcher-label" aria-hidden="true">Language</span><ul>';
        foreach ($items as $lang => $url) {
            $settings = DNML_Core::languages()[$lang];
            $html .= '<li><a href="' . esc_url($url) . '" lang="' . esc_attr($lang) . '" hreflang="' . esc_attr($lang) . '" dir="' . esc_attr($settings['dir']) . '"' . ($lang === $current ? ' aria-current="page"' : '') . '>' . esc_html($settings['label']) . '</a></li>';
        }
        return $html . '</ul></nav>';
    }
    public function content($content) {
        if (is_admin() || is_feed() || (defined('REST_REQUEST') && REST_REQUEST) || !is_singular(array('post', 'page')) || !in_the_loop() || !is_main_query() || get_the_ID() !== get_queried_object_id() || post_password_required()) { return $content; }
        $position = DNML_Core::settings()['position'];
        $original = get_post_field('post_content', get_the_ID());
        $switcher = 'off' === $position || has_shortcode($original, 'dn_language_switcher') ? '' : $this->switcher(get_the_ID());
        $lang = self::current(); $languages = DNML_Core::languages();
        if (isset($languages[$lang]) && 'rtl' === $languages[$lang]['dir']) { $content = '<div class="dnml-rtl" dir="rtl" lang="' . esc_attr($lang) . '">' . $content . '</div>'; }
        return (in_array($position, array('top', 'both'), true) ? $switcher : '') . $content . (in_array($position, array('bottom', 'both'), true) ? $switcher : '');
    }
    public function search_form($form) {
        if (is_admin() || !DNML_Core::settings()['archives'] || false !== strpos($form, 'name="dnml_lang"')) { return $form; }
        return str_replace('</form>', '<input type="hidden" name="dnml_lang" value="' . esc_attr(self::current()) . '"></form>', $form);
    }
    public function pagination($url) {
        if (!is_admin() && !is_singular() && DNML_Core::settings()['archives'] && self::requested()) { return add_query_arg('dnml_lang', self::requested(), $url); }
        return $url;
    }
}
