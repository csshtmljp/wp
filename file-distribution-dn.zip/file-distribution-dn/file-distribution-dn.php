<?php
/**
 * Plugin Name: ファイル配布dn
 * Description: メディアライブラリの公開ファイルをカード・一覧・ボタンで配布し、ダウンロード受付回数を集計します。
 * Version: 1.2.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: dn
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: file-distribution-dn
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class File_Distribution_Dn {
    const VERSION = '1.2.0';
    const TYPE = 'file_dist_dn';
    const PREFIX = '_fddn_';
    private static $bulk_hook = '';

    public static function boot() {
        add_action( 'init', array( __CLASS__, 'register' ) );
        add_action( 'add_meta_boxes', array( __CLASS__, 'boxes' ) );
        add_action( 'save_post_' . self::TYPE, array( __CLASS__, 'save' ), 10, 2 );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
        add_action( 'wp_ajax_fddn_bulk', array( __CLASS__, 'ajax_bulk' ) );
        add_action( 'admin_post_file_download_dn', array( __CLASS__, 'download' ) );
        add_action( 'admin_post_nopriv_file_download_dn', array( __CLASS__, 'download' ) );
        add_action( 'before_delete_post', array( __CLASS__, 'delete_count' ), 10, 2 );
        add_filter( 'manage_' . self::TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
        add_action( 'manage_' . self::TYPE . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
        add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'links' ) );
        add_shortcode( 'file_download_dn', array( __CLASS__, 'single' ) );
        add_shortcode( 'file_downloads_dn', array( __CLASS__, 'listing' ) );
    }

    public static function register() {
        $caps = array();
        foreach ( array( 'edit_post', 'read_post', 'delete_post', 'edit_posts', 'edit_others_posts',
            'publish_posts', 'read_private_posts', 'delete_posts', 'delete_private_posts',
            'delete_published_posts', 'delete_others_posts', 'edit_private_posts', 'edit_published_posts', 'create_posts' ) as $cap ) {
            $caps[ $cap ] = 'manage_options';
        }
        register_post_type( self::TYPE, array(
            'labels' => array( 'name' => 'ファイル配布dn', 'singular_name' => '配布ファイルdn',
                'add_new' => 'ファイルを追加', 'add_new_item' => '配布ファイルを追加', 'edit_item' => '配布ファイルを編集',
                'search_items' => '配布ファイルを検索', 'not_found' => '配布ファイルがありません',
                'not_found_in_trash' => 'ゴミ箱に配布ファイルはありません', 'all_items' => '配布ファイル一覧' ),
            'public' => false, 'publicly_queryable' => false, 'exclude_from_search' => true,
            'show_ui' => true, 'show_in_menu' => true, 'show_in_rest' => false,
            'rewrite' => false, 'query_var' => false, 'has_archive' => false,
            'menu_icon' => 'dashicons-download', 'supports' => array( 'title' ),
            'capabilities' => $caps, 'map_meta_cap' => false,
        ) );
    }

    private static function text( $value, $length = 120 ) {
        return wp_html_excerpt( sanitize_text_field( is_scalar( $value ) ? (string) $value : '' ), $length, '' );
    }
    public static function id( $value ) {
        return is_scalar( $value ) && preg_match( '/^[1-9][0-9]{0,9}$/D', (string) $value ) ? (int) $value : 0;
    }
    private static function meta( $id, $key ) { return get_post_meta( $id, self::PREFIX . $key, true ); }
    private static function counter_key( $id ) { return 'file_distribution_dn_count_' . (int) $id; }
    public static function count( $id ) { return max( 0, (int) get_option( self::counter_key( $id ), 0 ) ); }

    public static function boxes() {
        add_meta_box( 'fddn-file', '配布ファイルの設定', array( __CLASS__, 'box' ), self::TYPE, 'normal', 'high' );
    }
    public static function box( $post ) {
        $attachment = self::id( self::meta( $post->ID, 'attachment' ) );
        $url = $attachment ? self::attachment_url( $attachment ) : '';
        $enabled = metadata_exists( 'post', $post->ID, self::PREFIX . 'enabled' ) ? '1' === self::meta( $post->ID, 'enabled' ) : true;
        wp_nonce_field( 'fddn_save_' . $post->ID, 'fddn_nonce' );
        ?>
        <div class="fddn-admin">
            <p><strong>一般公開するファイル用です。</strong>メディアの直接URLは、配布停止・下書きへの変更後もアクセスできます。</p>
            <input type="hidden" id="fddn-attachment" name="fddn_attachment" value="<?php echo esc_attr( $attachment ); ?>">
            <p><button type="button" class="button button-primary" id="fddn-select">ファイルを選択・アップロード</button>
                <button type="button" class="button" id="fddn-clear">選択を解除</button></p>
            <p id="fddn-selected" role="status"><?php echo esc_html( $url ? self::filename( $url ) : 'ファイルが選択されていません。' ); ?></p>
            <?php if ( $attachment && ! $url ) : ?><p class="fddn-warning">選択されたメディアが見つかりません。選び直してください。</p><?php endif; ?>
            <p><label for="fddn-version"><strong>バージョン（任意）</strong></label><br>
                <input type="text" id="fddn-version" name="fddn_version" class="regular-text" maxlength="60" value="<?php echo esc_attr( self::meta( $post->ID, 'version' ) ); ?>" placeholder="例：1.0.0"></p>
            <p><label for="fddn-summary"><strong>説明文（任意）</strong></label><br>
                <textarea id="fddn-summary" name="fddn_summary" class="large-text" rows="4" maxlength="2000"><?php echo esc_textarea( self::meta( $post->ID, 'summary' ) ); ?></textarea></p>
            <p><label for="fddn-label"><strong>ボタンの文字</strong></label><br>
                <input type="text" id="fddn-label" name="fddn_label" class="regular-text" maxlength="50" value="<?php echo esc_attr( self::meta( $post->ID, 'label' ) ?: 'ダウンロード' ); ?>"></p>
            <p><label><input type="checkbox" name="fddn_enabled" value="1" <?php checked( $enabled ); ?>> 配布を有効にする</label>（「公開」したファイルだけ表示されます）</p>
            <hr>
            <p><strong>ダウンロード受付回数：<?php echo esc_html( number_format_i18n( self::count( $post->ID ) ) ); ?>回</strong><br>
                <span class="description">ボタン経由の受付回数です。保存完了数・人数ではありません。直接URLからの取得は集計されません。</span></p>
            <p><label for="fddn-shortcode"><strong>個別表示用ショートコード</strong></label><br>
                <input id="fddn-shortcode" class="large-text code" type="text" readonly value="<?php echo esc_attr( '[file_download_dn id="' . $post->ID . '"]' ); ?>" onclick="this.select()"></p>
            <p class="description">投稿・固定ページの「ショートコード」ブロックに貼り付けてください。一覧表示は <code>[file_downloads_dn]</code> です。</p>
        </div>
        <?php
    }

    public static function save( $post_id, $post ) {
        if ( self::TYPE !== $post->post_type || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) { return; }
        if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'edit_post', $post_id ) ) { return; }
        if ( ! isset( $_POST['fddn_nonce'] ) || ! is_string( $_POST['fddn_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fddn_nonce'] ) ), 'fddn_save_' . $post_id ) ) { return; }
        $raw = isset( $_POST['fddn_attachment'] ) ? wp_unslash( $_POST['fddn_attachment'] ) : '';
        $attachment = self::id( $raw );
        if ( ( ! is_scalar( $raw ) ) || ( '' !== (string) $raw && '0' !== (string) $raw && ! $attachment ) ||
            ( $attachment && ( ! current_user_can( 'upload_files' ) || ! current_user_can( 'edit_post', $attachment ) || ! self::attachment_url( $attachment ) ) ) ) {
            add_filter( 'redirect_post_location', array( __CLASS__, 'invalid_attachment' ) );
            return;
        }
        $summary = isset( $_POST['fddn_summary'] ) && is_string( $_POST['fddn_summary'] ) ? wp_unslash( $_POST['fddn_summary'] ) : '';
        $values = array(
            'attachment' => $attachment,
            'version' => self::text( isset( $_POST['fddn_version'] ) ? wp_unslash( $_POST['fddn_version'] ) : '', 60 ),
            'summary' => wp_html_excerpt( sanitize_textarea_field( $summary ), 2000, '' ),
            'label' => self::text( isset( $_POST['fddn_label'] ) ? wp_unslash( $_POST['fddn_label'] ) : '', 50 ) ?: 'ダウンロード',
            'enabled' => isset( $_POST['fddn_enabled'] ) && '1' === $_POST['fddn_enabled'] ? '1' : '0',
        );
        foreach ( $values as $key => $value ) { update_post_meta( $post_id, self::PREFIX . $key, wp_slash( $value ) ); }
    }
    public static function invalid_attachment( $url ) { return add_query_arg( 'fddn_error', 'attachment', $url ); }
    public static function notice() {
        $screen = get_current_screen();
        if ( $screen && self::TYPE === $screen->post_type && current_user_can( 'manage_options' ) && isset( $_GET['fddn_error'] ) && 'attachment' === $_GET['fddn_error'] ) {
            echo '<div class="notice notice-error"><p>配布ファイルの設定を保存できませんでした。有効なメディアを選び直し、もう一度更新してください。</p></div>';
        }
    }

    public static function attachment_url( $id ) {
        $post = get_post( $id );
        if ( ! $post || 'attachment' !== $post->post_type || 'trash' === $post->post_status ) { return ''; }
        $url = esc_url_raw( wp_get_attachment_url( $id ), array( 'http', 'https' ) );
        $parts = wp_parse_url( $url );
        if ( ! is_array( $parts ) || empty( $parts['host'] ) || empty( $parts['scheme'] ) ||
            ! in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) || isset( $parts['user'] ) || isset( $parts['pass'] ) ) { return ''; }
        return $url;
    }
    private static function filename( $url ) {
        return sanitize_text_field( rawurldecode( wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) ) );
    }
    public static function file( $id ) {
        $post = get_post( $id );
        if ( ! $post || self::TYPE !== $post->post_type || 'publish' !== $post->post_status || '' !== $post->post_password || '1' !== self::meta( $id, 'enabled' ) ) { return false; }
        $attachment = self::id( self::meta( $id, 'attachment' ) );
        $url = $attachment ? self::attachment_url( $attachment ) : '';
        if ( ! $url ) { return false; }
        return array( 'post' => $post, 'attachment' => $attachment, 'url' => $url, 'name' => self::filename( $url ) );
    }
    private static function token( $id, $attachment ) {
        // Public form integrity only: deliberately not an expiring login/access token.
        return hash_hmac( 'sha256', 'file-distribution-dn|' . (int) $id . '|' . (int) $attachment, wp_salt( 'auth' ) );
    }
    public static function validate_download( $method, $input ) {
        if ( ! in_array( $method, array( 'GET', 'HEAD', 'POST' ), true ) ) { return new WP_Error( 'method', 'ダウンロードボタンから操作してください。', 405 ); }
        $input = is_array( $input ) ? $input : array();
        $id = self::id( isset( $input['file_id'] ) ? $input['file_id'] : 0 );
        $file = $id ? self::file( $id ) : false;
        if ( ! $file ) { return new WP_Error( 'unavailable', 'このファイルは現在配布されていません。', 404 ); }
        $token = isset( $input['file_token'] ) && is_string( $input['file_token'] ) ? $input['file_token'] : '';
        if ( ! hash_equals( self::token( $id, $file['attachment'] ), $token ) ) {
            return new WP_Error( 'token', 'ページを再読み込みして、ダウンロードボタンを押してください。', 403 );
        }
        return $file;
    }
    public static function increment( $id ) {
        global $wpdb;
        // A unique option_name makes simultaneous requests atomic. No IP/user data is stored.
        $name = self::counter_key( $id );
        $result = $wpdb->query( $wpdb->prepare(
            "INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, '1', 'no') ON DUPLICATE KEY UPDATE option_value = CAST(option_value AS UNSIGNED) + 1",
            $name
        ) );
        wp_cache_delete( $name, 'options' );
        wp_cache_delete( 'notoptions', 'options' );
        return false !== $result;
    }
    public static function download() {
        nocache_headers();
        $method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '';
        $file = self::validate_download( $method, wp_unslash( 'POST' === $method ? $_POST : $_GET ) );
        if ( is_wp_error( $file ) ) {
            if ( 405 === $file->get_error_data() ) { header( 'Allow: GET, HEAD, POST' ); }
            wp_die( esc_html( $file->get_error_message() ), 'ファイル配布dn', array( 'response' => $file->get_error_data(), 'back_link' => true ) );
        }
        $path = self::local_path( $file['attachment'] );
        if ( $path ) { self::send_local( $file, $path, $method ); }
        $uploads = wp_get_upload_dir();
        $base_url = isset( $uploads['baseurl'] ) ? rtrim( $uploads['baseurl'], '/' ) . '/' : '';
        // A missing local upload must not be counted and redirected to a broken URL.
        $local_url = $base_url && strtolower( (string) wp_parse_url( $file['url'], PHP_URL_HOST ) ) === strtolower( (string) wp_parse_url( $base_url, PHP_URL_HOST ) ) &&
            strpos( (string) wp_parse_url( $file['url'], PHP_URL_PATH ), (string) wp_parse_url( $base_url, PHP_URL_PATH ) ) === 0;
        if ( $local_url ) {
            wp_die( '配布ファイルの実体が見つかりません。サイト管理者に再アップロードをご依頼ください。', 'ファイル配布dn', array( 'response' => 404, 'back_link' => true ) );
        }
        // Offloaded files remain on their registered CDN. Their server controls download headers.
        // Trust only the stored attachment's host, never a request-supplied redirect URL.
        $host = strtolower( (string) wp_parse_url( $file['url'], PHP_URL_HOST ) );
        $allow = static function( $hosts ) use ( $host ) { $hosts[] = $host; return array_unique( $hosts ); };
        add_filter( 'allowed_redirect_hosts', $allow );
        if ( 'HEAD' !== $method ) { self::increment( $file['post']->ID ); }
        $redirected = wp_safe_redirect( $file['url'], 303, 'File Distribution dn' );
        remove_filter( 'allowed_redirect_hosts', $allow );
        if ( ! $redirected ) { wp_die( 'ファイルを開けませんでした。サイト管理者にお問い合わせください。', 'ファイル配布dn', array( 'response' => 500 ) ); }
        exit;
    }
    public static function local_path( $attachment ) {
        $path = get_attached_file( $attachment );
        $uploads = wp_get_upload_dir();
        if ( ! is_string( $path ) || '' === $path || strpos( $path, '://' ) !== false || strpos( $path, "\0" ) !== false || empty( $uploads['basedir'] ) ) { return false; }
        $base = realpath( $uploads['basedir'] );
        $real = realpath( $path );
        if ( ! $base || ! $real || strpos( $real, rtrim( $base, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR ) !== 0 || ! is_file( $real ) || ! is_readable( $real ) ) { return false; }
        return $real;
    }
    public static function byte_range( $header, $size ) {
        $full = array( 'start' => 0, 'length' => $size, 'partial' => false );
        // Ignore unsupported/malformed and multi-range requests; serve the whole file.
        if ( ! is_string( $header ) || ! preg_match( '/^bytes=(\d*)-(\d*)$/D', trim( $header ), $match ) || ( '' === $match[1] && '' === $match[2] ) ) { return $full; }
        if ( $size <= 0 ) { return new WP_Error( 'range', '取得範囲が正しくありません。', 416 ); }
        if ( '' === $match[1] ) {
            $length = (int) min( (float) $match[2], $size );
            if ( $length <= 0 ) { return new WP_Error( 'range', '取得範囲が正しくありません。', 416 ); }
            return array( 'start' => $size - $length, 'length' => $length, 'partial' => true );
        }
        if ( (float) $match[1] >= $size ) { return new WP_Error( 'range', '取得範囲が正しくありません。', 416 ); }
        $start = (int) $match[1];
        $end = '' === $match[2] ? $size - 1 : (int) min( (float) $match[2], $size - 1 );
        if ( $end < $start ) { return new WP_Error( 'range', '取得範囲が正しくありません。', 416 ); }
        return array( 'start' => $start, 'length' => $end - $start + 1, 'partial' => true );
    }
    public static function disposition( $filename ) {
        $filename = sanitize_file_name( $filename );
        if ( '' === $filename ) { $filename = 'download-dn'; }
        $ascii = preg_replace( '/[^A-Za-z0-9._-]/', '_', $filename );
        return 'attachment; filename="' . $ascii . '"; filename*=UTF-8\'\'' . rawurlencode( $filename );
    }
    private static function send_local( $file, $path, $method ) {
        $handle = @fopen( $path, 'rb' );
        $stat = $handle ? fstat( $handle ) : false;
        if ( ! $stat || ! isset( $stat['size'] ) || $stat['size'] < 0 ) {
            if ( $handle ) { fclose( $handle ); }
            wp_die( 'ファイルを読み込めませんでした。サイト管理者にお問い合わせください。', 'ファイル配布dn', array( 'response' => 404 ) );
        }
        $size = $stat['size'];
        // If-Range requests receive a fresh whole file because this endpoint has no validators.
        $range_header = 'GET' === $method && empty( $_SERVER['HTTP_IF_RANGE'] ) && isset( $_SERVER['HTTP_RANGE'] ) ? $_SERVER['HTTP_RANGE'] : '';
        $range = self::byte_range( $range_header, $size );
        if ( is_wp_error( $range ) ) {
            fclose( $handle );
            status_header( 416 );
            header( 'Content-Range: bytes */' . $size );
            header( 'Content-Length: 0' );
            exit;
        }
        if ( $range['start'] && 0 !== fseek( $handle, $range['start'] ) ) {
            fclose( $handle );
            wp_die( 'ファイルの読み込みに失敗しました。もう一度お試しください。', 'ファイル配布dn', array( 'response' => 500 ) );
        }
        @ini_set( 'zlib.output_compression', '0' );
        while ( ob_get_level() > 0 ) { if ( ! @ob_end_clean() ) { break; } }
        if ( headers_sent() ) { fclose( $handle ); wp_die( 'ダウンロードを開始できませんでした。サイト管理者にお問い合わせください。', 'ファイル配布dn', array( 'response' => 500 ) ); }
        if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 0 ); }
        status_header( $range['partial'] ? 206 : 200 );
        header( 'Content-Type: application/octet-stream' );
        header( 'Content-Disposition: ' . self::disposition( $file['name'] ) );
        header( 'X-Content-Type-Options: nosniff' );
        header( 'Cache-Control: private, no-store, no-cache, must-revalidate, no-transform' );
        header( 'Accept-Ranges: bytes' );
        header( 'Content-Length: ' . $range['length'] );
        if ( $range['partial'] ) { header( 'Content-Range: bytes ' . $range['start'] . '-' . ( $range['start'] + $range['length'] - 1 ) . '/' . $size ); }
        if ( 'HEAD' === $method ) { fclose( $handle ); exit; }
        // A restart at byte zero counts as a start; a resume from later bytes does not.
        if ( ! $range['partial'] || 0 === $range['start'] ) {
            ob_start();
            self::increment( $file['post']->ID );
            ob_end_clean(); // Database debug output must never corrupt the binary body.
        }
        $remaining = $range['length'];
        while ( $remaining > 0 && ! feof( $handle ) && ! connection_aborted() ) {
            $chunk = @fread( $handle, min( 1048576, $remaining ) );
            if ( false === $chunk || '' === $chunk ) { break; }
            echo $chunk;
            $remaining -= strlen( $chunk );
            flush();
        }
        fclose( $handle );
        exit;
    }
    public static function delete_count( $id, $post ) {
        if ( $post && self::TYPE === $post->post_type ) { delete_option( self::counter_key( $id ) ); }
    }

    public static function assets() {
        // Small scoped stylesheet, also covers shortcodes inside templates and widgets.
        wp_enqueue_style( 'file-distribution-dn', plugin_dir_url( __FILE__ ) . 'assets/file-distribution-dn.css', array(), self::VERSION );
    }
    public static function admin_assets( $hook ) {
        if ( self::$bulk_hook && self::$bulk_hook === $hook ) {
            wp_enqueue_media();
            wp_enqueue_style( 'file-distribution-bulk-dn', plugin_dir_url( __FILE__ ) . 'assets/file-distribution-bulk-dn.css', array(), self::VERSION );
            wp_enqueue_script( 'file-distribution-bulk-dn', plugin_dir_url( __FILE__ ) . 'assets/file-distribution-bulk-dn.js', array( 'media-views' ), self::VERSION, true );
            return;
        }
        $screen = get_current_screen();
        if ( ! $screen || self::TYPE !== $screen->post_type || ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) { return; }
        wp_enqueue_media();
        wp_enqueue_script( 'file-distribution-admin-dn', plugin_dir_url( __FILE__ ) . 'assets/file-distribution-admin-dn.js', array( 'media-views' ), self::VERSION, true );
    }
    private static function size( $id ) {
        $meta = wp_get_attachment_metadata( $id );
        if ( is_array( $meta ) && isset( $meta['filesize'] ) && is_numeric( $meta['filesize'] ) && $meta['filesize'] >= 0 ) { return size_format( (float) $meta['filesize'], 1 ); }
        $path = get_attached_file( $id );
        $uploads = wp_get_upload_dir();
        // Never inspect arbitrary paths, streams or files outside this site's uploads.
        if ( ! is_string( $path ) || strpos( $path, '://' ) !== false || empty( $uploads['basedir'] ) ) { return ''; }
        $base = realpath( $uploads['basedir'] );
        $real = realpath( $path );
        if ( $base && $real && strpos( $real, rtrim( $base, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR ) === 0 && is_file( $real ) && is_readable( $real ) ) {
            $bytes = filesize( $real );
            return false !== $bytes ? size_format( $bytes, 1 ) : '';
        }
        return '';
    }
    private static function form( $file ) {
        $id = $file['post']->ID;
        $label = self::meta( $id, 'label' ) ?: 'ダウンロード';
        $title = $file['post']->post_title ?: $file['name'];
        $url = add_query_arg( array( 'action' => 'file_download_dn', 'file_id' => $id, 'file_token' => self::token( $id, $file['attachment'] ) ), admin_url( 'admin-post.php' ) );
        return '<div class="fddn-form"><a class="fddn-button" href="' . esc_url( $url ) . '" download="' . esc_attr( $file['name'] ) . '" aria-label="' . esc_attr( $label . '：' . $title ) . '">' .
            '<svg aria-hidden="true" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3v12m-5-5 5 5 5-5M5 16v4h14v-4"/></svg>' . esc_html( $label ) . '</a></div>';
    }
    private static function card( $file, $show_count = false ) {
        $id = $file['post']->ID;
        $title = $file['post']->post_title ?: $file['name'];
        $version = self::meta( $id, 'version' );
        $summary = self::meta( $id, 'summary' );
        $ext = strtoupper( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
        $ext = preg_match( '/^[A-Z0-9]{1,8}$/D', $ext ) ? $ext : 'FILE';
        $size = self::size( $file['attachment'] );
        $html = '<article class="fddn-card"><div class="fddn-card-head"><span class="fddn-type">' . esc_html( $ext ) . '</span><div><h3 class="fddn-title">' . esc_html( $title ) . '</h3>';
        $html .= '<p class="fddn-filename">' . esc_html( $file['name'] ) . '</p></div></div>';
        $html .= '<div class="fddn-meta">';
        if ( $version ) { $html .= '<span>バージョン ' . esc_html( $version ) . '</span>'; }
        if ( $size ) { $html .= '<span>' . esc_html( $size ) . '</span>'; }
        if ( $show_count ) { $html .= '<span>受付 ' . esc_html( number_format_i18n( self::count( $id ) ) ) . '回</span>'; }
        $html .= '</div><div class="fddn-card-foot">' . self::form( $file ) . '</div>';
        if ( $summary ) { $html .= '<p class="fddn-summary">' . nl2br( esc_html( $summary ) ) . '</p>'; }
        $html .= '</article>';
        return $html;
    }
    public static function single( $attrs ) {
        $attrs = shortcode_atts( array( 'id' => 0, 'style' => 'card', 'show_count' => '0' ), $attrs, 'file_download_dn' );
        $id = self::id( $attrs['id'] );
        $file = $id ? self::file( $id ) : false;
        if ( ! $file ) { return '<p class="fddn-empty">このファイルは現在配布されていません。</p>'; }
        return '<div class="fddn-wrap">' . ( 'button' === $attrs['style'] ? self::form( $file ) : self::card( $file, '1' === (string) $attrs['show_count'] ) ) . '</div>';
    }
    public static function listing( $attrs ) {
        $attrs = shortcode_atts( array( 'limit' => 12, 'columns' => 2, 'show_count' => '0' ), $attrs, 'file_downloads_dn' );
        $limit = max( 1, min( 100, self::id( $attrs['limit'] ) ?: 12 ) );
        $columns = max( 1, min( 3, self::id( $attrs['columns'] ) ?: 2 ) );
        $query = new WP_Query( array( 'post_type' => self::TYPE, 'post_status' => 'publish', 'has_password' => false,
            'posts_per_page' => $limit, 'no_found_rows' => true, 'ignore_sticky_posts' => true,
            'orderby' => array( 'date' => 'DESC', 'ID' => 'DESC' ), 'update_post_term_cache' => false,
            'meta_query' => array( array( 'key' => self::PREFIX . 'enabled', 'value' => '1' ) ),
        ) );
        $html = '';
        foreach ( $query->posts as $post ) {
            $file = self::file( $post->ID );
            if ( $file ) { $html .= self::card( $file, '1' === (string) $attrs['show_count'] ); }
        }
        return $html ? '<div class="fddn-wrap fddn-grid fddn-columns-' . $columns . '">' . $html . '</div>' : '<p class="fddn-empty">現在配布中のファイルはありません。</p>';
    }

    public static function columns( $columns ) {
        $columns['fddn_file'] = '配布設定';
        $columns['fddn_shortcode'] = 'ショートコード';
        $columns['fddn_count'] = '受付回数';
        return $columns;
    }
    public static function column( $column, $id ) {
        if ( 'fddn_file' === $column ) {
            echo esc_html( self::file( $id ) ? '配布中' : '停止中・未設定・未公開' );
        } elseif ( 'fddn_shortcode' === $column ) {
            echo '<code>' . esc_html( '[file_download_dn id="' . $id . '"]' ) . '</code>';
        } elseif ( 'fddn_count' === $column ) {
            echo esc_html( number_format_i18n( self::count( $id ) ) );
        }
    }
    public static function menu() {
        self::$bulk_hook = add_submenu_page( 'edit.php?post_type=' . self::TYPE, '一括アップロード・編集 — ファイル配布dn', '一括アップロード・編集', 'manage_options', 'file-distribution-dn-bulk', array( __CLASS__, 'bulk_page' ) );
        add_submenu_page( 'edit.php?post_type=' . self::TYPE, '使い方 — ファイル配布dn', '使い方', 'manage_options', 'file-distribution-dn-help', array( __CLASS__, 'help' ) );
    }
    public static function links( $links ) {
        array_unshift( $links, '<a href="' . esc_url( admin_url( 'edit.php?post_type=' . self::TYPE . '&page=file-distribution-dn-bulk' ) ) . '">一括アップロード</a>' );
        array_unshift( $links, '<a href="' . esc_url( admin_url( 'edit.php?post_type=' . self::TYPE ) ) . '">ファイル管理</a>' );
        return $links;
    }
    private static function bulk_existing( $attachment ) {
        $ids = get_posts( array( 'post_type' => self::TYPE, 'post_status' => array( 'publish', 'draft', 'private', 'future', 'pending' ),
            'posts_per_page' => 1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'DESC',
            'meta_key' => self::PREFIX . 'attachment', 'meta_value' => $attachment, 'suppress_filters' => true ) );
        return $ids ? (int) $ids[0] : 0;
    }
    public static function bulk_item( $id, $attachment = 0 ) {
        $post = $id ? get_post( $id ) : null;
        $attachment = $post ? self::id( self::meta( $id, 'attachment' ) ) : $attachment;
        $url = self::attachment_url( $attachment );
        $media = get_post( $attachment );
        $statuses = array( 'publish' => '公開', 'draft' => '下書き', 'private' => '非公開', 'future' => '予約', 'pending' => '承認待ち' );
        return array(
            'id' => $id, 'attachment' => $attachment, 'filename' => $url ? self::filename( $url ) : 'ファイル未設定・メディアが見つかりません',
            'title' => $post ? $post->post_title : ( $media ? $media->post_title : '' ),
            'summary' => $post ? (string) self::meta( $id, 'summary' ) : '',
            'version' => $post ? (string) self::meta( $id, 'version' ) : '',
            'enabled' => $post ? '1' === self::meta( $id, 'enabled' ) : true,
            'status' => $post ? 'keep' : 'publish',
            'statusLabel' => $post ? ( isset( $statuses[ $post->post_status ] ) ? $statuses[ $post->post_status ] : $post->post_status ) : '未登録',
        );
    }
    public static function bulk_lookup( $ids ) {
        if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'upload_files' ) ) { return new WP_Error( 'permission', 'ファイルを管理する権限がありません。', 403 ); }
        if ( ! is_array( $ids ) || count( $ids ) > 100 ) { return new WP_Error( 'limit', '一度に選択できるファイルは100件までです。', 400 ); }
        $items = array();
        foreach ( $ids as $raw ) {
            $attachment = self::id( $raw );
            if ( ! $attachment || ! current_user_can( 'edit_post', $attachment ) || ! self::attachment_url( $attachment ) ) {
                return new WP_Error( 'attachment', '選択されたメディアを利用できません。選び直してください。', 400 );
            }
            if ( isset( $items[ $attachment ] ) ) { continue; }
            $id = self::bulk_existing( $attachment );
            if ( $id && ! current_user_can( 'edit_post', $id ) ) { return new WP_Error( 'permission', '配布項目を編集する権限がありません。', 403 ); }
            $items[ $attachment ] = self::bulk_item( $id, $attachment );
        }
        return array_values( $items );
    }
    public static function bulk_save( $input ) {
        if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'upload_files' ) ) { return new WP_Error( 'permission', 'ファイルを管理する権限がありません。', 403 ); }
        if ( ! is_array( $input ) ) { return new WP_Error( 'input', '入力内容が正しくありません。', 400 ); }
        $attachment = self::id( isset( $input['attachment'] ) ? $input['attachment'] : 0 );
        if ( ! $attachment || ! current_user_can( 'edit_post', $attachment ) || ! self::attachment_url( $attachment ) ) {
            return new WP_Error( 'attachment', '配布するメディアが見つからないか、利用する権限がありません。', 400 );
        }
        $raw_id = isset( $input['id'] ) ? $input['id'] : 0;
        $id = self::id( $raw_id );
        if ( ! $id && 0 !== $raw_id && '0' !== $raw_id ) { return new WP_Error( 'id', '配布項目のIDが正しくありません。', 400 ); }
        // A retry after a lost response updates the same media entry, rather than adding another.
        if ( ! $id ) { $id = self::bulk_existing( $attachment ); }
        $post = $id ? get_post( $id ) : null;
        if ( $id && ( ! $post || self::TYPE !== $post->post_type || 'trash' === $post->post_status || ! current_user_can( 'edit_post', $id ) ) ) {
            return new WP_Error( 'permission', 'この配布項目は編集できません。', 403 );
        }
        $status = isset( $input['status'] ) ? $input['status'] : 'keep';
        if ( ! in_array( $status, array( 'keep', 'publish', 'draft' ), true ) || ( ! $id && 'keep' === $status ) ) {
            return new WP_Error( 'status', '公開状態を選択してください。', 400 );
        }
        $title = self::text( isset( $input['title'] ) ? $input['title'] : '', 200 );
        if ( '' === $title ) { $title = self::filename( self::attachment_url( $attachment ) ); }
        $summary = isset( $input['summary'] ) && is_string( $input['summary'] ) ? $input['summary'] : '';
        $values = array(
            self::PREFIX . 'attachment' => $attachment,
            self::PREFIX . 'summary' => wp_html_excerpt( sanitize_textarea_field( $summary ), 2000, '' ),
            self::PREFIX . 'version' => self::text( isset( $input['version'] ) ? $input['version'] : '', 60 ),
            self::PREFIX . 'enabled' => ! empty( $input['enabled'] ) && in_array( $input['enabled'], array( true, 1, '1' ), true ) ? '1' : '0',
        );
        if ( ! $id ) { $values[ self::PREFIX . 'label' ] = 'ダウンロード'; }
        $args = array( 'post_title' => $title, 'meta_input' => $values );
        if ( 'keep' !== $status ) { $args['post_status'] = $status; }
        if ( $id ) {
            $args['ID'] = $id;
            $result = wp_update_post( wp_slash( $args ), true );
        } else {
            $args['post_type'] = self::TYPE;
            $args['comment_status'] = 'closed';
            $args['ping_status'] = 'closed';
            $result = wp_insert_post( wp_slash( $args ), true );
        }
        if ( is_wp_error( $result ) || ! $result ) { return new WP_Error( 'save', '保存に失敗しました。入力内容を残したまま再試行してください。', 500 ); }
        return self::bulk_item( (int) $result );
    }
    public static function ajax_bulk() {
        if ( 'POST' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) ) { wp_send_json_error( array( 'message' => 'POSTで操作してください。' ), 405 ); }
        if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'upload_files' ) ) { wp_send_json_error( array( 'message' => '操作する権限がありません。' ), 403 ); }
        if ( ! check_ajax_referer( 'fddn_bulk', 'nonce', false ) ) { wp_send_json_error( array( 'message' => '認証期限が切れました。入力文を控えてからページを再読み込みしてください。' ), 403 ); }
        $raw = isset( $_POST['payload'] ) && is_string( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '';
        if ( strlen( $raw ) > 100000 ) { wp_send_json_error( array( 'message' => '送信内容が大きすぎます。' ), 400 ); }
        $input = json_decode( $raw, true );
        if ( ! is_array( $input ) || ! isset( $input['mode'] ) ) { wp_send_json_error( array( 'message' => '送信内容が正しくありません。' ), 400 ); }
        if ( 'lookup' === $input['mode'] ) {
            $result = self::bulk_lookup( isset( $input['ids'] ) ? $input['ids'] : null );
        } elseif ( 'save' === $input['mode'] ) {
            $result = self::bulk_save( isset( $input['item'] ) ? $input['item'] : null );
        } else {
            $result = new WP_Error( 'mode', '操作が正しくありません。', 400 );
        }
        if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), $result->get_error_data() ); }
        wp_send_json_success( $result );
    }
    public static function bulk_page() {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $page = max( 1, min( 100000, self::id( isset( $_GET['fddn_page'] ) ? $_GET['fddn_page'] : 1 ) ?: 1 ) );
        $query = new WP_Query( array( 'post_type' => self::TYPE, 'post_status' => array( 'publish', 'draft', 'private', 'future', 'pending' ),
            'posts_per_page' => 20, 'paged' => $page, 'orderby' => array( 'ID' => 'DESC' ), 'update_post_term_cache' => false ) );
        $items = array();
        foreach ( $query->posts as $post ) { if ( self::TYPE === $post->post_type && current_user_can( 'edit_post', $post->ID ) ) { $items[] = self::bulk_item( $post->ID ); } }
        ?>
        <div class="wrap"><h1>ファイル配布dn — 一括アップロード・編集</h1>
            <p>複数のファイルをアップロード・選択し、各ファイルの下に説明文を書いて、まとめて保存できます。選択画面ではファイルをクリック・タップするたびにチェックを付け外しできます。Ctrl・Shiftキーは不要です。</p>
            <p>新しい項目は初期設定で公開されます。一般公開用のファイルを選んでください。同じメディアを選ぶと既存の配布項目を読み込みます。</p>
            <div id="fddn-bulk" data-endpoint="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'fddn_bulk' ) ); ?>" data-items="<?php echo esc_attr( wp_json_encode( $items ) ); ?>">
                <div class="fddn-bulk-toolbar"><button type="button" id="fddn-bulk-add" class="button">ファイルをまとめてアップロード・選択</button>
                    <button type="button" id="fddn-bulk-save" class="button button-primary">変更をまとめて保存</button></div>
                <p id="fddn-bulk-status" role="status" aria-live="polite">一度に100ファイルまで追加できます。</p>
                <div id="fddn-bulk-rows"></div>
                <noscript><p>一括編集にはJavaScriptが必要です。個別の編集画面も引き続き利用できます。</p></noscript>
            </div>
            <?php if ( $query->max_num_pages > 1 ) : ?><nav aria-label="配布ファイルのページ"><p><?php
                echo wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'fddn_page', '%#%', admin_url( 'edit.php?post_type=' . self::TYPE . '&page=file-distribution-dn-bulk' ) ), 'format' => '', 'current' => $page, 'total' => $query->max_num_pages ) ) );
            ?></p></nav><?php endif; ?>
            <h2>サイトへの設置</h2><p>投稿・固定ページの「ショートコード」ブロックに <code>[file_downloads_dn limit="100" columns="1"]</code> を貼り付けてください。</p>
            <p>ファイル名・ダウンロードボタンの下に、入力した説明文が改行付きで表示されます。登録済みの項目は1ページ20件ずつ編集できます。</p>
            <p>「一覧から外す」はこの画面の編集対象から外す操作です。メディアや登録済みの配布項目は削除されません。配布を止める場合は「配布を有効にする」のチェックを外して保存します。</p>
        </div>
        <?php
    }
    public static function help() {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        ?>
        <div class="wrap"><h1>ファイル配布dn — 使い方</h1>
            <h2>複数ファイルをまとめて登録</h2>
            <ol><li>「一括アップロード・編集 → ファイルをまとめてアップロード・選択」を開きます。</li>
                <li>複数ファイルをアップロード、またはメディアを順にクリック・タップしてチェックし、「チェックしたファイルをまとめて追加」を押します。</li>
                <li>各ファイルの下に説明文を入力し、「変更をまとめて保存」を押します。</li>
                <li>一覧の設置コードは <code>[file_downloads_dn limit="100" columns="1"]</code> です。</li></ol>
            <h2>個別に登録する場合</h2>
            <ol><li>「ファイル配布dn → ファイルを追加」でタイトルを入力します。</li>
                <li>メディアライブラリからファイルを選ぶか、アップロードします。説明文・バージョン・ボタンの文字は任意です。</li>
                <li>「配布を有効にする」にチェックを入れて「公開」を押します。</li>
                <li>表示されたショートコードを、投稿・固定ページの「ショートコード」ブロックに貼り付けます。</li></ol>
            <h2>表示例</h2><p><code>[file_download_dn id="123"]</code> 個別カード（123を配布ファイルのIDに変更）</p>
            <p><code>[file_download_dn id="123" style="button"]</code> ボタンのみ</p>
            <p><code>[file_downloads_dn limit="12" columns="2" show_count="1"]</code> 新しい順の一覧・受付回数表示</p>
            <p>一覧件数は1〜100、列数は1〜3です。スマートフォンでは1列になります。受付回数は通常は非表示です。</p>
            <h2>配布と集計について</h2>
            <ul><li>公開用です。メディアの直接URLを保護する機能、会員限定・有料配布機能はありません。</li>
                <li>配布停止・下書き・ゴミ箱により、本プラグイン経由の受付を停止します。直接URLは引き続き利用できます。</li>
                <li>サイト内に保存されているファイルは保存用ヘッダー付きで直接送信します。外部CDNだけにあるファイルは配信先の設定に従います。</li>
                <li>受付回数は保存完了数・人数ではなく、繰り返し操作・自動アクセスを含みます。個人のIPアドレス等は保存しません。</li>
                <li>ファイルを差し替えた後、ページキャッシュを使用している場合はキャッシュを削除してください。</li>
                <li>アップロード可能な形式・容量はWordPressとサーバーの設定に従います。</li>
                <li>プラグインの停止・削除で登録内容やファイルは消えません。配布項目の完全削除で、その項目の受付回数は消えます。メディア本体は残ります。</li></ul>
        </div>
        <?php
    }
}
File_Distribution_Dn::boot();
