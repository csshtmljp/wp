(function () {
    'use strict';
    function init() {
        var root = document.getElementById('fddn-bulk');
        if (!root || !window.wp || !window.wp.media) { return; }
        var rows = [], frame, busy = false;
        var list = document.getElementById('fddn-bulk-rows');
        var message = document.getElementById('fddn-bulk-status');
        var add = document.getElementById('fddn-bulk-add');
        var save = document.getElementById('fddn-bulk-save');
        function node(tag, text, className) {
            var element = document.createElement(tag);
            if (text !== undefined) { element.textContent = text; }
            if (className) { element.className = className; }
            return element;
        }
        function setBusy(value) {
            busy = value;
            root.setAttribute('aria-busy', String(value));
            root.querySelectorAll('button,input,textarea,select').forEach(function (input) { input.disabled = value; });
        }
        async function request(payload) {
            var body = new URLSearchParams({action: 'fddn_bulk', nonce: root.dataset.nonce, payload: JSON.stringify(payload)});
            var response = await window.fetch(root.dataset.endpoint, {method: 'POST', credentials: 'same-origin', body: body});
            var result;
            try { result = await response.json(); }
            catch (error) { throw new Error('サーバーの応答を読み取れませんでした。入力は残っています。再度保存してください。'); }
            if (!response.ok || !result.success) { throw new Error(result.data && result.data.message || '通信に失敗しました。再度お試しください。'); }
            return result.data;
        }
        function createRow(item) {
            if (rows.some(function (row) { return item.id && row.item.id === item.id || item.attachment && row.item.attachment === item.attachment; })) { return false; }
            var row = {item: item, dirty: !item.id};
            row.element = node('section', undefined, 'fddn-bulk-row');
            var heading = node('div', undefined, 'fddn-bulk-heading');
            var name = node('div');
            name.appendChild(node('h2', item.filename));
            row.state = node('small', item.statusLabel + (item.id ? ' / 配布ID: ' + item.id : ' / 保存すると登録されます'));
            name.appendChild(row.state);
            heading.appendChild(name);
            var remove = node('button', '一覧から外す', 'button');
            remove.type = 'button';
            remove.addEventListener('click', function () {
                if (busy) { return; }
                if (row.dirty && !window.confirm('この行の未保存の入力を破棄して、編集対象から外しますか？')) { return; }
                rows = rows.filter(function (current) { return current !== row; });
                row.element.remove();
            });
            heading.appendChild(remove);
            row.element.appendChild(heading);
            function field(labelText, tag, value, limit, parent) {
                var label = node('label', undefined, 'fddn-bulk-field');
                label.appendChild(node('span', labelText));
                var input = node(tag);
                if (tag === 'input') { input.type = 'text'; }
                if (limit) { input.maxLength = limit; }
                input.value = value || '';
                label.appendChild(input);
                (parent || row.element).appendChild(label);
                return input;
            }
            row.title = field('表示タイトル', 'input', item.title, 200);
            row.summary = field('このファイルの説明文（ファイルの下に表示）', 'textarea', item.summary, 2000);
            row.summary.placeholder = 'ファイルの内容、使い方、含まれるデータなどを自由に記入してください。';
            row.summary.rows = 5;
            var options = node('div', undefined, 'fddn-bulk-options');
            row.element.appendChild(options);
            row.version = field('バージョン（任意）', 'input', item.version, 60, options);
            row.status = field('保存後の公開状態', 'select', '', null, options);
            function statusOption(value, label) { var option = node('option', label); option.value = value; row.status.appendChild(option); }
            if (item.id) { statusOption('keep', '現在の状態を保持（' + item.statusLabel + '）'); }
            statusOption('publish', '公開');
            statusOption('draft', '下書き');
            row.status.value = item.status;
            var enabledLabel = node('label');
            row.enabled = node('input'); row.enabled.type = 'checkbox'; row.enabled.checked = item.enabled;
            enabledLabel.appendChild(row.enabled); enabledLabel.appendChild(document.createTextNode(' 配布を有効にする'));
            options.appendChild(enabledLabel);
            row.result = node('p', '', 'fddn-bulk-result'); row.result.setAttribute('role', 'status');
            row.element.appendChild(row.result);
            function dirty() { row.dirty = true; row.element.classList.add('is-dirty'); row.result.textContent = '未保存の変更があります。'; row.result.classList.remove('is-error'); }
            row.element.addEventListener('input', dirty);
            row.element.addEventListener('change', dirty);
            if (row.dirty) { dirty(); }
            list.appendChild(row.element);
            rows.push(row);
            return true;
        }
        try { JSON.parse(root.dataset.items || '[]').forEach(createRow); }
        catch (error) { message.textContent = '登録内容を読み込めませんでした。ページを再読み込みしてください。'; }
        add.addEventListener('click', function () {
            if (busy) { return; }
            if (!frame) {
                // WordPress uses true for modifier-key selection; toggle keeps each plain click independent.
                frame = window.wp.media({title: '配布するファイルをまとめて選択（クリックでチェック）', button: {text: 'チェックしたファイルをまとめて追加'}, multiple: 'toggle'});
                frame.on('select', async function () {
                    if (busy) { return; }
                    var selected = frame.state().get('selection').toJSON();
                    if (selected.length > 100) { message.textContent = '一度に選択できるのは100ファイルまでです。選択数を減らしてください。'; return; }
                    if (!selected.length) { return; }
                    setBusy(true); message.textContent = 'ファイルを読み込んでいます…';
                    try {
                        var items = await request({mode: 'lookup', ids: selected.map(function (item) { return item.id; })});
                        var added = 0;
                        items.forEach(function (item) { if (createRow(item)) { added++; } });
                        message.textContent = added + '件を編集欄に追加しました。説明文を入力して「変更をまとめて保存」を押してください。';
                    } catch (error) { message.textContent = error.message; }
                    finally { setBusy(false); }
                });
            }
            frame.open();
        });
        save.addEventListener('click', async function () {
            if (busy) { return; }
            var pending = rows.filter(function (row) { return row.dirty; });
            if (!pending.length) { message.textContent = '保存する変更はありません。'; return; }
            setBusy(true);
            var completed = 0, failed = 0;
            try {
                for (var index = 0; index < pending.length; index++) {
                    var row = pending[index];
                    message.textContent = (index + 1) + ' / ' + pending.length + '件を保存しています…';
                    try {
                        var item = await request({mode: 'save', item: {id: row.item.id, attachment: row.item.attachment,
                            title: row.title.value, summary: row.summary.value, version: row.version.value,
                            enabled: row.enabled.checked, status: row.status.value}});
                        row.item = item; row.dirty = false;
                        row.title.value = item.title; row.summary.value = item.summary; row.version.value = item.version;
                        row.state.textContent = item.statusLabel + ' / 配布ID: ' + item.id;
                        var keep = row.status.querySelector('option[value="keep"]');
                        if (!keep) { keep = node('option'); keep.value = 'keep'; row.status.insertBefore(keep, row.status.firstChild); }
                        keep.textContent = '現在の状態を保持（' + item.statusLabel + '）'; row.status.value = 'keep';
                        row.element.classList.remove('is-dirty'); row.result.classList.remove('is-error');
                        row.result.textContent = '保存しました。 [file_download_dn id="' + item.id + '"]';
                        completed++;
                    } catch (error) { failed++; row.result.textContent = error.message; row.result.classList.add('is-error'); }
                }
                message.textContent = completed + '件を保存しました。' + (failed ? ' ' + failed + '件は未保存です。入力は残っています。再度保存すると未保存分だけ再試行します。' : ' サイトに一覧のショートコードを設置してください。');
            } finally { setBusy(false); }
        });
        window.addEventListener('beforeunload', function (event) {
            if (busy || rows.some(function (row) { return row.dirty; })) { event.preventDefault(); event.returnValue = ''; }
        });
    }
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init, {once: true}); }
    else { init(); }
}());
