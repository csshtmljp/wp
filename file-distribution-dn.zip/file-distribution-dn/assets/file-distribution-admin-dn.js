(function () {
    'use strict';
    function init() {
        var select = document.getElementById('fddn-select');
        var clear = document.getElementById('fddn-clear');
        var input = document.getElementById('fddn-attachment');
        var status = document.getElementById('fddn-selected');
        if (!select || !clear || !input || !status || !window.wp || !window.wp.media) { return; }
        var frame;
        select.addEventListener('click', function () {
            if (!frame) {
                frame = window.wp.media({title: '配布するファイルを選択', button: {text: 'このファイルを使用'}, multiple: false});
                frame.on('select', function () {
                    var item = frame.state().get('selection').first();
                    if (!item) { return; }
                    var data = item.toJSON();
                    if (!Number.isSafeInteger(Number(data.id)) || Number(data.id) <= 0) { return; }
                    input.value = String(data.id);
                    status.textContent = data.filename || data.title || 'ファイルを選択しました。';
                });
            }
            frame.open();
        });
        clear.addEventListener('click', function () {
            input.value = '0';
            status.textContent = 'ファイルが選択されていません。';
        });
    }
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init, {once: true}); }
    else { init(); }
}());
