=== Category Post Table（カテゴリ記事一覧表） ===
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

カテゴリごとに「タイトル」と「記事全文」を表形式で一覧表示する固定ページを作成します。

== 説明 ==

* カテゴリ1つにつき固定ページを1つ、ボタン1回で一括作成します。
* 表は「No. / タイトル / 本文（全文）」の構成です。<!--more--> 以降も含めた記事全文を表示します。
* 表の上にタイトルの目次（ページ内リンク）を表示できます。
* スマートフォンでは表を縦積みのカード表示に自動で切り替えます。
* 新しいカテゴリを作ったときに自動で固定ページを作る設定、カテゴリ削除時にページを下書き・ゴミ箱へ移す設定があります。
* 並び順・件数・日付・アイキャッチ・子カテゴリの扱いなどは設定画面で全ページ共通に変更でき、ショートコード属性でページごとに上書きもできます。
* ショートコードは手動で好きな固定ページに配置することもできます。

== インストール ==

1. 管理画面「プラグイン → 新規追加 → プラグインのアップロード」で ZIP をアップロードし、有効化します。
2. 「設定 → カテゴリ記事一覧表」を開きます。
3. 「1. 固定ページの生成」でカテゴリにチェックを入れ、「選択したカテゴリの固定ページを作成」を押します。
   すべてのカテゴリ分を作る場合は「すべてのカテゴリの固定ページを作成」を押します。
4. 作成されたページは「固定ページ」一覧に「カテゴリ一覧表: ○○」の表示付きで並びます。

== ショートコード ==

[category_post_table category="news"]
[category_post_table category="12" orderby="title" order="ASC" posts_per_page="10"]
[category_post_table category="news,event" show_toc="0"]
[category_post_table_index]  … 生成済みの各カテゴリ一覧ページへのリンク集

主な属性:
* category … カテゴリの ID・スラッグ・名前（カンマ区切りで複数可）。必須
* orderby … date / modified / title / menu_order / ID / comment_count / rand
* order … DESC / ASC
* posts_per_page … 1ページの件数。0 ですべて（ページ送りなし）
* include_children, show_number, show_date, show_thumbnail, show_toc, show_description, link_title … 1 / 0
* content_filter … the_content（通常） / basic（WordPress標準の整形のみ）
* date_format … 日付書式（例 Y/m/d）
* number_label, title_label, content_label … 表の見出し文字
* empty_message … 記事が0件のときの文言

== よくある質問 ==

= 表の中にシェアボタンや関連記事が記事ごとに入ってしまう =
設定画面の「本文の処理方式」を「シンプル」にしてください。他プラグインが本文に追加する装飾を除外し、WordPress標準の整形だけで表示します。

= 記事が多くてページが重い =
「1ページの表示件数」を 10〜20 程度にするとページ送りが付きます。

= パスワード保護された記事はどうなる？ =
本文の代わりにパスワード入力欄が表示されます。

= デザインを変えたい =
テーマの追加CSSで .cptl-wrap { --cptl-accent: #c00; --cptl-title-width: 30%; } のように変数を上書きできます。

= プラグインを削除するとページも消える？ =
設定と紐付け情報だけを削除し、作成済みの固定ページは残ります（ショートコードは表示されなくなります）。

== 開発者向けフック ==

* cptl_query_args（filter） … 一覧の WP_Query 引数
* cptl_post_content（filter） … 表に出す本文 HTML
* cptl_page_postarr（filter） … 生成する固定ページのデータ
* cptl_page_generated（action） … 固定ページ生成・更新後

== Changelog ==

= 1.0.0 =
* 初版
