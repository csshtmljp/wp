<?php
/**
 * カテゴリごとの固定ページ生成・同期。
 *
 * @package CategoryPostTable
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CPTL_Page_Generator {

	public static function init() {
		add_action( 'created_category', array( __CLASS__, 'on_category_created' ), 10, 1 );
		add_action( 'pre_delete_term', array( __CLASS__, 'on_category_pre_delete' ), 10, 2 );
	}

	/**
	 * カテゴリに対応する固定ページ ID（ゴミ箱・削除済みは 0）。
	 *
	 * @param int $term_id カテゴリ ID.
	 * @return int
	 */
	public static function get_page_id( $term_id ) {
		$page_id = (int) get_term_meta( (int) $term_id, CPTL_TERM_META, true );
		if ( ! $page_id ) {
			return 0;
		}
		$page = get_post( $page_id );
		if ( ! $page || 'page' !== $page->post_type || 'trash' === $page->post_status ) {
			return 0;
		}
		return $page_id;
	}

	/**
	 * 固定ページ本文（ショートコードブロック）。カテゴリ ID で指定するのでスラッグ変更にも強い。
	 *
	 * @param WP_Term $term カテゴリ.
	 * @return string
	 */
	public static function build_content( $term ) {
		$shortcode = sprintf( '[%s category="%d"]', CPTL_Shortcode::TAG, (int) $term->term_id );
		return "<!-- wp:shortcode -->\n" . $shortcode . "\n<!-- /wp:shortcode -->";
	}

	/**
	 * テンプレートの {category} {slug} {id} を置換。
	 *
	 * @param string  $template テンプレート.
	 * @param WP_Term $term     カテゴリ.
	 * @return string
	 */
	public static function fill_template( $template, $term ) {
		return strtr(
			(string) $template,
			array(
				'{category}' => $term->name,
				'{slug}'     => urldecode( $term->slug ),
				'{id}'       => (string) $term->term_id,
			)
		);
	}

	/**
	 * 1 カテゴリ分の固定ページを作成または更新。
	 *
	 * @param int  $term_id   カテゴリ ID.
	 * @param bool $overwrite 既存ページのタイトル・本文・親・状態を上書きするか.
	 * @return array { status: created|updated|skipped|error, page_id: int, term: WP_Term|null, message: string }
	 */
	public static function generate( $term_id, $overwrite = false ) {
		$term = get_term( (int) $term_id, 'category' );
		if ( ! $term instanceof WP_Term ) {
			return array(
				'status'  => 'error',
				'page_id' => 0,
				'term'    => null,
				'message' => __( 'カテゴリが見つかりません。', 'category-post-table' ),
			);
		}

		$s        = CPTL_Settings::get();
		$existing = self::get_page_id( $term->term_id );

		if ( $existing && ! $overwrite ) {
			return array(
				'status'  => 'skipped',
				'page_id' => $existing,
				'term'    => $term,
				'message' => '',
			);
		}

		$postarr = array(
			'post_type'    => 'page',
			'post_title'   => self::fill_template( $s['title_template'], $term ),
			'post_content' => self::build_content( $term ),
			'post_status'  => $s['page_status'],
			'post_parent'  => (int) $s['page_parent'],
		);

		/**
		 * 生成する固定ページのデータを変更するフィルター。
		 *
		 * @param array   $postarr  wp_insert_post 用配列.
		 * @param WP_Term $term     カテゴリ.
		 * @param int     $existing 既存ページ ID（新規は 0）.
		 */
		$postarr = apply_filters( 'cptl_page_postarr', $postarr, $term, $existing );

		if ( $existing ) {
			$postarr['ID'] = $existing;
			$result        = wp_update_post( wp_slash( $postarr ), true );
			$status        = 'updated';
		} else {
			$postarr['post_name'] = sanitize_title( self::fill_template( $s['slug_template'], $term ) );
			$result               = wp_insert_post( wp_slash( $postarr ), true );
			$status               = 'created';
		}

		if ( is_wp_error( $result ) || ! $result ) {
			return array(
				'status'  => 'error',
				'page_id' => 0,
				'term'    => $term,
				'message' => is_wp_error( $result ) ? $result->get_error_message() : __( 'ページを保存できませんでした。', 'category-post-table' ),
			);
		}

		$page_id = (int) $result;
		update_term_meta( $term->term_id, CPTL_TERM_META, $page_id );
		update_post_meta( $page_id, CPTL_PAGE_META, $term->term_id );

		/**
		 * 固定ページ生成後のアクション。
		 *
		 * @param int     $page_id ページ ID.
		 * @param WP_Term $term    カテゴリ.
		 * @param string  $status  created|updated.
		 */
		do_action( 'cptl_page_generated', $page_id, $term, $status );

		return array(
			'status'  => $status,
			'page_id' => $page_id,
			'term'    => $term,
			'message' => '',
		);
	}

	/**
	 * 新規カテゴリ作成時に自動生成（設定で有効な場合）。
	 *
	 * @param int $term_id カテゴリ ID.
	 */
	public static function on_category_created( $term_id ) {
		if ( ! CPTL_Settings::value( 'auto_create' ) ) {
			return;
		}
		self::generate( $term_id, false );
	}

	/**
	 * カテゴリ削除前に、対応ページを下書き／ゴミ箱へ（設定に従う）。
	 *
	 * @param int    $term_id  ターム ID.
	 * @param string $taxonomy タクソノミー.
	 */
	public static function on_category_pre_delete( $term_id, $taxonomy ) {
		if ( 'category' !== $taxonomy ) {
			return;
		}
		$action  = CPTL_Settings::value( 'on_delete' );
		$page_id = self::get_page_id( $term_id );
		if ( ! $page_id || 'none' === $action ) {
			return;
		}
		if ( 'trash' === $action ) {
			wp_trash_post( $page_id );
		} else {
			wp_update_post(
				array(
					'ID'          => $page_id,
					'post_status' => 'draft',
				)
			);
		}
		delete_post_meta( $page_id, CPTL_PAGE_META );
	}

	/**
	 * カテゴリを親子順に並べる（表示用）。
	 *
	 * @param WP_Term[] $terms タームの配列.
	 * @return array[] 各要素 { term: WP_Term, depth: int }
	 */
	public static function sort_hierarchically( $terms ) {
		$by_parent = array();
		$ids       = array();
		foreach ( $terms as $t ) {
			$ids[ $t->term_id ] = true;
		}
		foreach ( $terms as $t ) {
			// 親が一覧に含まれない場合はトップレベル扱い.
			$parent                 = ( $t->parent && isset( $ids[ $t->parent ] ) ) ? (int) $t->parent : 0;
			$by_parent[ $parent ][] = $t;
		}

		$out  = array();
		$walk = static function ( $parent, $depth ) use ( &$walk, &$out, $by_parent ) {
			if ( empty( $by_parent[ $parent ] ) || $depth > 50 ) {
				return;
			}
			foreach ( $by_parent[ $parent ] as $t ) {
				$out[] = array(
					'term'  => $t,
					'depth' => $depth,
				);
				$walk( (int) $t->term_id, $depth + 1 );
			}
		};
		$walk( 0, 0 );
		return $out;
	}
}
