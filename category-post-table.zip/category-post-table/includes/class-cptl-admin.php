<?php
/**
 * 管理画面（設定 → カテゴリ記事一覧表）。
 *
 * @package CategoryPostTable
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CPTL_Admin {

	const SLUG   = 'category-post-table';
	const GROUP  = 'cptl_settings_group';
	const ACTION = 'cptl_generate_pages';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_post_' . self::ACTION, array( __CLASS__, 'handle_generate' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( CPTL_FILE ), array( __CLASS__, 'action_links' ) );
		add_filter( 'display_post_states', array( __CLASS__, 'post_states' ), 10, 2 );
	}

	public static function menu() {
		add_options_page(
			__( 'カテゴリ記事一覧表', 'category-post-table' ),
			__( 'カテゴリ記事一覧表', 'category-post-table' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	public static function register_settings() {
		register_setting(
			self::GROUP,
			CPTL_OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'CPTL_Settings', 'sanitize' ),
				'default'           => CPTL_Settings::defaults(),
			)
		);
	}

	public static function action_links( $links ) {
		$url = admin_url( 'options-general.php?page=' . self::SLUG );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( '設定', 'category-post-table' ) . '</a>' );
		return $links;
	}

	/**
	 * 固定ページ一覧で「カテゴリ一覧表: ○○」と表示。
	 *
	 * @param string[] $states 表示状態.
	 * @param WP_Post  $post   投稿.
	 * @return string[]
	 */
	public static function post_states( $states, $post ) {
		if ( 'page' !== $post->post_type ) {
			return $states;
		}
		$term_id = (int) get_post_meta( $post->ID, CPTL_PAGE_META, true );
		if ( $term_id ) {
			$term = get_term( $term_id, 'category' );
			if ( $term instanceof WP_Term ) {
				/* translators: %s: category name */
				$states['cptl'] = sprintf( __( 'カテゴリ一覧表: %s', 'category-post-table' ), $term->name );
			}
		}
		return $states;
	}

	/**
	 * 「固定ページを生成」フォームの送信処理。
	 */
	public static function handle_generate() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'この操作を行う権限がありません。', 'category-post-table' ), 403 );
		}
		check_admin_referer( self::ACTION );

		if ( ! empty( $_POST['cptl_all'] ) ) {
			$ids = get_terms(
				array(
					'taxonomy'   => 'category',
					'hide_empty' => false,
					'fields'     => 'ids',
				)
			);
			$ids = is_wp_error( $ids ) ? array() : $ids;
		} else {
			$ids = isset( $_POST['cptl_terms'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['cptl_terms'] ) ) : array();
		}
		$ids       = array_values( array_unique( array_filter( $ids ) ) );
		$overwrite = ! empty( $_POST['cptl_overwrite'] );

		$report = array(
			'created' => array(),
			'updated' => array(),
			'skipped' => array(),
			'error'   => array(),
		);
		foreach ( $ids as $term_id ) {
			$r    = CPTL_Page_Generator::generate( $term_id, $overwrite );
			$name = $r['term'] instanceof WP_Term ? $r['term']->name : '#' . $term_id;
			$report[ $r['status'] ][] = array(
				'name'    => $name,
				'page_id' => $r['page_id'],
				'message' => $r['message'],
			);
		}

		set_transient( 'cptl_report_' . get_current_user_id(), $report, 120 );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'      => self::SLUG,
					'cptl_done' => empty( $ids ) ? 'none' : '1',
				),
				admin_url( 'options-general.php' )
			)
		);
		exit;
	}

	/**
	 * 生成結果の通知。
	 */
	private static function render_report() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 表示切替のみ.
		$done = isset( $_GET['cptl_done'] ) ? sanitize_key( $_GET['cptl_done'] ) : '';
		if ( 'none' === $done ) {
			echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'カテゴリが選択されていません。', 'category-post-table' ) . '</p></div>';
			return;
		}
		if ( '1' !== $done ) {
			return;
		}
		$key    = 'cptl_report_' . get_current_user_id();
		$report = get_transient( $key );
		delete_transient( $key );
		if ( ! is_array( $report ) ) {
			return;
		}

		$labels = array(
			'created' => array( 'notice-success', __( '作成しました', 'category-post-table' ) ),
			'updated' => array( 'notice-success', __( '上書き更新しました', 'category-post-table' ) ),
			'skipped' => array( 'notice-info', __( '作成済みのためスキップしました（上書きする場合は「既存ページを上書き更新する」にチェック）', 'category-post-table' ) ),
			'error'   => array( 'notice-error', __( 'エラーが発生しました', 'category-post-table' ) ),
		);

		foreach ( $labels as $status => $meta ) {
			if ( empty( $report[ $status ] ) ) {
				continue;
			}
			$parts = array();
			foreach ( $report[ $status ] as $row ) {
				$text = esc_html( $row['name'] );
				if ( $row['page_id'] ) {
					$text = '<a href="' . esc_url( get_permalink( $row['page_id'] ) ) . '" target="_blank" rel="noopener">' . $text . '</a>';
				}
				if ( '' !== $row['message'] ) {
					$text .= '（' . esc_html( $row['message'] ) . '）';
				}
				$parts[] = $text;
			}
			printf(
				'<div class="notice %1$s is-dismissible"><p><strong>%2$s（%3$d件）</strong>：%4$s</p></div>',
				esc_attr( $meta[0] ),
				esc_html( $meta[1] ),
				count( $report[ $status ] ),
				implode( '、', $parts ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			);
		}
	}

	/**
	 * 設定画面の描画。
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s    = CPTL_Settings::get();
		$name = CPTL_OPTION;
		?>
		<div class="wrap cptl-admin">
			<h1><?php esc_html_e( 'カテゴリ記事一覧表', 'category-post-table' ); ?></h1>
			<p><?php esc_html_e( 'カテゴリごとに「タイトル」と「記事全文」を表で一覧表示する固定ページを作成します。下の「固定ページの生成」でカテゴリを選ぶと、カテゴリ1つにつき固定ページが1つ作られます。', 'category-post-table' ); ?></p>

			<?php self::render_report(); ?>

			<h2 class="title"><?php esc_html_e( '1. 固定ページの生成', 'category-post-table' ); ?></h2>
			<?php self::render_category_table(); ?>

			<hr>

			<h2 class="title"><?php esc_html_e( '2. 設定', 'category-post-table' ); ?></h2>
			<form method="post" action="options.php">
				<?php settings_fields( self::GROUP ); ?>

				<h3><?php esc_html_e( '固定ページの作成ルール', 'category-post-table' ); ?></h3>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="cptl_title_template"><?php esc_html_e( 'ページタイトル', 'category-post-table' ); ?></label></th>
						<td>
							<input type="text" class="regular-text" id="cptl_title_template" name="<?php echo esc_attr( $name ); ?>[title_template]" value="<?php echo esc_attr( $s['title_template'] ); ?>">
							<p class="description"><?php esc_html_e( '{category} = カテゴリ名、{slug} = カテゴリのスラッグ、{id} = カテゴリID', 'category-post-table' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cptl_slug_template"><?php esc_html_e( 'ページのスラッグ', 'category-post-table' ); ?></label></th>
						<td>
							<input type="text" class="regular-text" id="cptl_slug_template" name="<?php echo esc_attr( $name ); ?>[slug_template]" value="<?php echo esc_attr( $s['slug_template'] ); ?>">
							<p class="description"><?php esc_html_e( '新規作成時のみ使用します。例：{slug}-list → news-list', 'category-post-table' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cptl_page_status"><?php esc_html_e( '公開状態', 'category-post-table' ); ?></label></th>
						<td>
							<select id="cptl_page_status" name="<?php echo esc_attr( $name ); ?>[page_status]">
								<option value="publish" <?php selected( $s['page_status'], 'publish' ); ?>><?php esc_html_e( '公開', 'category-post-table' ); ?></option>
								<option value="draft" <?php selected( $s['page_status'], 'draft' ); ?>><?php esc_html_e( '下書き', 'category-post-table' ); ?></option>
								<option value="private" <?php selected( $s['page_status'], 'private' ); ?>><?php esc_html_e( '非公開', 'category-post-table' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cptl_page_parent"><?php esc_html_e( '親ページ', 'category-post-table' ); ?></label></th>
						<td>
							<?php
							wp_dropdown_pages(
								array(
									'name'              => esc_attr( $name ) . '[page_parent]',
									'id'                => 'cptl_page_parent',
									'selected'          => (int) $s['page_parent'],
									'show_option_none'  => __( '（なし）', 'category-post-table' ),
									'option_none_value' => '0',
									'post_status'       => array( 'publish', 'draft', 'private' ),
								)
							);
							?>
							<p class="description"><?php esc_html_e( '生成ページをまとめたい親ページがあれば選びます（例：「カテゴリ別一覧」ページの子ページにする）。', 'category-post-table' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( '自動作成', 'category-post-table' ); ?></th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[auto_create]" value="1" <?php checked( $s['auto_create'], 1 ); ?>> <?php esc_html_e( '新しいカテゴリを作ったとき、自動で固定ページも作成する', 'category-post-table' ); ?></label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cptl_on_delete"><?php esc_html_e( 'カテゴリ削除時', 'category-post-table' ); ?></label></th>
						<td>
							<select id="cptl_on_delete" name="<?php echo esc_attr( $name ); ?>[on_delete]">
								<option value="draft" <?php selected( $s['on_delete'], 'draft' ); ?>><?php esc_html_e( '対応する固定ページを下書きに戻す', 'category-post-table' ); ?></option>
								<option value="trash" <?php selected( $s['on_delete'], 'trash' ); ?>><?php esc_html_e( '対応する固定ページをゴミ箱へ移動', 'category-post-table' ); ?></option>
								<option value="none" <?php selected( $s['on_delete'], 'none' ); ?>><?php esc_html_e( '何もしない', 'category-post-table' ); ?></option>
							</select>
						</td>
					</tr>
				</table>

				<h3><?php esc_html_e( '一覧表の表示（全ページ共通の既定値）', 'category-post-table' ); ?></h3>
				<p class="description"><?php esc_html_e( 'ここを変更すると、生成済みの全ページの表示にすぐ反映されます。ページごとに変えたい場合はショートコードの属性で上書きできます。', 'category-post-table' ); ?></p>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="cptl_orderby"><?php esc_html_e( '並び順', 'category-post-table' ); ?></label></th>
						<td>
							<select id="cptl_orderby" name="<?php echo esc_attr( $name ); ?>[orderby]">
								<?php
								$orderby_labels = array(
									'date'          => __( '公開日', 'category-post-table' ),
									'modified'      => __( '更新日', 'category-post-table' ),
									'title'         => __( 'タイトル', 'category-post-table' ),
									'menu_order'    => __( '順序（menu_order）', 'category-post-table' ),
									'ID'            => __( '記事ID', 'category-post-table' ),
									'comment_count' => __( 'コメント数', 'category-post-table' ),
									'rand'          => __( 'ランダム', 'category-post-table' ),
								);
								foreach ( $orderby_labels as $value => $label ) {
									printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $value ), selected( $s['orderby'], $value, false ), esc_html( $label ) );
								}
								?>
							</select>
							<select name="<?php echo esc_attr( $name ); ?>[order]" aria-label="<?php esc_attr_e( '昇順・降順', 'category-post-table' ); ?>">
								<option value="DESC" <?php selected( $s['order'], 'DESC' ); ?>><?php esc_html_e( '降順（新しい順・Z→A）', 'category-post-table' ); ?></option>
								<option value="ASC" <?php selected( $s['order'], 'ASC' ); ?>><?php esc_html_e( '昇順（古い順・A→Z）', 'category-post-table' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cptl_posts_per_page"><?php esc_html_e( '1ページの表示件数', 'category-post-table' ); ?></label></th>
						<td>
							<input type="number" min="0" step="1" class="small-text" id="cptl_posts_per_page" name="<?php echo esc_attr( $name ); ?>[posts_per_page]" value="<?php echo esc_attr( (string) $s['posts_per_page'] ); ?>">
							<p class="description"><?php esc_html_e( '0 = すべての記事を1ページに表示。記事が多く全文が長い場合は 10〜20 程度にするとページ送りが付き、表示が軽くなります。', 'category-post-table' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( '表示項目', 'category-post-table' ); ?></th>
						<td>
							<fieldset>
								<?php
								$checks = array(
									'show_number'      => __( '番号（No.）列を表示', 'category-post-table' ),
									'show_date'        => __( 'タイトルの下に公開日を表示', 'category-post-table' ),
									'show_thumbnail'   => __( 'タイトルの下にアイキャッチ画像を表示', 'category-post-table' ),
									'link_title'       => __( 'タイトルを個別記事へのリンクにする', 'category-post-table' ),
									'show_toc'         => __( '表の上にタイトルの目次（ページ内リンク）を表示', 'category-post-table' ),
									'show_description' => __( 'カテゴリの説明文を表の上に表示', 'category-post-table' ),
									'include_children' => __( '子カテゴリの記事も含める', 'category-post-table' ),
								);
								foreach ( $checks as $key => $label ) {
									printf(
										'<label><input type="checkbox" name="%1$s[%2$s]" value="1" %3$s> %4$s</label><br>',
										esc_attr( $name ),
										esc_attr( $key ),
										checked( $s[ $key ], 1, false ),
										esc_html( $label )
									);
								}
								?>
							</fieldset>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cptl_content_filter"><?php esc_html_e( '本文の処理方式', 'category-post-table' ); ?></label></th>
						<td>
							<select id="cptl_content_filter" name="<?php echo esc_attr( $name ); ?>[content_filter]">
								<option value="the_content" <?php selected( $s['content_filter'], 'the_content' ); ?>><?php esc_html_e( '通常（個別記事ページと同じ表示）', 'category-post-table' ); ?></option>
								<option value="basic" <?php selected( $s['content_filter'], 'basic' ); ?>><?php esc_html_e( 'シンプル（WordPress標準の整形のみ）', 'category-post-table' ); ?></option>
							</select>
							<p class="description"><?php esc_html_e( '表の中に SNS シェアボタンや関連記事、目次プラグインの目次などが記事ごとに入ってしまう場合は「シンプル」にしてください。', 'category-post-table' ); ?></p>
						</td>
					</tr>
				</table>

				<?php submit_button( __( '設定を保存', 'category-post-table' ) ); ?>
			</form>

			<hr>

			<h2 class="title"><?php esc_html_e( '3. ショートコードの使い方（手動で配置する場合）', 'category-post-table' ); ?></h2>
			<p><?php esc_html_e( '任意の固定ページに「ショートコード」ブロックを追加し、次のように入力しても一覧表を表示できます。', 'category-post-table' ); ?></p>
			<p><code>[category_post_table category="news"]</code> <?php esc_html_e( '… スラッグ「news」のカテゴリ', 'category-post-table' ); ?></p>
			<p><code>[category_post_table category="12" orderby="title" order="ASC" posts_per_page="10"]</code></p>
			<p><code>[category_post_table category="news,event" show_toc="0" show_date="0"]</code> <?php esc_html_e( '… 複数カテゴリをまとめて1つの表に', 'category-post-table' ); ?></p>
			<p><code>[category_post_table_index]</code> <?php esc_html_e( '… 生成済みの各カテゴリ一覧ページへのリンク集（目次ページ用）', 'category-post-table' ); ?></p>
			<table class="widefat striped" style="max-width:960px">
				<thead><tr><th><?php esc_html_e( '属性', 'category-post-table' ); ?></th><th><?php esc_html_e( '内容', 'category-post-table' ); ?></th></tr></thead>
				<tbody>
					<?php
					$attr_docs = array(
						'category'         => 'カテゴリのID・スラッグ・名前（カンマ区切りで複数可）。必須',
						'orderby / order'  => '並び順（date / modified / title / menu_order / ID / comment_count / rand）と ASC / DESC',
						'posts_per_page'   => '1ページの件数。0 ですべて',
						'include_children' => '子カテゴリの記事も含める（1 / 0）',
						'show_number'      => '番号列（1 / 0）',
						'show_date'        => '公開日（1 / 0）',
						'show_thumbnail'   => 'アイキャッチ画像（1 / 0）',
						'show_toc'         => 'タイトルの目次（1 / 0）',
						'show_description' => 'カテゴリ説明文（1 / 0）',
						'link_title'       => 'タイトルを記事へのリンクにする（1 / 0）',
						'content_filter'   => 'the_content（通常） / basic（シンプル）',
						'date_format'      => '日付の書式（例：Y/m/d）。空なら「設定 → 一般」の書式',
						'number_label / title_label / content_label' => '表の見出し文字（既定：No. / タイトル / 本文）',
						'empty_message'    => '記事が0件のときの文言',
					);
					foreach ( $attr_docs as $attr => $desc ) {
						echo '<tr><td><code>' . esc_html( $attr ) . '</code></td><td>' . esc_html( $desc ) . '</td></tr>';
					}
					?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * カテゴリ一覧と生成フォーム。
	 */
	private static function render_category_table() {
		$terms = get_terms(
			array(
				'taxonomy'   => 'category',
				'hide_empty' => false,
				'orderby'    => 'name',
			)
		);
		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			echo '<p>' . esc_html__( 'カテゴリがありません。', 'category-post-table' ) . '</p>';
			return;
		}
		$rows = CPTL_Page_Generator::sort_hierarchically( $terms );

		$status_labels = array(
			'publish' => __( '公開', 'category-post-table' ),
			'draft'   => __( '下書き', 'category-post-table' ),
			'private' => __( '非公開', 'category-post-table' ),
			'pending' => __( 'レビュー待ち', 'category-post-table' ),
			'future'  => __( '予約済み', 'category-post-table' ),
		);
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
			<?php wp_nonce_field( self::ACTION ); ?>

			<table class="wp-list-table widefat fixed striped" style="max-width:960px">
				<thead>
					<tr>
						<td class="manage-column column-cb check-column"><input type="checkbox" aria-label="<?php esc_attr_e( 'すべて選択', 'category-post-table' ); ?>"></td>
						<th scope="col"><?php esc_html_e( 'カテゴリ', 'category-post-table' ); ?></th>
						<th scope="col" style="width:18%"><?php esc_html_e( 'スラッグ', 'category-post-table' ); ?></th>
						<th scope="col" style="width:8%"><?php esc_html_e( '記事数', 'category-post-table' ); ?></th>
						<th scope="col" style="width:34%"><?php esc_html_e( '一覧表の固定ページ', 'category-post-table' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $rows as $row ) : ?>
					<?php
					$term    = $row['term'];
					$page_id = CPTL_Page_Generator::get_page_id( $term->term_id );
					$cb_id   = 'cptl-term-' . $term->term_id;
					?>
					<tr>
						<th scope="row" class="check-column"><input type="checkbox" id="<?php echo esc_attr( $cb_id ); ?>" name="cptl_terms[]" value="<?php echo esc_attr( (string) $term->term_id ); ?>"></th>
						<td><label for="<?php echo esc_attr( $cb_id ); ?>"><?php echo esc_html( str_repeat( '— ', (int) $row['depth'] ) . $term->name ); ?></label></td>
						<td><?php echo esc_html( urldecode( $term->slug ) ); ?></td>
						<td><?php echo esc_html( (string) $term->count ); ?></td>
						<td>
							<?php if ( $page_id ) : ?>
								<?php
								$st = get_post_status( $page_id );
								echo '<strong>' . esc_html( get_the_title( $page_id ) ) . '</strong>';
								echo ' <span class="description">（' . esc_html( isset( $status_labels[ $st ] ) ? $status_labels[ $st ] : $st ) . '）</span><br>';
								echo '<a href="' . esc_url( get_permalink( $page_id ) ) . '" target="_blank" rel="noopener">' . esc_html__( '表示', 'category-post-table' ) . '</a>';
								$edit = get_edit_post_link( $page_id );
								if ( $edit ) {
									echo ' | <a href="' . esc_url( $edit ) . '">' . esc_html__( '編集', 'category-post-table' ) . '</a>';
								}
								?>
							<?php else : ?>
								<span class="description"><?php esc_html_e( '未作成', 'category-post-table' ); ?></span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<p>
				<label><input type="checkbox" name="cptl_overwrite" value="1"> <?php esc_html_e( '既存ページを上書き更新する（タイトル・本文・親ページ・公開状態を現在の設定で作り直します）', 'category-post-table' ); ?></label>
			</p>
			<p>
				<?php submit_button( __( '選択したカテゴリの固定ページを作成', 'category-post-table' ), 'primary', 'cptl_selected', false ); ?>
				&nbsp;
				<?php submit_button( __( 'すべてのカテゴリの固定ページを作成', 'category-post-table' ), 'secondary', 'cptl_all', false ); ?>
			</p>
		</form>
		<?php
	}
}
