<?php
/**
 * 設定値の既定値・取得・サニタイズ。
 *
 * @package CategoryPostTable
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CPTL_Settings {

	/** 並び順として許可する値 */
	const ORDERBY = array( 'date', 'modified', 'title', 'menu_order', 'ID', 'rand', 'comment_count' );

	/** 本文の処理方式 */
	const CONTENT_FILTERS = array( 'the_content', 'basic' );

	/** 固定ページの公開状態 */
	const PAGE_STATUSES = array( 'publish', 'draft', 'private' );

	/** カテゴリ削除時の動作 */
	const ON_DELETE = array( 'none', 'draft', 'trash' );

	/**
	 * 既定値。
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			// 固定ページ生成.
			'page_status'      => 'publish',
			'page_parent'      => 0,
			'title_template'   => '{category}の記事一覧',
			'slug_template'    => '{slug}-list',
			'auto_create'      => 0,
			'on_delete'        => 'draft',
			// 一覧表の表示.
			'orderby'          => 'date',
			'order'            => 'DESC',
			'posts_per_page'   => 0, // 0 = すべて.
			'include_children' => 0,
			'show_number'      => 1,
			'show_date'        => 1,
			'show_toc'         => 1,
			'show_thumbnail'   => 0,
			'show_description' => 1,
			'link_title'       => 1,
			'content_filter'   => 'the_content',
		);
	}

	/**
	 * 現在の設定（既定値で補完）。
	 *
	 * @return array
	 */
	public static function get() {
		$saved = get_option( CPTL_OPTION, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return wp_parse_args( $saved, self::defaults() );
	}

	/**
	 * 1項目だけ取得。
	 *
	 * @param string $key キー.
	 * @return mixed
	 */
	public static function value( $key ) {
		$all = self::get();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/**
	 * 保存時のサニタイズ。
	 *
	 * @param mixed $input 入力値.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$d   = self::defaults();
		$in  = is_array( $input ) ? $input : array();
		$out = array();

		$out['page_status'] = self::pick( $in, 'page_status', self::PAGE_STATUSES, $d['page_status'] );
		$out['page_parent'] = isset( $in['page_parent'] ) ? absint( $in['page_parent'] ) : 0;

		$title                 = isset( $in['title_template'] ) ? sanitize_text_field( $in['title_template'] ) : '';
		$out['title_template'] = '' !== $title ? $title : $d['title_template'];

		$slug                 = isset( $in['slug_template'] ) ? sanitize_text_field( $in['slug_template'] ) : '';
		$out['slug_template'] = '' !== $slug ? $slug : $d['slug_template'];

		$out['on_delete']      = self::pick( $in, 'on_delete', self::ON_DELETE, $d['on_delete'] );
		$out['orderby']        = self::pick( $in, 'orderby', self::ORDERBY, $d['orderby'] );
		$out['order']          = isset( $in['order'] ) && 'ASC' === strtoupper( (string) $in['order'] ) ? 'ASC' : 'DESC';
		$out['posts_per_page'] = isset( $in['posts_per_page'] ) ? max( 0, (int) $in['posts_per_page'] ) : 0;
		$out['content_filter'] = self::pick( $in, 'content_filter', self::CONTENT_FILTERS, $d['content_filter'] );

		foreach ( array( 'auto_create', 'include_children', 'show_number', 'show_date', 'show_toc', 'show_thumbnail', 'show_description', 'link_title' ) as $key ) {
			$out[ $key ] = empty( $in[ $key ] ) ? 0 : 1;
		}

		return $out;
	}

	/**
	 * 許可リストから値を選ぶ。
	 *
	 * @param array  $in       入力.
	 * @param string $key      キー.
	 * @param array  $allowed  許可値.
	 * @param string $fallback 既定値.
	 * @return string
	 */
	private static function pick( $in, $key, $allowed, $fallback ) {
		if ( isset( $in[ $key ] ) && in_array( (string) $in[ $key ], $allowed, true ) ) {
			return (string) $in[ $key ];
		}
		return $fallback;
	}

	/**
	 * ショートコード属性の真偽値を解釈。
	 *
	 * @param mixed $value 値.
	 * @return bool
	 */
	public static function to_bool( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}
		return in_array( strtolower( trim( (string) $value ) ), array( '1', 'true', 'yes', 'on' ), true );
	}
}
