<?php
/**
 * ショートコード [category_post_table] / [category_post_table_index]。
 *
 * @package CategoryPostTable
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CPTL_Shortcode {

	const TAG       = 'category_post_table';
	const INDEX_TAG = 'category_post_table_index';
	const STYLE     = 'cptl-frontend';

	/** 入れ子描画の防止用カウンタ */
	private static $depth = 0;

	/** 同一ページ内の表の通し番号（アンカー・ページ送り用） */
	private static $instance = 0;

	public static function init() {
		add_shortcode( self::TAG, array( __CLASS__, 'render' ) );
		add_shortcode( self::INDEX_TAG, array( __CLASS__, 'render_index' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_if_needed' ) );
	}

	/**
	 * 表示中のページにショートコードがあれば <head> で CSS を読み込む。
	 */
	public static function enqueue_if_needed() {
		wp_register_style( self::STYLE, CPTL_URL . 'assets/css/category-post-table.css', array(), CPTL_VERSION );

		if ( ! is_singular() ) {
			return;
		}
		$post = get_queried_object();
		if ( $post instanceof WP_Post && ( has_shortcode( $post->post_content, self::TAG ) || has_shortcode( $post->post_content, self::INDEX_TAG ) ) ) {
			wp_enqueue_style( self::STYLE );
		}
	}

	/**
	 * ウィジェット等 <head> 後に描画された場合のための保険。
	 */
	private static function ensure_style() {
		if ( ! wp_style_is( self::STYLE, 'registered' ) ) {
			wp_register_style( self::STYLE, CPTL_URL . 'assets/css/category-post-table.css', array(), CPTL_VERSION );
		}
		wp_enqueue_style( self::STYLE );
	}

	/**
	 * [category_post_table] の描画。
	 *
	 * @param array|string $atts 属性.
	 * @return string
	 */
	public static function render( $atts ) {
		// 一覧対象の記事本文の中に同じショートコードがあっても無限ループしないようにする.
		if ( self::$depth > 0 ) {
			return '';
		}

		$s    = CPTL_Settings::get();
		$atts = shortcode_atts(
			array(
				'category'         => '',
				'include_children' => $s['include_children'],
				'orderby'          => $s['orderby'],
				'order'            => $s['order'],
				'posts_per_page'   => $s['posts_per_page'],
				'show_number'      => $s['show_number'],
				'show_date'        => $s['show_date'],
				'show_toc'         => $s['show_toc'],
				'show_thumbnail'   => $s['show_thumbnail'],
				'show_description' => $s['show_description'],
				'link_title'       => $s['link_title'],
				'content_filter'   => $s['content_filter'],
				'date_format'      => '',
				'number_label'     => 'No.',
				'title_label'      => 'タイトル',
				'content_label'    => '本文',
				'empty_message'    => 'このカテゴリにはまだ記事がありません。',
			),
			$atts,
			self::TAG
		);

		$terms = self::resolve_terms( $atts['category'] );
		if ( empty( $terms ) ) {
			if ( current_user_can( 'edit_posts' ) ) {
				return '<p class="cptl-error">' . esc_html__( '［カテゴリ記事一覧表］指定されたカテゴリが見つかりません。ショートコードの category 属性を確認してください。', 'category-post-table' ) . '</p>';
			}
			return '';
		}

		self::ensure_style();
		++self::$instance;
		$uid = 'cptl-' . self::$instance;

		$per_page = (int) $atts['posts_per_page'];
		if ( $per_page <= 0 ) {
			$per_page = -1;
		}

		$page_param = 1 === self::$instance ? 'cptl_page' : 'cptl_page_' . self::$instance;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 表示用のページ番号のみ.
		$paged = ( -1 !== $per_page && isset( $_GET[ $page_param ] ) ) ? max( 1, absint( $_GET[ $page_param ] ) ) : 1;

		$orderby = in_array( $atts['orderby'], CPTL_Settings::ORDERBY, true ) ? $atts['orderby'] : 'date';
		$order   = 'ASC' === strtoupper( (string) $atts['order'] ) ? 'ASC' : 'DESC';

		$query_args = array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $per_page,
			'paged'               => $paged,
			'orderby'             => $orderby,
			'order'               => $order,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => ( -1 === $per_page ),
			'tax_query'           => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy'         => 'category',
					'field'            => 'term_id',
					'terms'            => wp_list_pluck( $terms, 'term_id' ),
					'include_children' => CPTL_Settings::to_bool( $atts['include_children'] ),
				),
			),
		);

		$current_id = get_the_ID();
		if ( $current_id ) {
			$query_args['post__not_in'] = array( (int) $current_id );
		}

		/**
		 * 一覧表のクエリ引数を変更するフィルター。
		 *
		 * @param array $query_args WP_Query 引数.
		 * @param array $atts       ショートコード属性.
		 */
		$query_args = apply_filters( 'cptl_query_args', $query_args, $atts );

		$q = new WP_Query( $query_args );

		$show_number = CPTL_Settings::to_bool( $atts['show_number'] );
		$show_date   = CPTL_Settings::to_bool( $atts['show_date'] );
		$show_toc    = CPTL_Settings::to_bool( $atts['show_toc'] );
		$show_thumb  = CPTL_Settings::to_bool( $atts['show_thumbnail'] );
		$link_title  = CPTL_Settings::to_bool( $atts['link_title'] );
		$filter_mode = in_array( $atts['content_filter'], CPTL_Settings::CONTENT_FILTERS, true ) ? $atts['content_filter'] : 'the_content';
		$date_format = '' !== $atts['date_format'] ? $atts['date_format'] : get_option( 'date_format' );
		$total       = ( -1 === $per_page ) ? (int) $q->post_count : (int) $q->found_posts;
		$offset      = ( -1 === $per_page ) ? 0 : ( $paged - 1 ) * $per_page;

		ob_start();

		echo '<div class="cptl-wrap" id="' . esc_attr( $uid ) . '">';

		// カテゴリ説明.
		if ( CPTL_Settings::to_bool( $atts['show_description'] ) && 1 === count( $terms ) && '' !== trim( $terms[0]->description ) ) {
			echo '<div class="cptl-description">' . wp_kses_post( wpautop( $terms[0]->description ) ) . '</div>';
		}

		if ( ! $q->have_posts() ) {
			echo '<p class="cptl-empty">' . esc_html( $atts['empty_message'] ) . '</p></div>';
			wp_reset_postdata();
			return ob_get_clean();
		}

		echo '<p class="cptl-count">' . esc_html( sprintf( '全 %d 件', $total ) ) . '</p>';

		// 目次（このページに表示される記事のタイトル一覧）.
		if ( $show_toc && $q->post_count > 1 ) {
			echo '<nav class="cptl-toc" aria-label="' . esc_attr__( '記事の目次', 'category-post-table' ) . '">';
			echo '<p class="cptl-toc-title">' . esc_html__( '目次', 'category-post-table' ) . '</p>';
			echo '<ol class="cptl-toc-list" start="' . esc_attr( (string) ( $offset + 1 ) ) . '">';
			foreach ( $q->posts as $p ) {
				echo '<li><a href="#' . esc_attr( $uid . '-post-' . $p->ID ) . '">' . esc_html( self::plain_title( $p ) ) . '</a></li>';
			}
			echo '</ol></nav>';
		}

		echo '<div class="cptl-table-wrap"><table class="cptl-table">';
		echo '<thead><tr>';
		if ( $show_number ) {
			echo '<th scope="col" class="cptl-col-no">' . esc_html( $atts['number_label'] ) . '</th>';
		}
		echo '<th scope="col" class="cptl-col-title">' . esc_html( $atts['title_label'] ) . '</th>';
		echo '<th scope="col" class="cptl-col-content">' . esc_html( $atts['content_label'] ) . '</th>';
		echo '</tr></thead><tbody>';

		$i = 0;
		while ( $q->have_posts() ) {
			$q->the_post();
			++$i;
			$post_id = get_the_ID();

			echo '<tr id="' . esc_attr( $uid . '-post-' . $post_id ) . '" class="cptl-row">';

			if ( $show_number ) {
				echo '<td class="cptl-col-no" data-label="' . esc_attr( $atts['number_label'] ) . '">' . esc_html( (string) ( $offset + $i ) ) . '</td>';
			}

			// タイトル列.
			echo '<td class="cptl-col-title" data-label="' . esc_attr( $atts['title_label'] ) . '">';
			$title = esc_html( self::plain_title( get_post() ) );
			if ( $link_title ) {
				echo '<a class="cptl-title" href="' . esc_url( get_permalink() ) . '">' . $title . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			} else {
				echo '<span class="cptl-title">' . $title . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			}
			if ( $show_date ) {
				echo '<span class="cptl-date"><time datetime="' . esc_attr( get_the_date( 'c' ) ) . '">' . esc_html( get_the_date( $date_format ) ) . '</time></span>';
			}
			if ( $show_thumb && has_post_thumbnail() ) {
				echo '<div class="cptl-thumb">' . get_the_post_thumbnail( $post_id, 'thumbnail', array( 'loading' => 'lazy' ) ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</td>';

			// 本文（全文）列.
			echo '<td class="cptl-col-content" data-label="' . esc_attr( $atts['content_label'] ) . '"><div class="cptl-content">';
			echo self::full_content( $post_id, $filter_mode ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the_content 相当の出力.
			echo '</div></td>';

			echo '</tr>';
		}

		echo '</tbody></table></div>';

		// ページ送り.
		if ( -1 !== $per_page && $q->max_num_pages > 1 ) {
			$links = paginate_links(
				array(
					'base'         => add_query_arg( $page_param, '%#%' ),
					'format'       => '',
					'current'      => $paged,
					'total'        => (int) $q->max_num_pages,
					'prev_text'    => '&laquo; ' . esc_html__( '前へ', 'category-post-table' ),
					'next_text'    => esc_html__( '次へ', 'category-post-table' ) . ' &raquo;',
					'add_fragment' => '#' . $uid,
					'type'         => 'plain',
				)
			);
			if ( $links ) {
				echo '<nav class="cptl-pagination" aria-label="' . esc_attr__( '一覧のページ送り', 'category-post-table' ) . '">' . $links . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- paginate_links はエスケープ済み.
			}
		}

		echo '</div>';

		wp_reset_postdata();

		return ob_get_clean();
	}

	/**
	 * 記事の全文を取得（<!--more--> 以降も含む）。
	 *
	 * @param int    $post_id 記事 ID.
	 * @param string $mode    the_content | basic.
	 * @return string
	 */
	private static function full_content( $post_id, $mode ) {
		if ( post_password_required( $post_id ) ) {
			return get_the_password_form( $post_id );
		}

		$raw = (string) get_post_field( 'post_content', $post_id, 'raw' );
		// 全文表示なので「続きを読む」「改ページ」の区切り記号は取り除く.
		$raw = preg_replace( '/<!--(more|nextpage)(.*?)?-->/', '', $raw );

		++self::$depth;
		if ( 'basic' === $mode ) {
			$html = self::basic_content_filter( $raw );
		} else {
			$html = apply_filters( 'the_content', $raw ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core hook.
			$html = str_replace( ']]>', ']]&gt;', $html );
		}
		--self::$depth;

		/**
		 * 一覧表に出力する本文を変更するフィルター。
		 *
		 * @param string $html    本文 HTML.
		 * @param int    $post_id 記事 ID.
		 */
		return apply_filters( 'cptl_post_content', $html, $post_id );
	}

	/**
	 * WordPress 標準の整形処理だけを行う（他プラグインが the_content に追加する装飾を除外したい場合用）。
	 *
	 * @param string $content 本文.
	 * @return string
	 */
	private static function basic_content_filter( $content ) {
		global $wp_embed;

		$has_blocks = function_exists( 'has_blocks' ) && has_blocks( $content );
		if ( $has_blocks ) {
			$content = do_blocks( $content );
		}
		if ( isset( $wp_embed ) && $wp_embed instanceof WP_Embed ) {
			$content = $wp_embed->run_shortcode( $content );
			$content = $wp_embed->autoembed( $content );
		}
		$content = wptexturize( $content );
		if ( ! $has_blocks ) {
			$content = wpautop( $content );
		}
		$content = shortcode_unautop( $content );
		$content = do_shortcode( $content );
		$content = convert_smilies( $content );
		if ( function_exists( 'wp_filter_content_tags' ) ) {
			$content = wp_filter_content_tags( $content );
		}
		return str_replace( ']]>', ']]&gt;', $content );
	}

	/**
	 * HTML を含まない表示用タイトル。
	 *
	 * @param WP_Post $post 記事.
	 * @return string
	 */
	private static function plain_title( $post ) {
		$title = wp_strip_all_tags( get_the_title( $post ) );
		if ( '' === $title ) {
			$title = __( '（無題）', 'category-post-table' );
		}
		return html_entity_decode( $title, ENT_QUOTES, get_bloginfo( 'charset' ) );
	}

	/**
	 * category 属性（ID またはスラッグ、カンマ区切り可）をタームに変換。
	 *
	 * @param string $value 属性値.
	 * @return WP_Term[]
	 */
	private static function resolve_terms( $value ) {
		$terms = array();
		foreach ( array_filter( array_map( 'trim', explode( ',', (string) $value ) ), 'strlen' ) as $item ) {
			if ( ctype_digit( $item ) ) {
				$term = get_term( (int) $item, 'category' );
			} else {
				$term = get_term_by( 'slug', sanitize_title( $item ), 'category' );
				if ( ! $term ) {
					$term = get_term_by( 'name', $item, 'category' );
				}
			}
			if ( $term instanceof WP_Term ) {
				$terms[ $term->term_id ] = $term;
			}
		}
		return array_values( $terms );
	}

	/**
	 * [category_post_table_index]：生成済みの各カテゴリ一覧ページへのリンク集。
	 *
	 * @param array|string $atts 属性.
	 * @return string
	 */
	public static function render_index( $atts ) {
		$atts = shortcode_atts(
			array(
				'show_count' => '1',
				'hide_empty' => '0',
			),
			$atts,
			self::INDEX_TAG
		);

		$terms = get_terms(
			array(
				'taxonomy'   => 'category',
				'hide_empty' => CPTL_Settings::to_bool( $atts['hide_empty'] ),
				'orderby'    => 'name',
			)
		);
		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return '';
		}

		$items = array();
		foreach ( CPTL_Page_Generator::sort_hierarchically( $terms ) as $row ) {
			$term    = $row['term'];
			$page_id = CPTL_Page_Generator::get_page_id( $term->term_id );
			if ( ! $page_id || 'publish' !== get_post_status( $page_id ) ) {
				continue;
			}
			$label = esc_html( $term->name );
			if ( CPTL_Settings::to_bool( $atts['show_count'] ) ) {
				$label .= ' <span class="cptl-index-count">(' . esc_html( (string) $term->count ) . ')</span>';
			}
			$items[] = '<li class="cptl-index-depth-' . (int) $row['depth'] . '"><a href="' . esc_url( get_permalink( $page_id ) ) . '">' . $label . '</a></li>';
		}

		if ( empty( $items ) ) {
			return '';
		}

		self::ensure_style();
		return '<ul class="cptl-index">' . implode( '', $items ) . '</ul>';
	}
}
