<?php
/**
 * Plugin Name:       Category Post Table（カテゴリ記事一覧表）
 * Description:       カテゴリごとに「タイトル」と「記事全文」を表形式で一覧表示する固定ページを作成します。ショートコード [category_post_table] と、カテゴリごとの固定ページ一括生成機能を備えています。
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Category Post Table
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       category-post-table
 *
 * @package CategoryPostTable
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CPTL_VERSION', '1.0.0' );
define( 'CPTL_FILE', __FILE__ );
define( 'CPTL_DIR', plugin_dir_path( __FILE__ ) );
define( 'CPTL_URL', plugin_dir_url( __FILE__ ) );
define( 'CPTL_OPTION', 'cptl_settings' );
define( 'CPTL_TERM_META', '_cptl_page_id' );
define( 'CPTL_PAGE_META', '_cptl_category_id' );

require_once CPTL_DIR . 'includes/class-cptl-settings.php';
require_once CPTL_DIR . 'includes/class-cptl-shortcode.php';
require_once CPTL_DIR . 'includes/class-cptl-page-generator.php';
require_once CPTL_DIR . 'includes/class-cptl-admin.php';

add_action(
	'plugins_loaded',
	static function () {
		CPTL_Shortcode::init();
		CPTL_Page_Generator::init();
		if ( is_admin() ) {
			CPTL_Admin::init();
		}
	}
);

/**
 * 有効化時：既定値を保存（既存設定は保持）。
 */
register_activation_hook(
	__FILE__,
	static function () {
		if ( false === get_option( CPTL_OPTION, false ) ) {
			add_option( CPTL_OPTION, CPTL_Settings::defaults() );
		}
	}
);
