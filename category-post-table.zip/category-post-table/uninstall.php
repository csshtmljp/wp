<?php
/**
 * プラグイン削除時の後片付け。
 * 設定と紐付け情報のみ削除し、作成された固定ページ自体は残します（誤って内容を失わないため）。
 *
 * @package CategoryPostTable
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'cptl_settings' );
delete_metadata( 'term', 0, '_cptl_page_id', '', true );
delete_metadata( 'post', 0, '_cptl_category_id', '', true );
