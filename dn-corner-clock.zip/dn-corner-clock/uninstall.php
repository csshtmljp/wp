<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// Preserve preferences so reinstalling restores the user's display settings.
