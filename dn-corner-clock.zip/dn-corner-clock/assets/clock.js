(function (global) {
  'use strict';

  // Network timing is measured with a monotonic clock, not the device wall clock.
  function parseSample(payload, requestId, start, end) {
    const data = payload && payload.success === true && payload.data;
    if (!data || data.request_id !== requestId || data.source !== 'wordpress-server') throw new Error('stale-response');
    const received = data.received_ms;
    const sent = data.sent_ms;
    if (!Number.isFinite(received) || !Number.isFinite(sent) || received < 946684800000 || sent > 4102444800000) throw new Error('invalid-time');
    const rtt = end - start;
    const processing = sent - received;
    if (!Number.isFinite(rtt) || rtt < 0 || rtt > 8000 || processing < 0 || processing > 60000 || processing > rtt + 50) throw new Error('invalid-timing');
    const network = Math.max(0, rtt - processing);
    return { epochMs: sent + network / 2, monoMs: end, rttMs: rtt, networkMs: network };
  }

  class ClockModel {
    constructor() { this.anchor = null; this.failed = false; }
    apply(sample) { this.anchor = sample; this.failed = false; }
    invalidate() { this.anchor = null; this.failed = true; }
    now(mono, device) {
      return this.anchor && mono >= this.anchor.monoMs ? this.anchor.epochMs + mono - this.anchor.monoMs : device;
    }
    state(mono, ttl) {
      if (!this.anchor || mono < this.anchor.monoMs) return 'device';
      return this.failed || mono - this.anchor.monoMs > ttl ? 'holdover' : 'synced';
    }
  }

  function makeFormatters(zone, seconds) {
    let fallback = false;
    try { new Intl.DateTimeFormat('ja-JP', { timeZone: zone }).format(0); }
    catch (_) { zone = 'UTC'; fallback = true; }
    return {
      zone: zone, fallback: fallback,
      time: new Intl.DateTimeFormat('ja-JP', { timeZone: zone, hour: '2-digit', minute: '2-digit', second: seconds ? '2-digit' : undefined, hourCycle: 'h23' }),
      date: new Intl.DateTimeFormat('ja-JP', { timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit', weekday: 'short' })
    };
  }

  function mount(root, env) {
    if (!root || root.dataset.initialized === '1') return;
    root.dataset.initialized = '1';
    let config;
    try { config = JSON.parse(root.dataset.config); } catch (_) { return; }
    const doc = env.document;
    const timeEl = root.querySelector('.dncc-time');
    const dateEl = root.querySelector('.dncc-date');
    const status = root.querySelector('.dncc-status');
    const statusText = root.querySelector('.dncc-status-text');
    const syncButton = root.querySelector('.dncc-sync');
    const toggleButton = root.querySelector('.dncc-toggle');
    const label = root.querySelector('.dncc-label');
    if (!timeEl || !dateEl || !status || !statusText || !syncButton || !toggleButton || !label) return;
    if (!env.Intl || !env.performance || typeof env.performance.now !== 'function') {
      statusText.textContent = 'このブラウザーでは時刻を表示できません'; return;
    }
    const formats = makeFormatters(config.timezone || 'Asia/Tokyo', config.seconds !== false);
    label.textContent = formats.fallback ? 'UTC（指定地域に非対応）' : config.label || formats.zone;
    const interval = [60, 300, 600, 1800].includes(Number(config.interval)) ? Number(config.interval) * 1000 : 300000;
    const model = new ClockModel();
    let pending = false;
    let lastAttempt = -Infinity;
    let retryTimer = null;
    let tickTimer = null;
    let stopped = false;
    let generation = 0;
    let activeController = null;
    let previousMono = env.performance.now();
    let previousWall = Date.now();
    let hiddenAt = null;

    function paint() {
      const mono = env.performance.now();
      const value = model.now(mono, Date.now());
      const date = new Date(value);
      const state = model.state(mono, interval + 30000);
      timeEl.textContent = formats.time.format(date);
      timeEl.dateTime = date.toISOString();
      dateEl.textContent = config.date !== false ? formats.date.format(date) : '';
      dateEl.hidden = config.date === false;
      root.dataset.state = pending ? 'pending' : state;
      status.hidden = !pending && state === 'synced' && config.showStatus === false;
      statusText.textContent = pending ? (model.anchor ? '再同期中' : '同期中・端末時刻') : state === 'synced' ? 'サーバー同期' : state === 'holdover' ? '前回同期から計時' : '未同期・端末時刻';
      if (model.anchor) {
        status.title = '同期時刻 ' + formats.time.format(new Date(model.anchor.epochMs)) + ' / 通信往復 ' + Math.round(model.anchor.rttMs) + 'ms / 推定片道 ' + Math.round(model.anchor.networkMs / 2) + 'ms。絶対精度の保証値ではありません。';
      } else { status.title = 'サイトのサーバー時刻を取得できるまで端末の時計を表示します。'; }
    }

    function queueSync(delay) {
      env.clearTimeout(retryTimer);
      if (!stopped && !doc.hidden) retryTimer = env.setTimeout(function () { synchronize(false); }, delay);
    }

    function requestId() {
      if (env.crypto && typeof env.crypto.randomUUID === 'function') return env.crypto.randomUUID();
      return 'dncc-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2) + '-request';
    }

    async function sample() {
      const id = requestId();
      const controller = new env.AbortController();
      activeController = controller;
      const timer = env.setTimeout(function () { controller.abort(); }, 6000);
      const start = env.performance.now();
      try {
        const response = await env.fetch(config.endpoint, {
          method: 'POST', credentials: 'same-origin', cache: 'no-store',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' },
          body: new env.URLSearchParams({ action: 'dn_corner_clock_time', request_id: id }).toString(),
          signal: controller.signal, redirect: 'error'
        });
        if (!response.ok) throw new Error('http-' + response.status);
        const payload = await response.json();
        return parseSample(payload, id, start, env.performance.now());
      } finally { env.clearTimeout(timer); if (activeController === controller) activeController = null; }
    }

    async function synchronize(initial) {
      if (pending || stopped || doc.hidden) return;
      const mono = env.performance.now();
      if (mono - lastAttempt < 10000) { queueSync(10000 - (mono - lastAttempt)); return; }
      if (typeof env.fetch !== 'function' || typeof env.AbortController !== 'function' || typeof env.URLSearchParams !== 'function' || env.navigator.onLine === false) {
        model.failed = true; paint(); queueSync(60000); return;
      }
      pending = true; lastAttempt = mono; syncButton.disabled = true; paint();
      const ownGeneration = generation;
      let best = null;
      const count = initial || !model.anchor ? 2 : 1;
      try {
        for (let i = 0; i < count && !stopped && !doc.hidden; i += 1) {
          try {
            const next = await sample();
            if (ownGeneration !== generation || stopped || doc.hidden) break;
            if (!best || next.networkMs < best.networkMs) { best = next; model.apply(next); paint(); }
          } catch (_) { /* The second attempt may still succeed. */ }
        }
        if (!best && ownGeneration === generation) model.failed = true;
      } finally {
        pending = false; syncButton.disabled = false;
        if (!stopped) { paint(); queueSync(ownGeneration !== generation ? 0 : best ? interval : Math.min(60000, interval)); }
      }
    }

    function tick() {
      if (stopped || doc.hidden) return;
      const mono = env.performance.now();
      const wall = Date.now();
      if (Math.abs((wall - previousWall) - (mono - previousMono)) > 2000) {
        // Sleep and wall-clock edits cannot always be distinguished. Mark the
        // previous synchronization uncertain and re-check, without silently
        // claiming that the resumed clock is still synchronized.
        model.failed = true; synchronize(false);
      }
      previousMono = mono; previousWall = wall;
      paint();
      const value = model.now(mono, wall);
      const delay = Math.max(50, Math.min(1000, 1000 - ((value % 1000 + 1000) % 1000) + 8));
      tickTimer = env.setTimeout(tick, delay);
    }

    function resume() {
      stopped = false;
      env.clearTimeout(tickTimer);
      const mono = env.performance.now();
      if (hiddenAt && Math.abs((Date.now() - hiddenAt.wall) - (mono - hiddenAt.mono)) > 2000) model.invalidate();
      hiddenAt = null; previousMono = mono; previousWall = Date.now();
      tick(); synchronize(false);
    }
    doc.addEventListener('visibilitychange', function () {
      env.clearTimeout(tickTimer); env.clearTimeout(retryTimer);
      if (doc.hidden) { generation += 1; if (activeController) activeController.abort(); hiddenAt = { mono: env.performance.now(), wall: Date.now() }; }
      else { resume(); }
    });
    env.addEventListener('pageshow', function (event) { if (event.persisted) { model.failed = true; resume(); } });
    env.addEventListener('pagehide', function () { stopped = true; generation += 1; if (activeController) activeController.abort(); hiddenAt = { mono: env.performance.now(), wall: Date.now() }; env.clearTimeout(tickTimer); env.clearTimeout(retryTimer); });
    env.addEventListener('online', function () { synchronize(false); });
    env.addEventListener('offline', function () { model.failed = true; paint(); });
    syncButton.addEventListener('click', function () { synchronize(false); });
    toggleButton.addEventListener('click', function () {
      const compact = root.classList.toggle('dncc-compact');
      toggleButton.textContent = compact ? '＋' : '−';
      toggleButton.setAttribute('aria-expanded', compact ? 'false' : 'true');
      toggleButton.setAttribute('aria-label', compact ? '時計を通常の大きさに戻す' : '時計を小さく表示');
      toggleButton.title = compact ? '通常表示' : '小さく表示';
    });
    syncButton.hidden = false; toggleButton.hidden = false;
    tick(); synchronize(true);
    return { model: model, synchronize: synchronize, paint: paint };
  }

  if (typeof module === 'object' && module.exports) {
    module.exports = { parseSample: parseSample, ClockModel: ClockModel, makeFormatters: makeFormatters, mount: mount };
  } else {
    const start = function () { mount(global.document.getElementById('dn-corner-clock'), global); };
    if (global.document.readyState === 'loading') global.document.addEventListener('DOMContentLoaded', start, { once: true });
    else start();
  }
})(typeof window !== 'undefined' ? window : globalThis);
