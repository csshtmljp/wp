<?php
/**
 * Plugin Name: DN Corner Clock — 左下の同期時計
 * Description: 画面左下に日本時間を秒単位で表示。サイトのサーバー時刻と同期し、通信遅延を補正します。
 * Version: 1.0.0
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Author: DN
 * License: GPL-2.0-or-later
 * Text Domain: dn-corner-clock
 */
if (!defined('ABSPATH')) { exit; }

final class DN_Corner_Clock {
    const VERSION = '1.0.0';
    const OPTION = 'dn_corner_clock';

    public static function defaults() {
        return array('enabled' => 1, 'timezone' => 'Asia/Tokyo', 'label' => '日本時間', 'seconds' => 1, 'date' => 1, 'status' => 1, 'theme' => 'dark', 'size' => 26, 'left' => 16, 'bottom' => 16, 'interval' => 300, 'zindex' => 9999);
    }
    public static function settings() { return wp_parse_args(get_option(self::OPTION, array()), self::defaults()); }
    public static function activate() { add_option(self::OPTION, self::defaults(), '', false); }
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'assets'));
        add_action('wp_footer', array($this, 'render'), 5);
        add_action('wp_ajax_dn_corner_clock_time', array($this, 'time_response'));
        add_action('wp_ajax_nopriv_dn_corner_clock_time', array($this, 'time_response'));
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'links'));
    }
    public function links($links) {
        array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=dn-corner-clock')) . '">設定</a>');
        return $links;
    }
    public function menu() { add_options_page('DN 左下時計', 'DN 左下時計', 'manage_options', 'dn-corner-clock', array($this, 'settings_page')); }
    public function register_settings() {
        register_setting('dn_corner_clock_group', self::OPTION, array('type' => 'array', 'sanitize_callback' => array($this, 'sanitize'), 'default' => self::defaults()));
    }
    public function sanitize($input) {
        $input = is_array($input) ? $input : array();
        $old = self::settings(); $out = self::defaults();
        foreach (array('enabled', 'seconds', 'date', 'status') as $key) { $out[$key] = !empty($input[$key]) && '1' === (string) (is_scalar($input[$key]) ? $input[$key] : '') ? 1 : 0; }
        $zone = isset($input['timezone']) && is_string($input['timezone']) ? sanitize_text_field($input['timezone']) : '';
        if (!in_array($zone, timezone_identifiers_list(), true) && 'UTC' !== $zone) {
            $zone = $old['timezone'];
            if (function_exists('add_settings_error')) { add_settings_error(self::OPTION, 'invalid_zone', 'タイムゾーンが無効なため、以前の設定を維持しました。'); }
        }
        $out['timezone'] = $zone;
        $label = isset($input['label']) && is_string($input['label']) ? sanitize_text_field($input['label']) : '';
        $out['label'] = function_exists('mb_substr') ? mb_substr($label, 0, 40) : $label;
        if (strlen($out['label']) > 160) { $out['label'] = ''; }
        $out['theme'] = isset($input['theme']) && 'light' === $input['theme'] ? 'light' : 'dark';
        foreach (array('size' => array(16, 48), 'left' => array(0, 300), 'bottom' => array(0, 300), 'zindex' => array(1, 2147483000)) as $key => $range) {
            $value = isset($input[$key]) && is_scalar($input[$key]) && is_numeric($input[$key]) ? (int) $input[$key] : $old[$key];
            $out[$key] = max($range[0], min($range[1], $value));
        }
        $interval = isset($input['interval']) && is_scalar($input['interval']) ? (int) $input['interval'] : 300;
        $out['interval'] = in_array($interval, array(60, 300, 600, 1800), true) ? $interval : 300;
        return $out;
    }
    public function assets() {
        if (is_admin() || is_feed() || !self::settings()['enabled']) { return; }
        wp_enqueue_style('dn-corner-clock', plugins_url('assets/clock.css', __FILE__), array(), self::VERSION);
        wp_enqueue_script('dn-corner-clock', plugins_url('assets/clock.js', __FILE__), array(), self::VERSION, array('in_footer' => true, 'strategy' => 'defer'));
    }
    public function render() {
        static $rendered = false;
        $s = self::settings();
        if ($rendered || is_admin() || is_feed() || !$s['enabled']) { return; }
        $rendered = true;
        $config = array('endpoint' => wp_make_link_relative(admin_url('admin-ajax.php')), 'timezone' => $s['timezone'], 'label' => $s['label'], 'seconds' => (bool) $s['seconds'], 'date' => (bool) $s['date'], 'showStatus' => (bool) $s['status'], 'interval' => (int) $s['interval']);
        $style = sprintf('--dncc-left:%dpx;--dncc-bottom:%dpx;--dncc-size:%dpx;--dncc-z:%d;', $s['left'], $s['bottom'], $s['size'], $s['zindex']);
        ?>
        <aside id="dn-corner-clock" class="dncc dncc-<?php echo esc_attr($s['theme']); ?>" data-config="<?php echo esc_attr(wp_json_encode($config)); ?>" data-state="pending" style="<?php echo esc_attr($style); ?>" aria-label="現在時刻" lang="ja" dir="ltr">
            <div class="dncc-heading"><span class="dncc-label"><?php echo esc_html($s['label'] ?: $s['timezone']); ?></span><div class="dncc-controls"><button type="button" class="dncc-sync" aria-label="サーバー時刻に再同期" title="再同期" hidden>↻</button><button type="button" class="dncc-toggle" aria-label="時計を小さく表示" aria-expanded="true" title="小さく表示" hidden>−</button></div></div>
            <time class="dncc-time" role="timer" aria-live="off">--:--<?php echo $s['seconds'] ? ':--' : ''; ?></time>
            <div class="dncc-date"<?php echo $s['date'] ? '' : ' hidden'; ?>></div>
            <span class="dncc-status"><span class="dncc-dot" aria-hidden="true"></span><span class="dncc-status-text">時計を準備中</span></span>
            <noscript><span class="dncc-noscript">時刻表示にはJavaScriptが必要です。</span></noscript>
        </aside>
        <?php
    }
    /** Public read-only endpoint. No login, secrets, write operation or WP nonce required. */
    public function time_payload($request_id) {
        $now = microtime(true) * 1000;
        $received = isset($_SERVER['REQUEST_TIME_FLOAT']) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] * 1000 : $now;
        // Reject server clock jumps during PHP startup; the client retries later.
        if ($received > $now || $now - $received > 60000) { return new WP_Error('clock_changed', 'サーバー時刻を再取得してください。'); }
        return array('request_id' => $request_id, 'received_ms' => $received, 'sent_ms' => $now, 'source' => 'wordpress-server');
    }
    public function time_response() {
        nocache_headers();
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Surrogate-Control: no-store');
        header('X-Content-Type-Options: nosniff');
        if (!isset($_SERVER['REQUEST_METHOD']) || 'POST' !== $_SERVER['REQUEST_METHOD']) {
            header('Allow: POST'); wp_send_json_error(array('message' => 'POST is required.'), 405);
        }
        $id = isset($_POST['request_id']) && is_string($_POST['request_id']) ? wp_unslash($_POST['request_id']) : '';
        if (!preg_match('/^[a-zA-Z0-9-]{12,80}$/D', $id)) { wp_send_json_error(array('message' => 'Invalid request ID.'), 400); }
        $payload = $this->time_payload($id);
        if (is_wp_error($payload)) { wp_send_json_error(array('message' => $payload->get_error_message()), 503); }
        wp_send_json_success($payload);
    }
    public function settings_page() {
        if (!current_user_can('manage_options')) { return; }
        $s = self::settings();
        $zones = array('Asia/Tokyo' => '日本時間（Asia/Tokyo）', 'UTC' => '協定世界時（UTC）', 'Asia/Seoul' => '韓国（Asia/Seoul）', 'Asia/Shanghai' => '中国（Asia/Shanghai）', 'Asia/Taipei' => '台湾（Asia/Taipei）', 'Asia/Singapore' => 'シンガポール', 'Asia/Kolkata' => 'インド', 'Europe/London' => 'ロンドン', 'Europe/Paris' => 'パリ', 'America/New_York' => 'ニューヨーク', 'America/Los_Angeles' => 'ロサンゼルス', 'Pacific/Honolulu' => 'ハワイ', 'Australia/Sydney' => 'シドニー');
        if (!isset($zones[$s['timezone']])) { $zones[$s['timezone']] = $s['timezone']; }
        ?>
        <div class="wrap" style="max-width:940px"><h1>DN 左下時計</h1><p>公開サイトの左下に、サーバー時刻と同期する時計を表示します。初期設定は日本時間・秒表示です。</p>
        <?php settings_errors(); ?>
        <form action="options.php" method="post"><?php settings_fields('dn_corner_clock_group'); ?>
        <table class="form-table" role="presentation"><tbody>
        <tr><th scope="row">時計の表示</th><td><label><input type="checkbox" name="dn_corner_clock[enabled]" value="1" <?php checked($s['enabled']); ?>> 公開サイトの左下に表示する</label></td></tr>
        <tr><th scope="row"><label for="dncc-zone">タイムゾーン</label></th><td><select id="dncc-zone" name="dn_corner_clock[timezone]"><?php foreach ($zones as $value => $label) { echo '<option value="' . esc_attr($value) . '" ' . selected($s['timezone'], $value, false) . '>' . esc_html($label) . '</option>'; } ?></select><p class="description">夏時間がある地域はブラウザーのタイムゾーン情報に従います。</p></td></tr>
        <tr><th scope="row"><label for="dncc-label">時計の見出し</label></th><td><input id="dncc-label" name="dn_corner_clock[label]" value="<?php echo esc_attr($s['label']); ?>" type="text" maxlength="40" class="regular-text"><p class="description">例：日本時間。空欄ならタイムゾーン名を表示します。</p></td></tr>
        <tr><th scope="row">表示内容</th><td><?php foreach (array('seconds' => '秒まで表示する', 'date' => '日付と曜日を表示する', 'status' => '正常時も同期状態を表示する') as $key => $label) { echo '<p><label><input type="checkbox" name="dn_corner_clock[' . esc_attr($key) . ']" value="1" ' . checked($s[$key], 1, false) . '> ' . esc_html($label) . '</label></p>'; } ?><p class="description">未同期・再同期が必要な場合の状態は常に表示します。</p></td></tr>
        <tr><th scope="row"><label for="dncc-theme">配色</label></th><td><select id="dncc-theme" name="dn_corner_clock[theme]"><option value="dark" <?php selected($s['theme'], 'dark'); ?>>ダーク</option><option value="light" <?php selected($s['theme'], 'light'); ?>>ライト</option></select></td></tr>
        <?php foreach (array('size' => array('時刻の文字サイズ', 16, 48, 'px'), 'left' => array('左端からの距離', 0, 300, 'px'), 'bottom' => array('下端からの距離', 0, 300, 'px'), 'zindex' => array('重なり順', 1, 2147483000, '')) as $key => $field) { ?><tr><th scope="row"><label for="dncc-<?php echo esc_attr($key); ?>"><?php echo esc_html($field[0]); ?></label></th><td><input type="number" id="dncc-<?php echo esc_attr($key); ?>" name="dn_corner_clock[<?php echo esc_attr($key); ?>]" min="<?php echo esc_attr($field[1]); ?>" max="<?php echo esc_attr($field[2]); ?>" value="<?php echo esc_attr($s[$key]); ?>" class="small-text"> <?php echo esc_html($field[3]); ?></td></tr><?php } ?>
        <tr><th scope="row"><label for="dncc-interval">再同期の間隔</label></th><td><select id="dncc-interval" name="dn_corner_clock[interval]"><?php foreach (array(60 => '1分', 300 => '5分（標準）', 600 => '10分', 1800 => '30分') as $value => $label) { echo '<option value="' . esc_attr($value) . '" ' . selected($s['interval'], $value, false) . '>' . esc_html($label) . '</option>'; } ?></select></td></tr>
        </tbody></table><?php submit_button('設定を保存'); ?></form>
        <hr><h2>時刻の合わせ方</h2><p>ページ表示時にサーバー時刻を取得し、往復通信時間とサーバー処理時間から通信遅延を推定して補正します。以降は端末の時計変更に影響されにくい経過時間を使って秒表示を進め、定期的に再同期します。</p><p><strong>標準時との一致は、サーバー側の時刻同期状態と通信環境に依存します。</strong>サーバーの時計がずれている場合は、ホスティング会社の時刻同期設定を確認してください。原子時計やNICTへ直接接続するプラグインではありません。</p><p>同期失敗時は「前回同期から計時」または「未同期・端末時刻」と明示します。ページを開き直したときも新しく同期します。Cookie・広告・外部API・APIキーは使用しません。</p><p>「↻」は手動再同期、「− / ＋」は時計の縮小・展開です。画面端のセーフエリアを考慮します。ほかの固定ボタンに重なる場合は、左端／下端からの距離を調整してください。</p><p>テーマに <code>wp_footer()</code> が必要です。設定後に表示が変わらない場合はサイトのキャッシュを消去してください。<code>admin-ajax.php</code> の本プラグインの時刻リクエストをキャッシュ・遮断しないでください。</p></div>
        <?php
    }
}
register_activation_hook(__FILE__, array('DN_Corner_Clock', 'activate'));
new DN_Corner_Clock();
