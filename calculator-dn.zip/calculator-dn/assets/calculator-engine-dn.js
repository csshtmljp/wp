/* 電卓dn 1.0.0 | GPL-2.0-or-later | A limited arithmetic parser, no code execution. */
(function (root, factory) {
    'use strict';
    var api = factory();
    if (typeof module === 'object' && module.exports) module.exports = api;
    else root.CalculatorDnMath = api;
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
    'use strict';
    function finite(value) {
        if (!Number.isFinite(value)) throw new Error('計算できる数値の範囲を超えています。');
        return Object.is(value, -0) ? 0 : value;
    }
    function round(value) {
        return finite(Number(finite(value).toPrecision(15)));
    }
    function normalize(source) {
        return String(source).replace(/[！-～]/g, function (c) { return String.fromCharCode(c.charCodeAt(0) - 0xFEE0); })
            .replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/√/g, 'sqrt');
    }
    function evaluate(source) {
        if (typeof source !== 'string' || source.length > 256) throw new Error('計算式は256文字以内で入力してください。');
        var text = normalize(source), tokens = [], at = 0, cursor = 0, depth = 0;
        while (cursor < text.length) {
            var rest = text.slice(cursor), match;
            if (/^\s/.test(rest)) { cursor++; continue; }
            if ((match = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/.exec(rest))) {
                tokens.push({ type: 'number', value: finite(Number(match[0])) }); cursor += match[0].length;
            } else if (rest.slice(0, 4).toLowerCase() === 'sqrt') {
                tokens.push({ type: 'sqrt' }); cursor += 4;
            } else if (/^[+\-*/^()%]/.test(rest)) {
                tokens.push({ type: rest[0] }); cursor++;
            } else { throw new Error('数字・四則演算・括弧・%・^・sqrt を入力してください。'); }
        }
        if (!tokens.length) throw new Error('計算式を入力してください。');
        function take(type) {
            if (tokens[at] && tokens[at].type === type) { at++; return true; }
            return false;
        }
        function nested(fn) {
            depth++;
            if (depth > 32) throw new Error('括弧や演算の入れ子が多すぎます。');
            var value = fn(); depth--; return value;
        }
        function sum() {
            var value = product();
            while (at < tokens.length) {
                if (take('+')) value = finite(value + product());
                else if (take('-')) value = finite(value - product());
                else break;
            }
            return value;
        }
        function product() {
            var value = unary(), divisor;
            while (at < tokens.length) {
                if (take('*')) value = finite(value * unary());
                else if (take('/')) {
                    divisor = unary();
                    if (divisor === 0) throw new Error('0では割れません。');
                    value = finite(value / divisor);
                } else break;
            }
            return value;
        }
        function unary() {
            if (take('+')) return nested(unary);
            if (take('-')) return -nested(unary);
            return power();
        }
        function power() {
            var value = postfix();
            if (take('^')) {
                var exponent = nested(unary);
                if (value === 0 && exponent < 0) throw new Error('0では割れません。');
                value = Math.pow(value, exponent);
                if (Number.isNaN(value)) throw new Error('実数で計算できない式です。');
            }
            return finite(value);
        }
        function postfix() {
            var value = primary();
            if (take('%')) value /= 100;
            return value;
        }
        function primary() {
            var token = tokens[at], value;
            if (!token) throw new Error('式の末尾に数値が必要です。');
            if (take('number')) return token.value;
            if (take('(')) {
                value = nested(sum);
                if (!take(')')) throw new Error('閉じ括弧「)」が必要です。');
                return value;
            }
            if (take('sqrt')) {
                if (!take('(')) throw new Error('平方根は sqrt(9) のように入力してください。');
                value = nested(sum);
                if (!take(')')) throw new Error('閉じ括弧「)」が必要です。');
                if (value < 0) throw new Error('負数の平方根は計算できません。');
                return Math.sqrt(value);
            }
            throw new Error('数値または開き括弧が必要です。');
        }
        var answer = sum();
        if (at !== tokens.length) throw new Error('式を確認してください。掛け算には「×」または「*」が必要です。');
        return round(answer);
    }
    function format(value) { return String(round(value)); }
    return Object.freeze({ evaluate: evaluate, format: format, round: round });
}));
