/* 電卓dn 1.0.0 | GPL-2.0-or-later */
(function () {
    'use strict';
    var math = window.CalculatorDnMath;
    if (!math) return;

    function init(root) {
        if (root.dataset.ready === 'yes') return;
        root.dataset.ready = 'yes';
        var input = root.querySelector('.calculator-dn__input');
        var result = root.querySelector('.calculator-dn__result');
        var status = root.querySelector('.calculator-dn__status');
        var copy = root.querySelector('[data-action="copy"]');
        var list = root.querySelector('.calculator-dn__history-list');
        var memory = 0, history = [], lastValue = null, finished = false;

        function message(text, error) {
            status.textContent = text;
            root.classList.toggle('calculator-dn--error', !!error);
            input.setAttribute('aria-invalid', error ? 'true' : 'false');
        }
        function dirty() {
            finished = false; lastValue = null; copy.disabled = true;
            result.textContent = '—';
            message('「＝」を押すと計算します。');
        }
        function setExpression(text, caret) {
            if (text.length > 256) { message('計算式は256文字以内で入力してください。', true); return false; }
            input.value = text;
            var pos = typeof caret === 'number' ? caret : text.length;
            input.setSelectionRange(pos, pos);
            dirty();
            return true;
        }
        function insert(text) {
            var source = input.value, start = input.selectionStart, end = input.selectionEnd;
            if (finished) {
                // Operators continue the last answer; numbers start a new expression.
                source = /^[+−\-×÷*/^%]$/.test(text) ? math.format(lastValue) : '';
                start = end = source.length;
            }
            setExpression(source.slice(0, start) + text + source.slice(end), start + text.length);
        }
        function renderHistory() {
            if (!list) return;
            list.textContent = '';
            history.forEach(function (item, index) {
                var li = document.createElement('li'), button = document.createElement('button');
                var expression = document.createElement('span'), answer = document.createElement('strong');
                button.type = 'button'; button.dataset.action = 'history-recall'; button.dataset.index = String(index);
                expression.textContent = item.expression; answer.textContent = '= ' + item.answer;
                button.setAttribute('aria-label', item.expression + '、結果 ' + item.answer + '。式を再入力');
                button.append(expression, answer); li.appendChild(button); list.appendChild(li);
            });
            root.querySelector('.calculator-dn__count').textContent = String(history.length);
            root.querySelector('.calculator-dn__empty').hidden = history.length > 0;
            root.querySelector('[data-action="history-clear"]').disabled = history.length === 0;
        }
        function fail(error) {
            result.textContent = '—'; lastValue = null; finished = false; copy.disabled = true;
            message(error.message || '計算式を確認してください。', true);
        }
        function calculate() {
            try {
                lastValue = math.evaluate(input.value);
                result.textContent = math.format(lastValue); copy.disabled = false; finished = true;
                message('計算しました。');
                if (list) {
                    var item = { expression: input.value.trim(), answer: math.format(lastValue) };
                    if (!history.length || history[0].expression !== item.expression || history[0].answer !== item.answer) {
                        history.unshift(item); history = history.slice(0, 20); renderHistory();
                    }
                }
            } catch (error) { fail(error); }
        }
        function wrap(action) {
            var source = finished ? math.format(lastValue) : input.value.trim();
            if (!source) {
                if (action === 'sqrt') setExpression('sqrt(');
                else if (action === 'negate') setExpression('-');
                else message('二乗する式を入力してください。', true);
                return;
            }
            if (action === 'sqrt') setExpression('sqrt(' + source + ')');
            if (action === 'square') setExpression('(' + source + ')^2');
            if (action === 'negate') setExpression('-(' + source + ')');
        }
        async function copyResult() {
            if (lastValue === null) return;
            var text = math.format(lastValue);
            try {
                if (!navigator.clipboard || !window.isSecureContext) throw new Error('unavailable');
                await navigator.clipboard.writeText(text);
                message('結果をコピーしました。');
            } catch (_) {
                // Older browsers / HTTP: offer standard manual copy if clipboard is unavailable.
                setExpression(text); input.focus(); input.select();
                lastValue = Number(text); result.textContent = text; copy.disabled = false;
                message('結果を選択しました。端末の「コピー」または Ctrl+C / ⌘C を使ってください。');
            }
        }
        function action(name, value, button) {
            if (name === 'insert') insert(value);
            else if (name === 'equals') calculate();
            else if (name === 'clear') {
                setExpression(''); result.textContent = '0'; message('式を消去しました。');
            } else if (name === 'backspace') {
                var start = input.selectionStart, end = input.selectionEnd;
                if (start === end && start > 0) start--;
                setExpression(input.value.slice(0, start) + input.value.slice(end), start);
            } else if (name === 'sqrt' || name === 'square' || name === 'negate') wrap(name);
            else if (name === 'copy') copyResult();
            else if (name === 'memory-clear') { memory = 0; message('メモリーを消去しました。'); }
            else if (name === 'memory-recall') {
                var recalled = math.format(memory);
                insert(memory < 0 ? '(' + recalled + ')' : recalled); message('メモリーを入力しました。');
            } else if (name === 'memory-add' || name === 'memory-subtract') {
                try {
                    var valueNow = math.evaluate(input.value || '0');
                    var next = math.round(memory + (name === 'memory-add' ? valueNow : -valueNow));
                    memory = next; message('メモリーを更新しました。');
                } catch (error) { fail(error); }
            } else if (name === 'history-clear') { history = []; renderHistory(); message('履歴を消去しました。'); }
            else if (name === 'history-recall') {
                var selected = history[Number(button.dataset.index)];
                if (selected) { setExpression(selected.expression); message('履歴の式を入力しました。'); }
            }
            root.querySelector('.calculator-dn__memory-value').textContent = 'メモリー：' + math.format(memory);
        }
        root.addEventListener('click', function (event) {
            var button = event.target.closest('button[data-action]');
            if (button && root.contains(button) && !button.disabled) action(button.dataset.action, button.dataset.value || '', button);
        });
        input.addEventListener('input', dirty);
        root.addEventListener('keydown', function (event) {
            if (event.isComposing || event.ctrlKey || event.metaKey || event.altKey) return;
            var isInput = event.target === input;
            if ((event.key === 'Enter' && isInput) || event.key === '=') {
                event.preventDefault(); calculate();
            } else if (event.key === 'Escape') {
                event.preventDefault(); action('clear');
            } else if (!isInput && /^[0-9.+\-*/()%\^]$/.test(event.key)) {
                event.preventDefault(); insert(event.key);
            } else if (!isInput && event.key === 'Backspace') {
                event.preventDefault(); action('backspace');
            } else if (isInput && finished && /^[0-9.+\-*/()%\^]$/.test(event.key)) {
                event.preventDefault(); insert(event.key);
            }
        });
    }
    function scan(scope) {
        if (scope.nodeType !== 1 && scope.nodeType !== 9) return;
        if (scope.matches && scope.matches('.calculator-dn')) init(scope);
        scope.querySelectorAll('.calculator-dn').forEach(init);
    }
    function boot() {
        scan(document);
        // Support shortcodes inserted by a page builder after initial load.
        new MutationObserver(function (records) {
            records.forEach(function (record) { record.addedNodes.forEach(scan); });
        }).observe(document.body, { childList: true, subtree: true });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
}());
