<?php
/**
 * Plugin Name: 電卓dn
 * Description: 投稿・固定ページと管理画面で使える、日本語の多機能電卓。ショートコード [calculator_dn] で設置できます。
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: dn
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: calculator-dn
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Calculator_Dn_Plugin {
    const VERSION = '1.0.0';

    public static function init() {
        add_shortcode( 'calculator_dn', array( __CLASS__, 'render' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
        add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
        add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'action_links' ) );
    }

    public static function assets() {
        // Small, fully local assets also support shortcode widgets and template calls.
        $base = plugin_dir_url( __FILE__ ) . 'assets/';
        wp_enqueue_style( 'calculator-dn', $base . 'calculator-dn.css', array(), self::VERSION );
        wp_enqueue_script( 'calculator-engine-dn', $base . 'calculator-engine-dn.js', array(), self::VERSION, true );
        wp_enqueue_script( 'calculator-dn', $base . 'calculator-dn.js', array( 'calculator-engine-dn' ), self::VERSION, true );
    }

    public static function admin_menu() {
        add_management_page( '電卓dn', '電卓dn', 'manage_options', 'calculator-dn', array( __CLASS__, 'admin_page' ) );
    }

    public static function admin_assets( $hook ) {
        if ( 'tools_page_calculator-dn' === $hook ) {
            self::assets();
        }
    }

    public static function action_links( $links ) {
        $url = admin_url( 'tools.php?page=calculator-dn' );
        array_unshift( $links, '<a href="' . esc_url( $url ) . '">使い方・電卓</a>' );
        return $links;
    }

    public static function render( $atts = array() ) {
        $atts = shortcode_atts( array( 'title' => '電卓dn', 'theme' => 'light', 'history' => 'yes' ), $atts, 'calculator_dn' );
        $theme = in_array( $atts['theme'], array( 'light', 'dark', 'auto' ), true ) ? $atts['theme'] : 'light';
        $title = sanitize_text_field( $atts['title'] );
        if ( '' === $title ) {
            $title = '電卓dn';
        }
        $history = ! in_array( strtolower( (string) $atts['history'] ), array( 'no', 'false', '0' ), true );
        $id = wp_unique_id( 'calculator-dn-' );
        $keys = array(
            array( 'AC', 'clear', '', 'すべて消去', 'clear' ),
            array( '(', 'insert', '(', '左括弧', 'utility' ),
            array( ')', 'insert', ')', '右括弧', 'utility' ),
            array( '÷', 'insert', '÷', '割る', 'operator' ),
            array( '7', 'insert', '7', '7', '' ), array( '8', 'insert', '8', '8', '' ), array( '9', 'insert', '9', '9', '' ),
            array( '×', 'insert', '×', '掛ける', 'operator' ),
            array( '4', 'insert', '4', '4', '' ), array( '5', 'insert', '5', '5', '' ), array( '6', 'insert', '6', '6', '' ),
            array( '−', 'insert', '−', '引く', 'operator' ),
            array( '1', 'insert', '1', '1', '' ), array( '2', 'insert', '2', '2', '' ), array( '3', 'insert', '3', '3', '' ),
            array( '+', 'insert', '+', '足す', 'operator' ),
            array( '±', 'negate', '', '式全体の符号を反転', 'utility' ),
            array( '0', 'insert', '0', '0', '' ), array( '.', 'insert', '.', '小数点', '' ),
            array( '=', 'equals', '', '計算する', 'equals' ),
        );
        ob_start();
        ?>
        <section class="calculator-dn" data-theme="<?php echo esc_attr( $theme ); ?>" aria-labelledby="<?php echo esc_attr( $id ); ?>-title">
            <div class="calculator-dn__header">
                <div><span class="calculator-dn__eyebrow">EVERYDAY CALCULATOR</span><h2 id="<?php echo esc_attr( $id ); ?>-title"><?php echo esc_html( $title ); ?></h2></div>
                <span class="calculator-dn__badge" aria-hidden="true">dn</span>
            </div>
            <div class="calculator-dn__display">
                <label for="<?php echo esc_attr( $id ); ?>-input">計算式</label>
                <input id="<?php echo esc_attr( $id ); ?>-input" class="calculator-dn__input" type="text" inputmode="decimal" maxlength="256" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="例：1200 × 3 + 500" aria-describedby="<?php echo esc_attr( $id ); ?>-hint <?php echo esc_attr( $id ); ?>-status" dir="ltr">
                <div class="calculator-dn__result-row"><span>結果</span><output class="calculator-dn__result" for="<?php echo esc_attr( $id ); ?>-input" aria-live="polite" aria-atomic="true">0</output></div>
                <div class="calculator-dn__status" id="<?php echo esc_attr( $id ); ?>-status" role="status" aria-live="polite">式を入力して「＝」を押してください。</div>
            </div>
            <div class="calculator-dn__memory" aria-label="メモリー操作">
                <button type="button" data-action="memory-clear" title="メモリー消去" aria-label="メモリー消去">MC</button>
                <button type="button" data-action="memory-recall" title="メモリー呼び出し" aria-label="メモリー呼び出し">MR</button>
                <button type="button" data-action="memory-add" title="現在の式の値をメモリーに加算" aria-label="メモリー加算">M+</button>
                <button type="button" data-action="memory-subtract" title="現在の式の値をメモリーから減算" aria-label="メモリー減算">M−</button>
            </div>
            <div class="calculator-dn__memory-value" aria-live="polite">メモリー：0</div>
            <div class="calculator-dn__keys" aria-label="電卓キー">
                <?php foreach ( $keys as $key ) : ?>
                    <button type="button" class="calculator-dn__key <?php echo esc_attr( $key[4] ? 'calculator-dn__key--' . $key[4] : '' ); ?>" data-action="<?php echo esc_attr( $key[1] ); ?>" data-value="<?php echo esc_attr( $key[2] ); ?>" aria-label="<?php echo esc_attr( $key[3] ); ?>"><?php echo esc_html( $key[0] ); ?></button>
                <?php endforeach; ?>
            </div>
            <div class="calculator-dn__extras" aria-label="追加の演算">
                <button type="button" data-action="sqrt" aria-label="式全体の平方根">√</button>
                <button type="button" data-action="square" aria-label="式全体の二乗">x²</button>
                <button type="button" data-action="insert" data-value="%" aria-label="パーセント、直前の値を100で割る">%</button>
                <button type="button" data-action="backspace" aria-label="一文字削除">⌫</button>
            </div>
            <button type="button" class="calculator-dn__copy" data-action="copy" disabled>結果をコピー</button>
            <p class="calculator-dn__hint" id="<?php echo esc_attr( $id ); ?>-hint">％は直前の値を100で割ります。例：200 × 10% = 20<br>Enter：計算 ／ Esc：式を消去</p>
            <?php if ( $history ) : ?>
                <details class="calculator-dn__history">
                    <summary>計算履歴 <span class="calculator-dn__count">0</span></summary>
                    <p class="calculator-dn__history-note">この画面での最新20件。選ぶと式を再入力します。</p>
                    <ol class="calculator-dn__history-list"></ol>
                    <p class="calculator-dn__empty">計算履歴はまだありません。</p>
                    <button type="button" class="calculator-dn__history-clear" data-action="history-clear" disabled>履歴を消去</button>
                </details>
            <?php endif; ?>
            <noscript><p>電卓を使うには、ブラウザーのJavaScriptを有効にしてください。</p></noscript>
        </section>
        <?php
        return ob_get_clean();
    }

    public static function admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        ?>
        <div class="wrap calculator-dn-admin">
            <h1>電卓dn</h1>
            <p>この画面ですぐに電卓を使えます。投稿や固定ページにも設置できます。</p>
            <div class="calculator-dn-admin__layout">
                <div><?php echo self::render(); // Output escaped in render(). ?></div>
                <div class="calculator-dn-admin__guide">
                    <h2>ページへの設置</h2>
                    <ol><li>投稿または固定ページの編集画面を開きます。</li><li>「ショートコード」ブロックを追加します。</li><li>以下を貼り付け、プレビューまたは公開ページで確認します。</li></ol>
                    <p><code>[calculator_dn]</code></p>
                    <h3>見た目を変える</h3>
                    <p>ダーク表示：<br><code>[calculator_dn theme="dark"]</code></p>
                    <p>端末の設定に合わせる：<br><code>[calculator_dn theme="auto"]</code></p>
                    <p>タイトル変更・履歴非表示：<br><code>[calculator_dn title="かんたん計算" history="no"]</code></p>
                    <h3>使える計算</h3>
                    <p>四則演算、括弧、小数、負数、％、平方根、二乗、べき乗（^）、指数表記（1e3）に対応しています。</p>
                    <p>例：<code>(1200+300)*2</code>、<code>sqrt(81)</code>、<code>2^3</code></p>
                    <p>％は常に100分の1です。<code>200+10%</code> は <strong>200.1</strong> になります。10％増しは <code>200*1.1</code> と入力します。</p>
                    <p>√・x²・±は入力中の式全体に作用します。MCはメモリー消去、MRは呼び出し、M+ / M−は式の値を加減算します。ACではメモリーと履歴は消えません。</p>
                    <h3>データと計算精度</h3>
                    <p>計算はブラウザー内で行います。外部API、外部CDN、アカウント登録は不要です。このプラグインは計算内容をサーバーに送信しません。履歴とメモリーは再読み込みで消えます。</p>
                    <p>一般的な浮動小数点演算を使い、結果は有効数字15桁で丸めます。厳密な会計処理や非常に大きな整数の計算には対応していません。式は最大256文字です。</p>
                </div>
            </div>
        </div>
        <?php
    }
}

add_action( 'init', array( 'Calculator_Dn_Plugin', 'init' ) );
