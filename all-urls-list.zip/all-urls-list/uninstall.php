<?php
/**
 * アンインストール時処理.
 * オプションだけを削除し、自動作成した固定ページは残します
 * （ユーザーのコンテンツを勝手に消さないため）.
 *
 * @package AllUrlsList
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'aul_list_page_id' );
delete_option( 'aul_list_page_created' );
