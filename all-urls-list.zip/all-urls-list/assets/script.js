(function () {
	'use strict';

	function copyText(text) {
		if (navigator.clipboard && navigator.clipboard.writeText) {
			return navigator.clipboard.writeText(text);
		}
		return new Promise(function (resolve, reject) {
			var ta = document.createElement('textarea');
			ta.value = text;
			ta.style.position = 'fixed';
			ta.style.opacity = '0';
			document.body.appendChild(ta);
			ta.select();
			try {
				document.execCommand('copy');
				resolve();
			} catch (e) {
				reject(e);
			} finally {
				document.body.removeChild(ta);
			}
		});
	}

	function initWrap(wrap) {
		var search = wrap.querySelector('[data-aul-search]');
		var items = Array.prototype.slice.call(wrap.querySelectorAll('[data-aul-item]'));
		var noResult = wrap.querySelector('[data-aul-no-result]');
		var urlOnly = wrap.querySelector('.aul-url-only');
		var copied = wrap.querySelector('[data-aul-copied]');

		function flashCopied(msg) {
			if (!copied) return;
			copied.textContent = msg;
			window.setTimeout(function () {
				copied.textContent = '';
			}, 2500);
		}

		// 絞り込み検索.
		if (search && items.length) {
			search.addEventListener('input', function () {
				var q = search.value.trim().toLowerCase();
				var visible = 0;
				items.forEach(function (item) {
					var hay = item.getAttribute('data-search') || '';
					var show = !q || hay.indexOf(q) !== -1;
					item.style.display = show ? '' : 'none';
					if (show) visible++;
				});
				// グループ見出し: 配下が全て非表示なら見出しも隠す.
				wrap.querySelectorAll('.aul-list').forEach(function (list) {
					var anyVisible = Array.prototype.some.call(
						list.querySelectorAll('[data-aul-item]'),
						function (el) { return el.style.display !== 'none'; }
					);
					list.style.display = anyVisible ? '' : 'none';
					var heading = list.previousElementSibling;
					if (heading && heading.classList.contains('aul-group-title')) {
						heading.style.display = anyVisible ? '' : 'none';
					}
				});
				if (noResult) {
					noResult.hidden = visible !== 0;
				}
			});
		}

		// 個別コピー.
		wrap.querySelectorAll('[data-aul-copy-one]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var item = btn.closest('[data-aul-item]');
				var url = item ? item.getAttribute('data-url') : '';
				if (!url) return;
				copyText(url).then(function () {
					var old = btn.textContent;
					btn.textContent = 'コピーしました';
					window.setTimeout(function () { btn.textContent = old; }, 2000);
				});
			});
		});

		// 表示中をすべてコピー.
		var copyAll = wrap.querySelector('[data-aul-copy-all]');
		if (copyAll) {
			copyAll.addEventListener('click', function () {
				var urls = [];
				if (urlOnly) {
					// url_only 形式はテキストエリアの中身そのもの（改行区切り）.
					urlOnly.value.split('\n').forEach(function (line) {
						var v = line.trim();
						if (v) urls.push(v);
					});
				} else {
					items.forEach(function (item) {
						if (item.style.display === 'none') return;
						var url = item.getAttribute('data-url');
						if (url && urls.indexOf(url) === -1) urls.push(url);
					});
				}
				if (!urls.length) {
					flashCopied('コピーできるURLがありません');
					return;
				}
				copyText(urls.join('\n')).then(function () {
					flashCopied(urls.length + '件のURLをコピーしました');
				});
			});
		}
	}

	document.querySelectorAll('[data-aul]').forEach(initWrap);
})();
