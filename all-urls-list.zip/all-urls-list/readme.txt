=== 全URL一覧 - All URLs List ===
Contributors: taira
Tags: url, list, sitemap, posts, pages, shortcode
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

サイト内の投稿記事と固定ページのURLを、固定ページ上に全て一覧表示するプラグインです。

== Description ==

固定ページにショートコード `[all_urls]` を置くだけで、公開済みの投稿記事と固定ページを
「タイトル（リンク）＋URL＋公開日」付きで全件一覧表示します。

* 有効化すると「全記事・固定ページURL一覧」という固定ページ（スラッグ: all-urls）を自動で1つ作成します
* 投稿と固定ページを分けて見出し付きで表示し、件数も表示します
* 一覧上部の検索欄でタイトル・URLをその場で絞り込みできます
* 「表示中のURLをすべてコピー」ボタンと、記事ごとのコピーボタンを付けられます
* 表示形式はリスト／URLのみ／表 の3種類から選べます
* 下書き・予約投稿・非公開の記事は含みません
* ショートコードを置いたページ自体は一覧から自動で除外します
* 外部へのデータ送信は一切しません

= ショートコードの例 =

* `[all_urls]` — 投稿＋固定ページ（既定）
* `[all_urls type="post"]` — 投稿記事だけ
* `[all_urls type="page"]` — 固定ページだけ
* `[all_urls type="all"]` — 公開中の全投稿タイプ（添付ファイルを除く）
* `[all_urls format="url_only"]` — URLだけを1行ずつ
* `[all_urls format="table"]` — 表形式
* `[all_urls orderby="title" order="ASC"]` — タイトル順（昇順）
* `[all_urls login_only="1"]` — ログインユーザーだけに表示

別名ショートコード: `[all_post_page_urls]` / `[site_url_list]`

== Installation ==

1. WordPress管理画面「プラグイン > 新規追加 > プラグインのアップロード」から zip をアップロードします。
   （または `wp-content/plugins/` に `all-urls-list` フォルダごと置きます）
2. 「全URL一覧 - All URLs List」を有効化します。
3. 自動作成された固定ページ「全記事・固定ページURL一覧」を開くと一覧が表示されます。
   自分の好きなページに置きたい場合は、そのページ本文に `[all_urls]` と書いてください。

== Frequently Asked Questions ==

= 下書きは表示されますか？ =
いいえ。表示するのは公開済み（publish）の記事・固定ページだけです。

= プラグインを削除したら一覧ページも消えますか？ =
いいえ。自動作成した固定ページは残ります。不要な場合は固定ページ一覧から手動で削除してください。
アンインストール時はプラグインのオプションだけを削除します。

= カスタム投稿タイプも出せますか？ =
はい。例: `[all_urls type="post,page,book"]` のようにタイプ名をカンマ区切りで追加してください。
`type="all"` で公開中の全投稿タイプ（添付ファイルを除く）も指定できます。

== Changelog ==

= 1.0.0 =
* 初版公開。ショートコード [all_urls]、自動ページ作成、検索・コピー機能、リスト／URLのみ／表の3形式。
