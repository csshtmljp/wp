<?php
/**
 * Plugin Name:       全URL一覧 - All URLs List
 * Plugin URI:        https://example.com/all-urls-list
 * Description:       サイト内の投稿記事と固定ページのURLを、固定ページ上に全て一覧表示するプラグイン。ショートコード [all_urls] を置いたページに、タイトル付きリンク・URL・公開日と、検索／コピー機能付きの一覧を出力します。有効化すると専用の固定ページも自動で1つ作成します。
 * Version:           1.0.0
 * Author:            平
 * Author URI:        https://example.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       all-urls-list
 * Domain Path:       /languages
 * Requires at least: 5.8
 * Requires PHP:      7.4
 *
 * @package AllUrlsList
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // 直接アクセス禁止.
}

define( 'AUL_VERSION', '1.0.0' );
define( 'AUL_OPTION_PAGE_ID', 'aul_list_page_id' );
define( 'AUL_OPTION_CREATED', 'aul_list_page_created' );

/**
 * 有効化時: 一覧用固定ページを自動作成する（既にあれば作らない）.
 */
function aul_activate() {
	// 既に作成済みで、そのページがまだ存在する場合は何もしない.
	$existing_id = (int) get_option( AUL_OPTION_PAGE_ID, 0 );
	if ( $existing_id > 0 && get_post( $existing_id ) ) {
		return;
	}

	// 同じタイトルの固定ページが既にある場合は、それを流用する.
	$found = get_page_by_path( 'all-urls', OBJECT, 'page' );
	if ( $found instanceof WP_Post ) {
		update_option( AUL_OPTION_PAGE_ID, (int) $found->ID );
		update_option( AUL_OPTION_CREATED, 1 );
		return;
	}

	$page_id = wp_insert_post(
		array(
			'post_title'   => '全記事・固定ページURL一覧',
			'post_name'    => 'all-urls',
			'post_content' => '[all_urls]',
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_author'  => get_current_user_id() ? get_current_user_id() : 1,
		),
		true
	);

	if ( ! is_wp_error( $page_id ) && $page_id > 0 ) {
		update_option( AUL_OPTION_PAGE_ID, (int) $page_id );
		update_option( AUL_OPTION_CREATED, 1 );
	}
}
register_activation_hook( __FILE__, 'aul_activate' );

/**
 * 無効化時: 固定ページは残す（ユーザーのコンテンツを勝手に消さない）.
 */
function aul_deactivate() {
	// 意図的に何もしない.
}
register_deactivation_hook( __FILE__, 'aul_deactivate' );

/**
 * CSS / JS を登録しておく（ショートコードがあるページでのみ読み込む）.
 */
function aul_register_assets() {
	wp_register_style(
		'all-urls-list',
		plugins_url( 'assets/style.css', __FILE__ ),
		array(),
		AUL_VERSION
	);
	wp_register_script(
		'all-urls-list',
		plugins_url( 'assets/script.js', __FILE__ ),
		array(),
		AUL_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'aul_register_assets' );

/**
 * 投稿タイプ名の表示ラベルを返す.
 *
 * @param string $post_type 投稿タイプ.
 * @return string
 */
function aul_type_label( $post_type ) {
	if ( 'post' === $post_type ) {
		return '投稿記事';
	}
	if ( 'page' === $post_type ) {
		return '固定ページ';
	}
	$obj = get_post_type_object( $post_type );
	if ( $obj && ! empty( $obj->labels->name ) ) {
		return $obj->labels->name;
	}
	return $post_type;
}

/**
 * ショートコード [all_urls] の出力.
 *
 * 使い方の例:
 *   [all_urls]
 *   [all_urls type="post"]                     投稿だけ
 *   [all_urls type="page"]                     固定ページだけ
 *   [all_urls type="post,page,book"]           カスタム投稿タイプも追加可
 *   [all_urls format="url_only"]               URLだけを1行ずつ
 *   [all_urls format="table"]                  表形式
 *   [all_urls orderby="title" order="ASC"]     タイトル順
 *   [all_urls show_date="0"]                   日付を出さない
 *   [all_urls login_only="1"]                  ログインユーザーだけに表示
 *
 * @param array|string $atts ショートコード属性.
 * @return string HTML.
 */
function aul_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'type'             => 'post,page',
			'format'           => 'list',   // list | url_only | table.
			'orderby'          => 'date',   // date | title | id | menu_order.
			'order'            => 'DESC',   // DESC | ASC.
			'show_date'        => '1',
			'show_type'        => '1',
			'show_search'      => '1',
			'show_copy'        => '1',
			'exclude_current'  => '1',
			'login_only'       => '0',
		),
		is_array( $atts ) ? $atts : array(),
		'all_urls'
	);

	if ( '1' === (string) $atts['login_only'] && ! is_user_logged_in() ) {
		return '<p class="aul-login-required">この一覧はログインしたユーザーだけが見ることができます。</p>';
	}

	// 表示する投稿タイプを整える.
	if ( 'all' === strtolower( trim( (string) $atts['type'] ) ) ) {
		$types = get_post_types( array( 'public' => true ), 'names' );
		// 添付ファイルはURL一覧の対象外にする.
		unset( $types['attachment'] );
		$types = array_values( $types );
	} else {
		$types = array_filter( array_map( 'trim', explode( ',', (string) $atts['type'] ) ) );
		$types = array_values( array_unique( $types ) );
	}
	if ( empty( $types ) ) {
		$types = array( 'post', 'page' );
	}

	$orderby_whitelist = array( 'date', 'title', 'id', 'menu_order', 'modified' );
	$orderby           = in_array( strtolower( (string) $atts['orderby'] ), $orderby_whitelist, true )
		? strtolower( (string) $atts['orderby'] )
		: 'date';
	if ( 'id' === $orderby ) {
		$orderby = 'ID';
	}
	$order = ( 'ASC' === strtoupper( (string) $atts['order'] ) ) ? 'ASC' : 'DESC';

	$format = in_array( (string) $atts['format'], array( 'list', 'url_only', 'table' ), true )
		? (string) $atts['format']
		: 'list';

	$exclude = array();
	if ( '1' === (string) $atts['exclude_current'] ) {
		$current_id = get_the_ID();
		if ( $current_id ) {
			$exclude[] = (int) $current_id;
		}
	}

	// 全件取得（公開済みのみ）.
	$query = new WP_Query(
		array(
			'post_type'           => $types,
			'post_status'         => 'publish',
			'posts_per_page'      => -1,
			'orderby'             => $orderby,
			'order'               => $order,
			'post__not_in'        => $exclude,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'fields'              => 'all',
		)
	);

	$posts = $query->posts;
	wp_reset_postdata();

	if ( empty( $posts ) ) {
		return '<p class="aul-empty">表示できる記事・固定ページがありません。</p>';
	}

	// 投稿タイプごとにグループ化する（指定された順序を保つ）.
	$grouped = array();
	foreach ( $types as $t ) {
		$grouped[ $t ] = array();
	}
	foreach ( $posts as $post ) {
		$grouped[ $post->post_type ][] = $post;
	}
	// クエリで返ったが $types の順に無いタイプも漏らさない.
	foreach ( $posts as $post ) {
		if ( ! isset( $grouped[ $post->post_type ] ) ) {
			$grouped[ $post->post_type ] = array( $post );
		}
	}

	$total       = count( $posts );
	$show_date   = ( '1' === (string) $atts['show_date'] );
	$show_type   = ( '1' === (string) $atts['show_type'] );
	$show_search = ( '1' === (string) $atts['show_search'] );
	$show_copy   = ( '1' === (string) $atts['show_copy'] );

	wp_enqueue_style( 'all-urls-list' );
	if ( $show_search || $show_copy ) {
		wp_enqueue_script( 'all-urls-list' );
	}

	ob_start();
	?>
	<div class="aul-wrap" data-aul>
		<p class="aul-summary">
			<?php
			$parts = array();
			foreach ( $grouped as $t => $items ) {
				if ( ! empty( $items ) ) {
					$parts[] = esc_html( aul_type_label( $t ) ) . ' ' . number_format_i18n( count( $items ) ) . '件';
				}
			}
			echo '全 ' . number_format_i18n( $total ) . '件';
			if ( ! empty( $parts ) ) {
				echo '（' . implode( ' / ', $parts ) . '）'; // phpcs:ignore WordPress.Security.EscapeOutput -- $parts は esc_html 済み.
			}
			?>
		</p>

		<?php if ( $show_search || $show_copy ) : ?>
		<div class="aul-toolbar">
			<?php if ( $show_search ) : ?>
			<label class="aul-search-label">
				<span class="screen-reader-text">タイトル・URLで絞り込み</span>
				<input type="search" class="aul-search" data-aul-search placeholder="タイトル・URLで絞り込み" />
			</label>
			<?php endif; ?>
			<?php if ( $show_copy ) : ?>
			<button type="button" class="aul-copy-all" data-aul-copy-all>表示中のURLをすべてコピー</button>
			<span class="aul-copied" data-aul-copied aria-live="polite"></span>
			<?php endif; ?>
		</div>
		<?php endif; ?>

		<?php if ( 'url_only' === $format ) : ?>
			<textarea class="aul-url-only" data-aul-list readonly rows="15"><?php
				$lines = array();
				foreach ( $posts as $post ) {
					$lines[] = get_permalink( $post );
				}
				echo esc_textarea( implode( "\n", $lines ) );
			?></textarea>

		<?php elseif ( 'table' === $format ) : ?>
			<table class="aul-table">
				<thead>
					<tr>
						<th>タイトル</th>
						<th>URL</th>
						<?php if ( $show_type ) : ?><th>種類</th><?php endif; ?>
						<?php if ( $show_date ) : ?><th>公開日</th><?php endif; ?>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $posts as $post ) : ?>
					<?php
					$url   = get_permalink( $post );
					$title = get_the_title( $post );
					if ( '' === $title ) {
						$title = '（タイトルなし）';
					}
					?>
					<tr data-aul-item data-search="<?php echo esc_attr( strtolower( $title . ' ' . $url ) ); ?>" data-url="<?php echo esc_url( $url ); ?>">
						<td><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $title ); ?></a></td>
						<td class="aul-url-cell"><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $url ); ?></a></td>
						<?php if ( $show_type ) : ?><td><?php echo esc_html( aul_type_label( $post->post_type ) ); ?></td><?php endif; ?>
						<?php if ( $show_date ) : ?><td><?php echo esc_html( get_the_date( 'Y-m-d', $post ) ); ?></td><?php endif; ?>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

		<?php else : // list（既定） ?>
			<div data-aul-list>
			<?php foreach ( $grouped as $t => $items ) : ?>
				<?php if ( empty( $items ) ) { continue; } ?>
				<h2 class="aul-group-title"><?php echo esc_html( aul_type_label( $t ) ); ?>（<?php echo number_format_i18n( count( $items ) ); ?>件）</h2>
				<ul class="aul-list">
				<?php foreach ( $items as $post ) : ?>
					<?php
					$url   = get_permalink( $post );
					$title = get_the_title( $post );
					if ( '' === $title ) {
						$title = '（タイトルなし）';
					}
					?>
					<li class="aul-item" data-aul-item data-search="<?php echo esc_attr( strtolower( $title . ' ' . $url ) ); ?>" data-url="<?php echo esc_url( $url ); ?>">
						<a class="aul-item-title" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $title ); ?></a>
						<span class="aul-item-meta">
							<a class="aul-item-url" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $url ); ?></a>
							<?php if ( $show_date ) : ?>
							<span class="aul-item-date"><?php echo esc_html( get_the_date( 'Y-m-d', $post ) ); ?></span>
							<?php endif; ?>
							<?php if ( $show_copy ) : ?>
							<button type="button" class="aul-copy-one" data-aul-copy-one>URLをコピー</button>
							<?php endif; ?>
						</span>
					</li>
				<?php endforeach; ?>
				</ul>
			<?php endforeach; ?>
			</div>
			<p class="aul-no-result" data-aul-no-result hidden>条件に合う記事・固定ページがありません。</p>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode( 'all_urls', 'aul_shortcode' );
add_shortcode( 'all_post_page_urls', 'aul_shortcode' );
add_shortcode( 'site_url_list', 'aul_shortcode' );

/**
 * 管理画面: 設定 > 全URL一覧
 */
function aul_add_settings_page() {
	add_options_page(
		'全URL一覧',
		'全URL一覧',
		'manage_options',
		'all-urls-list',
		'aul_render_settings_page'
	);
}
add_action( 'admin_menu', 'aul_add_settings_page' );

/**
 * 設定ページの表示.
 */
function aul_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	// 一覧ページの作り直し.
	if ( isset( $_POST['aul_recreate'] ) && check_admin_referer( 'aul_settings' ) ) {
		delete_option( AUL_OPTION_PAGE_ID );
		delete_option( AUL_OPTION_CREATED );
		aul_activate();
		echo '<div class="notice notice-success is-dismissible"><p>一覧用固定ページを確認／作成しました。</p></div>';
	}

	$page_id  = (int) get_option( AUL_OPTION_PAGE_ID, 0 );
	$page_url = $page_id ? get_permalink( $page_id ) : '';
	?>
	<div class="wrap">
		<h1>全URL一覧</h1>
		<p>サイト内の投稿記事と固定ページのURLを、固定ページ上に全て一覧表示します。</p>

		<h2>使い方</h2>
		<p>一覧を表示したい固定ページ（または投稿）の本文に、次のショートコードを置いてください。</p>
		<p><code>[all_urls]</code></p>
		<p>同じ働きの別名: <code>[all_post_page_urls]</code> / <code>[site_url_list]</code></p>

		<table class="form-table" role="presentation">
			<tr>
				<th scope="row">自動作成した一覧ページ</th>
				<td>
					<?php if ( $page_id && $page_url ) : ?>
						<a href="<?php echo esc_url( $page_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $page_url ); ?></a>
						&nbsp;|&nbsp;
						<a href="<?php echo esc_url( get_edit_post_link( $page_id ) ); ?>">編集する</a>
					<?php else : ?>
						まだ作成されていません。下のボタンで作成できます。
					<?php endif; ?>
				</td>
			</tr>
		</table>

		<form method="post">
			<?php wp_nonce_field( 'aul_settings' ); ?>
			<p>
				<button type="submit" name="aul_recreate" value="1" class="button">一覧用固定ページを作成／再確認する</button>
			</p>
		</form>

		<h2>ショートコードのオプション例</h2>
		<ul style="list-style:disc;margin-left:20px;">
			<li><code>[all_urls type="post"]</code> — 投稿記事だけ</li>
			<li><code>[all_urls type="page"]</code> — 固定ページだけ</li>
			<li><code>[all_urls type="all"]</code> — 公開中の全投稿タイプ（添付ファイルを除く）</li>
			<li><code>[all_urls format="url_only"]</code> — URLだけを1行ずつ（コピーして使う用途向け）</li>
			<li><code>[all_urls format="table"]</code> — 表形式</li>
			<li><code>[all_urls orderby="title" order="ASC"]</code> — タイトル順（昇順）</li>
			<li><code>[all_urls show_date="0" show_search="0" show_copy="0"]</code> — 日付・検索・コピーボタンを消す</li>
			<li><code>[all_urls login_only="1"]</code> — ログインユーザーだけに表示</li>
		</ul>

		<h2>仕様</h2>
		<ul style="list-style:disc;margin-left:20px;">
			<li>表示するのは「公開済み（publish）」の記事・固定ページだけです。下書き・予約投稿・ゴミ箱は含みません。</li>
			<li>ショートコードを置いたページ自体は一覧から自動で除外します。</li>
			<li>プラグインを無効化／削除しても、自動作成した固定ページは残ります（不要なら固定ページ一覧から手動で削除してください）。</li>
			<li>外部へのデータ送信は一切しません。</li>
		</ul>
	</div>
	<?php
}

/**
 * プラグイン一覧画面に「設定」リンクを追加.
 *
 * @param array $links 既存リンク.
 * @return array
 */
function aul_plugin_action_links( $links ) {
	$url = admin_url( 'options-general.php?page=all-urls-list' );
	array_unshift( $links, '<a href="' . esc_url( $url ) . '">設定</a>' );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'aul_plugin_action_links' );
