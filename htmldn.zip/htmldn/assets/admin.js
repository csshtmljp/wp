(() => {
  'use strict';
  const form = document.querySelector('#htmldn-editor-form');
  if (!form || !window.htmldnAdmin) return;
  const source = document.querySelector('#htmldn-source');
  const feedback = document.querySelector('#htmldn-feedback');
  const config = window.htmldnAdmin;
  const editor = config.editor && window.wp && wp.codeEditor ? wp.codeEditor.initialize(source, config.editor) : null;
  let dirty = false;
  let previewRequest = null;
  const getSource = () => editor ? editor.codemirror.getValue() : source.value;
  const message = (text, error = false) => { feedback.textContent = text; feedback.classList.toggle('is-error', error); };
  const byteSize = text => new Blob([text]).size;
  function updateSize() { document.querySelector('#htmldn-size').textContent = (byteSize(getSource()) / 1024).toFixed(1) + ' KB / 2048 KB'; }
  function setSource(text) { if (editor) editor.codemirror.setValue(text); else source.value = text; dirty = true; updateSize(); }
  function unfence(text) { return text.replace(/^\uFEFF/, '').replace(/^\s*```(?:html)?[\t ]*\r?\n([\s\S]*?)\r?\n```[\t ]*\s*$/i, '$1'); }
  if (editor) editor.codemirror.on('change', () => { dirty = true; updateSize(); });
  else source.addEventListener('input', updateSize);
  form.addEventListener('input', () => { dirty = true; });
  form.addEventListener('change', () => { dirty = true; });
  updateSize();
  document.querySelector('#htmldn-file').addEventListener('change', async event => {
    const file = event.target.files[0];
    if (!file) return;
    if (!/\.html?$/i.test(file.name) || file.size > config.maxBytes) { message('2MB以内の.htmlまたは.htmファイルを選択してください。', true); event.target.value = ''; return; }
    if (getSource().trim() && !window.confirm('現在のコードを選択したファイルに置き換えますか？')) { event.target.value = ''; return; }
    try {
      const buffer = await file.arrayBuffer();
      const text = new TextDecoder('utf-8', {fatal: true}).decode(buffer);
      setSource(unfence(text));
      const title = document.querySelector('#htmldn-title');
      if (!title.value.trim()) title.value = file.name.replace(/\.html?$/i, '');
      message(file.name + 'を読み込みました。「HTMLを保存」で確定できます。');
    } catch (error) { message('ファイルを読み込めませんでした。UTF-8形式のHTMLをご利用ください。', true); }
    event.target.value = '';
  });
  document.querySelector('#htmldn-sample').addEventListener('click', () => {
    if (getSource().trim() && !window.confirm('現在のコードをサンプルに置き換えますか？')) return;
    setSource(config.example);
    if (!document.querySelector('#htmldn-title').value.trim()) document.querySelector('#htmldn-title').value = 'ゴールド・カウンター';
    message('サンプルを入力しました。プレビューで動作を確認できます。');
  });
  document.querySelector('#htmldn-unfence').addEventListener('click', () => { setSource(unfence(getSource())); message('コード全体を囲む```htmlなどの記号を除去しました。'); });
  form.addEventListener('submit', event => {
    const html = unfence(getSource());
    if (!html.trim() || byteSize(html) > config.maxBytes) { event.preventDefault(); message('空でない、2MB以内のHTMLコードを入力してください。', true); return; }
    source.value = html;dirty = false;
  });
  window.addEventListener('beforeunload', event => { if (dirty) { event.preventDefault(); event.returnValue = ''; } });
  const copy = document.querySelector('#htmldn-copy');
  if (copy) copy.addEventListener('click', async () => {
    const field = document.querySelector('#htmldn-shortcode');
    try { await navigator.clipboard.writeText(field.value); message('ショートコードをコピーしました。'); }
    catch (error) { field.focus();field.select();message('コードを選択しました。端末のコピー操作でコピーしてください。'); }
  });
  const preview = document.querySelector('#htmldn-preview');
  const stage = document.querySelector('#htmldn-preview-stage');
  preview.addEventListener('click', async () => {
    if (previewRequest) previewRequest.abort();
    const controller = new AbortController();previewRequest = controller;
    const payload = new FormData(form);
    payload.set('action', 'htmldn_preview');payload.set('nonce', config.previewNonce);payload.set('html', getSource());
    preview.disabled = true;message('プレビューを準備しています…');
    try {
      const response = await fetch(config.ajaxUrl, {method: 'POST', credentials: 'same-origin', body: payload, signal: controller.signal});
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error(result.data && result.data.message || 'プレビューを取得できませんでした。画面を再読み込みしてお試しください。');
      if (controller.signal.aborted) return;
      const data = result.data;
      const frame = document.createElement('iframe');
      frame.title = 'htmldn HTMLプレビュー';
      frame.setAttribute('sandbox', data.sandbox);
      frame.setAttribute('referrerpolicy', 'no-referrer');
      frame.dataset.htmldnToken = data.token;frame.dataset.htmldnAuto = data.resize ? '1' : '0';
      frame.style.cssText = 'display:block;width:100%;border:0;background:white;';frame.style.height = data.height + 'px';
      frame.srcdoc = data.document;
      stage.replaceChildren(frame);
      message('プレビューを更新しました。保存するまで変更は公開されません。');
    } catch (error) { if (error.name !== 'AbortError') message(error.message || 'プレビューの取得に失敗しました。', true); }
    finally { if (previewRequest === controller) { previewRequest = null; preview.disabled = false; } }
  });
  document.querySelector('#htmldn-preview-stop').addEventListener('click', () => {
    if (previewRequest) previewRequest.abort();previewRequest = null;preview.disabled = false;
    stage.replaceChildren();message('プレビューを停止しました。');
  });
  document.querySelector('#htmldn-preview-width').addEventListener('change', event => { stage.style.width = event.target.value; });
})();
