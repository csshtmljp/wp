/* Parent listener: only the originating sandbox frame may request its own height. */
(() => {
  'use strict';
  window.addEventListener('message', event => {
    const data = event.data;
    if (!data || data.type !== 'htmldn:resize' || typeof data.token !== 'string' || data.token.length > 100 || !Number.isFinite(data.height)) return;
    const frame = Array.from(document.querySelectorAll('iframe[data-htmldn-auto="1"]')).find(item => item.dataset.htmldnToken === data.token);
    if (!frame || event.source !== frame.contentWindow) return;
    const height = Math.max(120, Math.min(20000, Math.ceil(data.height)));
    if (Math.abs((parseInt(frame.style.height, 10) || 0) - height) > 2) {
      frame.style.height = height + 'px';
      frame.setAttribute('height', String(height));
    }
  });
})();
