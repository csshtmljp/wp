(() => {
  'use strict';
  const el = wp.element.createElement;
  const {useEffect, useState} = wp.element;
  const {Placeholder, SelectControl, Spinner, Notice, Button} = wp.components;
  wp.blocks.registerBlockType('htmldn/embed', {
    apiVersion: 3,
    title: 'htmldn HTML', icon: 'editor-code', category: 'widgets',
    description: 'htmldnに保存したHTMLを表示します。',
    attributes: {id: {type: 'number', default: 0}},
    supports: {html: false, align: ['wide', 'full']},
    edit: props => {
      const [items, setItems] = useState(null);
      const [error, setError] = useState('');
      const [attempt, setAttempt] = useState(0);
      useEffect(() => {
        let active = true;
        setError('');setItems(null);
        wp.apiFetch({path: '/htmldn/v1/documents'}).then(data => { if (active) setItems(data); }).catch(() => { if (active) setError('HTML一覧を取得できませんでした。接続を確認して再試行してください。'); });
        return () => { active = false; };
      }, [attempt]);
      const options = [{label: '表示するHTMLを選択…', value: '0'}];
      if (items) for (const item of items) options.push({label: item.title, value: String(item.id)});
      const missing = items && props.attributes.id && !items.some(item => item.id === props.attributes.id);
      return el('div', wp.blockEditor.useBlockProps(),
        el(Placeholder, {icon: 'editor-code', label: 'htmldn', instructions: 'HTMLを選択すると、公開ページに表示されます。'},
          error ? el('div', null, el(Notice, {status: 'error', isDismissible: false}, error), el(Button, {variant: 'secondary', onClick: () => setAttempt(attempt + 1)}, '再試行')) : !items ? el(Spinner) : el('div', {style: {width: '100%'}},
            el(SelectControl, {label: '保存済みHTML', value: String(props.attributes.id), options, onChange: value => props.setAttributes({id: Number(value)})}),
            items.length === 0 ? el('p', null, '管理者がhtmldn画面でHTMLを保存し、公開可にすると選択できます。') : null,
            missing ? el(Notice, {status: 'warning', isDismissible: false}, '選択したHTMLは下書きまたは削除済みです。別のHTMLを選択してください。') : null,
            props.attributes.id ? el('code', null, '[htmldn id="' + props.attributes.id + '"]') : null,
            el('p', {style: {fontSize: '12px', color: '#646970'}}, 'コードの動作確認はhtmldnのプレビュー、または記事のプレビューで行えます。')
          )
        )
      );
    },
    save: () => null
  });
})();
