/* Runs inside an opaque-origin sandbox; never reads the WordPress parent DOM. */
(() => {
  'use strict';
  const token = __HTMLDN_TOKEN_JSON__;
  let scheduled = false;
  let previous = 0;
  function measure() {
    scheduled = false;
    const body = document.body;
    if (!body) return;
    const style = getComputedStyle(body);
    let bottom = 0;
    for (const node of body.children) {
      if (/^(SCRIPT|STYLE|LINK|META|TEMPLATE)$/.test(node.tagName)) continue;
      const box = node.getBoundingClientRect();
      const margin = parseFloat(getComputedStyle(node).marginBottom) || 0;
      bottom = Math.max(bottom, box.bottom + window.scrollY + margin);
    }
    // Also account for plain text fragments, overflow, and layouts without element children.
    if (!bottom && body.childNodes.length) {
      const range = document.createRange();
      range.selectNodeContents(body);
      bottom = range.getBoundingClientRect().bottom + window.scrollY;
    }
    if (body.scrollHeight > window.innerHeight + 2) bottom = Math.max(bottom, body.scrollHeight);
    const height = Math.max(120, Math.min(20000, Math.ceil(bottom + (parseFloat(style.paddingBottom) || 0) + (parseFloat(style.marginBottom) || 0) + 2)));
    if (height !== previous) { previous = height; window.parent.postMessage({type: 'htmldn:resize', token, height}, '*'); }
  }
  function queue() { if (!scheduled) { scheduled = true; requestAnimationFrame(measure); } }
  function start() {
    if (!document.body) return;
    if ('ResizeObserver' in window) new ResizeObserver(queue).observe(document.body);
    new MutationObserver(queue).observe(document.body, {subtree: true, childList: true, attributes: true, characterData: true});
    document.addEventListener('load', queue, true);
    window.addEventListener('resize', queue);
    if (document.fonts) document.fonts.ready.then(queue);
    queue();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once: true});
  else start();
})();
