<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class HTMLDN_Plugin {
    const POST_TYPE = 'htmldn_html';
    const MAX_BYTES = 2097152;

    public static function boot() {
        add_action( 'init', array( __CLASS__, 'register' ) );
        add_action( 'rest_api_init', array( __CLASS__, 'rest_routes' ) );
        add_shortcode( 'htmldn', array( __CLASS__, 'shortcode' ) );
    }

    public static function can_manage() {
        return current_user_can( 'manage_options' ) && current_user_can( 'unfiltered_html' );
    }

    public static function register() {
        register_post_type( self::POST_TYPE, array(
            'label' => 'htmldn HTML', 'public' => false, 'publicly_queryable' => false,
            'exclude_from_search' => true, 'show_ui' => false, 'show_in_rest' => false,
            'rewrite' => false, 'query_var' => false, 'supports' => array( 'title' ),
            'can_export' => false, 'map_meta_cap' => false,
            'capabilities' => array(
                'edit_post' => 'do_not_allow', 'read_post' => 'do_not_allow', 'delete_post' => 'do_not_allow',
                'edit_posts' => 'do_not_allow', 'edit_others_posts' => 'do_not_allow',
                'publish_posts' => 'do_not_allow', 'read_private_posts' => 'do_not_allow',
                'create_posts' => 'do_not_allow', 'delete_posts' => 'do_not_allow',
            ),
        ) );
        wp_register_script( 'htmldn-frame', HTMLDN_URL . 'assets/frame.js', array(), HTMLDN_VERSION, true );
        wp_register_script( 'htmldn-block', HTMLDN_URL . 'assets/block.js', array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-api-fetch' ), HTMLDN_VERSION, true );
        register_block_type( 'htmldn/embed', array(
            'api_version' => 3, 'editor_script' => 'htmldn-block',
            'attributes' => array( 'id' => array( 'type' => 'number', 'default' => 0 ) ),
            'supports' => array( 'html' => false, 'align' => array( 'wide', 'full' ) ),
            'render_callback' => array( __CLASS__, 'block' ),
        ) );
    }

    public static function defaults() {
        return array( 'height' => 600, 'auto_height' => true, 'scripts' => true, 'forms' => false, 'downloads' => false, 'popups' => false );
    }

    public static function settings( $id ) {
        $value = get_post_meta( $id, '_htmldn_settings', true );
        return wp_parse_args( is_array( $value ) ? $value : array(), self::defaults() );
    }

    public static function clean_settings( $fields ) {
        $height = isset( $fields['height'] ) && is_scalar( $fields['height'] ) ? absint( $fields['height'] ) : 600;
        $settings = array( 'height' => max( 120, min( 20000, $height ) ) );
        foreach ( array( 'auto_height', 'scripts', 'forms', 'downloads', 'popups' ) as $key ) {
            $settings[ $key ] = isset( $fields[ $key ] ) && is_scalar( $fields[ $key ] ) && in_array( (string) $fields[ $key ], array( '1', 'on', 'true' ), true );
        }
        return $settings;
    }

    public static function get_document( $id ) {
        $post = get_post( absint( $id ) );
        return $post && self::POST_TYPE === $post->post_type ? $post : null;
    }

    public static function validate_html( $html ) {
        if ( ! is_string( $html ) ) { return new WP_Error( 'html_type', 'HTMLコードを入力してください。' ); }
        if ( strlen( $html ) > self::MAX_BYTES ) { return new WP_Error( 'html_size', 'HTMLは2MB以内で保存してください。' ); }
        $html = preg_replace( '/\A\xEF\xBB\xBF/', '', $html );
        if ( preg_match( '/\A\s*```(?:html)?[\t ]*\r?\n([\s\S]*?)\r?\n```[\t ]*\s*\z/i', $html, $matches ) ) { $html = $matches[1]; }
        if ( '' === trim( $html ) ) { return new WP_Error( 'html_empty', 'HTMLコードが空です。' ); }
        if ( false !== strpos( $html, "\0" ) || '' === wp_check_invalid_utf8( $html ) ) { return new WP_Error( 'html_encoding', 'UTF-8形式のHTMLファイルをご利用ください。' ); }
        return $html;
    }

    /** Store source only after both WordPress capability checks; no executable upload is created. */
    public static function save_document( $id, $fields ) {
        if ( ! self::can_manage() ) { return new WP_Error( 'permission', 'HTMLの管理権限がありません。' ); }
        $id = absint( $id );
        if ( $id && ( ! self::get_document( $id ) || 'trash' === get_post_status( $id ) ) ) { return new WP_Error( 'not_found', '編集対象が見つかりません。' ); }
        $html = self::validate_html( $fields['html'] ?? '' );
        if ( is_wp_error( $html ) ) { return $html; }
        $title = sanitize_text_field( is_string( $fields['title'] ?? null ) ? $fields['title'] : '' );
        if ( '' === trim( $title ) ) { return new WP_Error( 'title_empty', '管理用タイトルを入力してください。' ); }
        $saved = wp_insert_post( wp_slash( array(
            'ID' => $id, 'post_type' => self::POST_TYPE, 'post_title' => $title, 'post_content' => '',
            'post_status' => 'publish' === ( $fields['status'] ?? '' ) ? 'publish' : 'draft',
        ) ), true );
        if ( is_wp_error( $saved ) ) { return $saved; }
        // The source is intentionally unfiltered. It is never echoed into a parent document.
        update_post_meta( $saved, '_htmldn_source', wp_slash( $html ) );
        update_post_meta( $saved, '_htmldn_settings', self::clean_settings( $fields ) );
        return $saved;
    }

    public static function sandbox( $settings ) {
        $flags = array();
        foreach ( array( 'scripts' => 'allow-scripts', 'forms' => 'allow-forms', 'downloads' => 'allow-downloads', 'popups' => 'allow-popups' ) as $key => $flag ) {
            if ( ! empty( $settings[ $key ] ) ) { $flags[] = $flag; }
        }
        // Do not add allow-same-origin or top-navigation: the parent WordPress page stays isolated.
        return implode( ' ', $flags );
    }

    public static function frame_document( $html, $token, $resize ) {
        $head = '<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
        if ( ! preg_match( '/<html(?:\s|>)/i', $html ) ) {
            $html = '<!doctype html><html><head>' . $head . '<style>html,body{margin:0}img,video,canvas{max-width:100%}*{box-sizing:border-box}</style></head><body>' . $html . '</body></html>';
        } elseif ( ! preg_match( '/<meta\b[^>]*\bname\s*=\s*[\x22\x27]?viewport\b/i', $html ) ) {
            $html = preg_replace( '/(<head\b[^>]*>)/i', '$1' . $head, $html, 1 );
        }
        if ( $resize ) {
            $script = file_get_contents( HTMLDN_PATH . 'assets/resize-child.js' );
            $script = str_replace( '__HTMLDN_TOKEN_JSON__', wp_json_encode( $token, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ), $script );
            $html .= '<script>' . $script . '</script>';
        }
        return $html;
    }

    public static function shortcode( $attributes ) {
        $attributes = shortcode_atts( array( 'id' => 0, 'height' => '', 'auto_height' => '', 'title' => '' ), $attributes, 'htmldn' );
        $post = self::get_document( $attributes['id'] );
        if ( ! $post || 'publish' !== $post->post_status ) { return '<!-- htmldn: unavailable -->'; }
        $source = get_post_meta( $post->ID, '_htmldn_source', true );
        if ( ! is_string( $source ) || '' === $source ) { return ''; }
        $settings = self::settings( $post->ID );
        if ( '' !== $attributes['height'] ) { $settings['height'] = max( 120, min( 20000, absint( $attributes['height'] ) ) ); }
        if ( '' !== $attributes['auto_height'] ) { $settings['auto_height'] = '1' === (string) $attributes['auto_height']; }
        $resize = ! empty( $settings['auto_height'] ) && ! empty( $settings['scripts'] );
        $token = 'htmldn-' . wp_generate_uuid4();
        $title = $attributes['title'] ? sanitize_text_field( $attributes['title'] ) : $post->post_title;
        $document = self::frame_document( $source, $token, $resize );
        // srcdoc needs double entity encoding to preserve literal &lt; and &amp; in source.
        if ( $resize ) { wp_enqueue_script( 'htmldn-frame' ); }
        return '<div class="htmldn-embed"><iframe class="htmldn-frame" title="' . esc_attr( $title ) . '" sandbox="' . esc_attr( self::sandbox( $settings ) ) . '" referrerpolicy="no-referrer" loading="lazy" width="100%" height="' . absint( $settings['height'] ) . '" style="display:block;width:100%;max-width:100%;height:' . absint( $settings['height'] ) . 'px;border:0;aspect-ratio:auto" data-htmldn-token="' . esc_attr( $token ) . '" data-htmldn-auto="' . ( $resize ? '1' : '0' ) . '" srcdoc="' . htmlspecialchars( $document, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8', true ) . '"></iframe></div>';
    }

    public static function block( $attributes ) {
        $content = self::shortcode( array( 'id' => absint( $attributes['id'] ?? 0 ) ) );
        return '<div ' . get_block_wrapper_attributes( array( 'class' => 'htmldn-block' ) ) . '>' . $content . '</div>';
    }

    public static function rest_routes() {
        register_rest_route( 'htmldn/v1', '/documents', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => function() { return current_user_can( 'edit_posts' ) || current_user_can( 'edit_pages' ); },
            'callback' => function() {
                $posts = get_posts( array( 'post_type' => self::POST_TYPE, 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC', 'no_found_rows' => true ) );
                return rest_ensure_response( array_map( function( $post ) { return array( 'id' => $post->ID, 'title' => $post->post_title ); }, $posts ) );
            },
        ) );
    }
}
