<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class HTMLDN_Admin {
    public static function boot() {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
        foreach ( array( 'save', 'trash', 'restore', 'download' ) as $action ) {
            add_action( 'admin_post_htmldn_' . $action, array( __CLASS__, $action ) );
        }
        add_action( 'wp_ajax_htmldn_preview', array( __CLASS__, 'preview' ) );
        add_filter( 'plugin_action_links_' . plugin_basename( HTMLDN_PATH . 'htmldn.php' ), array( __CLASS__, 'plugin_links' ) );
    }

    public static function menu() { add_menu_page( 'htmldn', 'htmldn', 'manage_options', 'htmldn', array( __CLASS__, 'screen' ), 'dashicons-editor-code', 58 ); }
    public static function plugin_links( $links ) { array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=htmldn' ) ) . '">HTMLを管理</a>' ); return $links; }
    public static function url( $args = array() ) { return add_query_arg( array_merge( array( 'page' => 'htmldn' ), $args ), admin_url( 'admin.php' ) ); }

    public static function guard() {
        if ( ! HTMLDN_Plugin::can_manage() ) {
            wp_die( 'htmldnの管理には、manage_options と unfiltered_html の権限が必要です。マルチサイトでは特権管理者でご利用ください。', 'htmldn', array( 'response' => 403 ) );
        }
    }

    public static function assets( $hook ) {
        if ( 'toplevel_page_htmldn' !== $hook || ! HTMLDN_Plugin::can_manage() ) { return; }
        wp_enqueue_style( 'htmldn-admin', HTMLDN_URL . 'assets/admin.css', array(), HTMLDN_VERSION );
        $editor = wp_enqueue_code_editor( array( 'type' => 'text/html', 'codemirror' => array( 'lineNumbers' => true, 'lineWrapping' => true, 'indentUnit' => 2, 'tabSize' => 2 ) ) );
        wp_enqueue_script( 'htmldn-admin', HTMLDN_URL . 'assets/admin.js', $editor ? array( 'code-editor' ) : array(), HTMLDN_VERSION, true );
        wp_enqueue_script( 'htmldn-frame' );
        wp_localize_script( 'htmldn-admin', 'htmldnAdmin', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'previewNonce' => wp_create_nonce( 'htmldn_preview' ),
            'maxBytes' => HTMLDN_Plugin::MAX_BYTES, 'editor' => $editor,
            'example' => file_get_contents( HTMLDN_PATH . 'examples/gold-counter.html' ),
        ) );
    }

    public static function save() {
        self::guard();
        check_admin_referer( 'htmldn_save' );
        $result = HTMLDN_Plugin::save_document( absint( $_POST['id'] ?? 0 ), wp_unslash( $_POST ) );
        if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ), 'htmldn', array( 'response' => 400, 'back_link' => true ) ); }
        wp_safe_redirect( self::url( array( 'view' => 'edit', 'id' => $result, 'notice' => 'saved' ) ) );
        exit;
    }

    private static function target( $id ) {
        $post = HTMLDN_Plugin::get_document( $id );
        if ( ! $post ) { wp_die( '対象のHTMLが見つかりません。', 'htmldn', array( 'response' => 404 ) ); }
        return $post;
    }

    public static function trash() {
        self::guard(); $id = absint( $_POST['id'] ?? 0 ); check_admin_referer( 'htmldn_trash_' . $id ); self::target( $id );
        if ( defined( 'EMPTY_TRASH_DAYS' ) && ! EMPTY_TRASH_DAYS ) {
            wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
            wp_safe_redirect( self::url( array( 'notice' => 'drafted' ) ) ); exit;
        }
        if ( ! wp_trash_post( $id ) ) { wp_die( 'ゴミ箱へ移動できませんでした。', 'htmldn', array( 'response' => 400 ) ); }
        wp_safe_redirect( self::url( array( 'notice' => 'trashed' ) ) ); exit;
    }

    public static function restore() {
        self::guard(); $id = absint( $_POST['id'] ?? 0 ); check_admin_referer( 'htmldn_restore_' . $id ); $post = self::target( $id );
        if ( 'trash' !== $post->post_status || ! wp_untrash_post( $id ) ) { wp_die( '復元できませんでした。', 'htmldn', array( 'response' => 400 ) ); }
        wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
        wp_safe_redirect( self::url( array( 'view' => 'edit', 'id' => $id, 'notice' => 'restored' ) ) ); exit;
    }

    public static function download() {
        self::guard(); $id = absint( $_GET['id'] ?? 0 ); check_admin_referer( 'htmldn_download_' . $id ); self::target( $id );
        nocache_headers();
        header( 'Content-Type: application/octet-stream' );
        header( 'Content-Disposition: attachment; filename="htmldn-' . $id . '.html"' );
        header( 'X-Content-Type-Options: nosniff' );
        // A forced-download response, never a same-origin executable HTML page.
        echo get_post_meta( $id, '_htmldn_source', true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    public static function preview() {
        if ( ! HTMLDN_Plugin::can_manage() ) { wp_send_json_error( array( 'message' => 'プレビューの権限がありません。' ), 403 ); }
        check_ajax_referer( 'htmldn_preview', 'nonce' );
        $fields = wp_unslash( $_POST );
        $html = HTMLDN_Plugin::validate_html( $fields['html'] ?? '' );
        if ( is_wp_error( $html ) ) { wp_send_json_error( array( 'message' => $html->get_error_message() ), 400 ); }
        $settings = HTMLDN_Plugin::clean_settings( $fields );
        $token = 'htmldn-' . wp_generate_uuid4();
        $resize = $settings['auto_height'] && $settings['scripts'];
        wp_send_json_success( array( 'document' => HTMLDN_Plugin::frame_document( $html, $token, $resize ), 'sandbox' => HTMLDN_Plugin::sandbox( $settings ), 'token' => $token, 'resize' => $resize, 'height' => $settings['height'] ) );
    }

    public static function screen() {
        self::guard();
        $view = isset( $_GET['view'] ) && is_string( $_GET['view'] ) ? sanitize_key( $_GET['view'] ) : '';
        $notices = array( 'drafted' => 'このサイトはゴミ箱が無効のため、削除せず下書きに切り替えました。', 'saved' => 'HTMLを保存しました。', 'trashed' => 'ゴミ箱に移動しました。埋め込みは非表示になります。', 'restored' => '下書きとして復元しました。公開状態を確認して保存してください。' );
        $notice = isset( $_GET['notice'] ) && is_string( $_GET['notice'] ) ? sanitize_key( $_GET['notice'] ) : '';
        ?>
        <div class="wrap htmldn-app">
            <header class="htmldn-header"><div><span class="htmldn-kicker">YOUR HTML, ON WORDPRESS</span><h1>html<span>dn</span><small>1.0</small></h1><p>つくったHTMLを、そのままサイトへ。</p></div><a class="htmldn-new" href="<?php echo esc_url( self::url( array( 'view' => 'new' ) ) ); ?>">＋ HTMLを追加</a></header>
            <?php if ( isset( $notices[ $notice ] ) ) : ?><div class="notice notice-success inline"><p><?php echo esc_html( $notices[ $notice ] ); ?></p></div><?php endif; ?>
            <?php if ( in_array( $view, array( 'new', 'edit' ), true ) ) { self::editor( 'edit' === $view ? absint( $_GET['id'] ?? 0 ) : 0 ); } else { self::listing(); } ?>
            <footer class="htmldn-admin-footer">htmldn — HTMLを保存して、ブロックまたはショートコードで表示。 <span>追加サービスの登録は不要です。</span></footer>
        </div>
        <?php
    }

    private static function listing() {
        $trash = isset( $_GET['status'] ) && 'trash' === $_GET['status'];
        $search = isset( $_GET['s'] ) && is_string( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
        $page = max( 1, absint( $_GET['paged'] ?? 1 ) );
        $query = new WP_Query( array( 'post_type' => HTMLDN_Plugin::POST_TYPE, 'post_status' => $trash ? 'trash' : array( 'publish', 'draft' ), 'posts_per_page' => 20, 'paged' => $page, 'orderby' => 'modified', 'order' => 'DESC', 's' => $search ) );
        ?>
        <div class="htmldn-how"><div><b>01</b><span>貼り付け・ファイル読込</span></div><div><b>02</b><span>プレビューして保存</span></div><div><b>03</b><span>記事に埋め込み</span></div></div>
        <section class="htmldn-panel"><div class="htmldn-panel-top"><h2><?php echo $trash ? 'ゴミ箱' : '保存済みHTML'; ?> <span class="htmldn-count"><?php echo absint( $query->found_posts ); ?></span></h2><div><a href="<?php echo esc_url( self::url() ); ?>">一覧</a><span aria-hidden="true"> / </span><a href="<?php echo esc_url( self::url( array( 'status' => 'trash' ) ) ); ?>">ゴミ箱</a></div></div>
        <form method="get" class="htmldn-search"><input type="hidden" name="page" value="htmldn"><?php if ( $trash ) : ?><input type="hidden" name="status" value="trash"><?php endif; ?><label class="screen-reader-text" for="htmldn-search">タイトルを検索</label><input id="htmldn-search" type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="タイトルを検索"><button class="button">検索</button></form>
        <?php if ( $query->have_posts() ) : ?>
        <div class="htmldn-table-scroll"><table class="widefat htmldn-table"><thead><tr><th>タイトル</th><th>状態</th><th>埋め込みコード</th><th>更新日</th><th>操作</th></tr></thead><tbody>
        <?php foreach ( $query->posts as $item ) : ?>
        <tr><td><strong><?php if ( ! $trash ) : ?><a href="<?php echo esc_url( self::url( array( 'view' => 'edit', 'id' => $item->ID ) ) ); ?>"><?php echo esc_html( $item->post_title ); ?></a><?php else : echo esc_html( $item->post_title ); endif; ?></strong><small>ID <?php echo absint( $item->ID ); ?></small></td><td><span class="htmldn-status <?php echo 'publish' === $item->post_status ? 'is-live' : ''; ?>"><?php echo 'publish' === $item->post_status ? '公開可' : ( $trash ? 'ゴミ箱' : '下書き' ); ?></span></td><td><code>[htmldn id="<?php echo absint( $item->ID ); ?>"]</code></td><td><?php echo esc_html( get_the_modified_date( 'Y/m/d H:i', $item ) ); ?></td><td><div class="htmldn-row-actions">
            <?php if ( ! $trash ) : ?><a class="button button-small" href="<?php echo esc_url( self::url( array( 'view' => 'edit', 'id' => $item->ID ) ) ); ?>">編集</a><?php endif; ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="<?php echo $trash ? 'htmldn_restore' : 'htmldn_trash'; ?>"><input type="hidden" name="id" value="<?php echo absint( $item->ID ); ?>"><?php wp_nonce_field( 'htmldn_' . ( $trash ? 'restore_' : 'trash_' ) . $item->ID ); ?><button class="button-link <?php echo $trash ? '' : 'button-link-delete'; ?>" type="submit"><?php echo $trash ? '復元' : 'ゴミ箱へ'; ?></button></form>
        </div></td></tr>
        <?php endforeach; ?>
        </tbody></table></div>
        <div class="htmldn-pagination"><?php echo wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'paged', '%#%', self::url( array( 'status' => $trash ? 'trash' : '', 's' => $search ) ) ), 'format' => '', 'current' => $page, 'total' => $query->max_num_pages ) ) ); ?></div>
        <?php else : ?><div class="htmldn-empty"><span aria-hidden="true">&lt;/&gt;</span><h3><?php echo $trash ? 'ゴミ箱は空です。' : 'HTMLを追加して、はじめましょう。'; ?></h3><p>HTMLコードを貼り付けるか、.htmlファイルを読み込めます。</p><a class="button button-primary" href="<?php echo esc_url( self::url( array( 'view' => 'new' ) ) ); ?>">HTMLを追加</a></div><?php endif; ?>
        </section>
        <?php
    }

    private static function editor( $id ) {
        $post = $id ? self::target( $id ) : null;
        if ( $post && 'trash' === $post->post_status ) { echo '<p>ゴミ箱から復元して編集してください。</p>'; return; }
        $settings = $id ? HTMLDN_Plugin::settings( $id ) : HTMLDN_Plugin::defaults();
        $source = $id ? get_post_meta( $id, '_htmldn_source', true ) : '';
        ?>
        <p><a href="<?php echo esc_url( self::url() ); ?>">← HTML一覧へ</a></p>
        <form id="htmldn-editor-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="htmldn_save"><input type="hidden" name="id" value="<?php echo absint( $id ); ?>"><?php wp_nonce_field( 'htmldn_save' ); ?>
            <div class="htmldn-edit-grid"><section class="htmldn-panel htmldn-code-panel">
                <label class="htmldn-label" for="htmldn-title">管理用タイトル</label><input id="htmldn-title" class="htmldn-title-field" type="text" name="title" value="<?php echo esc_attr( $post ? $post->post_title : '' ); ?>" placeholder="例：料金シミュレーター / 商品紹介 / お知らせ" required maxlength="200">
                <div class="htmldn-toolbar"><label class="button" for="htmldn-file">HTMLファイルを読み込む</label><input id="htmldn-file" type="file" accept=".html,.htm,text/html" class="screen-reader-text"><button id="htmldn-sample" type="button" class="button">サンプルを入れる</button><button id="htmldn-unfence" type="button" class="button">コードフェンスを除去</button><span id="htmldn-size">0 KB</span></div>
                <label class="htmldn-label" for="htmldn-source">HTMLコード <span>HTML・CSS・JavaScript / UTF-8 / 最大2MB</span></label>
                <textarea id="htmldn-source" name="html" rows="24" spellcheck="false" aria-describedby="htmldn-code-hint"><?php echo esc_textarea( $source ); ?></textarea>
                <p id="htmldn-code-hint" class="description">ChatGPTなどのコードを、そのまま貼り付けてください。HTML全文にも、一部分のHTMLにも対応します。</p>
            </section><aside class="htmldn-panel htmldn-settings"><h2>表示の設定</h2>
                <label class="htmldn-label" for="htmldn-status">公開状態</label><select id="htmldn-status" name="status"><option value="publish" <?php selected( ! $post || 'publish' === $post->post_status ); ?>>公開可（埋め込み可能）</option><option value="draft" <?php selected( $post && 'draft' === $post->post_status ); ?>>下書き（非表示）</option></select>
                <label class="htmldn-label" for="htmldn-height">基本の表示高さ（px）</label><input id="htmldn-height" name="height" type="number" min="120" max="20000" step="1" value="<?php echo absint( $settings['height'] ); ?>">
                <label class="htmldn-check"><input type="checkbox" name="auto_height" value="1" <?php checked( $settings['auto_height'] ); ?>>内容に合わせて高さを調整</label>
                <hr><h3>HTML内で使用する機能</h3>
                <?php foreach ( array( 'scripts' => 'JavaScriptを有効にする', 'forms' => 'フォーム送信を許可する', 'downloads' => 'ファイルのダウンロードを許可する', 'popups' => '別タブ・ポップアップを許可する' ) as $key => $label ) : ?><label class="htmldn-check"><input type="checkbox" name="<?php echo esc_attr( $key ); ?>" value="1" <?php checked( $settings[ $key ] ); ?>><?php echo esc_html( $label ); ?></label><?php endforeach; ?>
                <p class="description">自動高さ調整にはJavaScriptが必要です。HTMLは別フレーム内で動作し、テーマのCSSから分離されます。</p>
                <button class="button button-primary button-hero htmldn-save" type="submit">HTMLを保存</button>
                <div id="htmldn-feedback" role="status" aria-live="polite"></div>
                <?php if ( $id ) : ?><div class="htmldn-embed-code"><label class="htmldn-label" for="htmldn-shortcode">記事に貼るショートコード</label><input id="htmldn-shortcode" readonly value="<?php echo esc_attr( '[htmldn id="' . $id . '"]' ); ?>"><button id="htmldn-copy" type="button" class="button">コピー</button><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=htmldn_download&id=' . $id ), 'htmldn_download_' . $id ) ); ?>">HTMLを書き出す</a></div><?php else : ?><p class="description">保存すると埋め込みコードが表示されます。ブロックエディターの「htmldn HTML」からも選択できます。</p><?php endif; ?>
            </aside></div>
        </form>
        <section class="htmldn-panel htmldn-preview-panel"><div class="htmldn-panel-top"><div><span class="htmldn-kicker">PREVIEW</span><h2>表示を確認</h2></div><div class="htmldn-preview-tools"><button class="button" id="htmldn-preview" type="button">プレビューを更新</button><button class="button" id="htmldn-preview-stop" type="button">停止</button><label class="screen-reader-text" for="htmldn-preview-width">プレビューの幅</label><select id="htmldn-preview-width"><option value="100%">PC・全幅</option><option value="768px">タブレット・768px</option><option value="390px">スマートフォン・390px</option></select></div></div><div id="htmldn-preview-stage"><p class="htmldn-preview-placeholder">「プレビューを更新」を押すと、保存前のコードも確認できます。</p></div><p class="description">公開前に表示と動作をご確認ください。公開ページ側のキャッシュが有効な場合は、更新後にキャッシュを削除してください。</p></section>
        <details class="htmldn-panel htmldn-notes"><summary>利用時のポイント</summary><ul><li>画像やCSSなどはHTMLに含めるか、HTTPSの絶対URLを使ってください。HTMLファイルだけを読み込んでも、別フォルダーの素材は移動しません。</li><li>PHPやWordPressのショートコードはHTML内では実行されません。React・Vueのビルド前ソースも、そのままでは表示できません。</li><li>Cookie・localStorage・親ページの操作・親ページへの移動は利用できません。外部APIには提供元のCORS対応が必要です。</li><li>HTMLやJavaScriptに秘密のAPIキーを記載しないでください。公開したコードは訪問者から見える状態になります。</li><li>JavaScriptや外部画像などを含むHTMLは、その内容に応じた通信や動作を行います。内容を確認したコードをご利用ください。</li><li>自動高さが合わない場合や画面全体を使うアプリは、自動調整を外して基本の表示高さを設定してください。</li></ul></details>
        <?php
    }
}
