<?php
/**
 * Plugin Name: htmldn
 * Description: ChatGPTなどで作成したHTMLを保存し、専用ブロックまたはショートコードで表示します。HTMLファイル読込・CSS・JavaScript・プレビューに対応。
 * Version: 1.0.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: htmldn
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: htmldn
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
define( 'HTMLDN_VERSION', '1.0.0' );
define( 'HTMLDN_PATH', plugin_dir_path( __FILE__ ) );
define( 'HTMLDN_URL', plugin_dir_url( __FILE__ ) );
require_once HTMLDN_PATH . 'includes/class-htmldn.php';
require_once HTMLDN_PATH . 'includes/class-htmldn-admin.php';
HTMLDN_Plugin::boot();
HTMLDN_Admin::boot();
