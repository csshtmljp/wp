<?php
if (!defined('ABSPATH')) { exit; }

final class TokushoDN {
    const TYPE='tokushodn_profile';
    const MAX_BYTES=262144;
    public static function boot() {
        add_action('init',array(__CLASS__,'register'));
        add_action('wp_enqueue_scripts',array(__CLASS__,'styles'));
        add_shortcode('tokushodn',array(__CLASS__,'shortcode'));
    }
    public static function register() {
        register_post_type(self::TYPE,array('label'=>'特商法プロフィール','public'=>false,'publicly_queryable'=>false,'exclude_from_search'=>true,'show_ui'=>false,'show_in_rest'=>false,'rewrite'=>false,'query_var'=>false,'can_export'=>false,'supports'=>array('title'),'map_meta_cap'=>false,'capabilities'=>array('edit_post'=>'do_not_allow','read_post'=>'do_not_allow','delete_post'=>'do_not_allow','edit_posts'=>'do_not_allow','edit_others_posts'=>'do_not_allow','publish_posts'=>'do_not_allow','read_private_posts'=>'do_not_allow','create_posts'=>'do_not_allow','delete_posts'=>'do_not_allow')));
    }
    public static function styles() { wp_enqueue_style('tokushodn-public',plugins_url('assets/public.css',TOKUSHODN_FILE),array(),TOKUSHODN_VERSION); }
    public static function can_manage() { return current_user_can('manage_options'); }
    public static function types() { return array('physical'=>'物販','digital'=>'デジタル商品','service'=>'サービス','mixed'=>'複合販売'); }
    public static function flags() {
        return array('recurring'=>array('定期購入・継続契約','支払周期・金額・契約期間・解約条件を追加します。'),'software'=>array('ソフトウェアを販売・提供する','必要なOSや端末など、動作環境の記載欄を追加します。'),'limited'=>array('申込期間を設ける','注文できる期限や期間を明記します。'),'restricted'=>array('数量・地域などの特別な条件がある','購入制限や提供対象の条件を明記します。'),'catalog'=>array('有料のカタログ等を送付する','請求により送る資料の料金を記載します。'),'email_ads'=>array('電子メールで商業広告を送る','広告に関する連絡先メールアドレスも確認します。'),'domestic'=>array('海外の事業者で、日本国内に事務所等がある','国内の所在場所と電話番号の欄を追加します。'));
    }
    // Input guidance is original text; no business identity or policy is prefilled.
    public static function fields() {
        return array(
            'seller'=>array('販売業者・役務提供事業者','基本情報','text','正式な法人名、または個人の氏名・登記された商号を入力します。屋号だけで済ませないよう確認してください。','【要入力】正式な事業者名'),
            'representative'=>array('代表者・通信販売の責任者','基本情報','text','法人では代表者または通信販売業務の責任者の氏名を入力します。','【要入力】担当する責任者の氏名'),
            'shop'=>array('ショップ・サービス名','基本情報','text','任意。事業者名とは別にブランド名を表示できます。','ショップ名'),
            'postal'=>array('郵便番号','基本情報','text','任意。所在地の補助として表示します。','郵便番号'),
            'address'=>array('所在地','基本情報','textarea','実際の活動場所を、建物名や部屋番号を含め正確に入力します。','【要入力】都道府県から建物名・部屋番号まで'),
            'phone'=>array('電話番号','基本情報','text','連絡が取れる電話番号を入力します。','【要入力】連絡可能な電話番号'),
            'contact_hours'=>array('お問い合わせ受付時間','基本情報','textarea','任意。曜日・時間・休業日を具体的に入力します。','例：平日 10:00〜17:00（土日祝を除く）'),
            'email'=>array('メールアドレス','基本情報','email','問い合わせ先。電子メール広告を行う設定では入力確認の対象です。','contact@example.com'),
            'contact_url'=>array('お問い合わせ窓口','基本情報','url','任意。問い合わせページの http / https URL を指定します。','https://example.com/contact/'),
            'website'=>array('販売サイト','基本情報','url','任意。販売サイトの http / https URL を指定します。','https://example.com/'),
            'price'=>array('販売価格・サービス料金','料金と決済','textarea','消費者が支払う価格を明確にします。商品ごとに異なる場合は、価格が確認できる場所も説明します。','【要入力】税込価格と、商品ごとに異なる場合の表示場所'),
            'price_url'=>array('価格の詳細','料金と決済','url','任意。具体的な価格が分かるページへのリンクです。','https://example.com/pricing/'),
            'fees'=>array('商品代金以外の費用','料金と決済','textarea','手数料などの内容・金額を入力します。発生しない場合も、その旨を実態に合わせて入力します。','【要入力】手数料などの内容と金額'),
            'shipping'=>array('送料','料金と決済','textarea','物販・複合販売では入力対象です。地域別料金や送料込み等の条件を具体的に入力します。','【要入力】地域別の送料、または送料込みの条件'),
            'shipping_url'=>array('送料の詳細','料金と決済','url','任意。料金表など、送料を確認できるページです。','https://example.com/shipping/'),
            'payment_methods'=>array('支払方法','料金と決済','textarea','実際に利用できる決済方法をすべて入力します。','【要入力】利用できる決済方法'),
            'payment_timing'=>array('支払時期','料金と決済','textarea','決済方法ごとに、決済時点・支払期限を具体的に入力します。','【要入力】決済方法別の支払時期・期限'),
            'delivery'=>array('引渡し・提供時期','提供と返品','textarea','注文・入金などの起点と、発送・納品・提供までの期間を入力します。','【要入力】いつから何日以内に発送・提供するか'),
            'application_period'=>array('申込期間','提供と返品','textarea','期間を限定する場合は、開始・終了の日時や対象条件を入力します。','【要入力】申込開始・終了日時と対象'),
            'quantity_limits'=>array('販売・提供条件','提供と返品','textarea','数量制限、対象地域、年齢や利用資格など、特別な条件を入力します。','【要入力】数量や対象地域などの条件'),
            'returns'=>array('返品・キャンセル・解除','提供と返品','textarea','可否だけでなく、期限・連絡方法・費用負担・返金条件などを記載します。','【要入力】返品や解約の可否、期限、方法、費用負担'),
            'defects'=>array('契約内容に適合しない場合の取扱い','提供と返品','textarea','この場合の責任に特別な定めがあるとき、その内容を入力します。通常の返品条件と区別して確認してください。','【要入力】不具合等の連絡先と対応内容（定める場合）'),
            'requirements'=>array('動作環境・利用環境','追加条件','textarea','必要なOS、対応端末、アプリやバージョン、容量などを入力します。','【要入力】対応OS・端末・必要アプリ等'),
            'license'=>array('利用許諾・利用制限','追加条件','textarea','任意。商用利用、複製、再配布などの条件を入力します。','【要入力】許諾する利用範囲と制限（定める場合）'),
            'subscription_cycle'=>array('継続契約の支払・提供周期','追加条件','textarea','課金周期、請求日、配送・提供の周期などを具体的に入力します。','【要入力】課金・提供の周期と日付'),
            'subscription_price'=>array('継続契約の料金・総額','追加条件','textarea','初回と2回目以降の価格、必要な継続回数、総額などを実際の契約に沿って明示します。','【要入力】初回・以後の料金、回数、総額や算定方法'),
            'subscription_term'=>array('契約期間・更新条件','追加条件','textarea','契約期間、最低継続期間、自動更新の有無と更新条件を入力します。','【要入力】期間、最低回数、自動更新の条件'),
            'subscription_cancel'=>array('定期購入の解約条件','追加条件','textarea','解約窓口、手順、申出期限、違約金等の有無と金額、解約の効力を具体化します。','【要入力】解約方法・期限・費用・効力'),
            'domestic_office'=>array('国内事務所等の所在地','追加条件','textarea','該当する海外事業者の、日本国内の事務所等を入力します。','【要入力】国内事務所等の所在地'),
            'domestic_phone'=>array('国内事務所等の電話番号','追加条件','text','該当する国内の事務所等と連絡が取れる番号を入力します。','【要入力】国内の電話番号'),
            'catalog_fee'=>array('カタログ等の送付料金','追加条件','textarea','有料で請求に応じて送る資料等の金額を入力します。','【要入力】資料の代金・送料等'),
            'privacy_url'=>array('プライバシーポリシー','関連情報','url','任意。公開済みのプライバシーポリシーへリンクします。','https://example.com/privacy/'),
            'terms_url'=>array('利用規約','関連情報','url','任意。公開済みの利用規約へリンクします。','https://example.com/terms/'),
            'notes'=>array('その他の事項','関連情報','textarea','任意。取引に必要な追加説明を入力します。','その他の説明')
        );
    }
    public static function defaults() {
        return array('entity'=>'individual','kind'=>'physical','flags'=>array(),'values'=>array(),'custom'=>array(),'heading'=>'特定商取引法に基づく表記','layout'=>'table','theme'=>'plain','show_title'=>1,'show_updated'=>1);
    }
    private static function text($v,$limit=5000) {
        if(!is_scalar($v)) { return ''; }
        $value=sanitize_textarea_field((string)$v);
        // wp_html_excerpt collapses line breaks; legal terms must keep paragraph boundaries.
        return mb_substr($value,0,$limit,'UTF-8');
    }
    public static function clean($raw) {
        $raw=is_array($raw)?$raw:array(); $d=self::defaults();
        $raw['values']=is_array($raw['values']??null)?$raw['values']:array();
        $raw['flags']=is_array($raw['flags']??null)?$raw['flags']:array();
        $d['entity']=($raw['entity']??'')==='corporate'?'corporate':'individual';
        $d['kind']=is_string($raw['kind']??null)&&isset(self::types()[$raw['kind']])?$raw['kind']:'physical';
        foreach(self::flags() as $key=>$label) { $d['flags'][$key]=!empty($raw['flags'][$key]); }
        foreach(self::fields() as $key=>$info) {
            $value=self::text($raw['values'][$key]??'', $info[2]==='textarea'?5000:500);
            // Preserve invalid URLs/emails as text; advisory checks do not prevent publication.
            $d['values'][$key]=$value;
        }
        foreach(array_slice(is_array($raw['custom']??null)?$raw['custom']:array(),0,20) as $row) {
            if(!is_array($row)) { continue; }
            $label=self::text($row['label']??'',100); $value=self::text($row['value']??'',5000);
            if($label!==''||$value!=='') { $d['custom'][]=array('label'=>$label,'value'=>$value); }
        }
        $d['heading']=self::text($raw['heading']??$d['heading'],120);
        $d['layout']=in_array($raw['layout']??'',array('table','cards'),true)?$raw['layout']:'table';
        $d['theme']=in_array($raw['theme']??'',array('plain','gold','slate'),true)?$raw['theme']:'plain';
        $d['show_title']=!empty($raw['show_title'])?1:0; $d['show_updated']=!empty($raw['show_updated'])?1:0;
        return $d;
    }
    public static function required($d) {
        $keys=array('seller','address','phone','price','fees','payment_methods','payment_timing','delivery','returns');
        if($d['entity']==='corporate') { $keys[]='representative'; }
        if(in_array($d['kind'],array('physical','mixed'),true)) { $keys[]='shipping'; }
        $map=array('recurring'=>array('subscription_cycle','subscription_price','subscription_term','subscription_cancel'),'software'=>array('requirements'),'limited'=>array('application_period'),'restricted'=>array('quantity_limits'),'catalog'=>array('catalog_fee'),'email_ads'=>array('email'),'domestic'=>array('domestic_office','domestic_phone'));
        foreach($map as $flag=>$extra) { if(!empty($d['flags'][$flag])) { $keys=array_merge($keys,$extra); } }
        return $keys;
    }
    public static function valid_url($value) {
        if(!is_string($value)||preg_match('/[\s<>"\x00-\x1F]/u',$value)) { return false; }
        $u=wp_parse_url($value);
        return is_array($u)&&!empty($u['host'])&&in_array(strtolower($u['scheme']??''),array('http','https'),true)&&!isset($u['user'])&&!isset($u['pass']);
    }
    public static function checks($d) {
        $errors=array();$warnings=array();$fields=self::fields();$required=self::required($d);
        foreach($fields as $key=>$info) {
            $value=$d['values'][$key]??'';
            if(in_array($key,$required,true)&&trim($value)==='') { $errors[]=$info[0].'を入力してください。'; }
            if($value!==''&&preg_match('/【要入力】|\{\{[^}]+\}\}|○○|〇〇|XXXX|example\.(com|org|net)/iu',$value)) { $errors[]=$info[0].'に仮の値が残っています。'; }
            if($value!==''&&$info[2]==='url'&&!self::valid_url($value)) { $errors[]=$info[0].'は http / https の有効なURLにしてください。'; }
            if($value!==''&&$info[2]==='email'&&!is_email($value)) { $errors[]='メールアドレスの形式を確認してください。'; }
        }
        foreach($d['custom'] as $row) {
            if($row['label']===''||$row['value']==='') { $errors[]='追加項目は見出しと内容を両方入力してください。'; }
            if(preg_match('/【要入力】|○○|〇〇|\{\{[^}]+\}\}/u',$row['label'].$row['value'])) { $errors[]='追加項目に仮の値が残っています。'; }
        }
        if($d['show_title']&&$d['heading']==='') { $errors[]='表示タイトルを入力してください。'; }
        if(empty($d['values']['email'])&&empty($d['values']['contact_url'])) { $warnings[]='問い合わせ先メールまたは窓口URLも確認してください。'; }
        if(in_array($d['kind'],array('digital','mixed'),true)&&empty($d['values']['requirements'])) { $warnings[]='デジタル商品を利用する環境・対応形式が必要か確認してください。ソフトウェアは追加条件にチェックします。'; }
        if(($d['values']['shipping']??'')==='送料実費') { $warnings[]='送料は具体的な金額や条件が分かる記載にしてください。'; }
        if(preg_match('/一切.*(返品|返金|責任).*(不可|応じ|負わ)|いかなる.*(返品|返金|責任)/u',$d['values']['returns'].' '.$d['values']['defects'])) { $warnings[]='返品・返金・責任を一律に否定する記載は、契約内容に適合しない場合なども区別して確認してください。'; }
        return array('errors'=>array_values(array_unique($errors)),'warnings'=>array_values(array_unique($warnings)),'filled'=>count(array_filter($d['values'],function($v){return $v!=='';})),'required'=>count($required));
    }
    public static function get($id) { $p=get_post(absint($id)); return $p&&$p->post_type===self::TYPE?$p:null; }
    public static function data($id) { $raw=get_post_meta($id,'_tokushodn_data',true); return self::clean(is_array($raw)?$raw:self::defaults()); }
    public static function save($id,$title,$raw,$status='draft') {
        if(!self::can_manage()) { return new WP_Error('permission','管理者権限が必要です。'); }
        $id=absint($id); if($id&&!self::get($id)) { return new WP_Error('type','対象のプロフィールがありません。'); }
        $title=sanitize_text_field(is_scalar($title)?(string)$title:''); if($title==='') { $title='名称未設定'; }
        if(strlen(wp_json_encode($raw))>self::MAX_BYTES) { return new WP_Error('size','データは256KB以内にしてください。'); }
        if(!is_array($raw)) { return new WP_Error('format','入力形式を確認してください。'); }
        foreach(self::fields() as $key=>$info) {
            $value=$raw['values'][$key]??'';
            if(!is_scalar($value)) { return new WP_Error('format',$info[0].'は文字列で入力してください。'); }
            $count=preg_match_all('/./us',(string)$value);
            if($count===false||$count>($info[2]==='textarea'?5000:500)) { return new WP_Error('length',$info[0].'の文字数または文字コードを確認してください。'); }
        }
        if(isset($raw['custom'])&&(!is_array($raw['custom'])||count($raw['custom'])>20)) { return new WP_Error('custom','追加項目は20件以内にしてください。'); }
        foreach($raw['custom']??array() as $row) {
            if(!is_array($row)||!is_scalar($row['label']??'')||!is_scalar($row['value']??'')) { return new WP_Error('custom','追加項目の形式を確認してください。'); }
            foreach(array('label'=>100,'value'=>5000) as $key=>$limit) { $count=preg_match_all('/./us',(string)($row[$key]??''));if($count===false||$count>$limit){return new WP_Error('length','追加項目の文字数または文字コードを確認してください。');} }
        }
        if(!is_scalar($raw['heading']??'')||preg_match_all('/./us',(string)($raw['heading']??''))>120) { return new WP_Error('length','表示タイトルは120文字以内にしてください。'); }
        // Content checks are advisory. Authorization, data limits and escaping remain enforced.
        $d=self::clean($raw); $status=$status==='publish'?'publish':'draft';
        $result=wp_insert_post(wp_slash(array('ID'=>$id,'post_type'=>self::TYPE,'post_status'=>$status,'post_title'=>wp_html_excerpt($title,120,''),'post_content'=>'','post_author'=>get_current_user_id())),true);
        if(is_wp_error($result)) { return $result; }
        update_post_meta($result,'_tokushodn_data',wp_slash($d));
        update_post_meta($result,'_tokushodn_updated',current_datetime()->format('Y-m-d'));
        update_post_meta($result,'_tokushodn_revision',wp_generate_uuid4());
        return $result;
    }
    public static function duplicate($id) {
        if(!self::can_manage()) { return new WP_Error('permission','管理者権限が必要です。'); }
        $p=self::get($id); if(!$p) { return new WP_Error('missing','プロフィールがありません。'); }
        return self::save(0,$p->post_title.'（複製）',self::data($id),'draft');
    }
    public static function import_json($json) {
        if(!self::can_manage()) { return new WP_Error('permission','管理者権限が必要です。'); }
        if(!is_string($json)||strlen($json)>self::MAX_BYTES) { return new WP_Error('size','JSONは256KB以内にしてください。'); }
        $r=json_decode(preg_replace('/^\xEF\xBB\xBF/','',$json),true);
        if(!is_array($r)||($r['format']??'')!=='tokushodn'||($r['version']??0)!==1||!is_array($r['data']??null)) { return new WP_Error('format','TokushoDNのバージョン1形式のJSONを指定してください。'); }
        return self::save(0,is_string($r['title']??null)?$r['title'].'（インポート）':'インポートした表記',$r['data'],'draft');
    }
    public static function rows($d) {
        $rows=array();
        foreach(self::fields() as $key=>$info) { $v=$d['values'][$key]??''; if($v!=='') { $rows[]=array('label'=>$info[0],'value'=>$v,'type'=>$info[2]); } }
        foreach($d['custom'] as $r) { if($r['label']!==''&&$r['value']!=='') { $rows[]=array('label'=>$r['label'],'value'=>$r['value'],'type'=>'textarea'); } }
        return $rows;
    }
    private static function value_html($row) {
        if($row['type']==='url'&&self::valid_url($row['value'])) { return '<a href="'.esc_url($row['value']).'">'.esc_html($row['value']).'</a>'; }
        if($row['type']==='email'&&is_email($row['value'])) { return '<a href="'.esc_attr('mailto:'.$row['value']).'">'.esc_html($row['value']).'</a>'; }
        return nl2br(esc_html($row['value']),false);
    }
    public static function render($d,$date='') {
        $d=self::clean($d);$rows=self::rows($d);$title_id=wp_unique_id('tokushodn-title-');$show_heading=$d['show_title']&&$d['heading']!=='';
        $out='<section class="tdn-public tdn-theme-'.esc_attr($d['theme']).' tdn-layout-'.esc_attr($d['layout']).'"'.($show_heading?' aria-labelledby="'.esc_attr($title_id).'"':' aria-label="特定商取引法に基づく表記"').'>';
        if($show_heading) { $out.='<h2 id="'.esc_attr($title_id).'">'.esc_html($d['heading']).'</h2>'; }
        if($d['layout']==='table') {
            $out.='<table class="tdn-table"><caption class="tdn-visually-hidden">販売条件と事業者情報</caption><tbody>';
            foreach($rows as $row) { $out.='<tr><th scope="row">'.esc_html($row['label']).'</th><td>'.self::value_html($row).'</td></tr>'; } $out.='</tbody></table>';
        } else {
            $out.='<dl class="tdn-cards">'; foreach($rows as $row) { $out.='<div><dt>'.esc_html($row['label']).'</dt><dd>'.self::value_html($row).'</dd></div>'; } $out.='</dl>';
        }
        if($d['show_updated']&&preg_match('/^\d{4}-\d{2}-\d{2}$/D',$date)) { $out.='<p class="tdn-updated">更新日：<time datetime="'.esc_attr($date).'">'.esc_html($date).'</time></p>'; }
        return $out.'</section>';
    }
    public static function shortcode($atts) {
        $a=shortcode_atts(array('id'=>0,'layout'=>'','theme'=>'','title'=>'','updated'=>''),$atts,'tokushodn'); $p=self::get(absint($a['id']));
        if(!$p||$p->post_status!=='publish') { return ''; }
        $d=self::data($p->ID);
        foreach(array('layout'=>array('table','cards'),'theme'=>array('plain','gold','slate')) as $key=>$allowed) { if(in_array($a[$key],$allowed,true)) { $d[$key]=$a[$key]; } }
        foreach(array('title'=>'show_title','updated'=>'show_updated') as $key=>$setting) { if(in_array((string)$a[$key],array('0','1'),true)) { $d[$setting]=(int)$a[$key]; } }
        return self::render($d,(string)get_post_meta($p->ID,'_tokushodn_updated',true));
    }
}
