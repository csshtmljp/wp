<?php
if (!defined('ABSPATH')) { exit; }

final class TokushoDN_Admin {
    public static function boot() {
        add_action('admin_menu',array(__CLASS__,'menu'));
        add_action('admin_enqueue_scripts',array(__CLASS__,'assets'));
        foreach(array('save','duplicate','trash','restore','import','export','page_draft') as $action) { add_action('admin_post_tokushodn_'.$action,array(__CLASS__,$action)); }
        add_action('wp_ajax_tokushodn_preview',array(__CLASS__,'preview'));
        add_filter('plugin_action_links_'.plugin_basename(TOKUSHODN_FILE),array(__CLASS__,'links'));
    }
    private static function guard() { if(!TokushoDN::can_manage()) { wp_die('管理者権限が必要です。','',array('response'=>403)); } }
    private static function scalar($arr,$key,$fallback='') { return isset($arr[$key])&&is_scalar($arr[$key])?wp_unslash((string)$arr[$key]):$fallback; }
    private static function url($args=array()) { return add_query_arg(array_merge(array('page'=>'tokushodn'),$args),admin_url('admin.php')); }
    private static function redirect($args=array()) { wp_safe_redirect(self::url($args)); exit; }
    private static function target() { $p=TokushoDN::get(absint(self::scalar($_REQUEST,'id'))); if(!$p) { wp_die('対象のプロフィールがありません。','',array('response'=>404)); } return $p; }
    public static function menu() { add_menu_page('TokushoDN 特商法表記','TokushoDN','manage_options','tokushodn',array(__CLASS__,'screen'),'dashicons-media-document',82); }
    public static function links($links) { array_unshift($links,'<a href="'.esc_url(self::url()).'">表記を作成</a>');return $links; }
    public static function assets($hook) {
        if($hook!=='toplevel_page_tokushodn') { return; }
        wp_enqueue_style('tokushodn-admin',plugins_url('assets/admin.css',TOKUSHODN_FILE),array(),TOKUSHODN_VERSION);
        wp_enqueue_script('tokushodn-admin',plugins_url('assets/admin.js',TOKUSHODN_FILE),array(),TOKUSHODN_VERSION,true);
        wp_add_inline_script('tokushodn-admin','window.TokushoDNAdmin='.wp_json_encode(array('endpoint'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('tokushodn_preview'),'maxBytes'=>TokushoDN::MAX_BYTES)).';','before');
    }
    private static function start_form($action,$id=0,$extra='') {
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" '.$extra.'><input type="hidden" name="action" value="tokushodn_'.esc_attr($action).'"><input type="hidden" name="id" value="'.esc_attr($id).'">';wp_nonce_field('tokushodn_'.$action);
    }
    private static function action_form($action,$id,$text) { self::start_form($action,$id,'class="tdn-inline-form"');echo '<button class="button" type="submit">'.esc_html($text).'</button></form>'; }
    private static function fail($error) { wp_die(esc_html(is_wp_error($error)?$error->get_error_message():(string)$error),'操作を完了できませんでした',array('response'=>400,'back_link'=>true)); }
    private static function doc($data,$date='') { return '<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>特定商取引法に基づく表記</title><style>body{margin:0;padding:22px;font-family:system-ui,sans-serif;background:#fff}main{max-width:1080px;margin:auto}'.file_get_contents(TOKUSHODN_PATH.'assets/public.css').'</style></head><body><main>'.TokushoDN::render($data,$date).'</main></body></html>'; }
    public static function save() {
        self::guard();check_admin_referer('tokushodn_save');
        $id=absint(self::scalar($_POST,'id'));$name=self::scalar($_POST,'name');$raw=isset($_POST['data'])&&is_array($_POST['data'])?wp_unslash($_POST['data']):array();$status=self::scalar($_POST,'status','draft');
        if($id) {
            $post=self::target();$revision=(string)get_post_meta($id,'_tokushodn_revision',true);
            if(!hash_equals($revision,self::scalar($_POST,'revision'))) { self::fail('別の画面から更新されています。変更内容を控え、再読み込みしてから編集してください。'); }
        }
        $result=TokushoDN::save($id,$name,$raw,$status);
        if(is_wp_error($result)) {
            $token=wp_generate_password(20,false,false);
            set_transient('tokushodn_attempt_'.get_current_user_id().'_'.$token,array('id'=>$id,'name'=>sanitize_text_field($name),'data'=>TokushoDN::clean($raw),'status'=>$status,'error'=>$result->get_error_message(),'revision'=>self::scalar($_POST,'revision')),10*MINUTE_IN_SECONDS);
            self::redirect(array('view'=>'edit','id'=>$id,'attempt'=>$token));
        }
        self::redirect(array('view'=>'edit','id'=>$result,'notice'=>'saved'));
    }
    public static function duplicate() { self::guard();check_admin_referer('tokushodn_duplicate');$p=self::target();$id=TokushoDN::duplicate($p->ID);if(is_wp_error($id)){self::fail($id);}self::redirect(array('view'=>'edit','id'=>$id,'notice'=>'copied')); }
    public static function trash() {
        self::guard();check_admin_referer('tokushodn_trash');$p=self::target();
        if(defined('EMPTY_TRASH_DAYS')&&!(int)EMPTY_TRASH_DAYS) { $r=wp_update_post(array('ID'=>$p->ID,'post_status'=>'draft'),true); } else { $r=wp_trash_post($p->ID); }
        if(!$r||is_wp_error($r)) { self::fail('公開停止処理に失敗しました。'); } update_post_meta($p->ID,'_tokushodn_revision',wp_generate_uuid4());self::redirect(array('notice'=>'stopped'));
    }
    public static function restore() {
        self::guard();check_admin_referer('tokushodn_restore');$p=self::target();
        $r=wp_update_post(array('ID'=>$p->ID,'post_status'=>'draft'),true);if(is_wp_error($r)){self::fail($r);}update_post_meta($p->ID,'_tokushodn_revision',wp_generate_uuid4());self::redirect(array('view'=>'edit','id'=>$p->ID,'notice'=>'restored'));
    }
    public static function import() { self::guard();check_admin_referer('tokushodn_import');$id=TokushoDN::import_json(self::scalar($_POST,'json'));if(is_wp_error($id)){self::fail($id);}self::redirect(array('view'=>'edit','id'=>$id,'notice'=>'imported')); }
    public static function export() {
        self::guard();check_admin_referer('tokushodn_export');$p=self::target();$data=TokushoDN::data($p->ID);$html=self::scalar($_GET,'format')==='html';
        $body=$html?self::doc($data,(string)get_post_meta($p->ID,'_tokushodn_updated',true)):wp_json_encode(array('format'=>'tokushodn','version'=>1,'title'=>$p->post_title,'data'=>$data),JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
        nocache_headers();header('X-Content-Type-Options: nosniff');header('Content-Type: application/octet-stream');header('Content-Disposition: attachment; filename="tokushodn-'.$p->ID.'.'.($html?'html':'json').'"');echo $body;exit;
    }
    public static function page_draft() {
        self::guard();check_admin_referer('tokushodn_page_draft');$p=self::target();
        if(!current_user_can('edit_pages')) { wp_die('固定ページの編集権限が必要です。','',array('response'=>403)); }
        $existing=get_post((int)get_post_meta($p->ID,'_tokushodn_page_id',true));
        if($existing&&$existing->post_type==='page'&&$existing->post_status!=='trash'&&(int)get_post_meta($existing->ID,'_tokushodn_profile_id',true)===$p->ID) { if(!current_user_can('edit_post',$existing->ID)){wp_die('この固定ページの編集権限がありません。','',array('response'=>403));}wp_safe_redirect(get_edit_post_link($existing->ID,'raw'));exit; }
        $id=wp_insert_post(array('post_type'=>'page','post_status'=>'draft','post_title'=>'特定商取引法に基づく表記','post_content'=>'<!-- wp:shortcode -->[tokushodn id="'.$p->ID.'"]<!-- /wp:shortcode -->','post_author'=>get_current_user_id()),true);
        if(is_wp_error($id)) { self::fail($id); } update_post_meta($p->ID,'_tokushodn_page_id',$id);update_post_meta($id,'_tokushodn_profile_id',$p->ID);wp_safe_redirect(get_edit_post_link($id,'raw'));exit;
    }
    public static function preview() {
        self::guard();check_ajax_referer('tokushodn_preview','nonce');
        $raw=isset($_POST['data'])&&is_array($_POST['data'])?wp_unslash($_POST['data']):array();
        if(strlen(wp_json_encode($raw))>TokushoDN::MAX_BYTES) { wp_send_json_error(array('message'=>'256KB以内にしてください。'),413); }
        $data=TokushoDN::clean($raw);nocache_headers();wp_send_json_success(array('document'=>self::doc($data,current_datetime()->format('Y-m-d')),'checks'=>TokushoDN::checks($data),'required'=>TokushoDN::required($data)));
    }
    public static function screen() {
        self::guard();echo '<div class="wrap tdn-admin"><header class="tdn-hero"><div><span>COMMERCE DISCLOSURE STUDIO</span><h1>Tokusho<span>DN</span></h1><p>販売の条件を、読みやすく、ひとつの表記に。</p></div><a class="button" href="'.esc_url(self::url(array('view'=>'edit'))).'">＋ 新しい表記</a></header><nav class="tdn-nav"><a href="'.esc_url(self::url()).'">プロフィール一覧</a><a href="'.esc_url(self::url(array('view'=>'tools'))).'">インポート・使い方</a><span>日本語 / 通信販売向け</span></nav>';
        $notices=array('saved'=>'保存しました。掲載用の内容を更新した場合は、ページキャッシュ・CDNを削除し、実際の掲載ページも確認してください。','copied'=>'下書きとして複製しました。','imported'=>'新しい下書きとしてインポートしました。','restored'=>'下書きとして復元しました。','stopped'=>'ショートコードでの表示を停止しました。ページキャッシュ・CDNも削除してください。');$n=self::scalar($_GET,'notice');
        if(isset($notices[$n])) { echo '<div class="notice notice-success"><p>'.esc_html($notices[$n]).'</p></div>'; }
        $view=self::scalar($_GET,'view');if($view==='edit'){self::editor();}elseif($view==='tools'){self::tools_page();}else{self::listing();}
        echo '<footer class="tdn-foot">TokushoDN 1.0.1 · 入力内容はこのWordPress内に保存します。</footer></div>';
    }
    private static function listing() {
        $status=self::scalar($_GET,'status','all');$status=in_array($status,array('draft','publish','trash'),true)?$status:'all';
        $paged=max(1,absint(self::scalar($_GET,'paged','1')));$search=sanitize_text_field(self::scalar($_GET,'s'));
        $q=new WP_Query(array('post_type'=>TokushoDN::TYPE,'post_status'=>$status==='all'?array('draft','publish'):$status,'posts_per_page'=>12,'paged'=>$paged,'s'=>$search,'orderby'=>'modified','order'=>'DESC'));
        echo '<div class="tdn-toolbar"><div><h2>表記プロフィール</h2><p>ショップや販売形態ごとに管理できます。</p></div><form method="get"><input type="hidden" name="page" value="tokushodn"><input type="hidden" name="status" value="'.esc_attr($status).'"><label class="screen-reader-text" for="tdn-search">プロフィールを検索</label><input id="tdn-search" name="s" value="'.esc_attr($search).'" placeholder="管理用の名前で検索"><button class="button">検索</button></form></div><div class="tdn-tabs">';
        foreach(array('all'=>'すべて','publish'=>'掲載用','draft'=>'下書き','trash'=>'ゴミ箱') as $key=>$label) { echo '<a '.($status===$key?'aria-current="page" ':'').'href="'.esc_url(self::url(array('status'=>$key))).'">'.esc_html($label).'</a>'; }echo '</div>';
        if(!$q->posts) { echo '<section class="tdn-panel tdn-empty"><div class="tdn-empty-mark">§</div><h2>販売条件をまとめるところから。</h2><p>事業者情報と取引条件を入力すると、掲載用ショートコードを生成できます。</p><a class="button button-primary" href="'.esc_url(self::url(array('view'=>'edit'))).'">最初の表記を作成</a></section>'; }
        echo '<div class="tdn-profile-grid">';foreach($q->posts as $p) {
            $d=TokushoDN::data($p->ID);echo '<article class="tdn-panel"><div class="tdn-card-top"><span class="tdn-badge">'.esc_html(TokushoDN::types()[$d['kind']]).'</span><span>'.esc_html($p->post_status==='publish'?'● 掲載用':($p->post_status==='trash'?'ゴミ箱':'○ 下書き')).'</span></div><h3><a href="'.esc_url(self::url(array('view'=>'edit','id'=>$p->ID))).'">'.esc_html($p->post_title).'</a></h3><p class="tdn-muted">更新 '.esc_html(get_post_meta($p->ID,'_tokushodn_updated',true)).' · ID '.esc_html($p->ID).'</p><label class="screen-reader-text" for="tdn-code-'.esc_attr($p->ID).'">ショートコード</label><div class="tdn-copy-row"><input id="tdn-code-'.esc_attr($p->ID).'" readonly value="'.esc_attr('[tokushodn id="'.$p->ID.'"]').'"><button class="button tdn-copy" type="button" data-copy="tdn-code-'.esc_attr($p->ID).'">コピー</button></div><div class="tdn-card-actions">';
            if($p->post_status==='trash') { self::action_form('restore',$p->ID,'下書きに戻す'); } else { echo '<a class="button button-primary" href="'.esc_url(self::url(array('view'=>'edit','id'=>$p->ID))).'">編集する</a>';self::action_form('duplicate',$p->ID,'複製');self::action_form('trash',$p->ID,'公開停止・ゴミ箱'); }echo '</div></article>';
        }echo '</div><div class="tdn-pagination">'.wp_kses_post(paginate_links(array('base'=>add_query_arg('paged','%#%',self::url(array('status'=>$status,'s'=>$search))),'total'=>$q->max_num_pages,'current'=>$paged))).'</div>';
        echo '<p class="tdn-callout">下書き・ゴミ箱の情報はショートコードから表示しません。「掲載用」に保存した内容は、ショートコードを置いた公開ページから閲覧できます。</p><div id="tdn-copy-status" class="screen-reader-text" role="status"></div>';
    }
    private static function select($name,$current,$values,$id='') { echo '<select name="'.esc_attr($name).'"'.($id?' id="'.esc_attr($id).'"':'').'>';foreach($values as $key=>$label){echo '<option value="'.esc_attr($key).'" '.selected($current,$key,false).'>'.esc_html($label).'</option>';}echo '</select>'; }
    private static function editor() {
        $id=absint(self::scalar($_GET,'id'));$p=$id?TokushoDN::get($id):null;if($id&&!$p){self::fail('プロフィールがありません。');}
        $d=$p?TokushoDN::data($id):TokushoDN::clean(TokushoDN::defaults());$name=$p?$p->post_title:'';$status=$p&&$p->post_status==='publish'?'publish':'draft';$revision=$p?(string)get_post_meta($id,'_tokushodn_revision',true):'';
        $attempt=self::scalar($_GET,'attempt');$saved_attempt=preg_match('/^[A-Za-z0-9]{20}$/D',$attempt)?get_transient('tokushodn_attempt_'.get_current_user_id().'_'.$attempt):false;
        if(is_array($saved_attempt)&&(int)$saved_attempt['id']===$id) { $d=$saved_attempt['data'];$name=$saved_attempt['name'];$status=$saved_attempt['status'];$revision=$saved_attempt['revision'];echo '<div class="notice notice-error"><p><b>保存できませんでした。既存の掲載内容は変更していません。</b></p><p>'.nl2br(esc_html($saved_attempt['error'])).'</p></div>'; }
        $checks=TokushoDN::checks($d);
        if($p&&$p->post_status==='publish'&&!$saved_attempt&&$checks['errors']) { echo '<div class="notice notice-warning"><p><b>入力確認の警告が '.esc_html(count($checks['errors'])).' 件ありますが、掲載用として保存されています。</b>「入力の確認」で内容を確認できます。</p></div>'; }
        echo '<div class="tdn-toolbar"><div><h2>'.($id?'プロフィールを編集':'新しいプロフィール').'</h2><p>入力した内容は、右側でプレビューできます。</p></div></div><p class="tdn-callout">入力補助ツールです。事実・適用条件・法的適合性を自動判定するものではありません。特商法表記ページとは別に、商品ページや注文の最終確認画面も実際の取引に合わせて確認してください。</p><div class="tdn-editor-grid"><div>';
        self::start_form('save',$id,'id="tdn-editor"');echo '<input type="hidden" name="revision" value="'.esc_attr($revision).'">';
        echo '<section class="tdn-panel"><div class="tdn-section-kicker">01 / PROFILE</div><h3>管理と販売形態</h3><label class="tdn-field">管理用の名前<input name="name" value="'.esc_attr($name).'" maxlength="120" placeholder="例：オンラインショップ・通常販売"><small>管理画面だけに表示する名前です。空欄の場合は「名称未設定」で保存します。</small></label><div class="tdn-two"><label class="tdn-field">事業者の形態';self::select('data[entity]',$d['entity'],array('individual'=>'個人事業者','corporate'=>'法人'));echo '</label><label class="tdn-field">販売の形態';self::select('data[kind]',$d['kind'],TokushoDN::types());echo '</label></div><details class="tdn-flags" open><summary>該当する追加条件</summary>';
        foreach(TokushoDN::flags() as $key=>$info){echo '<label><input type="checkbox" name="data[flags]['.esc_attr($key).']" value="1" '.checked(!empty($d['flags'][$key]),true,false).'><span><b>'.esc_html($info[0]).'</b><small>'.esc_html($info[1]).'</small></span></label>';}echo '</details></section>';
        $groups=array();foreach(TokushoDN::fields() as $key=>$info){$groups[$info[1]][$key]=$info;}$required=TokushoDN::required($d);
        $num=2;foreach($groups as $group=>$fields) {
            echo '<section class="tdn-panel"><div class="tdn-section-kicker">'.esc_html(sprintf('%02d',$num++)).' / DETAILS</div><h3>'.esc_html($group).'</h3>';
            foreach($fields as $key=>$info){echo '<label class="tdn-field" data-field="'.esc_attr($key).'" for="tdn-'.esc_attr($key).'"><span>'.esc_html($info[0]).' <i class="tdn-required"'.(!in_array($key,$required,true)?' hidden':'').'>入力確認</i></span>';
                $attrs=' id="tdn-'.esc_attr($key).'" name="data[values]['.esc_attr($key).']" placeholder="'.esc_attr($info[4]).'"';
                if($info[2]==='textarea'){echo '<textarea'.$attrs.' rows="3" maxlength="5000">'.esc_textarea($d['values'][$key]).'</textarea>';}else{echo '<input type="text"'.$attrs.' value="'.esc_attr($d['values'][$key]).'" maxlength="500"'.(in_array($info[2],array('email','url'),true)?' inputmode="'.esc_attr($info[2]).'"':'').'>';}
                echo '<small>'.esc_html($info[3]).'</small></label>';
            }echo '</section>';
        }
        echo '<section class="tdn-panel"><h3>追加の表示項目</h3><p class="tdn-muted">最大20項目。並び順は上下ボタンで変更できます。</p><div id="tdn-custom-rows">';
        foreach($d['custom'] as $i=>$row){self::custom_row($i,$row);}echo '</div><button type="button" class="button" id="tdn-add-row">＋ 項目を追加</button></section>';
        echo '<section class="tdn-panel"><h3>表示デザイン</h3><label class="tdn-field">表記のタイトル<input name="data[heading]" value="'.esc_attr($d['heading']).'" maxlength="120"></label><div class="tdn-two"><label class="tdn-field">レイアウト';self::select('data[layout]',$d['layout'],array('table'=>'表形式','cards'=>'カード形式'),'tdn-layout');echo '</label><label class="tdn-field">配色';self::select('data[theme]',$d['theme'],array('plain'=>'プレーン','gold'=>'ゴールド','slate'=>'スレート'),'tdn-theme');echo '</label></div><div class="tdn-toggles"><label><input id="tdn-show-title" type="checkbox" name="data[show_title]" value="1" '.checked($d['show_title'],1,false).'>タイトルを表示</label><label><input id="tdn-show-updated" type="checkbox" name="data[show_updated]" value="1" '.checked($d['show_updated'],1,false).'>更新日を表示</label></div></section>';
        echo '<section class="tdn-panel tdn-save"><h3>保存と掲載</h3><label class="tdn-field">掲載状態';self::select('status',$status,array('draft'=>'下書き（公開ページに表示しない）','publish'=>'掲載用（ショートコードで表示する）'));echo '</label><p class="tdn-muted">入力エラーは警告として表示し、未入力・形式エラーがあっても「掲載用」で保存できます。法令の全要件を満たしたという意味ではありません。掲載用の更新は、すでにショートコードを設置したページにも反映されます。</p><button class="button button-primary button-large">保存する</button></section></form></div><aside class="tdn-sidebar"><div class="tdn-sticky"><section class="tdn-panel"><div class="tdn-preview-top"><h3>表示プレビュー</h3><div><button type="button" class="button tdn-width" data-width="wide">通常</button><button type="button" class="button tdn-width" data-width="mobile">スマホ</button></div></div><p id="tdn-preview-status" class="tdn-muted" role="status">プレビューを読み込みます…</p><iframe id="tdn-preview" sandbox="" title="特商法表記のプレビュー"></iframe><button type="button" class="button" id="tdn-preview-refresh">プレビューを更新</button></section><section class="tdn-panel"><h3>入力の確認</h3><p class="tdn-muted">未入力・形式・仮の値を確認します。警告があっても掲載できます。</p><div id="tdn-checks" aria-live="polite">';self::check_list(TokushoDN::checks($d));echo '</div></section><section class="tdn-panel"><h3>ショートコード生成</h3>';
        if($id){echo '<label class="screen-reader-text" for="tdn-shortcode">生成したショートコード</label><textarea id="tdn-shortcode" rows="4" readonly data-id="'.esc_attr($id).'">'.esc_textarea('[tokushodn id="'.$id.'"]').'</textarea><button type="button" class="button button-primary tdn-copy" data-copy="tdn-shortcode">ショートコードをコピー</button><p class="tdn-muted">投稿・固定ページの「ショートコード」ブロックに貼り付けます。デザイン設定を変えたら保存してください。下書きは公開ページに表示されません。</p>';self::action_form('page_draft',$id,'固定ページの下書きを作成');
            echo '<p class="tdn-export-links">';foreach(array('json'=>'JSONを書き出し','html'=>'単独HTMLを書き出し') as $format=>$label){echo '<a href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=tokushodn_export&id='.$id.'&format='.$format),'tokushodn_export')).'">'.esc_html($label).'</a> ';}echo '</p><p class="tdn-muted">書き出すのは最後に保存した内容です。ファイルには入力した住所・電話番号なども含まれます。</p>';
        }else{echo '<p>一度保存すると、この場所にショートコードを生成します。</p>';}
        echo '<div id="tdn-copy-status" role="status" class="tdn-muted"></div></section></div></aside></div>';
    }
    private static function custom_row($i,$row){echo '<div class="tdn-custom"><label>項目名<input name="data[custom]['.esc_attr($i).'][label]" maxlength="100" value="'.esc_attr($row['label']).'"></label><label>内容<textarea name="data[custom]['.esc_attr($i).'][value]" maxlength="5000" rows="3">'.esc_textarea($row['value']).'</textarea></label><div><button type="button" class="button tdn-row-up" aria-label="項目を上へ">↑</button> <button type="button" class="button tdn-row-down" aria-label="項目を下へ">↓</button> <button type="button" class="button tdn-row-remove">削除</button></div></div>';}
    private static function check_list($checks){echo '<p><b>'.esc_html($checks['filled']).'項目入力済み</b> / 未入力・形式の確認 '.esc_html(count($checks['errors'])).'件</p>';if(!$checks['errors']){echo '<p>入力形式の確認事項はありません。内容の正確さは別途確認してください。</p>';}echo '<ul>';foreach(array_merge($checks['errors'],$checks['warnings']) as $message){echo '<li>'.esc_html($message).'</li>';}echo '</ul>';}
    private static function tools_page(){
        echo '<div class="tdn-tools-grid"><section class="tdn-panel"><h2>JSONインポート</h2><p>このプラグインで書き出したJSONから、新しい下書きを作成します。既存プロフィールは上書きしません。</p>';self::start_form('import');echo '<label class="tdn-field">JSONファイル（256KB以内）<input type="file" id="tdn-import-file" accept=".json,application/json"></label><label class="tdn-field">JSONデータ<textarea id="tdn-import-json" name="json" rows="12" required spellcheck="false"></textarea></label><p id="tdn-import-status" role="status"></p><button class="button button-primary">下書きとして読み込む</button></form></section><section class="tdn-panel"><h2>掲載までの手順</h2><ol><li>プロフィールを作成し、実際の事業者情報と条件を入力します。</li><li>プレビューと入力チェックを確認します。</li><li>内容を確認して「掲載用」で保存します。</li><li>固定ページの「ショートコード」ブロックに生成コードを貼り付け、ページを公開します。</li><li>販売ページから「特定商取引法に基づく表記」へ分かりやすくリンクします。</li><li>商品ページ・注文直前の最終確認画面も確認します。</li></ol><h3>ショートコード</h3><pre><code>[tokushodn id="123"]</code></pre><pre><code>[tokushodn id="123" layout="cards" theme="gold" title="1" updated="1"]</code></pre><p>layout は table / cards、theme は plain / gold / slate、title と updated は 1 / 0 を指定します。IDは保存後に表示される実際のIDを使います。</p></section></div><section class="tdn-panel"><h2>確認範囲について</h2><p>日本国内の通信販売向けの表示入力支援です。表示義務の適用、個別条件の有効性、表示省略の可否を自動で判断しません。判断が必要な場合は、所管窓口や専門家に確認してください。</p><p>このプラグインだけで購入・決済画面の表示が変更されることはありません。定期購入では回数・料金・総額・更新や解約の条件を、実際の申込画面でも確認してください。住所や電話番号の自動非表示・代行開示機能はありません。</p><h3>公式資料</h3><ul><li><a href="https://www.no-trouble.caa.go.jp/what/mailorder/" target="_blank" rel="noopener noreferrer">消費者庁：通信販売の概要</a></li><li><a href="https://www.no-trouble.caa.go.jp/what/mailorder/advertising.html" target="_blank" rel="noopener noreferrer">消費者庁：広告の表示事項</a></li><li><a href="https://www.caa.go.jp/policies/policy/consumer_transaction/amendment/2021/notice02/" target="_blank" rel="noopener noreferrer">消費者庁：最終確認画面等の表示資料</a></li></ul><p class="tdn-muted">公開資料確認日：2026年10月17日。自動更新されません。実際の掲載時には最新資料を確認してください。</p></section>';
    }
}
