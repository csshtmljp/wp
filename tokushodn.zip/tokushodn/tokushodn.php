<?php
/**
 * Plugin Name: TokushoDN — 特商法表記・ショートコード生成
 * Description: 通信販売の特定商取引法に基づく表記を、入力チェック・プレビュー・複数プロフィール・ショートコードで作成します。
 * Version: 1.0.1
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: TokushoDN
 * License: GPL-2.0-or-later
 * Text Domain: tokushodn
 */
if (!defined('ABSPATH')) { exit; }
define('TOKUSHODN_VERSION','1.0.1');
define('TOKUSHODN_FILE',__FILE__);
define('TOKUSHODN_PATH',plugin_dir_path(__FILE__));
require_once TOKUSHODN_PATH.'includes/class-tokushodn.php';
require_once TOKUSHODN_PATH.'includes/class-tokushodn-admin.php';
TokushoDN::boot();
TokushoDN_Admin::boot();
