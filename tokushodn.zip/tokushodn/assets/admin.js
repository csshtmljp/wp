(function () {
    'use strict';
    var config = window.TokushoDNAdmin || {}, form = document.getElementById('tdn-editor');
    var generation = 0, timer, controller, dirty = false;
    function message(text) { var el = document.getElementById('tdn-copy-status'); if (el) el.textContent = text; }
    document.addEventListener('click', function (event) {
        var button = event.target.closest('.tdn-copy'); if (!button) return;
        var input = document.getElementById(button.dataset.copy); if (!input) return;
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(input.value).then(function () { message('コピーしました。'); }, function () { input.focus(); input.select(); message('文字列を選択しました。端末のコピー操作でコピーしてください。'); });
        } else { input.focus(); input.select(); message('文字列を選択しました。端末のコピー操作でコピーしてください。'); }
    });
    var importFile = document.getElementById('tdn-import-file');
    if (importFile) importFile.addEventListener('change', async function () {
        var file = importFile.files[0], status = document.getElementById('tdn-import-status'); if (!file) return;
        document.getElementById('tdn-import-json').value = '';
        if (file.size > config.maxBytes) { status.textContent = '256KB以内のJSONを指定してください。'; return; }
        try {
            var text = new TextDecoder('utf-8', {fatal:true}).decode(await file.arrayBuffer());
            JSON.parse(text.replace(/^\uFEFF/, ''));
            document.getElementById('tdn-import-json').value = text;
            status.textContent = '読み込みました。「下書きとして読み込む」で保存します。';
        } catch (e) { status.textContent = 'UTF-8形式の有効なJSONを指定してください。'; }
    });
    if (!form) return;
    function shortcode() {
        var output = document.getElementById('tdn-shortcode'); if (!output) return;
        output.value = '[tokushodn id="' + output.dataset.id + '" layout="' + document.getElementById('tdn-layout').value + '" theme="' + document.getElementById('tdn-theme').value + '" title="' + (document.getElementById('tdn-show-title').checked ? '1' : '0') + '" updated="' + (document.getElementById('tdn-show-updated').checked ? '1' : '0') + '"]';
    }
    function showChecks(checks, required) {
        var target = document.getElementById('tdn-checks'); target.replaceChildren();
        var p = document.createElement('p'); p.textContent = checks.filled + '項目入力済み / 未入力・形式の確認 ' + checks.errors.length + '件'; target.append(p);
        if (!checks.errors.length) { var ready = document.createElement('p'); ready.textContent = '入力形式の確認事項はありません。内容の正確さは別途確認してください。'; target.append(ready); }
        var ul = document.createElement('ul'); checks.errors.concat(checks.warnings).forEach(function (text) { var li = document.createElement('li'); li.textContent = text; ul.append(li); }); target.append(ul);
        form.querySelectorAll('[data-field]').forEach(function (label) { label.querySelector('.tdn-required').hidden = !required.includes(label.dataset.field); });
    }
    async function preview() {
        var current = ++generation, status = document.getElementById('tdn-preview-status');
        if (controller) controller.abort(); controller = new AbortController();
        var params = new URLSearchParams(new FormData(form)); params.set('action', 'tokushodn_preview'); params.set('nonce', config.nonce);
        status.textContent = 'プレビューを更新しています…';
        try {
            var response = await fetch(config.endpoint, {method:'POST',credentials:'same-origin',cache:'no-store',body:params,signal:controller.signal});
            if (!response.ok) throw new Error('response');
            var result = await response.json(); if (!result.success) throw new Error('data'); if (current !== generation) return;
            document.getElementById('tdn-preview').srcdoc = result.data.document;
            showChecks(result.data.checks, result.data.required);
            status.textContent = dirty ? '入力中の内容（未保存）' : 'プレビュー / 入力例は自動保存されません';
        } catch (e) { if (e.name !== 'AbortError' && current === generation) status.textContent = 'プレビューを更新できませんでした。再読み込みして認証を更新できます。'; }
    }
    function changed() { dirty = true; shortcode(); clearTimeout(timer); timer = setTimeout(preview, 550); }
    form.addEventListener('input', changed); form.addEventListener('change', changed);
    form.addEventListener('submit', function () { dirty = false; });
    window.addEventListener('beforeunload', function (event) { if (dirty) { event.preventDefault(); event.returnValue = ''; } });
    document.getElementById('tdn-preview-refresh').addEventListener('click', function () { clearTimeout(timer); preview(); });
    document.querySelectorAll('.tdn-width').forEach(function (button) { button.addEventListener('click', function () { document.getElementById('tdn-preview').classList.toggle('is-mobile', button.dataset.width === 'mobile'); }); });
    var rows = document.getElementById('tdn-custom-rows');
    function renumber() { rows.querySelectorAll('.tdn-custom').forEach(function (row, index) { row.querySelector('input').name = 'data[custom][' + index + '][label]'; row.querySelector('textarea').name = 'data[custom][' + index + '][value]'; }); }
    document.getElementById('tdn-add-row').addEventListener('click', function () {
        if (rows.children.length >= 20) { message('追加項目は20件までです。'); return; }
        var row = document.createElement('div'); row.className = 'tdn-custom';
        // Only a fixed, application-owned template is assigned as markup.
        row.innerHTML = '<label>項目名<input maxlength="100"></label><label>内容<textarea maxlength="5000" rows="3"></textarea></label><div><button type="button" class="button tdn-row-up" aria-label="項目を上へ">↑</button> <button type="button" class="button tdn-row-down" aria-label="項目を下へ">↓</button> <button type="button" class="button tdn-row-remove">削除</button></div>';
        rows.append(row); renumber(); row.querySelector('input').focus(); changed();
    });
    rows.addEventListener('click', function (event) {
        var button = event.target.closest('button'), row = event.target.closest('.tdn-custom'); if (!button || !row) return;
        if (button.classList.contains('tdn-row-remove')) row.remove();
        else if (button.classList.contains('tdn-row-up') && row.previousElementSibling) rows.insertBefore(row, row.previousElementSibling);
        else if (button.classList.contains('tdn-row-down') && row.nextElementSibling) rows.insertBefore(row.nextElementSibling, row);
        renumber(); changed();
    });
    shortcode(); preview();
})();
