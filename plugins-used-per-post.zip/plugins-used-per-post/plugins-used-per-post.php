<?php
/**
 * Plugin Name:       Plugins Used Per Post
 * Description:       各投稿・固定ページで使われているプラグインを、管理者にだけ一覧表示します。ショートコード・ブロック・読み込まれたスクリプトやスタイルから判定します。
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Plugins Used Per Post
 * License:           GPL-2.0-or-later
 * Text Domain:       plugins-used-per-post
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugins_Used_Per_Post {

	const CACHE      = 'pup_scan';
	const UNKNOWN_SC = '__shortcode';
	const UNKNOWN_BL = '__block';

	private $segments = null; // フォルダ名 => プラグインファイル
	private $plugins  = null;

	public static function init() {
		$self = new self();

		// サイト表示側
		add_action( 'admin_bar_menu', array( $self, 'admin_bar' ), 100 );
		add_action( 'wp_footer', array( $self, 'front_panel' ), 9999 );

		// 管理画面
		add_action( 'admin_init', array( $self, 'register_columns' ) );
		add_action( 'add_meta_boxes', array( $self, 'add_meta_box' ) );
		add_action( 'admin_menu', array( $self, 'add_menu' ) );

		// 集計結果の破棄
		foreach ( array( 'save_post', 'deleted_post', 'activated_plugin', 'deactivated_plugin' ) as $hook ) {
			add_action( $hook, array( $self, 'flush' ) );
		}
	}

	/** 表示してよいユーザーか(既定は管理者のみ) */
	private function can() {
		return current_user_can( apply_filters( 'pup_capability', 'manage_options' ) );
	}

	private function post_types() {
		$types = get_post_types( array( 'public' => true ) );
		unset( $types['attachment'] );
		return (array) apply_filters( 'pup_post_types', array_values( $types ) );
	}

	public function flush() {
		delete_transient( self::CACHE );
	}

	/* ------------------------------------------------------------------
	 * プラグインの特定
	 * ---------------------------------------------------------------- */

	private function all_plugins() {
		if ( null === $this->plugins ) {
			if ( ! function_exists( 'get_plugins' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}
			$this->plugins = get_plugins();
		}
		return $this->plugins;
	}

	/** プラグインフォルダ名(または1ファイル名)からプラグインファイルを引く */
	private function plugin_by_segment( $segment ) {
		if ( null === $this->segments ) {
			$this->segments = array();
			foreach ( array_keys( $this->all_plugins() ) as $file ) {
				$seg = ( false !== strpos( $file, '/' ) ) ? strtok( $file, '/' ) : $file;
				if ( ! isset( $this->segments[ $seg ] ) || is_plugin_active( $file ) ) {
					$this->segments[ $seg ] = $file;
				}
			}
		}
		return isset( $this->segments[ $segment ] ) ? $this->segments[ $segment ] : null;
	}

	private function plugin_from_path( $path ) {
		if ( ! $path ) {
			return null;
		}
		$path = wp_normalize_path( $path );
		$dir  = trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) );
		if ( 0 === strpos( $path, $dir ) ) {
			return $this->plugin_by_segment( strtok( substr( $path, strlen( $dir ) ), '/' ) );
		}
		if ( defined( 'WPMU_PLUGIN_DIR' ) ) {
			$mu = trailingslashit( wp_normalize_path( WPMU_PLUGIN_DIR ) );
			if ( 0 === strpos( $path, $mu ) ) {
				return 'mu:' . strtok( substr( $path, strlen( $mu ) ), '/' );
			}
		}
		return null;
	}

	private function plugin_from_url( $src ) {
		if ( ! is_string( $src ) || '' === $src ) {
			return null;
		}
		if ( 0 === strpos( $src, '/' ) && 0 !== strpos( $src, '//' ) ) {
			$src = site_url( $src );
		}
		$strip = static function ( $url ) {
			return preg_replace( '#^https?:#i', '', $url );
		};
		$src  = $strip( strtok( $src, '?' ) );
		$base = trailingslashit( $strip( plugins_url() ) );
		if ( 0 === strpos( $src, $base ) ) {
			return $this->plugin_by_segment( strtok( substr( $src, strlen( $base ) ), '/' ) );
		}
		if ( defined( 'WPMU_PLUGIN_URL' ) ) {
			$mu = trailingslashit( $strip( WPMU_PLUGIN_URL ) );
			if ( 0 === strpos( $src, $mu ) ) {
				return 'mu:' . strtok( substr( $src, strlen( $mu ) ), '/' );
			}
		}
		return null;
	}

	/** コールバックが定義されているファイル */
	private function callable_file( $callback ) {
		try {
			if ( $callback instanceof Closure ) {
				$ref = new ReflectionFunction( $callback );
			} elseif ( is_string( $callback ) && false !== strpos( $callback, '::' ) ) {
				list( $class, $method ) = explode( '::', $callback, 2 );
				$ref                    = new ReflectionMethod( $class, $method );
			} elseif ( is_string( $callback ) ) {
				$ref = new ReflectionFunction( $callback );
			} elseif ( is_array( $callback ) && 2 === count( $callback ) ) {
				$ref = new ReflectionMethod( $callback[0], $callback[1] );
			} elseif ( is_object( $callback ) ) {
				$ref = new ReflectionClass( $callback );
			} else {
				return null;
			}
			$file = $ref->getFileName();
			return $file ? $file : null;
		} catch ( Throwable $e ) {
			return null;
		}
	}

	private function label( $key ) {
		if ( self::UNKNOWN_SC === $key ) {
			return '未登録のショートコードらしき記述';
		}
		if ( self::UNKNOWN_BL === $key ) {
			return '提供元を判定できないブロック';
		}
		if ( 0 === strpos( $key, 'mu:' ) ) {
			return 'must-use: ' . substr( $key, 3 );
		}
		$all = $this->all_plugins();
		return isset( $all[ $key ]['Name'] ) && '' !== $all[ $key ]['Name'] ? $all[ $key ]['Name'] : $key;
	}

	/* ------------------------------------------------------------------
	 * 本文からの判定(ショートコードとブロック)
	 * ---------------------------------------------------------------- */

	/**
	 * @return array プラグインのキー => 理由の配列
	 */
	private function detect_content( $content, $depth = 0 ) {
		$found   = array();
		$content = (string) $content;
		$add     = static function ( $key, $reason ) use ( &$found ) {
			if ( ! isset( $found[ $key ] ) ) {
				$found[ $key ] = array();
			}
			if ( ! in_array( $reason, $found[ $key ], true ) && count( $found[ $key ] ) < 20 ) {
				$found[ $key ][] = $reason;
			}
		};

		// ショートコード
		if ( false !== strpos( $content, '[' ) ) {
			global $shortcode_tags;
			$text = preg_replace( '/<!--.*?-->/s', '', $content ); // ブロックのコメント内は対象外
			if ( preg_match_all( '/(?<![\w\[])\[([A-Za-z][\w-]{1,})(?=[\s\]\/])[^\[\]]*\]/', $text, $m ) ) {
				foreach ( array_unique( $m[1] ) as $tag ) {
					if ( isset( $shortcode_tags[ $tag ] ) ) {
						$key = $this->plugin_from_path( $this->callable_file( $shortcode_tags[ $tag ] ) );
						if ( $key ) {
							$add( $key, 'ショートコード [' . $tag . ']' );
						}
					} else {
						$add( self::UNKNOWN_SC, '[' . $tag . ']' );
					}
				}
			}
		}

		// ブロック
		if ( function_exists( 'has_blocks' ) && has_blocks( $content ) ) {
			$stack = parse_blocks( $content );
			while ( $stack ) {
				$block = array_pop( $stack );
				if ( ! empty( $block['innerBlocks'] ) ) {
					foreach ( $block['innerBlocks'] as $inner ) {
						$stack[] = $inner;
					}
				}
				$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
				if ( '' === $name ) {
					continue;
				}
				// 再利用ブロック(同期パターン)は中身をたどる
				if ( 'core/block' === $name && ! empty( $block['attrs']['ref'] ) && $depth < 3 ) {
					$ref = get_post( (int) $block['attrs']['ref'] );
					if ( $ref ) {
						foreach ( $this->detect_content( $ref->post_content, $depth + 1 ) as $key => $reasons ) {
							foreach ( $reasons as $reason ) {
								$add( $key, $reason );
							}
						}
					}
					continue;
				}
				if ( 0 === strpos( $name, 'core/' ) ) {
					continue;
				}
				$key = $this->block_plugin( $name );
				if ( $key ) {
					$add( $key, 'ブロック ' . $name );
				} else {
					$add( self::UNKNOWN_BL, $name );
				}
			}
		}

		return $found;
	}

	private function block_plugin( $name ) {
		$type = WP_Block_Type_Registry::get_instance()->get_registered( $name );
		if ( $type ) {
			if ( ! empty( $type->render_callback ) ) {
				$key = $this->plugin_from_path( $this->callable_file( $type->render_callback ) );
				if ( $key ) {
					return $key;
				}
			}
			$sets = array(
				'script' => array( 'editor_script_handles', 'script_handles', 'view_script_handles' ),
				'style'  => array( 'editor_style_handles', 'style_handles' ),
			);
			foreach ( $sets as $kind => $props ) {
				$registry = ( 'script' === $kind ) ? wp_scripts() : wp_styles();
				foreach ( $props as $prop ) {
					if ( ! property_exists( $type, $prop ) || empty( $type->$prop ) ) {
						continue;
					}
					foreach ( (array) $type->$prop as $handle ) {
						if ( isset( $registry->registered[ $handle ] ) ) {
							$key = $this->plugin_from_url( $registry->registered[ $handle ]->src );
							if ( $key ) {
								return $key;
							}
						}
					}
				}
			}
		}
		// 最後の手がかり: ブロック名の前半がプラグインのフォルダ名と一致する場合
		return $this->plugin_by_segment( strtok( $name, '/' ) );
	}

	/* ------------------------------------------------------------------
	 * 表示中のページで読み込まれたスクリプトとスタイル
	 * ---------------------------------------------------------------- */

	private function detect_assets() {
		$found = array();
		$sets  = array(
			'スクリプト' => wp_scripts(),
			'スタイル'  => wp_styles(),
		);
		foreach ( $sets as $kind => $registry ) {
			foreach ( (array) $registry->done as $handle ) {
				if ( ! isset( $registry->registered[ $handle ] ) ) {
					continue;
				}
				$key = $this->plugin_from_url( $registry->registered[ $handle ]->src );
				if ( $key ) {
					$found[ $key ][] = $kind . ' ' . $handle;
				}
			}
		}
		return $found;
	}

	/* ------------------------------------------------------------------
	 * 一覧の出力(共通)
	 * ---------------------------------------------------------------- */

	private function sort_found( $found ) {
		$known   = array();
		$unknown = array();
		foreach ( $found as $key => $reasons ) {
			if ( self::UNKNOWN_SC === $key || self::UNKNOWN_BL === $key ) {
				$unknown[ $key ] = $reasons;
			} else {
				$known[ $key ] = $reasons;
			}
		}
		uksort(
			$known,
			function ( $a, $b ) {
				return strcasecmp( $this->label( $a ), $this->label( $b ) );
			}
		);
		return $known + $unknown;
	}

	private function list_html( $found, $with_reasons = true ) {
		if ( ! $found ) {
			return '<span class="pup-none" style="opacity:.7">なし</span>';
		}
		$html = '<ul class="pup-list" style="margin:0;padding:0;list-style:none">';
		foreach ( $this->sort_found( $found ) as $key => $reasons ) {
			$muted = ( self::UNKNOWN_SC === $key || self::UNKNOWN_BL === $key );
			$html .= '<li style="margin:0 0 6px">';
			$html .= $muted ? '<em>' . esc_html( $this->label( $key ) ) . '</em>' : '<strong>' . esc_html( $this->label( $key ) ) . '</strong>';
			if ( $with_reasons && $reasons ) {
				$html .= '<br><span class="pup-why" style="font-size:12px;opacity:.75;overflow-wrap:anywhere">' . esc_html( implode( '、', $reasons ) ) . '</span>';
			}
			$html .= '</li>';
		}
		return $html . '</ul>';
	}

	/* ------------------------------------------------------------------
	 * サイト表示側: 管理バーとパネル
	 * ---------------------------------------------------------------- */

	public function admin_bar( $bar ) {
		if ( is_admin() || ! $this->can() ) {
			return;
		}
		$bar->add_node(
			array(
				'id'    => 'pup',
				'title' => '使用プラグイン',
				'href'  => '#pup-panel',
			)
		);
	}

	public function front_panel() {
		if ( ! $this->can() ) {
			return;
		}
		$content = array();
		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post instanceof WP_Post ) {
				$content = $this->detect_content( $post->post_content );
			}
		}
		$assets = $this->detect_assets();
		$total  = count( array_diff( array_keys( $content + $assets ), array( self::UNKNOWN_SC, self::UNKNOWN_BL ) ) );
		$bar    = is_admin_bar_showing();
		?>
		<style>
			#pup-panel{position:fixed;right:12px;bottom:12px;z-index:99998;width:min(380px,calc(100vw - 24px));max-height:min(70vh,560px);overflow:auto;background:#fff;color:#1d2327;border:1px solid #c3c4c7;border-radius:10px;box-shadow:0 12px 40px rgba(0,0,0,.25);font:14px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI","Hiragino Sans","Noto Sans JP",sans-serif;text-align:left}
			#pup-panel[hidden]{display:none}
			#pup-panel header{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:10px 14px;border-bottom:1px solid #dcdcde;position:sticky;top:0;background:#fff}
			#pup-panel header b{font-size:15px}
			#pup-panel h3{margin:14px 14px 6px;font-size:13px;font-weight:700;color:#50575e}
			#pup-panel .pup-body{padding:0 14px 6px}
			#pup-panel .pup-note{margin:0;padding:8px 14px 12px;font-size:12px;color:#646970}
			#pup-panel button,#pup-toggle{font:inherit;cursor:pointer;border:1px solid #c3c4c7;background:#f6f7f7;color:#1d2327;border-radius:6px;padding:4px 10px}
			#pup-toggle{position:fixed;right:12px;bottom:12px;z-index:99997;box-shadow:0 4px 14px rgba(0,0,0,.2)}
		</style>
		<?php if ( ! $bar ) : ?>
			<button type="button" id="pup-toggle">使用プラグイン (<?php echo (int) $total; ?>)</button>
		<?php endif; ?>
		<div id="pup-panel" hidden role="dialog" aria-label="このページで使用しているプラグイン">
			<header><b>このページのプラグイン (<?php echo (int) $total; ?>)</b><button type="button" id="pup-close">閉じる</button></header>
			<?php if ( is_singular() ) : ?>
				<h3>本文で使用(ショートコード・ブロック)</h3>
				<div class="pup-body"><?php echo $this->list_html( $content ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
			<?php endif; ?>
			<h3>このページで読み込まれたスクリプト・スタイル</h3>
			<div class="pup-body"><?php echo $this->list_html( $assets ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
			<p class="pup-note">この一覧は管理者にだけ表示されています。</p>
		</div>
		<script>
		(function(){
			var panel=document.getElementById('pup-panel'); if(!panel){return;}
			function toggle(e){ if(e){e.preventDefault();} panel.hidden=!panel.hidden; }
			var node=document.querySelector('#wp-admin-bar-pup > a, #wp-admin-bar-pup > .ab-item');
			if(node){ node.textContent='使用プラグイン (<?php echo (int) $total; ?>)'; node.addEventListener('click',toggle); }
			var btn=document.getElementById('pup-toggle'); if(btn){ btn.addEventListener('click',toggle); }
			document.getElementById('pup-close').addEventListener('click',toggle);
			document.addEventListener('keydown',function(e){ if(e.key==='Escape'){ panel.hidden=true; } });
		})();
		</script>
		<?php
	}

	/* ------------------------------------------------------------------
	 * 管理画面: 一覧の列と編集画面の欄
	 * ---------------------------------------------------------------- */

	public function register_columns() {
		if ( ! $this->can() ) {
			return;
		}
		foreach ( $this->post_types() as $type ) {
			add_filter( "manage_{$type}_posts_columns", array( $this, 'add_column' ) );
			add_action( "manage_{$type}_posts_custom_column", array( $this, 'render_column' ), 10, 2 );
		}
	}

	public function add_column( $columns ) {
		$columns['pup_plugins'] = '使用プラグイン';
		return $columns;
	}

	public function render_column( $column, $post_id ) {
		if ( 'pup_plugins' !== $column ) {
			return;
		}
		$post = get_post( $post_id );
		echo $post ? $this->list_html( $this->detect_content( $post->post_content ), false ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public function add_meta_box() {
		if ( ! $this->can() ) {
			return;
		}
		foreach ( $this->post_types() as $type ) {
			add_meta_box( 'pup-box', '使用プラグイン', array( $this, 'render_meta_box' ), $type, 'side', 'low' );
		}
	}

	public function render_meta_box( $post ) {
		echo $this->list_html( $this->detect_content( $post->post_content ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<p class="description">保存済みの本文から判定しています。編集中の内容は、保存して再読み込みすると反映されます。</p>';
	}

	/* ------------------------------------------------------------------
	 * 管理画面: サイト全体の一覧
	 * ---------------------------------------------------------------- */

	public function add_menu() {
		add_management_page(
			'使用プラグイン一覧',
			'使用プラグイン一覧',
			apply_filters( 'pup_capability', 'manage_options' ),
			'pup-overview',
			array( $this, 'render_overview' )
		);
	}

	private function scan( $force = false ) {
		$cached = get_transient( self::CACHE );
		if ( ! $force && is_array( $cached ) ) {
			return $cached;
		}

		$limit = max( 200, (int) apply_filters( 'pup_scan_limit', 3000 ) );
		$map   = array();
		$count = 0;
		$paged = 1;
		$full  = false;

		do {
			$query = new WP_Query(
				array(
					'post_type'              => $this->post_types(),
					'post_status'            => array( 'publish', 'future', 'draft', 'pending', 'private' ),
					'posts_per_page'         => 200,
					'paged'                  => $paged,
					'orderby'                => 'ID',
					'order'                  => 'DESC',
					'no_found_rows'          => true,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
				)
			);
			foreach ( $query->posts as $post ) {
				$count++;
				$found = $this->detect_content( $post->post_content );
				if ( $found ) {
					$map[ $post->ID ] = $found;
				}
			}
			$full = ( 200 === count( $query->posts ) );
			$paged++;
		} while ( $full && $count < $limit );

		$data = array(
			'time'      => time(),
			'count'     => $count,
			'truncated' => $full,
			'map'       => $map,
		);
		set_transient( self::CACHE, $data, 15 * MINUTE_IN_SECONDS );
		return $data;
	}

	public function render_overview() {
		if ( ! $this->can() ) {
			return;
		}
		$base  = admin_url( 'tools.php?page=pup-overview' );
		$force = isset( $_GET['pup_rescan'] ) && check_admin_referer( 'pup_rescan' );
		$data  = $this->scan( $force );
		$map   = $data['map'];

		// プラグインごとの件数
		$totals = array();
		foreach ( $map as $found ) {
			foreach ( array_keys( $found ) as $key ) {
				$totals[ $key ] = isset( $totals[ $key ] ) ? $totals[ $key ] + 1 : 1;
			}
		}
		$totals = $this->sort_found( $totals );

		$filter = isset( $_GET['pup_plugin'] ) ? sanitize_text_field( wp_unslash( $_GET['pup_plugin'] ) ) : '';
		if ( '' !== $filter && ! isset( $totals[ $filter ] ) ) {
			$filter = '';
		}
		$ids = array();
		foreach ( $map as $id => $found ) {
			if ( '' === $filter || isset( $found[ $filter ] ) ) {
				$ids[] = $id;
			}
		}

		$per   = 50;
		$pages = max( 1, (int) ceil( count( $ids ) / $per ) );
		$page  = isset( $_GET['paged'] ) ? max( 1, min( $pages, absint( $_GET['paged'] ) ) ) : 1;
		$shown = array_slice( $ids, ( $page - 1 ) * $per, $per );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline">使用プラグイン一覧</h1>
			<a class="page-title-action" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'pup_rescan', '1', $base ), 'pup_rescan' ) ); ?>">再集計</a>
			<hr class="wp-header-end">
			<p>
				<?php echo (int) $data['count']; ?> 件の投稿・ページを調べ、<?php echo (int) count( $map ); ?> 件でプラグインの使用が見つかりました(集計: <?php echo esc_html( wp_date( 'Y-m-d H:i', $data['time'] ) ); ?>)。
				本文のショートコードとブロックから判定しています。
			</p>
			<?php if ( $data['truncated'] ) : ?>
				<div class="notice notice-warning inline"><p>件数が多いため、新しいものから <?php echo (int) $data['count']; ?> 件までを集計しています。</p></div>
			<?php endif; ?>

			<h2>プラグイン別の件数</h2>
			<?php if ( $totals ) : ?>
				<table class="widefat striped" style="max-width:720px">
					<thead><tr><th>プラグイン</th><th style="width:8em">使用している件数</th></tr></thead>
					<tbody>
						<?php foreach ( $totals as $key => $n ) : ?>
							<tr>
								<td><a href="<?php echo esc_url( add_query_arg( 'pup_plugin', rawurlencode( $key ), $base ) ); ?>"><?php echo esc_html( $this->label( $key ) ); ?></a></td>
								<td><?php echo (int) $n; ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p>本文でプラグインを使っている投稿・ページは見つかりませんでした。</p>
			<?php endif; ?>

			<h2>
				投稿・ページ別
				<?php if ( '' !== $filter ) : ?>
					:「<?php echo esc_html( $this->label( $filter ) ); ?>」を使用
					<a href="<?php echo esc_url( $base ); ?>" style="font-size:13px;font-weight:400;margin-left:8px">絞り込みを解除</a>
				<?php endif; ?>
			</h2>
			<?php if ( $shown ) : ?>
				<table class="widefat striped">
					<thead><tr><th>タイトル</th><th style="width:9em">種類</th><th style="width:7em">状態</th><th>使用プラグイン</th></tr></thead>
					<tbody>
						<?php
						foreach ( $shown as $id ) :
							$post = get_post( $id );
							if ( ! $post ) {
								continue;
							}
							$type   = get_post_type_object( $post->post_type );
							$status = get_post_status_object( $post->post_status );
							$title  = '' !== $post->post_title ? $post->post_title : '(タイトルなし)';
							?>
							<tr>
								<td>
									<strong><a href="<?php echo esc_url( get_edit_post_link( $id, 'raw' ) ); ?>"><?php echo esc_html( $title ); ?></a></strong>
									<?php if ( 'publish' === $post->post_status ) : ?>
										<br><a href="<?php echo esc_url( get_permalink( $id ) ); ?>">表示</a>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( $type ? $type->labels->singular_name : $post->post_type ); ?></td>
								<td><?php echo esc_html( $status ? $status->label : $post->post_status ); ?></td>
								<td><?php echo $this->list_html( $map[ $id ] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php
				$links = paginate_links(
					array(
						'base'    => add_query_arg( 'paged', '%#%' ),
						'format'  => '',
						'current' => $page,
						'total'   => $pages,
					)
				);
				if ( $links ) {
					echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( $links ) . '</div></div>';
				}
				?>
			<?php else : ?>
				<p>該当する投稿・ページはありません。</p>
			<?php endif; ?>
		</div>
		<?php
	}
}

Plugins_Used_Per_Post::init();
