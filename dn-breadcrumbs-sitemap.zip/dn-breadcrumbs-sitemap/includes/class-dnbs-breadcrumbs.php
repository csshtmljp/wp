<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DNBS_Breadcrumbs {
	private static $rendered = false;

	public static function boot() {
		add_shortcode( 'dn_breadcrumbs', array( __CLASS__, 'render' ) );
		add_filter( 'the_content', array( __CLASS__, 'prepend' ), 12 );
	}

	public static function prepend( $content ) {
		if ( is_admin() || is_feed() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ! is_singular( array( 'post', 'page' ) ) || ! in_the_loop() || ! is_main_query() || get_the_ID() !== get_queried_object_id() ) {
			return $content;
		}
		$s = DNBS_Plugin::settings();
		$key = is_page() ? 'auto_pages' : 'auto_posts';
		return ! empty( $s[ $key ] ) ? self::render() . $content : $content;
	}

	public static function title( $post ) {
		$name = trim( wp_strip_all_tags( get_the_title( $post ) ) );
		return '' !== $name ? $name : 'タイトルなし';
	}

	public static function visible( $post ) {
		return $post instanceof WP_Post && 'publish' === $post->post_status && '' === $post->post_password && is_post_type_viewable( $post->post_type );
	}

	private static function add_post( &$items, $id ) {
		if ( (int) $id <= 0 ) {
			return;
		}
		$post = get_post( $id );
		if ( self::visible( $post ) && (int) $id !== (int) get_option( 'page_on_front' ) ) {
			$items[] = array( 'name' => self::title( $post ), 'url' => get_permalink( $post ) );
		}
	}

	private static function add_term( &$items, $term ) {
		if ( ! $term instanceof WP_Term ) {
			return;
		}
		foreach ( array_reverse( get_ancestors( $term->term_id, $term->taxonomy, 'taxonomy' ) ) as $id ) {
			$ancestor = get_term( $id, $term->taxonomy );
			if ( $ancestor instanceof WP_Term ) {
				$url = get_term_link( $ancestor );
				if ( ! is_wp_error( $url ) ) {
					$items[] = array( 'name' => $ancestor->name, 'url' => $url );
				}
			}
		}
		$url = get_term_link( $term );
		if ( ! is_wp_error( $url ) ) {
			$items[] = array( 'name' => $term->name, 'url' => $url );
		}
	}

	public static function items() {
		if ( is_front_page() ) {
			return array();
		}
		$s = DNBS_Plugin::settings();
		$items = array( array( 'name' => $s['home_label'], 'url' => home_url( '/' ) ) );
		if ( is_home() ) {
			$id = (int) get_option( 'page_for_posts' );
			$items[] = array( 'name' => $id ? self::title( $id ) : '投稿一覧', 'url' => $id ? get_permalink( $id ) : home_url( '/' ) );
		} elseif ( is_singular() ) {
			$post = get_queried_object();
			if ( ! $post instanceof WP_Post ) {
				return array();
			}
			if ( 'post' === $post->post_type ) {
				if ( 'page' === get_option( 'show_on_front' ) ) {
					self::add_post( $items, (int) get_option( 'page_for_posts' ) );
				}
				$terms = get_the_terms( $post, 'category' );
				if ( is_array( $terms ) && $terms ) {
					// Choose the deepest category; tie-break by ID for stable output.
					usort( $terms, function ( $a, $b ) {
						$depth_a = count( get_ancestors( $a->term_id, 'category', 'taxonomy' ) );
						$depth_b = count( get_ancestors( $b->term_id, 'category', 'taxonomy' ) );
						return $depth_a === $depth_b ? $a->term_id <=> $b->term_id : $depth_b <=> $depth_a;
					} );
					self::add_term( $items, $terms[0] );
				}
			} elseif ( 'page' !== $post->post_type ) {
				$type = get_post_type_object( $post->post_type );
				$url = get_post_type_archive_link( $post->post_type );
				if ( $type && $url ) {
					$items[] = array( 'name' => $type->labels->name, 'url' => $url );
				}
			}
			foreach ( array_reverse( get_post_ancestors( $post ) ) as $ancestor ) {
				self::add_post( $items, $ancestor );
			}
			$items[] = array( 'name' => self::title( $post ), 'url' => get_permalink( $post ) );
		} elseif ( is_category() || is_tag() || is_tax() ) {
			self::add_term( $items, get_queried_object() );
		} elseif ( is_post_type_archive() ) {
			$type = get_queried_object();
			if ( $type instanceof WP_Post_Type ) {
				$items[] = array( 'name' => $type->labels->name, 'url' => get_post_type_archive_link( $type->name ) );
			}
		} elseif ( is_author() ) {
			$author = get_queried_object();
			if ( $author instanceof WP_User ) {
				$items[] = array( 'name' => $author->display_name . 'の記事', 'url' => get_author_posts_url( $author->ID ) );
			}
		} elseif ( is_date() ) {
			$year = (int) get_query_var( 'year' );
			$month = (int) get_query_var( 'monthnum' );
			$day = (int) get_query_var( 'day' );
			$items[] = array( 'name' => $year . '年', 'url' => get_year_link( $year ) );
			if ( $month ) {
				$items[] = array( 'name' => $month . '月', 'url' => get_month_link( $year, $month ) );
			}
			if ( $day ) {
				$items[] = array( 'name' => $day . '日', 'url' => get_day_link( $year, $month, $day ) );
			}
		} elseif ( is_search() ) {
			$items[] = array( 'name' => '検索結果：「' . get_search_query( false ) . '」', 'url' => '' );
		} elseif ( is_404() ) {
			$items[] = array( 'name' => 'ページが見つかりません', 'url' => '' );
		} else {
			return array();
		}
		$paged = (int) get_query_var( 'paged' );
		if ( $paged > 1 && ! is_singular() ) {
			$items[] = array( 'name' => $paged . 'ページ目', 'url' => get_pagenum_link( $paged, false ) );
		}
		return $items;
	}

	public static function render( $attributes = array() ) {
		if ( self::$rendered || is_admin() || is_feed() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return '';
		}
		$items = self::items();
		if ( count( $items ) < 2 ) {
			return '';
		}
		self::$rendered = true;
		$last = count( $items ) - 1;
		$html = '<nav class="dnbs-breadcrumbs" aria-label="パンくずリスト"><ol>';
		$schema = array();
		foreach ( $items as $i => $item ) {
			$name = wp_strip_all_tags( $item['name'] );
			$html .= '<li>';
			if ( $i ) {
				$html .= '<span class="dnbs-separator" aria-hidden="true">›</span>';
			}
			$html .= $i === $last || ! $item['url'] ? '<span aria-current="page">' . esc_html( $name ) . '</span>' : '<a href="' . esc_url( $item['url'] ) . '">' . esc_html( $name ) . '</a>';
			$html .= '</li>';
			$entry = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => html_entity_decode( $name, ENT_QUOTES, get_bloginfo( 'charset' ) ) );
			if ( $i !== $last && $item['url'] ) {
				$entry['item'] = esc_url_raw( $item['url'] );
			}
			$schema[] = $entry;
		}
		$html .= '</ol></nav>';
		$s = DNBS_Plugin::settings();
		if ( $s['schema'] && ! is_search() && ! is_404() && ! is_preview() ) {
			$html .= '<script type="application/ld+json" class="dnbs-schema">' . wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $schema ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script>';
		}
		return $html;
	}
}
