<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DNBS_Sitemap {
	public static function boot() {
		add_shortcode( 'dn_sitemap', array( __CLASS__, 'render' ) );
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'xml_query' ), 20, 2 );
		add_filter( 'wp_sitemaps_add_provider', array( __CLASS__, 'xml_provider' ), 20, 2 );
	}

	public static function xml_query( $args, $post_type ) {
		$s = DNBS_Plugin::settings();
		if ( ! $s['xml_rules'] ) {
			return $args;
		}
		$args['has_password'] = false;
		$args['post__not_in'] = array_values( array_unique( array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(), DNBS_Plugin::ids( $s['exclude_ids'] ) ) ) );
		return $args;
	}

	public static function xml_provider( $provider, $name ) {
		$s = DNBS_Plugin::settings();
		return 'users' === $name && $s['xml_hide_users'] ? false : $provider;
	}

	private static function page_number( $key ) {
		// These parameters deliberately are not registered WordPress query vars.
		$value = isset( $_GET[ $key ] ) && is_string( $_GET[ $key ] ) ? wp_unslash( $_GET[ $key ] ) : '1'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public read-only navigation.
		return ctype_digit( $value ) ? max( 1, min( 1000000, (int) $value ) ) : 1;
	}

	private static function page_title( $post, $excluded ) {
		$names = array();
		foreach ( array_reverse( get_post_ancestors( $post ) ) as $id ) {
			$ancestor = get_post( $id );
			if ( DNBS_Breadcrumbs::visible( $ancestor ) && ! in_array( (int) $id, $excluded, true ) && (int) $id !== (int) get_option( 'page_on_front' ) ) {
				$names[] = DNBS_Breadcrumbs::title( $ancestor );
			}
		}
		$names[] = DNBS_Breadcrumbs::title( $post );
		return implode( ' › ', $names );
	}

	public static function render( $attributes = array() ) {
		if ( is_admin() || is_feed() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return '';
		}
		$s = DNBS_Plugin::settings();
		$a = shortcode_atts( array( 'types' => 'page,post', 'per_page' => $s['per_page'] ), $attributes, 'dn_sitemap' );
		$types = array_values( array_unique( array_intersect( explode( ',', str_replace( ' ', '', (string) $a['types'] ) ), array( 'page', 'post' ) ) ) );
		if ( ! $types ) {
			return '';
		}
		$limit = is_numeric( $a['per_page'] ) ? max( 10, min( 200, (int) $a['per_page'] ) ) : (int) $s['per_page'];
		$excluded = DNBS_Plugin::ids( $s['exclude_ids'] );
		if ( is_singular() ) {
			$excluded[] = get_queried_object_id();
		}
		$base = is_singular() ? get_permalink( get_queried_object_id() ) : home_url( '/' );
		$instance = wp_unique_id( 'dnbs-map-' );
		$html = '<div class="dnbs-sitemap">';
		foreach ( $types as $type ) {
			$key = 'dnbs_' . $type . '_page';
			$current = self::page_number( $key );
			$title = 'page' === $type ? '固定ページ' : '投稿';
			$anchor = $instance . '-' . $type;
			$query = new WP_Query( array(
				'post_type' => $type, 'post_status' => 'publish', 'has_password' => false,
				'post__not_in' => $excluded, 'posts_per_page' => $limit, 'paged' => $current,
				'orderby' => 'page' === $type ? array( 'menu_order' => 'ASC', 'title' => 'ASC', 'ID' => 'ASC' ) : array( 'date' => 'DESC', 'ID' => 'DESC' ),
				'ignore_sticky_posts' => true, 'update_post_term_cache' => false, 'update_post_meta_cache' => false,
			) );
			$html .= '<section class="dnbs-section" aria-labelledby="' . esc_attr( $anchor ) . '"><h2 id="' . esc_attr( $anchor ) . '">' . esc_html( $title ) . '</h2>';
			if ( $query->posts ) {
				$html .= '<ul class="dnbs-links">';
				foreach ( $query->posts as $post ) {
					$name = 'page' === $type ? self::page_title( $post, $excluded ) : DNBS_Breadcrumbs::title( $post );
					$html .= '<li><a href="' . esc_url( get_permalink( $post ) ) . '">' . esc_html( $name ) . '</a></li>';
				}
				$html .= '</ul>';
			} else {
				$html .= '<p class="dnbs-empty">表示できる' . esc_html( $title ) . 'はありません。</p>';
			}
			$total = (int) $query->max_num_pages;
			if ( $total > 1 || $current > 1 ) {
				// Preserve the other list's page number without copying arbitrary URL parameters.
				$other = 'page' === $type ? 'dnbs_post_page' : 'dnbs_page_page';
				$pagination_base = add_query_arg( $other, self::page_number( $other ), $base );
				$html .= '<nav class="dnbs-pagination" aria-label="' . esc_attr( $title . 'のページ切り替え' ) . '">';
				if ( $current > 1 ) {
					$previous = $current > $total ? 1 : $current - 1;
					$html .= '<a href="' . esc_url( add_query_arg( $key, $previous, $pagination_base ) . '#' . $anchor ) . '">' . ( $current > $total ? '最初のページ' : '前へ' ) . '</a>';
				}
				if ( $total && $current <= $total ) {
					$html .= '<span>' . esc_html( $current . ' / ' . $total . 'ページ' ) . '</span>';
				}
				if ( $current < $total ) {
					$html .= '<a href="' . esc_url( add_query_arg( $key, $current + 1, $pagination_base ) . '#' . $anchor ) . '">次へ</a>';
				}
				$html .= '</nav>';
			}
			$html .= '</section>';
		}
		return $html . '</div>';
	}
}
