<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DNBS_Plugin {
	const OPTION = 'dnbs_settings';

	public static function boot() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_post_dnbs_create_sitemap', array( __CLASS__, 'create_page' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( DNBS_FILE ), array( __CLASS__, 'action_links' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		DNBS_Breadcrumbs::boot();
		DNBS_Sitemap::boot();
	}

	public static function defaults() {
		return array(
			'auto_posts' => 1, 'auto_pages' => 1, 'schema' => 1,
			'home_label' => 'ホーム', 'per_page' => 100, 'exclude_ids' => array(),
			'xml_rules' => 1, 'xml_hide_users' => 0, 'delete_data' => 0,
		);
	}

	public static function settings() {
		$saved = get_option( self::OPTION, array() );
		return array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
	}

	public static function activate() {
		add_option( self::OPTION, self::defaults() );
	}

	public static function ids( $value ) {
		if ( is_string( $value ) ) {
			$value = preg_split( '/[\s,、，]+/u', $value );
		}
		if ( ! is_array( $value ) ) {
			return array();
		}
		$ids = array();
		foreach ( $value as $id ) {
			if ( is_scalar( $id ) && preg_match( '/^[0-9]+$/D', (string) $id ) && (int) $id > 0 ) {
				$ids[] = (int) $id;
			}
		}
		return array_values( array_unique( array_slice( $ids, 0, 2000 ) ) );
	}

	public static function sanitize( $input ) {
		$input = is_array( $input ) ? $input : array();
		$out = self::defaults();
		foreach ( array( 'auto_posts', 'auto_pages', 'schema', 'xml_rules', 'xml_hide_users', 'delete_data' ) as $key ) {
			$out[ $key ] = isset( $input[ $key ] ) && is_scalar( $input[ $key ] ) && '1' === (string) $input[ $key ] ? 1 : 0;
		}
		if ( isset( $input['home_label'] ) && is_string( $input['home_label'] ) ) {
			$label = sanitize_text_field( $input['home_label'] );
			$out['home_label'] = '' !== $label ? $label : 'ホーム';
		}
		if ( isset( $input['per_page'] ) && is_scalar( $input['per_page'] ) && is_numeric( $input['per_page'] ) ) {
			$out['per_page'] = max( 10, min( 200, (int) $input['per_page'] ) );
		}
		$out['exclude_ids'] = self::ids( isset( $input['exclude_ids'] ) ? $input['exclude_ids'] : array() );
		return $out;
	}

	public static function register_settings() {
		register_setting( 'dnbs_group', self::OPTION, array( 'type' => 'array', 'sanitize_callback' => array( __CLASS__, 'sanitize' ), 'default' => self::defaults() ) );
	}

	public static function assets() {
		// Also covers shortcodes in templates, widgets and reusable blocks.
		wp_enqueue_style( 'dnbs', plugins_url( 'assets/navigation.css', DNBS_FILE ), array(), DNBS_VERSION );
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=dn-breadcrumbs-sitemap' ) ) . '">設定</a>' );
		return $links;
	}

	public static function menu() {
		add_options_page( 'パンくず＆サイトマップ', 'パンくず＆サイトマップ', 'manage_options', 'dn-breadcrumbs-sitemap', array( __CLASS__, 'screen' ) );
	}

	private static function checkbox( $key, $label, $settings ) {
		echo '<label><input type="checkbox" name="dnbs_settings[' . esc_attr( $key ) . ']" value="1" ' . checked( 1, $settings[ $key ], false ) . '> ' . esc_html( $label ) . '</label><br>';
	}

	public static function screen() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = self::settings();
		$server = wp_sitemaps_get_server();
		$xml_enabled = $server && $server->sitemaps_enabled();
		?>
		<div class="wrap">
			<h1>パンくず＆サイトマップ</h1>
			<p>記事への道順とサイト内の一覧を表示します。外部サービス・APIキーは不要です。</p>
			<?php settings_errors(); ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'dnbs_group' ); ?>
				<h2>パンくずリスト</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row">本文の先頭に自動表示</th><td><?php self::checkbox( 'auto_posts', '投稿に表示', $s ); self::checkbox( 'auto_pages', '固定ページに表示（トップページを除く）', $s ); ?><p class="description">テーマに既存のパンくずがある場合は、自動表示をオフにしてください。</p></td></tr>
					<tr><th scope="row"><label for="dnbs-home">先頭のラベル</label></th><td><input id="dnbs-home" class="regular-text" name="dnbs_settings[home_label]" value="<?php echo esc_attr( $s['home_label'] ); ?>"></td></tr>
					<tr><th scope="row">構造化データ</th><td><?php self::checkbox( 'schema', 'BreadcrumbList（JSON-LD）を出力', $s ); ?><p class="description">他のSEOプラグインがパンくずの構造化データを出力している場合はオフにできます。</p></td></tr>
				</table>
				<h2>サイトマップ</h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="dnbs-per-page">HTML一覧の表示件数</label></th><td><input id="dnbs-per-page" type="number" min="10" max="200" name="dnbs_settings[per_page]" value="<?php echo esc_attr( $s['per_page'] ); ?>"> 件／種類ごと・1ページ（10〜200件）</td></tr>
					<tr><th scope="row"><label for="dnbs-exclude">除外する投稿・固定ページID</label></th><td><textarea id="dnbs-exclude" class="large-text" rows="3" name="dnbs_settings[exclude_ids]" placeholder="12, 34, 56"><?php echo esc_textarea( implode( ', ', self::ids( $s['exclude_ids'] ) ) ); ?></textarea><p class="description">カンマまたは改行で入力（最大2,000件）。HTMLと、下の設定がオンのときWordPress標準XMLに適用。子ページは別途指定してください。URLへのアクセスや検索結果は制限しません。</p></td></tr>
					<tr><th scope="row">WordPress標準XML</th><td><?php self::checkbox( 'xml_rules', '指定IDとパスワード付きコンテンツを標準XMLから除外', $s ); self::checkbox( 'xml_hide_users', '標準XMLの著者サイトマップを除外', $s ); ?><p class="description">HTMLは常に公開済みでパスワードのない投稿・固定ページのみを表示します。SEOプラグイン独自のXMLには適用されません。</p></td></tr>
					<tr><th scope="row">プラグイン削除時</th><td><?php self::checkbox( 'delete_data', 'このプラグインの設定を削除する', $s ); ?><p class="description">作成した固定ページは削除しません。</p></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<hr><h2>HTMLサイトマップを設置</h2>
			<p>固定ページの「ショートコード」ブロックに <code>[dn_sitemap]</code> を入力して公開してください。以下のボタンで下書きを作成できます。</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="dnbs_create_sitemap">
				<?php wp_nonce_field( 'dnbs_create_sitemap', 'dnbs_nonce' ); submit_button( 'サイトマップ固定ページの下書きを作成・開く', 'secondary', 'submit', false ); ?>
			</form>
			<h2>XMLサイトマップ</h2>
			<?php if ( $xml_enabled ) : ?>
				<p>WordPress標準のXMLサイトマップを利用中です。投稿・固定ページなどを自動更新します。</p>
				<p><a href="<?php echo esc_url( get_sitemap_url( 'index' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( get_sitemap_url( 'index' ) ); ?></a></p>
			<?php else : ?>
				<p><strong>WordPress標準XMLは現在無効です。</strong>「設定 → 表示設定」の検索エンジン設定、またはSEOプラグインのXML設定を確認してください。本プラグインは無効設定を上書きしません。</p>
			<?php endif; ?>
			<h2>手動で表示する場合</h2>
			<p>パンくず：<code>[dn_breadcrumbs]</code>　／　固定ページのみ：<code>[dn_sitemap types="page"]</code>　／　投稿のみ：<code>[dn_sitemap types="post"]</code></p>
			<p>一覧・検索・404ページにも表示したい場合は、テンプレートのショートコードブロックかPHPの <code>dnbs_breadcrumbs()</code> を利用してください。</p>
		</div>
		<?php
	}

	public static function create_page() {
		if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'edit_pages' ) ) {
			wp_die( '権限がありません。', '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'dnbs_create_sitemap', 'dnbs_nonce' );
		$id = (int) get_option( 'dnbs_sitemap_page', 0 );
		$page = get_post( $id );
		if ( ! $page || 'page' !== $page->post_type || 'trash' === $page->post_status || ! has_shortcode( $page->post_content, 'dn_sitemap' ) ) {
			$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'draft', 'post_title' => 'サイトマップ', 'post_name' => 'sitemap', 'post_content' => '<!-- wp:shortcode -->[dn_sitemap]<!-- /wp:shortcode -->' ), true );
			if ( is_wp_error( $id ) ) {
				wp_die( esc_html( $id->get_error_message() ) );
			}
			update_option( 'dnbs_sitemap_page', $id, false );
		}
		wp_safe_redirect( get_edit_post_link( $id, 'raw' ) );
		exit;
	}
}
