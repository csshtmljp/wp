<?php
/**
 * Plugin Name: DN パンくず＆サイトマップ
 * Description: 投稿・固定ページのパンくずリスト、HTMLサイトマップ、WordPress標準XMLサイトマップの除外管理。
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: DN Plugins
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: dn-breadcrumbs-sitemap
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DNBS_VERSION', '1.0.0' );
define( 'DNBS_FILE', __FILE__ );
require_once __DIR__ . '/includes/class-dnbs-plugin.php';
require_once __DIR__ . '/includes/class-dnbs-breadcrumbs.php';
require_once __DIR__ . '/includes/class-dnbs-sitemap.php';

add_action( 'plugins_loaded', array( 'DNBS_Plugin', 'boot' ) );
register_activation_hook( __FILE__, array( 'DNBS_Plugin', 'activate' ) );

/** Echo the breadcrumbs from a classic theme template. */
function dnbs_breadcrumbs() {
	echo DNBS_Breadcrumbs::render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped by renderer.
}
