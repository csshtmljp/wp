<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

function dnbs_delete_site_settings() {
	$settings = get_option( 'dnbs_settings', array() );
	if ( is_array( $settings ) && ! empty( $settings['delete_data'] ) ) {
		delete_option( 'dnbs_settings' );
		delete_option( 'dnbs_sitemap_page' );
	}
}

if ( is_multisite() ) {
	$dnbs_offset = 0;
	do {
		$dnbs_sites = get_sites( array( 'fields' => 'ids', 'number' => 100, 'offset' => $dnbs_offset ) );
		foreach ( $dnbs_sites as $dnbs_site ) {
			switch_to_blog( $dnbs_site );
			dnbs_delete_site_settings();
			restore_current_blog();
		}
		$dnbs_offset += 100;
	} while ( count( $dnbs_sites ) === 100 );
} else {
	dnbs_delete_site_settings();
}
