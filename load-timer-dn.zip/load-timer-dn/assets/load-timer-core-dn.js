/* 読み込み時間計測dn 1.0.0 | GPL-2.0-or-later */
(function (root, factory) {
    'use strict';
    var core = factory();
    if (typeof module === 'object' && module.exports) module.exports = core;
    else root.LoadTimerCoreDn = core;
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
    'use strict';
    function number(value) { return typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : null; }
    function round(value) { return number(value) === null ? null : Math.round(value * 100) / 100; }
    function delta(end, start, allowZero) {
        if (number(end) === null || number(start) === null || end < start || (!allowZero && end === 0)) return null;
        return round(end - start);
    }
    function safeUrl(value, base) {
        try {
            var url = new URL(String(value), base);
            if (url.protocol !== 'http:' && url.protocol !== 'https:') return '[' + url.protocol.replace(':', '') + ']';
            return (url.origin + url.pathname).slice(0, 2000);
        } catch (_) { return '[URL不明]'; }
    }
    function timing(nav, paint) {
        if (!nav || number(nav.loadEventEnd) === null || nav.loadEventEnd <= 0) return null;
        var start = number(nav.startTime) === null ? 0 : nav.startTime;
        return {
            loadMs: delta(nav.loadEventEnd, start), ttfbMs: delta(nav.responseStart, start),
            domReadyMs: delta(nav.domContentLoadedEventEnd, start), fcpMs: paint ? delta(paint.startTime, start) : null,
            dnsMs: delta(nav.domainLookupEnd, nav.domainLookupStart, true),
            connectMs: delta(nav.connectEnd, nav.connectStart, true),
            tlsMs: nav.secureConnectionStart > 0 ? delta(nav.connectEnd, nav.secureConnectionStart, true) : null,
            requestWaitMs: nav.requestStart > 0 ? delta(nav.responseStart, nav.requestStart, true) : null,
            downloadMs: nav.responseStart > 0 ? delta(nav.responseEnd, nav.responseStart, true) : null
        };
    }
    function resources(entries, cutoff, base, pluginUrl) {
        var items = entries.filter(function (entry) {
            return number(entry.responseEnd) !== null && entry.responseEnd > 0 && entry.responseEnd <= cutoff && number(entry.duration) !== null;
        }).map(function (entry) {
            var path = safeUrl(entry.name, base);
            return { url: path, type: String(entry.initiatorType || 'other').slice(0, 32), durationMs: round(entry.duration),
                transferBytes: entry.transferSize > 0 ? round(entry.transferSize) : null,
                instrumentation: !!pluginUrl && path.indexOf(pluginUrl) === 0 };
        });
        return { count: items.length,
            knownTransferBytes: items.reduce(function (sum, item) { return sum + (item.transferBytes || 0); }, 0),
            unknownTransferCount: items.filter(function (item) { return item.transferBytes === null; }).length,
            top: items.sort(function (a, b) { return b.durationMs - a.durationMs; }).slice(0, 20) };
    }
    var metricKeys = ['loadMs', 'ttfbMs', 'domReadyMs', 'fcpMs', 'dnsMs', 'connectMs', 'tlsMs', 'requestWaitMs', 'downloadMs'];
    function cleanRecord(row) {
        if (!row || typeof row !== 'object' || typeof row.id !== 'string' || !row.metrics || number(row.metrics.loadMs) === null) return null;
        if (!['front', 'admin'].includes(row.context) || !Number.isFinite(Date.parse(row.at))) return null;
        var metrics = {};
        metricKeys.forEach(function (key) { metrics[key] = round(row.metrics[key]); });
        return { id: row.id.slice(0, 120), at: new Date(row.at).toISOString(), title: String(row.title || '').slice(0, 160),
            url: safeUrl(row.url), context: row.context, navigationType: String(row.navigationType || '').slice(0, 32), metrics: metrics };
    }
    function parseHistory(raw) {
        if (typeof raw !== 'string' || raw.length > 500000) return [];
        try { var list = JSON.parse(raw); return Array.isArray(list) ? list.slice(0, 100).map(cleanRecord).filter(Boolean) : []; }
        catch (_) { return []; }
    }
    function append(history, record) {
        var cleaned = cleanRecord(record);
        if (!cleaned) return history.slice(0, 100);
        return [cleaned].concat(history.filter(function (row) { return row.id !== cleaned.id; })).slice(0, 100);
    }
    function filter(history, context, search) {
        var needle = String(search || '').toLocaleLowerCase();
        return history.filter(function (row) {
            return (context === 'all' || row.context === context) && (row.title + ' ' + row.url).toLocaleLowerCase().includes(needle);
        });
    }
    function csvCell(value) {
        var text = value === null || value === undefined ? '' : String(value);
        // Neutralize spreadsheet formulas, including leading whitespace/control characters.
        if (/^[\s\u0000-\u001f]*[=+\-@]/.test(text) || /^[\t\r\n]/.test(text)) text = "'" + text;
        return '"' + text.replace(/"/g, '""') + '"';
    }
    function csv(history) {
        var rows = [['計測日時(UTC)', '範囲', 'ページ名', 'URL(クエリ除外)', '移動方法', '読込完了(ms)', 'TTFB(ms)', 'HTML準備(ms)', 'FCP(ms)']];
        history.forEach(function (row) { rows.push([row.at, row.context, row.title, row.url, row.navigationType,
            row.metrics.loadMs, row.metrics.ttfbMs, row.metrics.domReadyMs, row.metrics.fcpMs]); });
        return '\uFEFF' + rows.map(function (row) { return row.map(csvCell).join(','); }).join('\r\n');
    }
    function time(value) { return number(value) === null ? '—' : (value / 1000).toFixed(3) + ' 秒'; }
    function ms(value) { return number(value) === null ? '—' : value.toLocaleString('ja-JP', { maximumFractionDigits: 2 }) + ' ms'; }
    function bytes(value) { return number(value) === null ? '不明' : value >= 1048576 ? (value / 1048576).toFixed(2) + ' MB' : (value / 1024).toFixed(1) + ' KB'; }
    return Object.freeze({ number: number, timing: timing, resources: resources, safeUrl: safeUrl, cleanRecord: cleanRecord,
        parseHistory: parseHistory, append: append, filter: filter, csv: csv, csvCell: csvCell, time: time, ms: ms, bytes: bytes });
}));
