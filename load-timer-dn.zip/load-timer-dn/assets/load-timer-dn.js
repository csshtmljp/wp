/* 読み込み時間計測dn 1.0.0 | GPL-2.0-or-later */
(function () {
    'use strict';
    if (window.top !== window.self) return;
    function boot() {
        var configNode = document.getElementById('load-timer-config-dn');
        var panel = document.getElementById('load-timer-panel-dn'), core = window.LoadTimerCoreDn, config;
        if (!configNode || !panel || !core || panel.dataset.ready === 'yes') return;
        try { config = JSON.parse(configNode.textContent); } catch (_) { return; }
        panel.dataset.ready = 'yes';
        var launch = document.getElementById('load-timer-launch-dn');
        var bar = document.querySelector('#wp-admin-bar-load-timer-dn > .ab-item');
        var overlay = panel.classList.contains('load-timer-dn--overlay');
        var storeKey = config.storageKey + ':history', preferenceKey = config.storageKey + ':record';
        var history = [], current = null, storageOK = true, restored = false, opener = null;
        var autoRecord = panel.querySelector('[data-role="record"]');
        var status = panel.querySelector('.ltdn-status');
        var activeTimers = [];
        var context = config.context === 'admin' ? 'admin' : 'front';
        var navigationNames = { navigate: '通常の移動', reload: '再読み込み', back_forward: '戻る・進む（再取得）' };

        function field(key, text) {
            var node = panel.querySelector('[data-field="' + key + '"]');
            if (node) node.textContent = text;
        }
        function tell(text) {
            status.textContent = text + (storageOK ? '' : ' ブラウザー保存が使えないため、履歴はこの画面内だけで保持します。');
        }
        function readHistory() {
            try { return core.parseHistory(window.localStorage.getItem(storeKey)); }
            catch (_) { storageOK = false; return history; }
        }
        history = readHistory();
        try { autoRecord.checked = window.localStorage.getItem(preferenceKey) !== 'off'; }
        catch (_) { storageOK = false; }

        function filtered() {
            return core.filter(history, panel.querySelector('[data-filter="context"]').value, panel.querySelector('[data-filter="search"]').value);
        }
        function emptyRow(table, message) {
            table.textContent = '';
            var tr = document.createElement('tr'), td = document.createElement('td');
            td.colSpan = 4; td.textContent = message; tr.appendChild(td); table.appendChild(tr);
        }
        function textCell(tr, value) {
            var td = document.createElement('td'); td.textContent = value; tr.appendChild(td); return td;
        }
        function renderHistory() {
            var rows = filtered(), table = panel.querySelector('[data-table="history"]');
            table.textContent = '';
            field('historyCount', String(history.length));
            if (!rows.length) {
                emptyRow(table, '該当する履歴はありません。'); field('summary', '表示：0件');
            } else {
                var values = rows.map(function (r) { return r.metrics.loadMs; });
                var average = values.reduce(function (a, b) { return a + b; }, 0) / values.length;
                field('summary', '表示：' + rows.length + '件 ／ 読込平均 ' + core.time(average) + ' ／ 最小 ' + core.time(Math.min.apply(null, values)) + ' ／ 最大 ' + core.time(Math.max.apply(null, values)) + '（絞り込み結果の参考値）');
                rows.forEach(function (row) {
                    var tr = document.createElement('tr'), first = document.createElement('td');
                    var title = document.createElement('strong'), meta = document.createElement('small'), url = document.createElement('small');
                    title.textContent = row.title || row.url;
                    meta.textContent = new Date(row.at).toLocaleString('ja-JP') + ' · ' + (row.context === 'admin' ? '管理画面' : '公開ページ');
                    url.textContent = row.url;
                    first.append(meta, title, url); tr.appendChild(first);
                    textCell(tr, core.time(row.metrics.loadMs)); textCell(tr, core.time(row.metrics.ttfbMs)); textCell(tr, core.time(row.metrics.domReadyMs));
                    table.appendChild(tr);
                });
            }
            panel.querySelector('[data-action="csv"]').disabled = rows.length === 0;
            panel.querySelector('[data-action="json"]').disabled = !current && rows.length === 0;
            panel.querySelector('[data-action="clear"]').disabled = history.length === 0;
        }
        function setBadge(text) {
            var label = '読込 ' + text + ' dn';
            if (launch) { launch.textContent = label; launch.hidden = false; }
            if (bar) bar.textContent = label;
        }
        function saveCurrent() {
            if (!current || !autoRecord.checked || restored) return;
            history = core.append(storageOK ? readHistory() : history, current);
            try { window.localStorage.setItem(storeKey, JSON.stringify(history)); }
            catch (_) { storageOK = false; }
            renderHistory();
        }
        function resetMeasurement(message) {
            current = null;
            panel.querySelectorAll('[data-metric]').forEach(function (node) { node.textContent = '—'; });
            ['resourceCount', 'transfer', 'navigationType', 'php', 'queries', 'memory'].forEach(function (key) { field(key, '—'); });
            emptyRow(panel.querySelector('[data-table="resources"]'), message);
            setBadge('対象外'); tell(message); renderHistory();
        }
        function renderCurrent() {
            panel.querySelectorAll('[data-metric]').forEach(function (node) {
                var key = node.dataset.metric;
                node.textContent = ['loadMs', 'ttfbMs', 'domReadyMs', 'fcpMs'].includes(key) ? core.time(current.metrics[key]) : core.ms(current.metrics[key]);
            });
            field('resourceCount', current.resources.count + '件');
            field('transfer', core.bytes(current.resources.knownTransferBytes) + '（不明 ' + current.resources.unknownTransferCount + '件）');
            field('navigationType', navigationNames[current.navigationType] || current.navigationType || '不明');
            field('php', core.ms(current.server.phpElapsedMs));
            field('queries', core.number(current.server.queryCount) === null ? '—' : current.server.queryCount + '回');
            field('memory', core.bytes(current.server.peakMemoryBytes));
            var table = panel.querySelector('[data-table="resources"]'); table.textContent = '';
            if (!current.resources.top.length) emptyRow(table, '取得ファイルの記録はありません。');
            current.resources.top.forEach(function (resource) {
                var tr = document.createElement('tr');
                textCell(tr, resource.url + (resource.instrumentation ? '（計測プラグイン）' : ''));
                textCell(tr, resource.type); textCell(tr, core.ms(resource.durationMs)); textCell(tr, core.bytes(resource.transferBytes));
                table.appendChild(tr);
            });
            setBadge(core.time(current.metrics.loadMs)); renderHistory();
        }
        function later(callback, delay) { activeTimers.push(window.setTimeout(callback, delay)); }
        function collect(attempt) {
            if (restored || current) return;
            var nav, paint, entries, perf = window.performance;
            try {
                if (!perf || typeof perf.getEntriesByType !== 'function') throw new Error('unsupported');
                nav = perf.getEntriesByType('navigation')[0];
                entries = perf.getEntriesByType('resource');
                paint = perf.getEntriesByType('paint').filter(function (p) { return p.name === 'first-contentful-paint'; })[0];
            } catch (_) {
                resetMeasurement('このブラウザーでは必要な計測APIを利用できません。'); return;
            }
            if (nav && nav.activationStart > 0) {
                resetMeasurement('事前描画されたページです。通常の読み込み時間として記録しません。再読み込みすると計測できます。'); return;
            }
            var metrics = core.timing(nav, paint);
            if (!metrics) {
                if (attempt < 10) later(function () { collect(attempt + 1); }, 100);
                else resetMeasurement('読み込み完了時刻を取得できませんでした。再読み込みして計測してください。');
                return;
            }
            current = {
                id: String(perf.timeOrigin || Date.now()) + ':' + context,
                at: new Date().toISOString(), title: String(document.title).slice(0, 160),
                url: core.safeUrl(window.location.href), context: context, navigationType: String(nav.type || 'unknown'),
                metrics: metrics, server: config.server || {},
                resources: core.resources(entries, nav.loadEventEnd, window.location.href, config.pluginUrl)
            };
            renderCurrent(); saveCurrent();
            tell('計測が完了しました。' + (autoRecord.checked ? '直近100件の履歴に記録します。' : '履歴の自動記録は停止中です。'));
        }
        function openPanel(trigger) {
            if (overlay) {
                opener = trigger; panel.hidden = false;
                if (launch) launch.setAttribute('aria-expanded', 'true');
                panel.focus();
            } else if (typeof panel.scrollIntoView === 'function') panel.scrollIntoView({ block: 'start' });
        }
        function closePanel() {
            if (!overlay) return;
            panel.hidden = true;
            if (launch) launch.setAttribute('aria-expanded', 'false');
            if (opener && opener.isConnected) opener.focus();
        }
        function download(content, type, filename) {
            try {
                var blob = new Blob([content], { type: type }), url = URL.createObjectURL(blob), anchor = document.createElement('a');
                anchor.href = url; anchor.download = filename; document.body.appendChild(anchor); anchor.click(); anchor.remove();
                window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
                tell('保存を開始しました。ブラウザーのダウンロード先を確認してください。');
            } catch (_) { tell('このブラウザーではファイル保存を開始できませんでした。別のブラウザーでお試しください。'); }
        }
        field('context', context === 'admin' ? '管理画面の計測' : '公開ページの計測');
        field('page', document.title); field('url', core.safeUrl(window.location.href));
        setBadge('計測中…'); renderHistory();
        if (launch) launch.addEventListener('click', function () { panel.hidden ? openPanel(launch) : closePanel(); });
        if (bar) bar.addEventListener('click', function (event) { event.preventDefault(); openPanel(bar); });
        panel.addEventListener('keydown', function (event) { if (event.key === 'Escape' && overlay) { event.preventDefault(); closePanel(); } });
        panel.addEventListener('click', function (event) {
            var button = event.target.closest('button[data-action]');
            if (!button || !panel.contains(button) || button.disabled) return;
            switch (button.dataset.action) {
                case 'close': closePanel(); break;
                case 'reload': window.location.reload(); break;
                case 'csv': download(core.csv(filtered()), 'text/csv;charset=utf-8', 'load-history-dn.csv'); break;
                case 'json': download(JSON.stringify({ version: config.version, exportedAt: new Date().toISOString(), units: 'ms; bytes', current: current, history: filtered() }, null, 2), 'application/json', 'load-report-dn.json'); break;
                case 'clear':
                    history = [];
                    var removed = true;
                    try { window.localStorage.removeItem(storeKey); }
                    catch (_) { storageOK = false; removed = false; }
                    renderHistory(); tell(removed ? 'このサイト・ユーザーの計測履歴を、このブラウザーから消去しました。' : '画面内の履歴を消去しました。ブラウザーに保存済みの履歴は消去できませんでした。'); break;
            }
        });
        autoRecord.addEventListener('change', function () {
            try { window.localStorage.setItem(preferenceKey, autoRecord.checked ? 'on' : 'off'); }
            catch (_) { storageOK = false; }
            if (autoRecord.checked) saveCurrent();
            tell(autoRecord.checked ? '履歴の自動記録を有効にしました。' : '履歴の自動記録を停止しました。計測表示は続けます。');
        });
        panel.querySelectorAll('[data-filter]').forEach(function (input) { input.addEventListener('input', renderHistory); input.addEventListener('change', renderHistory); });
        window.addEventListener('storage', function (event) {
            if (event.key === storeKey || event.key === null) { history = readHistory(); renderHistory(); }
            if (event.key === preferenceKey || event.key === null) {
                try { autoRecord.checked = window.localStorage.getItem(preferenceKey) !== 'off'; } catch (_) { storageOK = false; }
            }
        });
        window.addEventListener('pageshow', function (event) {
            if (event.persisted) {
                restored = true;
                activeTimers.forEach(window.clearTimeout); activeTimers = [];
                history = readHistory();
                resetMeasurement('ブラウザーのメモリーから復元されたページです。前回の時間は再利用せず、履歴にも追加しません。再読み込みすると計測できます。');
            }
        });
        if (document.readyState === 'complete') later(function () { collect(0); }, 0);
        else window.addEventListener('load', function () { later(function () { collect(0); }, 0); }, { once: true });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
}());
