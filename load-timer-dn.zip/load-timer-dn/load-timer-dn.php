<?php
/**
 * Plugin Name: 読み込み時間計測dn
 * Description: 管理者のブラウザーでWordPressの読み込み時間・TTFB・取得ファイルを計測。直近100件の履歴とCSV・JSON出力に対応します。
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: dn
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: load-timer-dn
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Load_Timer_Dn {
    const VERSION = '1.0.0';
    private static $emitted = false;

    public static function boot() {
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
        add_action( 'wp_footer', array( __CLASS__, 'footer' ), 5 );
        add_action( 'admin_footer', array( __CLASS__, 'footer' ), 5 );
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_bar_menu', array( __CLASS__, 'bar' ), 100 );
        add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'links' ) );
    }

    public static function allowed() {
        return is_user_logged_in() && current_user_can( 'manage_options' );
    }

    private static function is_tool() {
        if ( ! is_admin() || ! function_exists( 'get_current_screen' ) ) {
            return false;
        }
        $screen = get_current_screen();
        return $screen && 'tools_page_load-timer-dn' === $screen->id;
    }

    public static function assets() {
        if ( ! self::allowed() ) {
            return;
        }
        $base = plugin_dir_url( __FILE__ ) . 'assets/';
        wp_enqueue_style( 'load-timer-dn', $base . 'load-timer-dn.css', array(), self::VERSION );
        wp_enqueue_script( 'load-timer-core-dn', $base . 'load-timer-core-dn.js', array(), self::VERSION, true );
        wp_enqueue_script( 'load-timer-dn', $base . 'load-timer-dn.js', array( 'load-timer-core-dn' ), self::VERSION, true );
    }

    public static function menu() {
        add_management_page( '読み込み時間計測dn', '読み込み時間計測dn', 'manage_options', 'load-timer-dn', array( __CLASS__, 'admin_page' ) );
    }

    public static function links( $links ) {
        if ( self::allowed() ) {
            array_unshift( $links, '<a href="' . esc_url( admin_url( 'tools.php?page=load-timer-dn' ) ) . '">計測・履歴</a>' );
        }
        return $links;
    }

    public static function bar( $bar ) {
        if ( ! self::allowed() ) {
            return;
        }
        $bar->add_node( array(
            'id'    => 'load-timer-dn',
            'title' => '読み込み計測dn',
            'href'  => admin_url( 'tools.php?page=load-timer-dn' ),
            'meta'  => array( 'title' => 'このページの計測結果を開く' ),
        ) );
    }

    public static function footer() {
        if ( ! self::allowed() || self::$emitted ) {
            return;
        }
        self::$emitted = true;
        $start = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : null;
        $now = microtime( true );
        $elapsed = $start && $start <= $now ? round( ( $now - $start ) * 1000, 2 ) : null;
        $config = array(
            'version' => self::VERSION,
            'context' => is_admin() ? 'admin' : 'front',
            'storageKey' => 'load-timer-dn:v1:' . get_current_blog_id() . ':' . get_current_user_id(),
            'pluginUrl' => plugin_dir_url( __FILE__ ),
            'server' => array(
                'phpElapsedMs' => $elapsed,
                'queryCount' => (int) get_num_queries(),
                'peakMemoryBytes' => memory_get_peak_usage( true ),
            ),
        );
        // JSON_HEX_* prevents markup termination; no executable inline JavaScript.
        echo '<script type="application/json" id="load-timer-config-dn">' . wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script>';
        if ( ! self::is_tool() ) {
            ?>
            <button type="button" id="load-timer-launch-dn" class="load-timer-launch-dn" aria-controls="load-timer-panel-dn" aria-expanded="false" hidden>読込 計測中… dn</button>
            <section id="load-timer-panel-dn" class="load-timer-dn load-timer-dn--overlay" role="dialog" aria-modal="false" aria-labelledby="load-timer-title-dn" hidden tabindex="-1">
                <?php self::panel( true ); ?>
            </section>
            <?php
        }
    }

    public static function admin_page() {
        if ( ! self::allowed() ) {
            return;
        }
        ?>
        <div class="wrap">
            <section id="load-timer-panel-dn" class="load-timer-dn load-timer-dn--dashboard" aria-labelledby="load-timer-title-dn">
                <?php self::panel( false ); ?>
            </section>
        </div>
        <?php
    }

    private static function panel( $overlay ) {
        $metrics = array(
            'loadMs' => array( '読み込み完了', '移動開始 → loadイベント完了' ),
            'ttfbMs' => array( '最初の応答まで', 'TTFB：移動開始 → 最初の1バイト' ),
            'domReadyMs' => array( 'HTMLの準備完了', 'DOMContentLoadedイベント完了' ),
            'fcpMs' => array( '最初の内容表示', 'FCP：文字・画像などの初回描画' ),
        );
        ?>
        <header class="ltdn-header">
            <div><span class="ltdn-eyebrow">PAGE LOAD INSIGHT</span><h1 id="load-timer-title-dn">読み込み時間計測dn</h1></div>
            <?php if ( $overlay ) : ?><button type="button" data-action="close" aria-label="計測パネルを閉じる" class="ltdn-close">×</button><?php endif; ?>
        </header>
        <p class="ltdn-intro">今開いているページを、この端末から計測します。一般の訪問者には表示されません。</p>
        <div class="ltdn-page"><span data-field="context">計測準備中</span><strong data-field="page">—</strong><small data-field="url"></small></div>
        <p class="ltdn-status" role="status" aria-live="polite">ページの読み込み完了を待っています。</p>
        <div class="ltdn-metrics">
            <?php foreach ( $metrics as $key => $metric ) : ?>
                <div class="ltdn-metric"><h2><?php echo esc_html( $metric[0] ); ?></h2><strong data-metric="<?php echo esc_attr( $key ); ?>">—</strong><small><?php echo esc_html( $metric[1] ); ?></small></div>
            <?php endforeach; ?>
        </div>
        <div class="ltdn-actions">
            <button type="button" data-action="reload" class="ltdn-primary">再読み込みして計測</button>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener noreferrer">サイトを開いて計測 ↗</a>
            <label><input type="checkbox" data-role="record" checked> 履歴を自動記録</label>
        </div>
        <p class="ltdn-note">load完了後の遅延画像・動画・追加通信は「読み込み完了」に含みません。TTFBは通信なども含み、PHPだけの処理時間ではありません。</p>
        <details class="ltdn-details" open>
            <summary>このページの内訳</summary>
            <dl class="ltdn-breakdown">
                <div><dt>DNS名前解決</dt><dd data-metric="dnsMs">—</dd></div>
                <div><dt>接続確立（TLSを含む）</dt><dd data-metric="connectMs">—</dd></div>
                <div><dt>TLS接続（上記の内数）</dt><dd data-metric="tlsMs">—</dd></div>
                <div><dt>要求から応答開始</dt><dd data-metric="requestWaitMs">—</dd></div>
                <div><dt>HTMLの受信</dt><dd data-metric="downloadMs">—</dd></div>
                <div><dt>記録された取得ファイル数</dt><dd data-field="resourceCount">—</dd></div>
                <div><dt>確認できたファイル転送量</dt><dd data-field="transfer">—</dd></div>
                <div><dt>ページの移動方法</dt><dd data-field="navigationType">—</dd></div>
            </dl>
            <p class="ltdn-note">内訳には重なる区間があり、単純合計はできません。接続の再利用では0msになる場合があります。未対応・非公開の値は「—」です。</p>
            <h2 class="ltdn-subtitle">WordPress側の参考値</h2>
            <dl class="ltdn-breakdown">
                <div><dt>PHP経過（フッター時点）</dt><dd data-field="php">—</dd></div>
                <div><dt>DBクエリ数（同時点）</dt><dd data-field="queries">—</dd></div>
                <div><dt>PHPメモリーのピーク（同時点）</dt><dd data-field="memory">—</dd></div>
            </dl>
            <p class="ltdn-note">PHP参考値はリクエスト開始からフッター出力時までです。リクエスト全体の処理時間やSQL別の所要時間ではありません。</p>
        </details>
        <details class="ltdn-details">
            <summary>取得に時間がかかったファイル（上位20件）</summary>
            <p class="ltdn-note">load完了までに取得が終わったリソースのうち、ブラウザーが保持する記録を表示します。転送量が0のときはキャッシュ等・制限の区別ができないため「不明」とします。</p>
            <div class="ltdn-table-wrap" tabindex="0" role="region" aria-label="ファイル取得時間一覧"><table><thead><tr><th scope="col">ファイル</th><th scope="col">種類</th><th scope="col">取得時間</th><th scope="col">転送量</th></tr></thead><tbody data-table="resources"><tr><td colspan="4">計測待ちです。</td></tr></tbody></table></div>
        </details>
        <details class="ltdn-details" <?php echo $overlay ? '' : 'open'; ?>>
            <summary>計測履歴 <span data-field="historyCount">0</span> / 100件</summary>
            <p class="ltdn-note">このブラウザー・サイト・ユーザーごとに直近100件を保存します。URLの「?」以降と「#」以降は保存しません。別端末には同期しません。</p>
            <div class="ltdn-filters">
                <label>範囲 <select data-filter="context"><option value="all">すべて</option><option value="front">公開ページ</option><option value="admin">管理画面</option></select></label>
                <label>絞り込み <input type="search" data-filter="search" placeholder="ページ名・URL" maxlength="120"></label>
            </div>
            <p class="ltdn-summary" data-field="summary">履歴はまだありません。</p>
            <div class="ltdn-table-wrap" tabindex="0" role="region" aria-label="計測履歴一覧"><table><thead><tr><th scope="col">計測日時・ページ</th><th scope="col">読込完了</th><th scope="col">TTFB</th><th scope="col">HTML準備</th></tr></thead><tbody data-table="history"><tr><td colspan="4">履歴はまだありません。</td></tr></tbody></table></div>
            <div class="ltdn-actions"><button type="button" data-action="csv">履歴CSVを保存</button><button type="button" data-action="json">JSONレポートを保存</button><button type="button" data-action="clear">履歴を全消去</button></div>
            <p class="ltdn-note">CSVは絞り込み中の履歴、JSONは現在の計測結果と絞り込み中の履歴です。数値の単位はmsです。</p>
        </details>
        <details class="ltdn-details">
            <summary>使い方・計測について</summary>
            <ol><li>管理者でログインしたまま、計測したいページを開きます。</li><li>画面右下の「読込 … dn」または管理バーを押すと詳細が開きます。</li><li>「ツール → 読み込み時間計測dn」で履歴を確認・保存できます。</li></ol>
            <p class="ltdn-note">同じURL・端末・回線・キャッシュ条件で数回計測して比較してください。管理者向けページは、一般訪問者が見るキャッシュ済みページと条件が異なります。このプラグインの読込による小さな負荷も計測に含まれます。</p>
            <p class="ltdn-note">戻る・進むによるメモリーからの復元（bfcache）と事前描画ページは、通常の読み込みとして記録しません。SPA内の画面遷移、外部サイトの巡回、PageSpeedスコア・LCP・CLS・INPの計測は行いません。</p>
            <p class="ltdn-note">計測結果の外部送信・データベース保存・APIキーはありません。ブラウザーに保存した履歴は無効化・削除後も残るため、不要な場合は先に「履歴を全消去」を押してください。</p>
        </details>
        <noscript><p>計測にはブラウザーのJavaScriptを有効にしてください。</p></noscript>
        <?php
    }
}

Load_Timer_Dn::boot();
