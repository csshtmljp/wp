<?php
/**
 * プラグイン削除時：設定と読み込んだブックマークのデータを削除します。
 *
 * @package ChromeBookmarksShowcase
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$cbs_index = get_option( 'cbs_index', array() );
if ( is_array( $cbs_index ) ) {
	foreach ( array_keys( $cbs_index ) as $cbs_id ) {
		delete_option( 'cbs_tree_' . sanitize_key( $cbs_id ) );
	}
}
delete_option( 'cbs_index' );
delete_option( 'cbs_settings' );
