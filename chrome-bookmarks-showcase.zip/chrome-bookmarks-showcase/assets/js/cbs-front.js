/*!
 * Chrome Bookmarks Showcase
 * 検索・フォルダ絞り込み・さらに表示・金箔の演出・カーソルの光
 */
(function () {
	'use strict';

	var mqReduce = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
	var mqFine = window.matchMedia ? window.matchMedia('(hover: hover) and (pointer: fine)') : null;
	var INTRO_MAX = 36;
	var POP_MAX = 30;

	function reduced() { return !!(mqReduce && mqReduce.matches); }

	/** 検索用の正規化：全角半角を統一、小文字化、カタカナ→ひらがな */
	function norm(s) {
		s = String(s || '');
		try { s = s.normalize('NFKC'); } catch (e) { /* 古いブラウザ */ }
		s = s.toLowerCase();
		return s.replace(/[ァ-ヶ]/g, function (c) { return String.fromCharCode(c.charCodeAt(0) - 0x60); });
	}

	function fmt(n) {
		try { return Number(n).toLocaleString('ja-JP'); } catch (e) { return String(n); }
	}

	/* ------------------------------------------------------------------
	 * 金箔（舞い落ちながら裏返り、光を受けた瞬間だけきらめく）
	 * ------------------------------------------------------------------ */
	function GoldLeaf(canvas, root) {
		this.canvas = canvas;
		this.root = root;
		this.ctx = canvas.getContext('2d');
		this.flakes = [];
		this.running = false;
		this.visible = true;
		this.wind = 0;
		this.windTarget = 0;
		this.last = 0;
		var cs = getComputedStyle(root);
		this.gold = cs.getPropertyValue('--cbs-gold').trim() || '#d6b25e';
		this.goldHi = cs.getPropertyValue('--cbs-gold-hi').trim() || '#f7e4a8';
		this.goldLo = cs.getPropertyValue('--cbs-gold-lo').trim() || '#8c6a2a';
		this.light = root.classList.contains('cbs-theme-hakuji');
		this.resize();
		this.bind();
	}

	GoldLeaf.prototype.resize = function () {
		var hero = this.root.querySelector('.cbs-hero');
		var height = hero ? hero.offsetTop + hero.offsetHeight + 90 : 460;
		this.root.style.setProperty('--cbs-leaf-h', height + 'px');
		var w = this.root.clientWidth;
		var h = height;
		var dpr = Math.min(2, window.devicePixelRatio || 1);
		this.w = w;
		this.h = h;
		this.canvas.width = Math.round(w * dpr);
		this.canvas.height = Math.round(h * dpr);
		this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		var count = Math.round(Math.max(14, Math.min(70, (w * h) / (w < 600 ? 15000 : 11000))));
		var flakes = [];
		for (var i = 0; i < count; i++) { flakes.push(this.make(true)); }
		this.flakes = flakes;
	};

	GoldLeaf.prototype.make = function (anywhere) {
		var size = 2.5 + Math.pow(Math.random(), 2.2) * 9;
		var pts = [];
		var corners = 4 + Math.floor(Math.random() * 3);
		for (var i = 0; i < corners; i++) {
			var a = (i / corners) * Math.PI * 2 + (Math.random() - 0.5) * 0.9;
			var r = size * (0.55 + Math.random() * 0.6);
			pts.push([Math.cos(a) * r, Math.sin(a) * r]);
		}
		return {
			x: Math.random() * this.w,
			y: anywhere ? Math.random() * this.h : -20 - Math.random() * 40,
			vy: 0.12 + Math.random() * 0.38 + size * 0.012,
			vx: (Math.random() - 0.5) * 0.15,
			rot: Math.random() * Math.PI * 2,
			vr: (Math.random() - 0.5) * 0.02,
			flip: Math.random() * Math.PI * 2,
			vf: 0.012 + Math.random() * 0.035,
			sway: Math.random() * Math.PI * 2,
			size: size,
			pts: pts,
			alpha: 0.45 + Math.random() * 0.5
		};
	};

	GoldLeaf.prototype.bind = function () {
		var self = this;
		if ('IntersectionObserver' in window) {
			new IntersectionObserver(function (entries) {
				self.visible = entries[0].isIntersecting;
				self.toggle();
			}).observe(this.canvas);
		}
		document.addEventListener('visibilitychange', function () { self.toggle(); });
		if ('ResizeObserver' in window) {
			var t;
			new ResizeObserver(function () {
				clearTimeout(t);
				t = setTimeout(function () { self.resize(); }, 150);
			}).observe(this.root);
		}
		this.root.addEventListener('pointermove', function (e) {
			var r = self.root.getBoundingClientRect();
			self.windTarget = ((e.clientX - r.left) / r.width - 0.5) * 0.9;
		});
		this.root.addEventListener('pointerleave', function () { self.windTarget = 0; });
		if (mqReduce && mqReduce.addEventListener) {
			mqReduce.addEventListener('change', function () { self.toggle(); });
		}
		this.toggle();
	};

	GoldLeaf.prototype.toggle = function () {
		var should = this.visible && !document.hidden && !reduced();
		if (should && !this.running) {
			this.running = true;
			this.last = 0;
			var self = this;
			requestAnimationFrame(function (t) { self.frame(t); });
		} else if (!should) {
			this.running = false;
		}
		this.canvas.style.display = reduced() ? 'none' : '';
	};

	GoldLeaf.prototype.frame = function (t) {
		if (!this.running) { return; }
		var dt = this.last ? Math.min(3, (t - this.last) / 16.67) : 1;
		this.last = t;
		this.wind += (this.windTarget - this.wind) * 0.03;

		var ctx = this.ctx;
		ctx.clearRect(0, 0, this.w, this.h);
		for (var i = 0; i < this.flakes.length; i++) {
			var f = this.flakes[i];
			f.y += f.vy * dt;
			f.sway += 0.012 * dt;
			f.x += (f.vx + Math.sin(f.sway) * 0.22 + this.wind * (0.4 + f.size * 0.05)) * dt;
			f.rot += f.vr * dt;
			f.flip += f.vf * dt;
			if (f.y > this.h + 20 || f.x < -40 || f.x > this.w + 40) {
				this.flakes[i] = f = this.make(false);
			}

			var face = Math.cos(f.flip);           // 裏返り（-1〜1）
			var shine = Math.pow(Math.abs(face), 6); // 正面を向いた瞬間に光る
			ctx.save();
			ctx.translate(f.x, f.y);
			ctx.rotate(f.rot);
			ctx.scale(1, Math.max(0.08, Math.abs(face)));
			ctx.globalAlpha = f.alpha * (0.55 + 0.45 * Math.abs(face));
			ctx.fillStyle = face > 0 ? (shine > 0.6 ? this.goldHi : this.gold) : this.goldLo;
			ctx.beginPath();
			ctx.moveTo(f.pts[0][0], f.pts[0][1]);
			for (var k = 1; k < f.pts.length; k++) { ctx.lineTo(f.pts[k][0], f.pts[k][1]); }
			ctx.closePath();
			ctx.fill();
			ctx.restore();

			// きらめき：正面を向いた瞬間だけ、細い光の筋を一瞬
			if (shine > 0.9 && f.size > 6 && !this.light) {
				var a = (shine - 0.9) / 0.1;
				var s = f.size * 1.15;
				ctx.save();
				ctx.globalAlpha = a * 0.75;
				ctx.fillStyle = this.goldHi;
				ctx.translate(f.x, f.y);
				ctx.beginPath();
				ctx.moveTo(0, -s); ctx.lineTo(s * 0.12, -s * 0.12); ctx.lineTo(s, 0); ctx.lineTo(s * 0.12, s * 0.12);
				ctx.lineTo(0, s); ctx.lineTo(-s * 0.12, s * 0.12); ctx.lineTo(-s, 0); ctx.lineTo(-s * 0.12, -s * 0.12);
				ctx.closePath();
				ctx.fill();
				ctx.restore();
			}
		}
		var self = this;
		requestAnimationFrame(function (n) { self.frame(n); });
	};

	/* ------------------------------------------------------------------
	 * 一覧の操作
	 * ------------------------------------------------------------------ */
	function Showcase(root) {
		this.root = root;
		try { this.cfg = JSON.parse(root.getAttribute('data-cbs') || '{}'); } catch (e) { this.cfg = {}; }
		this.fx = !!this.cfg.effects;
		this.query = '';
		this.group = '';
		this.input = root.querySelector('.cbs-q');
		this.status = root.querySelector('.cbs-status');
		this.empty = root.querySelector('.cbs-empty');
		this.emptyTitle = root.querySelector('.cbs-empty-title');
		this.chips = Array.prototype.slice.call(root.querySelectorAll('.cbs-chip'));

		var self = this;
		this.sections = Array.prototype.map.call(root.querySelectorAll('.cbs-section'), function (el) {
			var cards = Array.prototype.map.call(el.querySelectorAll('.cbs-card'), function (li) {
				var title = li.querySelector('.cbs-card-title');
				return { el: li, s: norm(li.getAttribute('data-s')), titleEl: title, title: title ? title.textContent : '', hl: false, extra: li.classList.contains('is-extra') };
			});
			var countEl = el.querySelector('.cbs-section-count');
			return {
				el: el,
				group: el.getAttribute('data-group') || '',
				cards: cards,
				countEl: countEl,
				total: countEl ? parseInt(countEl.getAttribute('data-total'), 10) || cards.length : cards.length,
				more: el.querySelector('.cbs-more')
			};
		});

		root.classList.add('cbs-js');
		this.icons();
		this.bind();
		if (this.fx) { this.effects(); }
	}

	Showcase.prototype.icons = function () {
		function done(img) {
			if (!img.classList || !img.classList.contains('cbs-favicon')) { return; }
			if (img.naturalWidth > 1) { img.classList.add('is-loaded'); } else { img.classList.add('is-broken'); }
		}
		this.root.addEventListener('load', function (e) { done(e.target); }, true);
		this.root.addEventListener('error', function (e) {
			if (e.target && e.target.classList && e.target.classList.contains('cbs-favicon')) { e.target.classList.add('is-broken'); }
		}, true);
		Array.prototype.forEach.call(this.root.querySelectorAll('.cbs-favicon'), function (img) {
			if (img.complete) { done(img); }
		});
	};

	Showcase.prototype.bind = function () {
		var self = this;

		if (this.input) {
			var timer;
			this.input.addEventListener('input', function () {
				clearTimeout(timer);
				timer = setTimeout(function () {
					self.query = self.input.value;
					self.apply(true);
				}, 110);
			});
			this.input.addEventListener('keydown', function (e) {
				if (e.key === 'Escape') {
					self.input.value = '';
					self.query = '';
					self.apply(true);
				}
			});
		}

		this.chips.forEach(function (chip) {
			chip.addEventListener('click', function () {
				self.group = chip.getAttribute('data-group') || '';
				self.chips.forEach(function (c) {
					var on = c === chip;
					c.classList.toggle('is-active', on);
					c.setAttribute('aria-pressed', on ? 'true' : 'false');
				});
				self.apply(true);
			});
		});

		this.sections.forEach(function (sec) {
			if (!sec.more) { return; }
			var rest = sec.more.getAttribute('data-rest');
			sec.more.addEventListener('click', function () {
				var open = !sec.el.classList.contains('is-expanded');
				sec.el.classList.toggle('is-expanded', open);
				sec.more.setAttribute('aria-expanded', open ? 'true' : 'false');
				sec.more.textContent = open ? '折りたたむ' : '残り' + fmt(rest) + '件を表示';
				if (open) {
					self.pop(sec.cards.filter(function (c) { return c.extra && !c.el.hidden; }));
				} else {
					var r = sec.el.getBoundingClientRect();
					if (r.top < 0) { sec.el.scrollIntoView({ block: 'start', behavior: reduced() ? 'auto' : 'smooth' }); }
				}
			});
		});

		var reset = this.root.querySelector('.cbs-reset');
		if (reset) {
			reset.addEventListener('click', function () {
				if (self.input) { self.input.value = ''; }
				self.query = '';
				var all = self.chips[0];
				if (all) { all.click(); } else { self.apply(true); }
				if (self.input) { self.input.focus(); }
			});
		}
	};

	/** 検索語と絞り込みを反映 */
	Showcase.prototype.apply = function (animate) {
		var raw = String(this.query || '').trim();
		var terms = raw ? norm(raw).split(/\s+/).filter(Boolean) : [];
		var searching = terms.length > 0;
		var group = this.group;
		var total = 0;
		var shown = [];

		this.root.classList.toggle('is-searching', searching);

		for (var i = 0; i < this.sections.length; i++) {
			var sec = this.sections[i];
			var inGroup = !group || sec.group === group;
			var n = 0;
			for (var j = 0; j < sec.cards.length; j++) {
				var c = sec.cards[j];
				var ok = inGroup;
				if (ok && searching) {
					for (var k = 0; k < terms.length; k++) {
						if (c.s.indexOf(terms[k]) === -1) { ok = false; break; }
					}
				}
				var wasHidden = c.el.hidden;
				c.el.hidden = !ok;
				if (ok) {
					n++;
					if (wasHidden && (!c.extra || searching || sec.el.classList.contains('is-expanded'))) {
						shown.push(c);
					}
				}
				this.highlight(c, ok && searching ? terms : null);
			}
			sec.el.hidden = n === 0;
			if (sec.countEl) {
				sec.countEl.textContent = searching ? fmt(n) + ' / ' + fmt(sec.total) : fmt(sec.total);
			}
			total += n;
		}

		this.empty.hidden = total > 0;
		if (total === 0) {
			this.emptyTitle.textContent = searching ? '「' + raw + '」に一致するブックマークはありません' : 'このフォルダには表示できるブックマークがありません';
		}
		if (this.status) {
			this.status.textContent = searching || group ? fmt(total) + '件を表示しています' : '';
		}
		if (animate) { this.pop(shown); }
	};

	/**
	 * 文字ごとに正規化し、正規化後の位置 → 元の文字列の位置 の対応表を作る
	 * （全角で検索しても半角のタイトルを強調できるように）。
	 */
	function normMap(text) {
		var out = '';
		var start = [];
		var end = [];
		var offset = 0;
		for (var it = text[Symbol.iterator](), r = it.next(); !r.done; r = it.next()) {
			var ch = r.value;
			var n = norm(ch);
			for (var u = 0; u < n.length; u++) {
				start.push(offset);
				end.push(offset + ch.length);
			}
			out += n;
			offset += ch.length;
		}
		return { s: out, start: start, end: end };
	}

	/** タイトル中の一致部分を <mark> で強調（テキストノードだけで組み立てる） */
	Showcase.prototype.highlight = function (c, terms) {
		if (!c.titleEl) { return; }
		if (!terms) {
			if (c.hl) { c.titleEl.textContent = c.title; c.hl = false; }
			return;
		}
		var text = c.title;
		if (!c.map) { c.map = normMap(text); }
		var ns = c.map.s;
		var ranges = [];
		terms.forEach(function (t) {
			if (!t) { return; }
			var at = ns.indexOf(t);
			while (at !== -1) {
				ranges.push([c.map.start[at], c.map.end[at + t.length - 1]]);
				at = ns.indexOf(t, at + t.length);
			}
		});
		if (!ranges.length) {
			if (c.hl) { c.titleEl.textContent = text; c.hl = false; }
			return;
		}
		ranges.sort(function (a, b) { return a[0] - b[0]; });
		var merged = [ranges[0]];
		for (var i = 1; i < ranges.length; i++) {
			var last = merged[merged.length - 1];
			if (ranges[i][0] <= last[1]) { last[1] = Math.max(last[1], ranges[i][1]); } else { merged.push(ranges[i]); }
		}
		var frag = document.createDocumentFragment();
		var pos = 0;
		merged.forEach(function (r) {
			if (r[0] > pos) { frag.appendChild(document.createTextNode(text.slice(pos, r[0]))); }
			var m = document.createElement('mark');
			m.textContent = text.slice(r[0], r[1]);
			frag.appendChild(m);
			pos = r[1];
		});
		if (pos < text.length) { frag.appendChild(document.createTextNode(text.slice(pos))); }
		c.titleEl.textContent = '';
		c.titleEl.appendChild(frag);
		c.hl = true;
	};

	/** 新しく見えたカードを軽く浮かび上がらせる（操作への応答） */
	Showcase.prototype.pop = function (cards) {
		if (!this.fx || reduced() || !cards.length) { return; }
		var list = cards.slice(0, POP_MAX);
		list.forEach(function (c, i) {
			c.el.classList.remove('is-pop');
			c.el.style.setProperty('--j', String(i));
		});
		void this.root.offsetWidth; // アニメーションを確実に再開させる
		list.forEach(function (c) { c.el.classList.add('is-pop'); });
		clearTimeout(this.popTimer);
		this.popTimer = setTimeout(function () {
			list.forEach(function (c) { c.el.classList.remove('is-pop'); });
		}, 1300);
	};

	Showcase.prototype.effects = function () {
		var root = this.root;

		// 金箔.
		var canvas = root.querySelector('.cbs-leaf');
		if (canvas && canvas.getContext) {
			try { new GoldLeaf(canvas, root); } catch (e) { /* 描画できない環境では何もしない */ }
		}

		// 読み込み時の演出：画面に入ったときに 1 回だけ.
		if (!reduced()) {
			root.classList.add('is-waiting');
			var start = function () {
				root.classList.remove('is-waiting');
				root.classList.add('is-intro');
				setTimeout(function () { root.classList.remove('is-intro'); }, INTRO_MAX * 34 + 260 + 900);
			};
			if ('IntersectionObserver' in window) {
				var io = new IntersectionObserver(function (entries) {
					if (entries[0].isIntersecting) {
						io.disconnect();
						start();
					}
				}, { threshold: 0.05 });
				io.observe(root);
			} else {
				start();
			}
		}

		// カーソルの光と傾き（マウス操作の端末のみ）.
		if (!mqFine || !mqFine.matches) { return; }
		var active = null;
		var pending = null;
		var raf = 0;
		function paint() {
			raf = 0;
			if (!pending) { return; }
			var link = pending.link;
			var r = link.getBoundingClientRect();
			var x = pending.x - r.left;
			var y = pending.y - r.top;
			link.style.setProperty('--mx', x + 'px');
			link.style.setProperty('--my', y + 'px');
			if (!reduced()) {
				link.style.setProperty('--ry', (((x / r.width) - 0.5) * 9).toFixed(2) + 'deg');
				link.style.setProperty('--rx', (-((y / r.height) - 0.5) * 9).toFixed(2) + 'deg');
			}
		}
		function reset(link) {
			link.style.removeProperty('--rx');
			link.style.removeProperty('--ry');
		}
		root.addEventListener('pointermove', function (e) {
			var link = e.target.closest ? e.target.closest('.cbs-link') : null;
			if (active && active !== link) { reset(active); }
			active = link;
			if (!link) { return; }
			pending = { link: link, x: e.clientX, y: e.clientY };
			if (!raf) { raf = requestAnimationFrame(paint); }
		});
		root.addEventListener('pointerleave', function () {
			if (active) { reset(active); active = null; }
		});
	};

	/* ------------------------------------------------------------------
	 * 初期化と「/」キー
	 * ------------------------------------------------------------------ */
	var instances = [];

	function init() {
		Array.prototype.forEach.call(document.querySelectorAll('.cbs[data-cbs]'), function (root) {
			if (!root.cbs) {
				root.cbs = new Showcase(root);
				instances.push(root.cbs);
			}
		});
	}

	document.addEventListener('keydown', function (e) {
		if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) { return; }
		var t = e.target;
		if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) { return; }
		// 画面に見えている一覧の検索欄へ.
		for (var i = 0; i < instances.length; i++) {
			var inst = instances[i];
			if (!inst.input) { continue; }
			var r = inst.root.getBoundingClientRect();
			if (r.bottom > 0 && r.top < window.innerHeight) {
				e.preventDefault();
				inst.input.focus();
				if (r.top < 0 || inst.input.getBoundingClientRect().top < 0) {
					inst.input.scrollIntoView({ block: 'center', behavior: reduced() ? 'auto' : 'smooth' });
				}
				return;
			}
		}
	});

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
