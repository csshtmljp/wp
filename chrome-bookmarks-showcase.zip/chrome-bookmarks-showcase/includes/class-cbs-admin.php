<?php
/**
 * 管理画面：アップロード・一覧・編集・設定。
 *
 * @package ChromeBookmarksShowcase
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CBS_Admin {

	const SLUG     = 'chrome-bookmarks';
	const SETTINGS = 'chrome-bookmarks-settings';
	const GROUP    = 'cbs_settings_group';
	const MAX_SIZE = 31457280; // 30MB.

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_post_cbs_upload', array( __CLASS__, 'handle_upload' ) );
		add_action( 'admin_post_cbs_save', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_cbs_delete', array( __CLASS__, 'handle_delete' ) );
		add_action( 'admin_post_cbs_create_page', array( __CLASS__, 'handle_create_page' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( CBS_FILE ), array( __CLASS__, 'action_links' ) );
	}

	public static function menu() {
		add_menu_page( 'Chromeブックマーク', 'Chromeブックマーク', 'manage_options', self::SLUG, array( __CLASS__, 'render_main' ), 'dashicons-star-filled', 26 );
		add_submenu_page( self::SLUG, 'ブックマーク一覧', 'ブックマーク一覧', 'manage_options', self::SLUG, array( __CLASS__, 'render_main' ) );
		add_submenu_page( self::SLUG, '表示設定', '表示設定', 'manage_options', self::SETTINGS, array( __CLASS__, 'render_settings' ) );
	}

	public static function register_settings() {
		register_setting(
			self::GROUP,
			CBS_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'CBS_Settings', 'sanitize' ),
				'default'           => CBS_Settings::defaults(),
			)
		);
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">ブックマークを追加</a>' );
		return $links;
	}

	private static function url( $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::SLUG ), $args ), admin_url( 'admin.php' ) );
	}

	private static function notice( $type, $message ) {
		set_transient( 'cbs_notice_' . get_current_user_id(), array( $type, $message ), 120 );
	}

	public static function notices() {
		$key = 'cbs_notice_' . get_current_user_id();
		$n   = get_transient( $key );
		if ( ! $n ) {
			return;
		}
		delete_transient( $key );
		printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $n[0] ), wp_kses_post( $n[1] ) );
	}

	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'この操作を行う権限がありません。', 'chrome-bookmarks-showcase' ), 403 );
		}
		check_admin_referer( $action );
	}

	/* ------------------------------------------------------------------
	 * 処理
	 * ------------------------------------------------------------------ */
	public static function handle_upload() {
		self::guard( 'cbs_upload' );

		$replace = isset( $_POST['cbs_id'] ) ? sanitize_key( wp_unslash( $_POST['cbs_id'] ) ) : '';
		$back    = $replace ? self::url( array( 'edit' => $replace ) ) : self::url();

		if ( empty( $_FILES['cbs_file'] ) || ! is_array( $_FILES['cbs_file'] ) ) {
			self::notice( 'error', 'ファイルが選ばれていません。' );
			wp_safe_redirect( $back );
			exit;
		}
		$file = $_FILES['cbs_file']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- tmp_name のみ読み込み.
		$err  = isset( $file['error'] ) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE;

		if ( UPLOAD_ERR_OK !== $err ) {
			$messages = array(
				UPLOAD_ERR_INI_SIZE   => 'ファイルがサーバーのアップロード上限（' . size_format( wp_max_upload_size() ) . '）を超えています。',
				UPLOAD_ERR_FORM_SIZE  => 'ファイルが大きすぎます。',
				UPLOAD_ERR_PARTIAL    => 'アップロードが途中で切れました。もう一度お試しください。',
				UPLOAD_ERR_NO_FILE    => 'ファイルが選ばれていません。',
			);
			self::notice( 'error', isset( $messages[ $err ] ) ? $messages[ $err ] : 'アップロードに失敗しました（エラー ' . $err . '）。' );
			wp_safe_redirect( $back );
			exit;
		}

		$name = isset( $file['name'] ) ? sanitize_file_name( wp_unslash( $file['name'] ) ) : '';
		$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( '' !== $ext && ! in_array( $ext, array( 'html', 'htm', 'json', 'txt', 'bak' ), true ) ) {
			self::notice( 'error', 'HTML ファイル（Chrome で書き出したもの）か、Chrome の Bookmarks ファイルを選んでください。' );
			wp_safe_redirect( $back );
			exit;
		}
		if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) || filesize( $file['tmp_name'] ) > self::MAX_SIZE ) {
			self::notice( 'error', 'ファイルを読み込めませんでした（30MB まで）。' );
			wp_safe_redirect( $back );
			exit;
		}

		$content = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$parsed  = CBS_Parser::parse( (string) $content );
		unset( $content );

		if ( is_wp_error( $parsed ) ) {
			self::notice( 'error', esc_html( $parsed->get_error_message() ) );
			wp_safe_redirect( $back );
			exit;
		}

		if ( $replace && CBS_Store::get( $replace ) ) {
			$id   = $replace;
			$meta = array( 'source' => $name );
			$verb = '置き換えました';
		} else {
			$id    = CBS_Store::new_id();
			$title = isset( $_POST['cbs_name'] ) ? sanitize_text_field( wp_unslash( $_POST['cbs_name'] ) ) : '';
			$meta  = array(
				'name'   => '' !== $title ? $title : 'ブックマーク',
				'source' => $name,
			);
			$verb  = '読み込みました';
		}
		CBS_Store::save_parsed( $id, $parsed, $meta );

		$msg = sprintf( 'ブックマーク %s件・フォルダ %s個を%s。', number_format_i18n( $parsed['links'] ), number_format_i18n( $parsed['folders'] ), $verb );
		if ( $parsed['skipped'] ) {
			$msg .= sprintf( ' ブックマークレットなど、ウェブページ以外の %s件は表示対象から外しました。', number_format_i18n( $parsed['skipped'] ) );
		}
		$msg .= ' 公開する前に、非表示にしたいフォルダが無いか下で確認してください。';
		self::notice( 'success', esc_html( $msg ) );
		wp_safe_redirect( self::url( array( 'edit' => $id ) ) );
		exit;
	}

	public static function handle_save() {
		self::guard( 'cbs_save' );
		$id = isset( $_POST['cbs_id'] ) ? sanitize_key( wp_unslash( $_POST['cbs_id'] ) ) : '';
		if ( ! CBS_Store::get( $id ) ) {
			wp_safe_redirect( self::url() );
			exit;
		}

		$tree = CBS_Store::tree( $id );
		$ids  = array();
		if ( $tree ) {
			CBS_Store::collect_folder_ids( $tree, $ids );
		}
		if ( isset( $_POST['cbs_hidden_list'] ) ) {
			// JavaScript がまとめた非表示フォルダの一覧（フォルダ数が多くても max_input_vars に引っかからない）.
			$list   = array_map( 'sanitize_key', explode( ',', sanitize_text_field( wp_unslash( $_POST['cbs_hidden_list'] ) ) ) );
			$hidden = array_values( array_intersect( $ids, $list ) );
		} else {
			$shown  = isset( $_POST['cbs_show'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['cbs_show'] ) ) : array();
			$hidden = array_values( array_diff( $ids, $shown ) );
		}

		$visibility = isset( $_POST['cbs_visibility'] ) ? sanitize_key( wp_unslash( $_POST['cbs_visibility'] ) ) : 'public';
		$theme      = isset( $_POST['cbs_theme'] ) ? sanitize_key( wp_unslash( $_POST['cbs_theme'] ) ) : '';
		$name       = isset( $_POST['cbs_name'] ) ? sanitize_text_field( wp_unslash( $_POST['cbs_name'] ) ) : '';

		CBS_Store::update_meta(
			$id,
			array(
				'name'        => '' !== $name ? $name : 'ブックマーク',
				'description' => isset( $_POST['cbs_description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['cbs_description'] ) ) : '',
				'visibility'  => isset( CBS_Store::VISIBILITY[ $visibility ] ) ? $visibility : 'public',
				'theme'       => isset( CBS_Settings::THEMES[ $theme ] ) ? $theme : '',
				'hidden'      => $hidden,
			)
		);
		self::notice( 'success', '保存しました。' );
		wp_safe_redirect( self::url( array( 'edit' => $id ) ) );
		exit;
	}

	public static function handle_delete() {
		self::guard( 'cbs_delete' );
		$id = isset( $_POST['cbs_id'] ) ? sanitize_key( wp_unslash( $_POST['cbs_id'] ) ) : '';
		$col = CBS_Store::get( $id );
		if ( $col ) {
			CBS_Store::delete( $id );
			self::notice( 'success', esc_html( '「' . $col['name'] . '」を削除しました。このショートコードを置いていたページには何も表示されなくなります。' ) );
		}
		wp_safe_redirect( self::url() );
		exit;
	}

	public static function handle_create_page() {
		self::guard( 'cbs_create_page' );
		$id  = isset( $_POST['cbs_id'] ) ? sanitize_key( wp_unslash( $_POST['cbs_id'] ) ) : '';
		$col = CBS_Store::get( $id );
		if ( ! $col ) {
			wp_safe_redirect( self::url() );
			exit;
		}
		$page_id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'draft',
				'post_title'   => $col['name'],
				'post_content' => "<!-- wp:shortcode -->\n[chrome_bookmarks id=\"" . $id . "\"]\n<!-- /wp:shortcode -->",
			),
			true
		);
		if ( is_wp_error( $page_id ) ) {
			self::notice( 'error', esc_html( $page_id->get_error_message() ) );
		} else {
			self::notice(
				'success',
				sprintf(
					'下書きの固定ページを作成しました。<a href="%1$s" target="_blank" rel="noopener">プレビューで見る</a> ／ <a href="%2$s">編集して公開する</a>',
					esc_url( get_preview_post_link( $page_id ) ),
					esc_url( get_edit_post_link( $page_id, 'raw' ) )
				)
			);
		}
		wp_safe_redirect( self::url( array( 'edit' => $id ) ) );
		exit;
	}

	/* ------------------------------------------------------------------
	 * 画面
	 * ------------------------------------------------------------------ */
	public static function render_main() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 表示切替のみ.
		$edit = isset( $_GET['edit'] ) ? sanitize_key( wp_unslash( $_GET['edit'] ) ) : '';
		if ( $edit && CBS_Store::get( $edit ) ) {
			self::render_edit( $edit );
			return;
		}
		$all = CBS_Store::all();
		?>
		<div class="wrap">
			<h1>Chromeブックマーク</h1>

			<div class="card" style="max-width:820px">
				<h2 class="title">ブックマークファイルをアップロード</h2>
				<ol>
					<li>Chrome で <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>O</kbd>（Mac は <kbd>⌘</kbd> + <kbd>Option</kbd> + <kbd>B</kbd>）を押して「ブックマーク マネージャ」を開きます。</li>
					<li>右上の「︙」から「ブックマークをエクスポート」を選び、HTML ファイルを保存します。</li>
					<li>保存したファイルを下で選んでアップロードします。</li>
				</ol>
				<p class="description">Edge・Firefox・Safari で書き出した HTML ファイルや、Chrome のプロファイルフォルダにある「Bookmarks」ファイルも使えます。ファイル自体はサーバーに保存せず、読み取った内容だけを保存します。</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
					<input type="hidden" name="action" value="cbs_upload">
					<?php wp_nonce_field( 'cbs_upload' ); ?>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="cbs_name">表示するタイトル</label></th>
							<td><input type="text" id="cbs_name" name="cbs_name" class="regular-text" value="" placeholder="例：よく使うサイト集"></td>
						</tr>
						<tr>
							<th scope="row"><label for="cbs_file">ファイル</label></th>
							<td>
								<input type="file" id="cbs_file" name="cbs_file" accept=".html,.htm,.json,text/html,application/json" required>
								<p class="description">アップロード上限：<?php echo esc_html( size_format( min( wp_max_upload_size(), self::MAX_SIZE ) ) ); ?></p>
							</td>
						</tr>
					</table>
					<?php submit_button( 'アップロードして読み込む', 'primary', 'submit', false ); ?>
				</form>
			</div>

			<h2>読み込んだブックマーク</h2>
			<?php if ( ! $all ) : ?>
				<p>まだありません。上のフォームからファイルをアップロードしてください。</p>
			<?php else : ?>
				<table class="widefat striped" style="max-width:1100px">
					<thead>
						<tr><th>タイトル</th><th>ショートコード</th><th>件数</th><th>公開範囲</th><th>更新日</th></tr>
					</thead>
					<tbody>
					<?php foreach ( $all as $id => $col ) : ?>
						<tr>
							<td>
								<strong><a href="<?php echo esc_url( self::url( array( 'edit' => $id ) ) ); ?>"><?php echo esc_html( $col['name'] ); ?></a></strong>
								<div class="row-actions"><a href="<?php echo esc_url( self::url( array( 'edit' => $id ) ) ); ?>">編集・フォルダの表示切り替え</a></div>
							</td>
							<td><input type="text" readonly class="regular-text code" value="<?php echo esc_attr( '[chrome_bookmarks id="' . $id . '"]' ); ?>" onclick="this.select()" style="max-width:300px"></td>
							<td><?php echo esc_html( number_format_i18n( (int) $col['links'] ) ); ?>件 / <?php echo esc_html( number_format_i18n( (int) $col['folders'] ) ); ?>フォルダ</td>
							<td><?php echo esc_html( CBS_Store::VISIBILITY[ $col['visibility'] ] ?? '' ); ?></td>
							<td><?php echo esc_html( wp_date( 'Y/m/d H:i', (int) $col['updated'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function render_edit( $id ) {
		$col  = CBS_Store::get( $id );
		$tree = CBS_Store::tree( $id );
		$hidden = array_flip( (array) $col['hidden'] );
		?>
		<div class="wrap">
			<h1><?php echo esc_html( $col['name'] ); ?></h1>
			<p><a href="<?php echo esc_url( self::url() ); ?>">← 一覧に戻る</a></p>

			<div class="card" style="max-width:820px">
				<h2 class="title">表示する場所</h2>
				<p>固定ページや投稿に「ショートコード」ブロックを追加して、次のコードを貼り付けます。</p>
				<p><input type="text" readonly class="large-text code" value="<?php echo esc_attr( '[chrome_bookmarks id="' . $id . '"]' ); ?>" onclick="this.select()"></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="cbs_create_page">
					<input type="hidden" name="cbs_id" value="<?php echo esc_attr( $id ); ?>">
					<?php wp_nonce_field( 'cbs_create_page' ); ?>
					<?php submit_button( 'このブックマーク用の固定ページを下書きで作成', 'secondary', 'submit', false ); ?>
				</form>
			</div>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="cbs-save-form">
				<input type="hidden" name="action" value="cbs_save">
				<input type="hidden" name="cbs_id" value="<?php echo esc_attr( $id ); ?>">
				<?php wp_nonce_field( 'cbs_save' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="cbs_name">タイトル</label></th>
						<td><input type="text" id="cbs_name" name="cbs_name" class="regular-text" value="<?php echo esc_attr( $col['name'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="cbs_description">説明文</label></th>
						<td><textarea id="cbs_description" name="cbs_description" class="large-text" rows="2" placeholder="タイトルの下に表示されます（空欄なら表示しません）"><?php echo esc_textarea( (string) ( $col['description'] ?? '' ) ); ?></textarea></td>
					</tr>
					<tr>
						<th scope="row"><label for="cbs_visibility">公開範囲</label></th>
						<td>
							<select id="cbs_visibility" name="cbs_visibility">
								<?php foreach ( CBS_Store::VISIBILITY as $value => $label ) : ?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $col['visibility'], $value ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description">対象外の人には、ショートコードの場所に何も表示されません。</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cbs_theme">デザイン</label></th>
						<td>
							<select id="cbs_theme" name="cbs_theme">
								<option value="">表示設定の既定を使う</option>
								<?php foreach ( CBS_Settings::THEMES as $value => $label ) : ?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $col['theme'], $value ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row">表示するフォルダ</th>
						<td>
							<p class="description" style="margin-bottom:8px">チェックを外したフォルダは表示されません。親フォルダを外すと、中のフォルダもまとめて非表示になります。社内システムや個人的なページのフォルダは外しておくと安心です。</p>
							<div style="max-height:460px;overflow:auto;border:1px solid #c3c4c7;background:#fff;padding:8px 12px;max-width:760px">
								<?php
								if ( $tree ) {
									self::render_tree( $tree, $hidden );
								}
								?>
							</div>
						</td>
					</tr>
				</table>
				<?php submit_button( '変更を保存' ); ?>
			</form>
			<script>
			( function () {
				var form = document.getElementById( 'cbs-save-form' );
				if ( ! form ) { return; }
				form.addEventListener( 'submit', function () {
					var hidden = [];
					form.querySelectorAll( 'input[name="cbs_show[]"]' ).forEach( function ( box ) {
						if ( ! box.checked ) { hidden.push( box.value ); }
						box.disabled = true;
					} );
					var input = document.createElement( 'input' );
					input.type = 'hidden';
					input.name = 'cbs_hidden_list';
					input.value = hidden.join( ',' );
					form.appendChild( input );
				} );
			} )();
			</script>

			<hr>
			<h2>ファイルを置き換える</h2>
			<p>ブックマークを更新したら、新しく書き出したファイルで置き換えます。ショートコードはそのままで、非表示にしたフォルダの設定も（同じ名前の場所にあれば）引き継がれます。</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
				<input type="hidden" name="action" value="cbs_upload">
				<input type="hidden" name="cbs_id" value="<?php echo esc_attr( $id ); ?>">
				<?php wp_nonce_field( 'cbs_upload' ); ?>
				<input type="file" name="cbs_file" accept=".html,.htm,.json,text/html,application/json" required>
				<?php submit_button( 'アップロードして置き換える', 'secondary', 'submit', false ); ?>
			</form>
			<p class="description">現在のファイル：<?php echo esc_html( (string) ( $col['source'] ?? '' ) ); ?>（<?php echo esc_html( number_format_i18n( (int) $col['links'] ) ); ?>件、<?php echo esc_html( wp_date( 'Y/m/d H:i', (int) $col['updated'] ) ); ?> 読み込み）</p>

			<hr>
			<h2>ショートコードのオプション</h2>
			<table class="widefat striped" style="max-width:1000px">
				<tbody>
					<tr><td><code>folder="ブックマーク バー/開発"</code></td><td>特定のフォルダだけを表示（/ 区切り。途中のフォルダ名から書いても探します）</td></tr>
					<tr><td><code>theme="urushi"</code></td><td>デザイン：urushi（漆）／ruri（瑠璃）／hakuji（白磁）</td></tr>
					<tr><td><code>sort="title"</code></td><td>並び順：default（ブックマークの順）／title（タイトル順）／new（追加が新しい順）／old（古い順）</td></tr>
					<tr><td><code>per_section="12"</code></td><td>フォルダごとに最初に見せる件数（0 ですべて）</td></tr>
					<tr><td><code>search="0" chips="0"</code></td><td>検索欄・フォルダの絞り込みボタンを隠す</td></tr>
					<tr><td><code>effects="0"</code></td><td>金箔の演出・カードの光る動きを止める</td></tr>
					<tr><td><code>title="none"</code> / <code>title="…"</code></td><td>タイトルを隠す／別のタイトルにする</td></tr>
					<tr><td><code>align="full"</code></td><td>配置：wide（幅広・既定）／full（画面の横幅いっぱい）／none（本文と同じ幅）。テーマが対応している場合に効きます</td></tr>
					<tr><td><code>show_date="1"</code></td><td>カードに追加日を表示</td></tr>
				</tbody>
			</table>

			<hr>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('「<?php echo esc_js( $col['name'] ); ?>」を削除します。よろしいですか？');">
				<input type="hidden" name="action" value="cbs_delete">
				<input type="hidden" name="cbs_id" value="<?php echo esc_attr( $id ); ?>">
				<?php wp_nonce_field( 'cbs_delete' ); ?>
				<?php submit_button( 'このブックマークを削除', 'delete', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}

	private static function count_links( $node ) {
		$n = 0;
		foreach ( $node['c'] as $c ) {
			$n += 'l' === $c['t'] ? 1 : self::count_links( $c );
		}
		return $n;
	}

	private static function render_tree( $node, $hidden, $depth = 0 ) {
		$folders = array_filter(
			$node['c'],
			static function ( $c ) {
				return 'f' === $c['t'];
			}
		);
		if ( ! $folders ) {
			return;
		}
		echo '<ul style="margin:0 0 0 ' . ( $depth ? 22 : 0 ) . 'px">';
		foreach ( $folders as $f ) {
			echo '<li style="margin:4px 0"><label><input type="checkbox" name="cbs_show[]" value="' . esc_attr( $f['id'] ) . '" ' . checked( ! isset( $hidden[ $f['id'] ] ), true, false ) . '> ';
			echo '<span class="dashicons dashicons-category" style="color:#b08d3c;font-size:16px;vertical-align:-3px"></span> ' . esc_html( '' !== $f['n'] ? $f['n'] : '（名前なし）' );
			echo ' <span class="description">（' . esc_html( number_format_i18n( self::count_links( $f ) ) ) . '）</span></label>';
			self::render_tree( $f, $hidden, $depth + 1 );
			echo '</li>';
		}
		echo '</ul>';
	}

	public static function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = CBS_Settings::get();
		$n = CBS_Settings::OPTION;
		?>
		<div class="wrap">
			<h1>表示設定</h1>
			<form method="post" action="options.php">
				<?php settings_fields( self::GROUP ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="cbs_theme_default">デザイン（既定）</label></th>
						<td>
							<select id="cbs_theme_default" name="<?php echo esc_attr( $n ); ?>[theme]">
								<?php foreach ( CBS_Settings::THEMES as $value => $label ) : ?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $s['theme'], $value ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cbs_favicon">サイトのアイコン</label></th>
						<td>
							<select id="cbs_favicon" name="<?php echo esc_attr( $n ); ?>[favicon]">
								<?php foreach ( CBS_Settings::FAVICONS as $value => $label ) : ?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $s['favicon'], $value ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description">Google・DuckDuckGo を選ぶと、閲覧者のブラウザがそのサービスからアイコンを読み込みます（閲覧者の IP アドレスとサイトのドメインが各サービスに送られます）。アイコンが取れないサイトは頭文字の丸紋で表示します。</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cbs_per_section">フォルダごとの初期表示件数</label></th>
						<td>
							<input type="number" min="0" max="500" id="cbs_per_section" class="small-text" name="<?php echo esc_attr( $n ); ?>[per_section]" value="<?php echo esc_attr( (string) $s['per_section'] ); ?>">
							<p class="description">これより多いフォルダには「残り○件を表示」ボタンが付きます。0 ですべて表示。</p>
						</td>
					</tr>
					<tr>
						<th scope="row">動きと表示</th>
						<td>
							<?php
							$checks = array(
								'effects'   => '金箔が舞う演出・カードが光る動きを付ける（「視差効果を減らす」設定の閲覧者には自動で止めます）',
								'webfont'   => '見出しに「しっぽり明朝」（Google Fonts）を使う',
								'new_tab'   => 'リンクを新しいタブで開く',
								'show_host' => 'カードにドメイン名を表示',
								'show_date' => 'カードに追加日を表示',
							);
							foreach ( $checks as $key => $label ) {
								printf( '<label><input type="checkbox" name="%1$s[%2$s]" value="1" %3$s> %4$s</label><br>', esc_attr( $n ), esc_attr( $key ), checked( (int) $s[ $key ], 1, false ), esc_html( $label ) );
							}
							?>
						</td>
					</tr>
				</table>
				<?php submit_button( '設定を保存' ); ?>
			</form>
		</div>
		<?php
	}
}
