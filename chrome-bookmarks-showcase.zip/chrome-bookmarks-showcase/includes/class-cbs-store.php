<?php
/**
 * コレクション（アップロードしたブックマーク 1 ファイル分）の保存。
 *
 * - 一覧と設定:   option `cbs_index`
 * - ツリー本体:   option `cbs_tree_{id}`（自動読み込みしない）
 *
 * アップロードされたファイル自体はサーバーに残しません（解析結果だけを保存）。
 *
 * @package ChromeBookmarksShowcase
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CBS_Store {

	const INDEX       = 'cbs_index';
	const TREE_PREFIX = 'cbs_tree_';

	const VISIBILITY = array(
		'public'    => '全員に公開',
		'logged_in' => 'このサイトにログインしているユーザーのみ',
		'admin'     => '管理者のみ',
	);

	public static function all() {
		$index = get_option( self::INDEX, array() );
		return is_array( $index ) ? $index : array();
	}

	public static function get( $id ) {
		$all = self::all();
		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	public static function tree( $id ) {
		$tree = get_option( self::TREE_PREFIX . $id, null );
		return is_array( $tree ) ? $tree : null;
	}

	/**
	 * 新しい ID（bookmarks, bookmarks-2, …）。
	 */
	public static function new_id() {
		$all = self::all();
		$id  = 'bookmarks';
		$n   = 2;
		while ( isset( $all[ $id ] ) || false !== get_option( self::TREE_PREFIX . $id, false ) ) {
			$id = 'bookmarks-' . $n;
			++$n;
		}
		return $id;
	}

	/**
	 * 解析結果を保存（新規または置き換え）。
	 *
	 * @param string $id     ID.
	 * @param array  $parsed CBS_Parser::parse() の結果.
	 * @param array  $meta   name, source など.
	 */
	public static function save_parsed( $id, $parsed, $meta ) {
		$all = self::all();
		$now = time();
		$cur = isset( $all[ $id ] ) ? $all[ $id ] : array(
			'name'        => '',
			'description' => '',
			'visibility'  => 'public',
			'theme'       => '',
			'hidden'      => array(),
			'created'     => $now,
		);

		$cur = array_merge( $cur, $meta );
		$cur['links']   = (int) $parsed['links'];
		$cur['folders'] = (int) $parsed['folders'];
		$cur['skipped'] = (int) $parsed['skipped'];
		$cur['format']  = $parsed['format'];
		$cur['updated'] = $now;

		// 置き換え時、もう存在しないフォルダの非表示設定は掃除する.
		$ids           = array();
		self::collect_folder_ids( $parsed['tree'], $ids );
		$cur['hidden'] = array_values( array_intersect( (array) $cur['hidden'], $ids ) );

		$all[ $id ] = $cur;

		// ツリーは大きくなり得るので自動読み込みしない.
		delete_option( self::TREE_PREFIX . $id );
		add_option( self::TREE_PREFIX . $id, $parsed['tree'], '', 'no' );
		update_option( self::INDEX, $all, false );
	}

	public static function update_meta( $id, $meta ) {
		$all = self::all();
		if ( ! isset( $all[ $id ] ) ) {
			return false;
		}
		$all[ $id ] = array_merge( $all[ $id ], $meta );
		update_option( self::INDEX, $all, false );
		return true;
	}

	public static function delete( $id ) {
		$all = self::all();
		unset( $all[ $id ] );
		update_option( self::INDEX, $all, false );
		delete_option( self::TREE_PREFIX . $id );
	}

	public static function collect_folder_ids( $node, &$ids ) {
		if ( 'f' !== ( $node['t'] ?? '' ) ) {
			return;
		}
		if ( 'root' !== $node['id'] ) {
			$ids[] = $node['id'];
		}
		foreach ( $node['c'] as $child ) {
			self::collect_folder_ids( $child, $ids );
		}
	}
}
