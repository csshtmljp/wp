<?php
/**
 * ショートコード [chrome_bookmarks] の表示。
 *
 * JavaScript が無くても全リンクが表示・クリックでき、JavaScript で検索・絞り込み・演出を加えます。
 *
 * @package ChromeBookmarksShowcase
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CBS_Renderer {

	const TAG    = 'chrome_bookmarks';
	const STYLE  = 'cbs-front';
	const SCRIPT = 'cbs-front';
	const FONT   = 'cbs-font';

	/** 読み込み時の演出で順番に表示するカードの数 */
	const INTRO_CARDS = 36;

	private static $instance = 0;

	public static function init() {
		add_shortcode( self::TAG, array( __CLASS__, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}

	public static function register_assets() {
		wp_register_style( self::STYLE, CBS_URL . 'assets/css/cbs-front.css', array(), CBS_VERSION );
		wp_register_script( self::SCRIPT, CBS_URL . 'assets/js/cbs-front.js', array(), CBS_VERSION, true );
		// 見出し用の明朝体（しっぽり明朝）。使う文字だけが分割配信される.
		wp_register_style( self::FONT, 'https://fonts.googleapis.com/css2?family=Shippori+Mincho+B1:wght@700;800&display=swap', array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion

		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post instanceof WP_Post && has_shortcode( $post->post_content, self::TAG ) ) {
				self::enqueue();
			}
		}
	}

	private static function enqueue() {
		if ( ! wp_style_is( self::STYLE, 'registered' ) ) {
			self::register_assets();
		}
		wp_enqueue_style( self::STYLE );
		wp_enqueue_script( self::SCRIPT );
		if ( CBS_Settings::get()['webfont'] ) {
			wp_enqueue_style( self::FONT );
		}
	}

	/**
	 * @param array|string $atts 属性.
	 * @return string
	 */
	public static function render( $atts ) {
		$s   = CBS_Settings::get();
		$all = CBS_Store::all();

		$atts = shortcode_atts(
			array(
				'id'          => $all ? (string) array_key_first( $all ) : '',
				'folder'      => '',
				'theme'       => '',
				'title'       => '',
				'description' => '',
				'search'      => '1',
				'chips'       => '1',
				'effects'     => $s['effects'],
				'per_section' => $s['per_section'],
				'sort'        => 'default',
				'new_tab'     => $s['new_tab'],
				'show_host'   => $s['show_host'],
				'show_date'   => $s['show_date'],
				'favicon'     => $s['favicon'],
				'align'       => 'wide',
				'wide'        => '0',
			),
			$atts,
			self::TAG
		);

		$id  = sanitize_key( $atts['id'] );
		$col = CBS_Store::get( $id );
		if ( ! $col ) {
			return self::editor_error( 'id="' . $id . '" のブックマークが見つかりません。管理画面の「Chromeブックマーク」でショートコードを確認してください。' );
		}
		if ( ! self::can_view( $col ) ) {
			return '';
		}
		$tree = CBS_Store::tree( $id );
		if ( ! $tree ) {
			return self::editor_error( 'ブックマークのデータが読み込めません。ファイルをアップロードし直してください。' );
		}

		$hidden = array_flip( (array) $col['hidden'] );
		$base   = $tree;
		if ( '' !== trim( $atts['folder'] ) ) {
			$base = self::find_folder( $tree, trim( $atts['folder'] ) );
			if ( ! $base ) {
				return self::editor_error( 'folder="' . $atts['folder'] . '" に一致するフォルダがありません。「ブックマーク バー/開発」のように / 区切りで指定してください。' );
			}
		}
		if ( isset( $hidden[ $base['id'] ] ) ) {
			return '';
		}

		// 絞り込みボタンの基準フォルダ：直下にリンクが無く子フォルダが 1 つだけなら 1 段下げる.
		$chip_base = $base;
		for ( $guard = 0; $guard < 20; $guard++ ) {
			$visible_folders = self::visible_child_folders( $chip_base, $hidden );
			if ( self::direct_links( $chip_base ) || 1 !== count( $visible_folders ) ) {
				break;
			}
			$chip_base = $visible_folders[0];
		}

		// 絞り込みボタンの単位（グループ）を決める。
		// Chrome では大半が「ブックマーク バー」に入っているため、全体の 6 割以上を占めるグループは中のフォルダ単位に分ける.
		$groups_def = array();
		foreach ( self::visible_child_folders( $chip_base, $hidden ) as $child ) {
			$groups_def[] = array(
				'folder' => $child,
				'direct' => false,
			);
		}
		if ( self::direct_links( $chip_base ) ) {
			array_unshift(
				$groups_def,
				array(
					'folder' => $chip_base,
					'direct' => true,
				)
			);
		}
		$grand = self::count_visible( $chip_base, $hidden );
		for ( $guard = 0; $guard < 6; $guard++ ) {
			$expanded = false;
			foreach ( $groups_def as $gi => $g ) {
				if ( $g['direct'] ) {
					continue;
				}
				$kids = self::visible_child_folders( $g['folder'], $hidden );
				$size = self::count_visible( $g['folder'], $hidden );
				if ( ! $kids || $size < $grand * 0.6 || count( $groups_def ) - 1 + count( $kids ) + 1 > 24 ) {
					continue;
				}
				$replace = array();
				if ( self::direct_links( $g['folder'] ) ) {
					$replace[] = array(
						'folder' => $g['folder'],
						'direct' => true,
					);
				}
				foreach ( $kids as $kid ) {
					$replace[] = array(
						'folder' => $kid,
						'direct' => false,
					);
				}
				array_splice( $groups_def, $gi, 1, $replace );
				$expanded = true;
				break;
			}
			if ( ! $expanded ) {
				break;
			}
		}

		// セクション（リンクを直接含むフォルダ）を集める.
		$sections = array();
		$groups   = array();
		foreach ( $groups_def as $g ) {
			$f   = $g['folder'];
			$gid = $f['id'];
			$groups[ $gid ] = array(
				'name'  => '' !== $f['n'] ? $f['n'] : 'ブックマーク',
				'count' => 0,
			);
			if ( $g['direct'] ) {
				$sections[] = array(
					'id'    => $gid,
					'name'  => $groups[ $gid ]['name'],
					'path'  => array(),
					'group' => $gid,
					'links' => self::direct_links( $f ),
				);
			} else {
				self::collect( $f, array(), $gid, $hidden, $sections );
			}
		}

		$total = 0;
		foreach ( $sections as $i => $sec ) {
			$sections[ $i ]['links'] = self::sort_links( $sec['links'], $atts['sort'] );
			$groups[ $sec['group'] ]['count'] += count( $sec['links'] );
			$total += count( $sec['links'] );
		}
		$groups = array_filter(
			$groups,
			static function ( $g ) {
				return $g['count'] > 0;
			}
		);

		if ( 0 === $total ) {
			return self::editor_error( '表示できるブックマークがありません（すべてのフォルダが非表示になっている可能性があります）。' );
		}

		self::enqueue();
		++self::$instance;
		$uid = 'cbs-' . self::$instance;

		$theme = sanitize_key( $atts['theme'] );
		if ( ! isset( CBS_Settings::THEMES[ $theme ] ) ) {
			$theme = ! empty( $col['theme'] ) && isset( CBS_Settings::THEMES[ $col['theme'] ] ) ? $col['theme'] : $s['theme'];
		}

		$opts = array(
			'favicon'   => isset( CBS_Settings::FAVICONS[ $atts['favicon'] ] ) ? $atts['favicon'] : $s['favicon'],
			'new_tab'   => CBS_Settings::to_bool( $atts['new_tab'] ),
			'show_host' => CBS_Settings::to_bool( $atts['show_host'] ),
			'show_date' => CBS_Settings::to_bool( $atts['show_date'] ),
			'per'       => max( 0, (int) $atts['per_section'] ),
		);

		$title       = '' !== $atts['title'] ? $atts['title'] : $col['name'];
		$description = '' !== $atts['description'] ? $atts['description'] : (string) ( $col['description'] ?? '' );
		$show_search = CBS_Settings::to_bool( $atts['search'] );
		$show_chips  = CBS_Settings::to_bool( $atts['chips'] ) && count( $groups ) > 1;
		$effects     = CBS_Settings::to_bool( $atts['effects'] );

		$classes = array( 'cbs', 'cbs-theme-' . $theme );
		// テーマの「幅広」「全幅」配置を使う（ブロックテーマ・対応テーマで有効）.
		$align = CBS_Settings::to_bool( $atts['wide'] ) ? 'full' : sanitize_key( $atts['align'] );
		if ( in_array( $align, array( 'wide', 'full' ), true ) ) {
			$classes[] = 'align' . $align;
		}
		if ( $effects ) {
			$classes[] = 'cbs-fx';
		}

		$config = array(
			'effects'    => $effects,
			'perSection' => $opts['per'],
		);

		ob_start();
		?>
		<div id="<?php echo esc_attr( $uid ); ?>" class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" data-cbs="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">
			<?php if ( $effects ) : ?>
				<canvas class="cbs-leaf" aria-hidden="true"></canvas>
			<?php endif; ?>
			<header class="cbs-hero">
				<div class="cbs-hero-inner">
					<?php if ( 'none' !== $title && '' !== trim( $title ) ) : ?>
						<h2 class="cbs-title"><?php echo esc_html( $title ); ?></h2>
					<?php endif; ?>
					<?php if ( '' !== trim( $description ) ) : ?>
						<p class="cbs-desc"><?php echo esc_html( $description ); ?></p>
					<?php endif; ?>
					<p class="cbs-meta"><?php echo esc_html( sprintf( '%s件のブックマークを%sのフォルダに収録', number_format_i18n( $total ), number_format_i18n( count( $sections ) ) ) ); ?></p>
					<?php if ( $show_search ) : ?>
						<div class="cbs-search">
							<label class="cbs-sr" for="<?php echo esc_attr( $uid ); ?>-q">ブックマークを検索</label>
							<svg class="cbs-search-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M15.5 15.5 21 21" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
							<input type="search" id="<?php echo esc_attr( $uid ); ?>-q" class="cbs-q" placeholder="タイトルやURLで探す" autocomplete="off" enterkeyhint="search" spellcheck="false">
							<kbd class="cbs-kbd" title="/ キーで検索欄へ移動">/</kbd>
						</div>
					<?php endif; ?>
				</div>
			</header>

			<?php if ( $show_chips ) : ?>
				<div class="cbs-chips" role="toolbar" aria-label="フォルダで絞り込む">
					<button type="button" class="cbs-chip is-active" data-group="" aria-pressed="true">すべて<span class="cbs-chip-count"><?php echo esc_html( number_format_i18n( $total ) ); ?></span></button>
					<?php foreach ( $groups as $gid => $g ) : ?>
						<button type="button" class="cbs-chip" data-group="<?php echo esc_attr( $gid ); ?>" aria-pressed="false"><?php echo esc_html( $g['name'] ); ?><span class="cbs-chip-count"><?php echo esc_html( number_format_i18n( $g['count'] ) ); ?></span></button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<p class="cbs-status cbs-sr" aria-live="polite"></p>

			<div class="cbs-body">
				<?php
				$card_index = 0;
				foreach ( $sections as $n => $sec ) {
					self::render_section( $uid . '-s' . $n, $sec, $opts, $card_index );
				}
				?>
			</div>

			<div class="cbs-empty" hidden>
				<p class="cbs-empty-title"></p>
				<p class="cbs-empty-hint">検索語を短くするか、絞り込みを「すべて」に戻してください。</p>
				<button type="button" class="cbs-reset">検索と絞り込みを解除</button>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	private static function render_section( $sid, $sec, $opts, &$card_index ) {
		$links = $sec['links'];
		$count = count( $links );
		$per   = $opts['per'];
		?>
		<section class="cbs-section" data-group="<?php echo esc_attr( $sec['group'] ); ?>" aria-labelledby="<?php echo esc_attr( $sid ); ?>">
			<div class="cbs-section-head">
				<h3 class="cbs-section-title" id="<?php echo esc_attr( $sid ); ?>">
					<?php if ( $sec['path'] ) : ?>
						<span class="cbs-section-path"><?php echo esc_html( implode( ' / ', $sec['path'] ) ); ?> / </span>
					<?php endif; ?>
					<?php echo esc_html( $sec['name'] ); ?>
				</h3>
				<span class="cbs-section-rule" aria-hidden="true"></span>
				<span class="cbs-section-count" data-total="<?php echo esc_attr( (string) $count ); ?>"><?php echo esc_html( number_format_i18n( $count ) ); ?></span>
			</div>
			<ul class="cbs-grid">
				<?php
				foreach ( $links as $i => $link ) {
					$extra = $per > 0 && $i >= $per;
					self::render_card( $link, $opts, $extra, $extra ? -1 : $card_index );
					if ( ! $extra ) {
						++$card_index;
					}
				}
				?>
			</ul>
			<?php if ( $per > 0 && $count > $per ) : ?>
				<button type="button" class="cbs-more" aria-expanded="false" data-rest="<?php echo esc_attr( (string) ( $count - $per ) ); ?>">残り<?php echo esc_html( number_format_i18n( $count - $per ) ); ?>件を表示</button>
			<?php endif; ?>
		</section>
		<?php
	}

	private static function render_card( $link, $opts, $extra, $index ) {
		$url   = $link['u'];
		$host  = (string) wp_parse_url( $url, PHP_URL_HOST );
		$host  = preg_replace( '/^www\./i', '', strtolower( $host ) );
		$title = (string) $link['n'];
		$char  = self::crest_char( $title, $host );

		$search = function_exists( 'mb_strtolower' ) ? mb_strtolower( $title . ' ' . $url, 'UTF-8' ) : strtolower( $title . ' ' . $url );

		$icon = '';
		switch ( $opts['favicon'] ) {
			case 'google':
				$icon = 'https://www.google.com/s2/favicons?domain=' . rawurlencode( $host ) . '&sz=64';
				break;
			case 'duckduckgo':
				$icon = 'https://icons.duckduckgo.com/ip3/' . rawurlencode( $host ) . '.ico';
				break;
			case 'file':
				$icon = isset( $link['i'] ) ? $link['i'] : '';
				break;
		}

		$style = $index >= 0 && $index < self::INTRO_CARDS ? ' style="--i:' . (int) $index . '"' : '';
		$class = 'cbs-card' . ( $extra ? ' is-extra' : '' );
		$attrs = $opts['new_tab'] ? ' target="_blank" rel="noopener noreferrer nofollow"' : ' rel="nofollow"';

		echo '<li class="' . esc_attr( $class ) . '" data-s="' . esc_attr( $search ) . '"' . $style . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $style は整数のみ.
		echo '<a class="cbs-link" href="' . esc_url( $url, array( 'http', 'https', 'ftp' ) ) . '"' . $attrs . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- 固定文字列.
		echo '<span class="cbs-crest" aria-hidden="true"><span class="cbs-crest-char">' . esc_html( $char ) . '</span>';
		if ( '' !== $icon ) {
			$src = 0 === strpos( $icon, 'data:' ) ? esc_attr( $icon ) : esc_url( $icon );
			echo '<img class="cbs-favicon" src="' . $src . '" alt="" width="32" height="32" loading="lazy" decoding="async" referrerpolicy="no-referrer">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- 上でエスケープ済み.
		}
		echo '</span>';
		echo '<span class="cbs-card-text"><span class="cbs-card-title">' . esc_html( $title ) . '</span>';
		if ( $opts['show_host'] && '' !== $host ) {
			echo '<span class="cbs-card-host">' . esc_html( $host ) . '</span>';
		}
		if ( $opts['show_date'] && ! empty( $link['d'] ) ) {
			echo '<span class="cbs-card-date">' . esc_html( wp_date( 'Y年n月j日', (int) $link['d'] ) ) . '追加</span>';
		}
		echo '</span></a></li>';
	}

	/**
	 * 丸紋に入れる 1 文字（タイトルの頭文字。記号ならドメインの頭文字）。
	 */
	private static function crest_char( $title, $host ) {
		$candidates = array( $title, $host );
		foreach ( $candidates as $text ) {
			if ( preg_match( '/[\p{L}\p{N}]/u', (string) $text, $m ) ) {
				return function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $m[0], 'UTF-8' ) : strtoupper( $m[0] );
			}
		}
		return '・';
	}

	private static function can_view( $col ) {
		$v = isset( $col['visibility'] ) ? $col['visibility'] : 'public';
		if ( 'logged_in' === $v ) {
			return is_user_logged_in();
		}
		if ( 'admin' === $v ) {
			return current_user_can( 'manage_options' );
		}
		return true;
	}

	private static function direct_links( $folder ) {
		$out = array();
		foreach ( $folder['c'] as $c ) {
			if ( 'l' === $c['t'] ) {
				$out[] = $c;
			}
		}
		return $out;
	}

	private static function visible_child_folders( $folder, $hidden ) {
		$out = array();
		foreach ( $folder['c'] as $c ) {
			if ( 'f' === $c['t'] && ! isset( $hidden[ $c['id'] ] ) && self::has_visible_links( $c, $hidden ) ) {
				$out[] = $c;
			}
		}
		return $out;
	}

	private static function has_visible_links( $folder, $hidden ) {
		foreach ( $folder['c'] as $c ) {
			if ( 'l' === $c['t'] ) {
				return true;
			}
			if ( 'f' === $c['t'] && ! isset( $hidden[ $c['id'] ] ) && self::has_visible_links( $c, $hidden ) ) {
				return true;
			}
		}
		return false;
	}

	private static function count_visible( $folder, $hidden ) {
		$n = 0;
		foreach ( $folder['c'] as $c ) {
			if ( 'l' === $c['t'] ) {
				++$n;
			} elseif ( ! isset( $hidden[ $c['id'] ] ) ) {
				$n += self::count_visible( $c, $hidden );
			}
		}
		return $n;
	}

	private static function collect( $folder, $path, $group, $hidden, &$sections ) {
		if ( isset( $hidden[ $folder['id'] ] ) ) {
			return;
		}
		$links = self::direct_links( $folder );
		if ( $links ) {
			$sections[] = array(
				'id'    => $folder['id'],
				'name'  => '' !== $folder['n'] ? $folder['n'] : '（名前なし）',
				'path'  => $path,
				'group' => $group,
				'links' => $links,
			);
		}
		foreach ( $folder['c'] as $c ) {
			if ( 'f' === $c['t'] ) {
				self::collect( $c, array_merge( $path, array( $folder['n'] ) ), $group, $hidden, $sections );
			}
		}
	}

	/**
	 * フォルダ指定（"ブックマーク バー/開発" のような名前の並び、またはフォルダ ID）。
	 */
	private static function find_folder( $tree, $spec ) {
		// ID 指定.
		if ( preg_match( '/^[a-f0-9]{12}$/', $spec ) ) {
			$found = self::find_by_id( $tree, $spec );
			if ( $found ) {
				return $found;
			}
		}
		$parts = array_values( array_filter( array_map( 'trim', explode( '/', $spec ) ), 'strlen' ) );
		if ( ! $parts ) {
			return null;
		}
		// ルートから順にたどる。見つからなければツリー全体から先頭の名前を探して開始.
		$found = self::walk_path( $tree, $parts );
		if ( $found ) {
			return $found;
		}
		return self::find_path_anywhere( $tree, $parts );
	}

	private static function walk_path( $node, $parts ) {
		foreach ( $parts as $name ) {
			$next = null;
			foreach ( $node['c'] as $c ) {
				if ( 'f' === $c['t'] && self::same_name( $c['n'], $name ) ) {
					$next = $c;
					break;
				}
			}
			if ( ! $next ) {
				return null;
			}
			$node = $next;
		}
		return $node;
	}

	private static function find_path_anywhere( $node, $parts ) {
		foreach ( $node['c'] as $c ) {
			if ( 'f' !== $c['t'] ) {
				continue;
			}
			if ( self::same_name( $c['n'], $parts[0] ) ) {
				$hit = 1 === count( $parts ) ? $c : self::walk_path( $c, array_slice( $parts, 1 ) );
				if ( $hit ) {
					return $hit;
				}
			}
			$hit = self::find_path_anywhere( $c, $parts );
			if ( $hit ) {
				return $hit;
			}
		}
		return null;
	}

	private static function find_by_id( $node, $id ) {
		if ( 'f' !== $node['t'] ) {
			return null;
		}
		if ( $node['id'] === $id ) {
			return $node;
		}
		foreach ( $node['c'] as $c ) {
			$hit = self::find_by_id( $c, $id );
			if ( $hit ) {
				return $hit;
			}
		}
		return null;
	}

	private static function same_name( $a, $b ) {
		$norm = static function ( $s ) {
			$s = preg_replace( '/\s+/u', '', (string) $s );
			return function_exists( 'mb_strtolower' ) ? mb_strtolower( $s, 'UTF-8' ) : strtolower( $s );
		};
		return $norm( $a ) === $norm( $b );
	}

	private static function sort_links( $links, $sort ) {
		switch ( $sort ) {
			case 'title':
				usort(
					$links,
					static function ( $a, $b ) {
						return strnatcasecmp( $a['n'], $b['n'] );
					}
				);
				break;
			case 'new':
				usort(
					$links,
					static function ( $a, $b ) {
						return (int) $b['d'] - (int) $a['d'];
					}
				);
				break;
			case 'old':
				usort(
					$links,
					static function ( $a, $b ) {
						return (int) $a['d'] - (int) $b['d'];
					}
				);
				break;
		}
		return $links;
	}

	private static function editor_error( $message ) {
		if ( current_user_can( 'edit_posts' ) ) {
			return '<p class="cbs-error" style="padding:.8em 1em;border-left:4px solid #b8322a;background:#fbeeee;">［Chromeブックマーク］' . esc_html( $message ) . '</p>';
		}
		return '';
	}
}
