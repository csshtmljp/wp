<?php
/**
 * 全体設定。
 *
 * @package ChromeBookmarksShowcase
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CBS_Settings {

	const OPTION = 'cbs_settings';

	/** テーマ（日本の工芸素材） */
	const THEMES = array(
		'urushi' => '漆（漆黒×金）',
		'ruri'   => '瑠璃（紺×金）',
		'hakuji' => '白磁（白×金・明るいサイト向け）',
	);

	/** アイコンの取得元 */
	const FAVICONS = array(
		'google'     => 'Google のアイコン配信（高解像度・おすすめ）',
		'duckduckgo' => 'DuckDuckGo のアイコン配信',
		'file'       => 'ブックマークファイル内のアイコンのみ（外部通信なし）',
		'none'       => '使わない（頭文字の丸紋だけ）',
	);

	public static function defaults() {
		return array(
			'theme'       => 'urushi',
			'favicon'     => 'google',
			'webfont'     => 1,
			'effects'     => 1,
			'per_section' => 24,
			'new_tab'     => 1,
			'show_host'   => 1,
			'show_date'   => 0,
		);
	}

	public static function get() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	public static function sanitize( $input ) {
		$in  = is_array( $input ) ? $input : array();
		$d   = self::defaults();
		$out = array();

		$out['theme']       = isset( $in['theme'] ) && isset( self::THEMES[ $in['theme'] ] ) ? $in['theme'] : $d['theme'];
		$out['favicon']     = isset( $in['favicon'] ) && isset( self::FAVICONS[ $in['favicon'] ] ) ? $in['favicon'] : $d['favicon'];
		$out['per_section'] = isset( $in['per_section'] ) ? min( 500, max( 0, (int) $in['per_section'] ) ) : $d['per_section'];

		foreach ( array( 'webfont', 'effects', 'new_tab', 'show_host', 'show_date' ) as $key ) {
			$out[ $key ] = empty( $in[ $key ] ) ? 0 : 1;
		}
		return $out;
	}

	public static function to_bool( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}
		return in_array( strtolower( trim( (string) $value ) ), array( '1', 'true', 'yes', 'on' ), true );
	}
}
