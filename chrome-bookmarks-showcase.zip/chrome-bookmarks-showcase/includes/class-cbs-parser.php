<?php
/**
 * ブックマークファイルの解析。
 *
 * 対応形式:
 *  - Chrome / Edge / Firefox / Safari の「ブックマークをエクスポート」で保存した HTML（Netscape Bookmark 形式）
 *  - Chrome のプロファイルフォルダにある「Bookmarks」ファイル（JSON）
 *
 * 出力するツリー（保存容量を抑えるため短いキー）:
 *  フォルダ: [ 't' => 'f', 'id' => string, 'n' => 名前, 'd' => 追加日時(UNIX), 'c' => 子の配列 ]
 *  リンク  : [ 't' => 'l', 'n' => タイトル, 'u' => URL, 'd' => 追加日時(UNIX), 'i' => data:image アイコン（任意） ]
 *
 * @package ChromeBookmarksShowcase
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CBS_Parser {

	const MAX_LINKS     = 30000;
	const MAX_ICON_SIZE = 8000;

	/** 解析中の集計 */
	private static $stats;

	/** 使用済みフォルダ ID */
	private static $ids;

	/**
	 * 解析のエントリーポイント。
	 *
	 * @param string $content ファイル内容.
	 * @return array|WP_Error { tree, links, folders, skipped, format }
	 */
	public static function parse( $content ) {
		$content = (string) $content;
		if ( '' === trim( $content ) ) {
			return new WP_Error( 'cbs_empty', 'ファイルが空です。' );
		}
		// BOM 除去.
		if ( 0 === strpos( $content, "\xEF\xBB\xBF" ) ) {
			$content = substr( $content, 3 );
		}
		// UTF-8 でなければ日本語の主な文字コードから変換.
		if ( function_exists( 'mb_check_encoding' ) && ! mb_check_encoding( $content, 'UTF-8' ) ) {
			$converted = @mb_convert_encoding( $content, 'UTF-8', 'SJIS-win,eucJP-win,UTF-8' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( is_string( $converted ) ) {
				$content = $converted;
			}
		}

		self::$stats = array(
			'links'   => 0,
			'folders' => 0,
			'skipped' => 0,
		);
		self::$ids   = array();

		$head = ltrim( substr( $content, 0, 2048 ) );
		if ( '{' === substr( $head, 0, 1 ) ) {
			$tree   = self::parse_json( $content );
			$format = 'json';
		} elseif ( false !== stripos( $content, '<DL' ) && ( false !== stripos( $content, '<A ' ) || false !== stripos( $content, '<H3' ) ) ) {
			$tree   = self::parse_html( $content );
			$format = 'html';
		} else {
			return new WP_Error( 'cbs_format', 'ブックマークファイルとして読み取れませんでした。Chrome の「ブックマーク マネージャ」→「︙」→「ブックマークをエクスポート」で保存した HTML ファイルを選んでください。' );
		}

		if ( is_wp_error( $tree ) ) {
			return $tree;
		}

		$tree = self::finalize( $tree, array() );

		if ( 0 === self::$stats['links'] ) {
			return new WP_Error( 'cbs_no_links', 'ファイルの中にブックマークが見つかりませんでした。' );
		}

		return array(
			'tree'    => $tree,
			'links'   => self::$stats['links'],
			'folders' => self::$stats['folders'],
			'skipped' => self::$stats['skipped'],
			'format'  => $format,
		);
	}

	/* ------------------------------------------------------------------
	 * HTML（Netscape Bookmark 形式）
	 * DT / P タグが閉じられていない独特の形式なので、DL・H3・A だけを順に読むトークナイザーで解析する。
	 * ------------------------------------------------------------------ */
	private static function parse_html( $html ) {
		$ok = preg_match_all(
			'#<DL\b[^>]*>|</DL\s*>|<H3\b([^>]*)>(.*?)</H3\s*>|<A\s([^>]*)>(.*?)</A\s*>#is',
			$html,
			$tokens,
			PREG_SET_ORDER
		);
		if ( false === $ok ) {
			return new WP_Error( 'cbs_regex', 'ファイルの解析に失敗しました（ファイルが大きすぎる可能性があります）。' );
		}

		$root    = self::new_folder( '', 0 );
		$current = $root;
		$stack   = array();
		$pending = null;

		foreach ( $tokens as $tk ) {
			$tag = strtoupper( substr( $tk[0], 0, 3 ) );

			if ( '<DL' === $tag ) {
				$stack[] = $current;
				if ( $pending ) {
					$current = $pending;
					$pending = null;
				}
				continue;
			}
			if ( '</D' === $tag ) {
				if ( $stack ) {
					$current = array_pop( $stack );
				}
				$pending = null;
				continue;
			}
			if ( '<H3' === $tag ) {
				$attrs  = self::attrs( $tk[1] );
				$folder = self::new_folder( self::text( $tk[2] ), isset( $attrs['add_date'] ) ? (int) $attrs['add_date'] : 0 );
				$current->c[] = $folder;
				$pending      = $folder;
				continue;
			}
			// <A>.
			$pending = null;
			$attrs   = self::attrs( $tk[3] );
			$link    = self::new_link(
				isset( $attrs['href'] ) ? $attrs['href'] : '',
				self::text( $tk[4] ),
				isset( $attrs['add_date'] ) ? (int) $attrs['add_date'] : 0,
				isset( $attrs['icon'] ) ? $attrs['icon'] : ''
			);
			if ( $link ) {
				$current->c[] = $link;
			}
			if ( self::$stats['links'] >= self::MAX_LINKS ) {
				break;
			}
		}

		return self::wrap_root_links( $root );
	}

	/**
	 * Chrome の書き出しは「その他のブックマーク」の中身がルート直下に並ぶため、フォルダにまとめる。
	 *
	 * @param object $root ルート.
	 * @return object
	 */
	private static function wrap_root_links( $root ) {
		$folders = array();
		$links   = array();
		foreach ( $root->c as $child ) {
			if ( 'f' === $child->t ) {
				$folders[] = $child;
			} else {
				$links[] = $child;
			}
		}
		if ( ! $links ) {
			return $root;
		}
		$wrap    = self::new_folder( $folders ? 'その他のブックマーク' : 'ブックマーク', 0 );
		$wrap->c = $links;
		$folders[] = $wrap;
		$root->c   = $folders;
		return $root;
	}

	/* ------------------------------------------------------------------
	 * Chrome の Bookmarks（JSON）
	 * ------------------------------------------------------------------ */
	private static function parse_json( $json ) {
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) || empty( $data['roots'] ) || ! is_array( $data['roots'] ) ) {
			return new WP_Error( 'cbs_json', 'JSON ファイルの形式が Chrome の Bookmarks ファイルと一致しません。' );
		}
		$labels = array(
			'bookmark_bar' => 'ブックマーク バー',
			'other'        => 'その他のブックマーク',
			'synced'       => 'モバイルのブックマーク',
		);
		$root = self::new_folder( '', 0 );
		foreach ( $data['roots'] as $key => $node ) {
			if ( ! is_array( $node ) || empty( $node['children'] ) ) {
				continue;
			}
			$name = isset( $labels[ $key ] ) ? $labels[ $key ] : ( isset( $node['name'] ) ? (string) $node['name'] : (string) $key );
			$f    = self::new_folder( $name, self::webkit_time( $node['date_added'] ?? '' ) );
			self::json_children( $f, $node['children'] );
			$root->c[] = $f;
		}
		return $root;
	}

	private static function json_children( $folder, $children ) {
		foreach ( (array) $children as $node ) {
			if ( ! is_array( $node ) || self::$stats['links'] >= self::MAX_LINKS ) {
				continue;
			}
			$type = $node['type'] ?? '';
			if ( 'folder' === $type ) {
				$f = self::new_folder( (string) ( $node['name'] ?? '' ), self::webkit_time( $node['date_added'] ?? '' ) );
				self::json_children( $f, $node['children'] ?? array() );
				$folder->c[] = $f;
			} elseif ( 'url' === $type ) {
				$link = self::new_link( (string) ( $node['url'] ?? '' ), (string) ( $node['name'] ?? '' ), self::webkit_time( $node['date_added'] ?? '' ), '' );
				if ( $link ) {
					$folder->c[] = $link;
				}
			}
		}
	}

	/**
	 * Chrome の日時（1601-01-01 からのマイクロ秒）→ UNIX 秒。
	 *
	 * @param string|int $value 値.
	 * @return int
	 */
	private static function webkit_time( $value ) {
		$v = (string) $value;
		if ( '' === $v || ! ctype_digit( $v ) ) {
			return 0;
		}
		$unix = (int) floor( ( (float) $v ) / 1000000 ) - 11644473600;
		return $unix > 0 ? $unix : 0;
	}

	/* ------------------------------------------------------------------
	 * 共通
	 * ------------------------------------------------------------------ */
	private static function new_folder( $name, $date ) {
		return (object) array(
			't' => 'f',
			'n' => self::clip( trim( $name ), 200 ),
			'd' => (int) $date,
			'c' => array(),
		);
	}

	/**
	 * リンクを作成。http / https / ftp 以外（ブックマークレット javascript: など）は除外。
	 */
	private static function new_link( $url, $title, $date, $icon ) {
		$url = trim( html_entity_decode( (string) $url, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		if ( '' === $url || strlen( $url ) > 4096 || ! preg_match( '#^(https?|ftp)://[^\s/?\#]+#i', $url ) || preg_match( '/[\x00-\x1F\x7F]/', $url ) ) {
			++self::$stats['skipped'];
			return null;
		}
		$host  = (string) wp_parse_url( $url, PHP_URL_HOST );
		$title = trim( $title );
		$link  = (object) array(
			't' => 'l',
			'n' => self::clip( '' !== $title ? $title : $host, 300 ),
			'u' => $url,
			'd' => (int) $date,
		);
		$icon = trim( (string) $icon );
		if ( '' !== $icon && strlen( $icon ) <= self::MAX_ICON_SIZE && preg_match( '#^data:image/(png|gif|jpeg|webp|x-icon|vnd\.microsoft\.icon);base64,[A-Za-z0-9+/=]+$#', $icon ) ) {
			$link->i = $icon;
		}
		++self::$stats['links'];
		return $link;
	}

	/**
	 * フォルダに安定した ID（親からの名前の並びのハッシュ）を付け、配列に変換。リンクの無い空フォルダは除く。
	 *
	 * @param object $node ノード.
	 * @param array  $path 祖先の名前.
	 * @return array|null
	 */
	private static function finalize( $node, $path ) {
		if ( 'l' === $node->t ) {
			return (array) $node;
		}
		$is_root = empty( $path ) && '' === $node->n;
		$my_path = $is_root ? array() : array_merge( $path, array( $node->n ) );

		$children = array();
		foreach ( $node->c as $child ) {
			$c = self::finalize( $child, $is_root ? array( '' ) : $my_path );
			if ( null !== $c ) {
				$children[] = $c;
			}
		}

		if ( ! $is_root && ! $children ) {
			return null;
		}

		if ( $is_root ) {
			$id = 'root';
		} else {
			$base = substr( md5( implode( "\x1F", $my_path ) ), 0, 12 );
			$id   = $base;
			$n    = 2;
			while ( isset( self::$ids[ $id ] ) ) {
				$id = substr( md5( implode( "\x1F", $my_path ) . '#' . $n ), 0, 12 );
				++$n;
			}
			self::$ids[ $id ] = true;
			++self::$stats['folders'];
		}

		return array(
			't'  => 'f',
			'id' => $id,
			'n'  => $node->n,
			'd'  => $node->d,
			'c'  => $children,
		);
	}

	private static function attrs( $str ) {
		$out = array();
		if ( preg_match_all( '/([A-Za-z_\-]+)\s*=\s*"([^"]*)"/', (string) $str, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $a ) {
				$out[ strtolower( $a[1] ) ] = html_entity_decode( $a[2], ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			}
		}
		return $out;
	}

	private static function text( $html ) {
		$t = html_entity_decode( wp_strip_all_tags( (string) $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		return trim( preg_replace( '/\s+/u', ' ', $t ) );
	}

	private static function clip( $s, $max ) {
		if ( function_exists( 'mb_substr' ) && mb_strlen( $s, 'UTF-8' ) > $max ) {
			return mb_substr( $s, 0, $max, 'UTF-8' );
		}
		return $s;
	}
}
