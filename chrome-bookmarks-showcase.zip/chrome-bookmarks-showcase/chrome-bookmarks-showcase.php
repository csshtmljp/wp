<?php
/**
 * Plugin Name:       Chrome Bookmarks Showcase（Chromeブックマーク・ギャラリー）
 * Description:       Google Chrome から書き出したブックマークファイルをアップロードし、ショートコード [chrome_bookmarks] で金箔が舞う豪華なデザインのリンク集として表示します。検索・フォルダ絞り込み付き。Edge / Firefox / Safari の書き出しファイルにも対応。
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Chrome Bookmarks Showcase
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       chrome-bookmarks-showcase
 *
 * @package ChromeBookmarksShowcase
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CBS_VERSION', '1.0.0' );
define( 'CBS_FILE', __FILE__ );
define( 'CBS_DIR', plugin_dir_path( __FILE__ ) );
define( 'CBS_URL', plugin_dir_url( __FILE__ ) );

require_once CBS_DIR . 'includes/class-cbs-settings.php';
require_once CBS_DIR . 'includes/class-cbs-parser.php';
require_once CBS_DIR . 'includes/class-cbs-store.php';
require_once CBS_DIR . 'includes/class-cbs-renderer.php';
require_once CBS_DIR . 'includes/class-cbs-admin.php';

add_action(
	'plugins_loaded',
	static function () {
		CBS_Renderer::init();
		if ( is_admin() ) {
			CBS_Admin::init();
		}
	}
);

register_activation_hook(
	__FILE__,
	static function () {
		if ( false === get_option( CBS_Settings::OPTION, false ) ) {
			add_option( CBS_Settings::OPTION, CBS_Settings::defaults() );
		}
	}
);
