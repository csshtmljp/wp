<?php
/**
 * Plugin Name:       VRM List
 * Description:       メディアライブラリのVRMファイルを一覧にし、その場で3Dプレビューできるようにします。ショートコード [vrm_list] と、管理画面の「メディア → VRM一覧」を追加します。
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            VRM List
 * License:           GPL-2.0-or-later
 * Text Domain:       vrm-list
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class VRM_List {

	const VERSION = '1.0.0';
	const MIME    = 'model/gltf-binary';

	private $page_hook = '';

	public static function init() {
		$self = new self();
		add_filter( 'upload_mimes', array( $self, 'allow_mime' ) );
		add_filter( 'wp_check_filetype_and_ext', array( $self, 'check_filetype' ), 10, 4 );
		add_action( 'init', array( $self, 'register_assets' ) );
		add_shortcode( 'vrm_list', array( $self, 'shortcode' ) );
		add_action( 'admin_menu', array( $self, 'add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $self, 'admin_assets' ) );
	}

	/* ------------------------------------------------------------------
	 * .vrm のアップロードを許可
	 * ---------------------------------------------------------------- */

	public function allow_mime( $mimes ) {
		$mimes['vrm'] = self::MIME;
		return $mimes;
	}

	/**
	 * VRMはバイナリglTFのため、WordPressの中身チェックでは種類を判定できない。
	 * 拡張子が .vrm で、先頭が glTF の識別子になっているものだけを通す。
	 */
	public function check_filetype( $data, $file, $filename, $mimes ) {
		if ( 'vrm' !== strtolower( pathinfo( (string) $filename, PATHINFO_EXTENSION ) ) ) {
			return $data;
		}
		$ok = false;
		if ( is_readable( $file ) ) {
			$handle = fopen( $file, 'rb' );
			if ( $handle ) {
				$ok = ( 'glTF' === fread( $handle, 4 ) );
				fclose( $handle );
			}
		}
		if ( $ok ) {
			$data['ext']  = 'vrm';
			$data['type'] = self::MIME;
		} else {
			$data['ext']  = false;
			$data['type'] = false;
		}
		return $data;
	}

	/* ------------------------------------------------------------------
	 * 表示
	 * ---------------------------------------------------------------- */

	public function register_assets() {
		wp_register_style( 'vrm-list', plugins_url( 'assets/vrm-list.css', __FILE__ ), array(), self::VERSION );
		wp_register_script( 'vrm-list', plugins_url( 'assets/vrm-viewer.js', __FILE__ ), array(), self::VERSION, true );
	}

	/** VRMファイルの添付を取得する */
	private function get_items( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'ids'     => array(),
				'limit'   => 50,
				'orderby' => 'date',
				'order'   => 'DESC',
			)
		);

		$query = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => max( 1, min( 200, (int) $args['limit'] ) ),
			'orderby'        => in_array( $args['orderby'], array( 'date', 'title', 'modified' ), true ) ? $args['orderby'] : 'date',
			'order'          => 'ASC' === strtoupper( $args['order'] ) ? 'ASC' : 'DESC',
			'no_found_rows'  => true,
			'meta_query'     => array(
				array(
					'key'     => '_wp_attached_file',
					'value'   => '.vrm',
					'compare' => 'LIKE',
				),
			),
		);
		if ( $args['ids'] ) {
			$query['post__in'] = array_map( 'absint', $args['ids'] );
			$query['orderby']  = 'post__in';
		}

		$items = array();
		foreach ( get_posts( $query ) as $post ) {
			$path = get_attached_file( $post->ID );
			$url  = wp_get_attachment_url( $post->ID );
			if ( ! $url || 'vrm' !== strtolower( pathinfo( (string) $path, PATHINFO_EXTENSION ) ) ) {
				continue;
			}
			$size    = ( $path && file_exists( $path ) ) ? filesize( $path ) : 0;
			$items[] = array(
				'id'    => $post->ID,
				'title' => '' !== $post->post_title ? $post->post_title : wp_basename( $path ),
				'url'   => $url,
				'file'  => wp_basename( $path ),
				'size'  => $size ? size_format( $size, 1 ) : '',
				'date'  => get_the_date( '', $post ),
			);
		}
		return $items;
	}

	/** 一覧とプレビューのHTML */
	private function render( $items, $opts = array() ) {
		$opts = wp_parse_args(
			$opts,
			array(
				'download'   => true,
				'height'     => 480,
				'autorotate' => true,
				'local'      => false,
			)
		);
		$height = max( 240, min( 1200, (int) $opts['height'] ) );

		ob_start();
		?>
		<div class="vrml-app" style="--vrml-height:<?php echo (int) $height; ?>px" data-autorotate="<?php echo $opts['autorotate'] ? '1' : '0'; ?>">
			<div class="vrml-stage">
				<canvas class="vrml-canvas" aria-label="VRMの3Dプレビュー。ドラッグで回転、ホイールやピンチで拡大縮小できます。"></canvas>
				<div class="vrml-meta" hidden></div>
				<div class="vrml-status" role="status" hidden></div>
				<div class="vrml-tools">
					<button type="button" data-vrml-act="rotate">自動回転</button>
					<button type="button" data-vrml-act="reset">視点を戻す</button>
				</div>
			</div>
			<div class="vrml-side">
				<?php if ( $opts['local'] ) : ?>
					<div class="vrml-localbox">
						<label for="vrml-local-file">アップロード前にプレビュー</label>
						<input type="file" id="vrml-local-file" class="vrml-local" accept=".vrm">
						<p>選んだファイルはこの画面で表示するだけで、サーバーには送信されません。</p>
					</div>
				<?php endif; ?>
				<?php if ( $items ) : ?>
					<p class="vrml-count"><?php echo (int) count( $items ); ?> 件のVRMファイル</p>
					<ul class="vrml-list">
						<?php foreach ( $items as $item ) : ?>
							<li>
								<button type="button" class="vrml-item" aria-pressed="false" data-url="<?php echo esc_url( $item['url'] ); ?>" data-title="<?php echo esc_attr( $item['title'] ); ?>">
									<span class="vrml-item-title"><?php echo esc_html( $item['title'] ); ?></span>
									<span class="vrml-item-sub"><?php echo esc_html( trim( $item['size'] . ' ・ ' . $item['date'], ' ・' ) ); ?></span>
								</button>
								<?php if ( $opts['download'] ) : ?>
									<a class="vrml-dl" href="<?php echo esc_url( $item['url'] ); ?>" download="<?php echo esc_attr( $item['file'] ); ?>" aria-label="<?php echo esc_attr( $item['title'] ); ?> をダウンロード">保存</a>
								<?php endif; ?>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<p class="vrml-empty">VRMファイルがまだありません。</p>
				<?php endif; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * [vrm_list] ショートコード
	 *
	 * ids="12,34"      表示する添付IDを指定(省略時はすべて)
	 * limit="50"       最大件数(上限200)
	 * orderby="date"   date / title / modified
	 * order="DESC"     DESC / ASC
	 * download="1"     保存リンクの表示(0で非表示)
	 * height="480"     プレビューの高さ(px)
	 * autorotate="1"   自動回転の初期状態(0でオフ)
	 */
	public function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'ids'        => '',
				'limit'      => 50,
				'orderby'    => 'date',
				'order'      => 'DESC',
				'download'   => '1',
				'height'     => 480,
				'autorotate' => '1',
			),
			$atts,
			'vrm_list'
		);

		$items = $this->get_items(
			array(
				'ids'     => array_filter( array_map( 'absint', explode( ',', (string) $atts['ids'] ) ) ),
				'limit'   => $atts['limit'],
				'orderby' => $atts['orderby'],
				'order'   => $atts['order'],
			)
		);

		wp_enqueue_style( 'vrm-list' );
		wp_enqueue_script( 'vrm-list' );

		return $this->render(
			$items,
			array(
				'download'   => '0' !== (string) $atts['download'],
				'height'     => $atts['height'],
				'autorotate' => '0' !== (string) $atts['autorotate'],
			)
		);
	}

	/* ------------------------------------------------------------------
	 * 管理画面
	 * ---------------------------------------------------------------- */

	public function add_menu() {
		$this->page_hook = add_media_page(
			'VRM一覧',
			'VRM一覧',
			'upload_files',
			'vrm-list',
			array( $this, 'render_admin_page' )
		);
	}

	public function admin_assets( $hook ) {
		if ( $hook !== $this->page_hook ) {
			return;
		}
		wp_enqueue_style( 'vrm-list' );
		wp_enqueue_script( 'vrm-list' );
	}

	public function render_admin_page() {
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}
		$items = $this->get_items( array( 'limit' => 200 ) );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline">VRM一覧</h1>
			<a href="<?php echo esc_url( admin_url( 'media-new.php' ) ); ?>" class="page-title-action">VRMをアップロード</a>
			<hr class="wp-header-end">
			<p>一覧のファイルを選ぶと、左のプレビューに表示されます。ドラッグで回転、ホイールやピンチで拡大縮小できます。</p>

			<?php
			// 出力は render() 内でエスケープ済み。
			echo $this->render( $items, array( 'local' => true ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			?>

			<h2>サイトに表示する</h2>
			<p>投稿や固定ページに次のショートコードを入れると、同じ一覧とプレビューが表示されます。</p>
			<p><code>[vrm_list]</code></p>
			<table class="widefat striped" style="max-width:720px">
				<thead><tr><th>指定</th><th>内容</th></tr></thead>
				<tbody>
					<tr><td><code>ids="12,34"</code></td><td>表示するファイルを添付IDで指定します。省略するとすべて表示します。</td></tr>
					<tr><td><code>limit="50"</code></td><td>最大件数です。上限は200です。</td></tr>
					<tr><td><code>orderby="title"</code></td><td>並び順です。date(日付)、title(名前)、modified(更新日)。</td></tr>
					<tr><td><code>order="ASC"</code></td><td>昇順にします。省略時は降順です。</td></tr>
					<tr><td><code>download="0"</code></td><td>保存リンクを隠します。</td></tr>
					<tr><td><code>height="600"</code></td><td>プレビューの高さ(px)です。</td></tr>
					<tr><td><code>autorotate="0"</code></td><td>自動回転を最初からオフにします。</td></tr>
				</tbody>
			</table>

			<?php if ( $items ) : ?>
				<h2>添付ID</h2>
				<table class="widefat striped" style="max-width:720px">
					<thead><tr><th>ID</th><th>名前</th><th>ファイル</th><th>サイズ</th></tr></thead>
					<tbody>
						<?php foreach ( $items as $item ) : ?>
							<tr>
								<td><?php echo (int) $item['id']; ?></td>
								<td><a href="<?php echo esc_url( get_edit_post_link( $item['id'], 'raw' ) ); ?>"><?php echo esc_html( $item['title'] ); ?></a></td>
								<td><?php echo esc_html( $item['file'] ); ?></td>
								<td><?php echo esc_html( $item['size'] ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}
}

VRM_List::init();
