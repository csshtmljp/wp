<?php
/**
 * Plugin Name: GitHub Repos Shortcode
 * Description: ショートコード [github_repos user="アカウント名"] で、GitHubアカウントの全公開リポジトリを一覧表示します。
 * Version:     1.0.0
 * Author:      Custom
 * License:     GPL-2.0-or-later
 * Text Domain: github-repos-shortcode
 * Requires PHP: 7.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GRS_GitHub_Repos_Shortcode {

	const OPTION    = 'grs_options';
	const CACHE_VER = 'grs_cache_ver';
	const MAX_PAGES = 10; // 100件 x 10ページ = 最大1000リポジトリ

	public function __construct() {
		add_shortcode( 'github_repos', array( $this, 'render_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_style' ) );
		add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_post_grs_clear_cache', array( $this, 'handle_clear_cache' ) );
	}

	/* ---------------------------------------------------------------------
	 * 設定値
	 * ------------------------------------------------------------------- */

	private function options() {
		$defaults = array(
			'user'      => '',
			'token'     => '',
			'cache_min' => 60,
		);
		return wp_parse_args( (array) get_option( self::OPTION, array() ), $defaults );
	}

	/* ---------------------------------------------------------------------
	 * ショートコード
	 * ------------------------------------------------------------------- */

	public function render_shortcode( $atts ) {
		$opt  = $this->options();
		$atts = shortcode_atts(
			array(
				'user'             => $opt['user'],
				'type'             => 'user',    // user | org
				'sort'             => 'updated', // updated | pushed | created | name | stars
				'order'            => '',        // asc | desc（空なら sort に応じて自動）
				'limit'            => 0,         // 0 = 全件
				'columns'          => 2,         // 1〜4
				'exclude_forks'    => 'no',
				'exclude_archived' => 'no',
				'exclude'          => '',        // 除外するリポジトリ名（カンマ区切り）
				'language'         => '',        // 指定言語のみ表示
				'show_description' => 'yes',
				'show_language'    => 'yes',
				'show_stars'       => 'yes',
				'show_forks'       => 'yes',
				'show_updated'     => 'yes',
				'show_topics'      => 'no',
				'show_header'      => 'yes',
				'new_tab'          => 'yes',
			),
			$atts,
			'github_repos'
		);

		$user = trim( (string) $atts['user'] );
		if ( '' === $user ) {
			return $this->error_html( 'GitHubのアカウント名が指定されていません。[github_repos user="アカウント名"] のように指定するか、設定画面で既定のアカウントを登録してください。' );
		}
		if ( ! preg_match( '/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/', $user ) ) {
			return $this->error_html( 'GitHubのアカウント名の形式が正しくありません。' );
		}

		$type  = ( 'org' === strtolower( $atts['type'] ) ) ? 'org' : 'user';
		$repos = $this->get_repos( $user, $type );

		if ( is_wp_error( $repos ) ) {
			return $this->error_html( $repos->get_error_message() );
		}

		// ---- 絞り込み ----
		$exclude_names = array_filter( array_map( 'strtolower', array_map( 'trim', explode( ',', (string) $atts['exclude'] ) ) ) );
		$language      = strtolower( trim( (string) $atts['language'] ) );
		$no_forks      = $this->is_yes( $atts['exclude_forks'] );
		$no_archived   = $this->is_yes( $atts['exclude_archived'] );

		$repos = array_filter(
			$repos,
			function ( $r ) use ( $exclude_names, $language, $no_forks, $no_archived ) {
				if ( $no_forks && $r['fork'] ) {
					return false;
				}
				if ( $no_archived && $r['archived'] ) {
					return false;
				}
				if ( $exclude_names && in_array( strtolower( $r['name'] ), $exclude_names, true ) ) {
					return false;
				}
				if ( '' !== $language && strtolower( (string) $r['language'] ) !== $language ) {
					return false;
				}
				return true;
			}
		);

		// ---- 並び替え ----
		$sort_map = array(
			'updated' => 'updated_at',
			'pushed'  => 'pushed_at',
			'created' => 'created_at',
			'name'    => 'name',
			'stars'   => 'stars',
		);
		$sort  = strtolower( (string) $atts['sort'] );
		$field = isset( $sort_map[ $sort ] ) ? $sort_map[ $sort ] : 'updated_at';
		$order = strtolower( (string) $atts['order'] );
		if ( 'asc' !== $order && 'desc' !== $order ) {
			$order = ( 'name' === $field ) ? 'asc' : 'desc';
		}

		usort(
			$repos,
			function ( $a, $b ) use ( $field, $order ) {
				if ( 'stars' === $field ) {
					$cmp = $a['stars'] <=> $b['stars'];
				} else {
					$cmp = strcasecmp( (string) $a[ $field ], (string) $b[ $field ] );
				}
				return ( 'asc' === $order ) ? $cmp : -$cmp;
			}
		);

		$total = count( $repos );
		$limit = absint( $atts['limit'] );
		if ( $limit > 0 ) {
			$repos = array_slice( $repos, 0, $limit );
		}

		if ( empty( $repos ) ) {
			return '<p class="grs-empty">表示できるリポジトリがありません。</p>';
		}

		wp_enqueue_style( 'grs-style' );

		// ---- 出力 ----
		$columns = min( 4, max( 1, absint( $atts['columns'] ) ) );
		$target  = $this->is_yes( $atts['new_tab'] ) ? ' target="_blank" rel="noopener noreferrer"' : '';

		$html = '<div class="grs-wrap">';

		if ( $this->is_yes( $atts['show_header'] ) ) {
			$html .= sprintf(
				'<p class="grs-header"><a href="%1$s"%2$s>@%3$s</a> のリポジトリ（%4$s件）</p>',
				esc_url( 'https://github.com/' . $user ),
				$target,
				esc_html( $user ),
				esc_html( number_format_i18n( $total ) )
			);
		}

		$html .= sprintf( '<ul class="grs-list grs-cols-%d">', $columns );

		foreach ( $repos as $r ) {
			$html .= '<li class="grs-item">';
			$html .= sprintf(
				'<h3 class="grs-name"><a href="%1$s"%2$s>%3$s</a>',
				esc_url( $r['url'] ),
				$target,
				esc_html( $r['name'] )
			);
			if ( $r['fork'] ) {
				$html .= ' <span class="grs-badge">Fork</span>';
			}
			if ( $r['archived'] ) {
				$html .= ' <span class="grs-badge">Archived</span>';
			}
			$html .= '</h3>';

			if ( $this->is_yes( $atts['show_description'] ) && '' !== (string) $r['description'] ) {
				$html .= '<p class="grs-desc">' . esc_html( $r['description'] ) . '</p>';
			}

			if ( $this->is_yes( $atts['show_topics'] ) && ! empty( $r['topics'] ) ) {
				$html .= '<p class="grs-topics">';
				foreach ( $r['topics'] as $topic ) {
					$html .= '<span class="grs-topic">' . esc_html( $topic ) . '</span>';
				}
				$html .= '</p>';
			}

			$meta = array();
			if ( $this->is_yes( $atts['show_language'] ) && '' !== (string) $r['language'] ) {
				$meta[] = '<span class="grs-lang">' . esc_html( $r['language'] ) . '</span>';
			}
			if ( $this->is_yes( $atts['show_stars'] ) ) {
				$meta[] = '<span class="grs-stars" title="Stars">★ ' . esc_html( number_format_i18n( $r['stars'] ) ) . '</span>';
			}
			if ( $this->is_yes( $atts['show_forks'] ) ) {
				$meta[] = '<span class="grs-forks" title="Forks">⑂ ' . esc_html( number_format_i18n( $r['forks'] ) ) . '</span>';
			}
			if ( $this->is_yes( $atts['show_updated'] ) && '' !== (string) $r['updated_at'] ) {
				$ts = strtotime( $r['updated_at'] );
				if ( $ts ) {
					$meta[] = '<span class="grs-updated">更新: ' . esc_html( date_i18n( get_option( 'date_format' ), $ts ) ) . '</span>';
				}
			}
			if ( $meta ) {
				$html .= '<p class="grs-meta">' . implode( '', $meta ) . '</p>';
			}

			$html .= '</li>';
		}

		$html .= '</ul></div>';

		return $html;
	}

	private function is_yes( $value ) {
		return in_array( strtolower( trim( (string) $value ) ), array( 'yes', 'true', '1', 'on' ), true );
	}

	/** エラーは管理者にのみ詳細表示し、一般訪問者には何も出さない */
	private function error_html( $message ) {
		if ( current_user_can( 'manage_options' ) ) {
			return '<p class="grs-error" style="color:#b32d2e;">[GitHub Repos] ' . esc_html( $message ) . '</p>';
		}
		return '';
	}

	/* ---------------------------------------------------------------------
	 * GitHub API
	 * ------------------------------------------------------------------- */

	private function cache_key( $user, $type ) {
		$ver = (int) get_option( self::CACHE_VER, 1 );
		return 'grs_' . md5( strtolower( $user ) . '|' . $type . '|' . $ver );
	}

	/**
	 * 全リポジトリを取得（ページネーション対応・Transientキャッシュ）
	 *
	 * @return array|WP_Error
	 */
	private function get_repos( $user, $type ) {
		$key    = $this->cache_key( $user, $type );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$opt     = $this->options();
		$headers = array(
			'Accept'               => 'application/vnd.github+json',
			'X-GitHub-Api-Version' => '2022-11-28',
			'User-Agent'           => 'WordPress-GitHub-Repos-Shortcode',
		);
		if ( '' !== trim( (string) $opt['token'] ) ) {
			$headers['Authorization'] = 'Bearer ' . trim( $opt['token'] );
		}

		$base  = ( 'org' === $type ) ? 'https://api.github.com/orgs/' : 'https://api.github.com/users/';
		$repos = array();

		for ( $page = 1; $page <= self::MAX_PAGES; $page++ ) {
			$url = add_query_arg(
				array(
					'per_page' => 100,
					'page'     => $page,
					'type'     => ( 'org' === $type ) ? 'public' : 'owner',
				),
				$base . rawurlencode( $user ) . '/repos'
			);

			$response = wp_remote_get(
				$url,
				array(
					'headers' => $headers,
					'timeout' => 15,
				)
			);

			if ( is_wp_error( $response ) ) {
				return new WP_Error( 'grs_http', 'GitHubへの接続に失敗しました: ' . $response->get_error_message() );
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			$body = json_decode( wp_remote_retrieve_body( $response ), true );

			if ( 404 === $code ) {
				return new WP_Error( 'grs_404', 'アカウント「' . $user . '」が見つかりません。組織アカウントの場合は type="org" を指定してください。' );
			}
			if ( 401 === $code ) {
				return new WP_Error( 'grs_401', 'GitHubトークンが無効です。設定画面のトークンを確認してください。' );
			}
			if ( 403 === $code || 429 === $code ) {
				return new WP_Error( 'grs_rate', 'GitHub APIの利用回数制限に達しました。しばらく待つか、設定画面でアクセストークンを登録してください。' );
			}
			if ( 200 !== $code || ! is_array( $body ) ) {
				return new WP_Error( 'grs_api', 'GitHub APIからエラーが返されました（HTTP ' . $code . '）。' );
			}

			foreach ( $body as $r ) {
				if ( ! is_array( $r ) || empty( $r['name'] ) || ! empty( $r['private'] ) ) {
					continue; // 非公開リポジトリは表示しない
				}
				$repos[] = array(
					'name'        => (string) $r['name'],
					'url'         => isset( $r['html_url'] ) ? (string) $r['html_url'] : '',
					'description' => isset( $r['description'] ) ? (string) $r['description'] : '',
					'language'    => isset( $r['language'] ) ? (string) $r['language'] : '',
					'stars'       => isset( $r['stargazers_count'] ) ? (int) $r['stargazers_count'] : 0,
					'forks'       => isset( $r['forks_count'] ) ? (int) $r['forks_count'] : 0,
					'fork'        => ! empty( $r['fork'] ),
					'archived'    => ! empty( $r['archived'] ),
					'topics'      => ( isset( $r['topics'] ) && is_array( $r['topics'] ) ) ? array_map( 'strval', $r['topics'] ) : array(),
					'updated_at'  => isset( $r['updated_at'] ) ? (string) $r['updated_at'] : '',
					'pushed_at'   => isset( $r['pushed_at'] ) ? (string) $r['pushed_at'] : '',
					'created_at'  => isset( $r['created_at'] ) ? (string) $r['created_at'] : '',
				);
			}

			if ( count( $body ) < 100 ) {
				break; // 最終ページ
			}
		}

		$minutes = max( 1, absint( $opt['cache_min'] ) );
		set_transient( $key, $repos, $minutes * MINUTE_IN_SECONDS );

		return $repos;
	}

	/* ---------------------------------------------------------------------
	 * スタイル
	 * ------------------------------------------------------------------- */

	public function register_style() {
		wp_register_style( 'grs-style', false, array(), '1.0.0' );
		wp_add_inline_style( 'grs-style', $this->css() );
	}

	private function css() {
		return '
.grs-wrap{margin:1.5em 0}
.grs-header{margin:0 0 .8em;font-weight:600}
.grs-list{list-style:none;margin:0;padding:0;display:grid;gap:14px;grid-template-columns:1fr}
.grs-item{margin:0;padding:14px 16px;border:1px solid rgba(128,128,128,.35);border-radius:8px;display:flex;flex-direction:column;gap:6px;min-width:0}
.grs-name{margin:0;font-size:1.05em;line-height:1.4;word-break:break-word}
.grs-name a{text-decoration:none}
.grs-name a:hover{text-decoration:underline}
.grs-badge{display:inline-block;font-size:.7em;font-weight:400;padding:1px 7px;border:1px solid rgba(128,128,128,.5);border-radius:999px;vertical-align:middle;opacity:.8}
.grs-desc{margin:0;font-size:.9em;line-height:1.6;opacity:.85;word-break:break-word}
.grs-topics{margin:0;display:flex;flex-wrap:wrap;gap:5px}
.grs-topic{font-size:.75em;padding:1px 8px;border-radius:999px;background:rgba(9,105,218,.12)}
.grs-meta{margin:auto 0 0;padding-top:4px;font-size:.8em;opacity:.75;display:flex;flex-wrap:wrap;gap:4px 14px}
.grs-lang::before{content:"";display:inline-block;width:.7em;height:.7em;border-radius:50%;background:currentColor;margin-right:.35em;opacity:.6}
@media(min-width:600px){
.grs-cols-2,.grs-cols-3,.grs-cols-4{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(min-width:900px){
.grs-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))}
.grs-cols-4{grid-template-columns:repeat(4,minmax(0,1fr))}
}';
	}

	/* ---------------------------------------------------------------------
	 * 管理画面
	 * ------------------------------------------------------------------- */

	public function add_settings_page() {
		add_options_page(
			'GitHub Repos Shortcode',
			'GitHub Repos',
			'manage_options',
			'grs-settings',
			array( $this, 'render_settings_page' )
		);
	}

	public function register_settings() {
		register_setting(
			'grs_settings_group',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize_options' ),
			)
		);
	}

	public function sanitize_options( $input ) {
		$input = (array) $input;
		$old   = $this->options();
		$out   = array();

		$user        = isset( $input['user'] ) ? sanitize_text_field( $input['user'] ) : '';
		$out['user'] = preg_match( '/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/', $user ) ? $user : '';

		$out['token']     = isset( $input['token'] ) ? sanitize_text_field( $input['token'] ) : '';
		$out['cache_min'] = isset( $input['cache_min'] ) ? max( 1, absint( $input['cache_min'] ) ) : 60;

		// トークンが変わったらキャッシュを無効化
		if ( $out['token'] !== $old['token'] ) {
			update_option( self::CACHE_VER, (int) get_option( self::CACHE_VER, 1 ) + 1 );
		}

		return $out;
	}

	public function handle_clear_cache() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '権限がありません。' );
		}
		check_admin_referer( 'grs_clear_cache' );
		update_option( self::CACHE_VER, (int) get_option( self::CACHE_VER, 1 ) + 1 );
		wp_safe_redirect( add_query_arg( array( 'page' => 'grs-settings', 'grs_cleared' => 1 ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$opt = $this->options();
		?>
		<div class="wrap">
			<h1>GitHub Repos Shortcode</h1>

			<?php if ( isset( $_GET['grs_cleared'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="notice notice-success is-dismissible"><p>キャッシュを削除しました。</p></div>
			<?php endif; ?>

			<form method="post" action="options.php">
				<?php settings_fields( 'grs_settings_group' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="grs_user">既定のGitHubアカウント</label></th>
						<td>
							<input type="text" id="grs_user" class="regular-text" name="<?php echo esc_attr( self::OPTION ); ?>[user]" value="<?php echo esc_attr( $opt['user'] ); ?>" placeholder="octocat">
							<p class="description">ショートコードで user を省略したときに使われます。</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="grs_token">アクセストークン（任意）</label></th>
						<td>
							<input type="password" id="grs_token" class="regular-text" name="<?php echo esc_attr( self::OPTION ); ?>[token]" value="<?php echo esc_attr( $opt['token'] ); ?>" autocomplete="off">
							<p class="description">未設定でも動作します。登録するとAPIの回数制限が緩和されます。権限（スコープ）なしのトークンで十分です。</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="grs_cache">キャッシュ時間（分）</label></th>
						<td>
							<input type="number" id="grs_cache" class="small-text" min="1" name="<?php echo esc_attr( self::OPTION ); ?>[cache_min]" value="<?php echo esc_attr( $opt['cache_min'] ); ?>">
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="grs_clear_cache">
				<?php wp_nonce_field( 'grs_clear_cache' ); ?>
				<?php submit_button( 'キャッシュを今すぐ削除', 'secondary', 'submit', false ); ?>
			</form>

			<h2>使い方</h2>
			<p><code>[github_repos user="octocat"]</code></p>
			<table class="widefat striped" style="max-width:900px">
				<thead><tr><th>属性</th><th>既定値</th><th>説明</th></tr></thead>
				<tbody>
					<tr><td><code>user</code></td><td>設定値</td><td>GitHubアカウント名</td></tr>
					<tr><td><code>type</code></td><td>user</td><td>組織アカウントは <code>org</code></td></tr>
					<tr><td><code>sort</code></td><td>updated</td><td>updated / pushed / created / name / stars</td></tr>
					<tr><td><code>order</code></td><td>自動</td><td>asc / desc</td></tr>
					<tr><td><code>limit</code></td><td>0</td><td>表示件数（0で全件）</td></tr>
					<tr><td><code>columns</code></td><td>2</td><td>列数（1〜4）</td></tr>
					<tr><td><code>exclude_forks</code></td><td>no</td><td>yes でフォークを除外</td></tr>
					<tr><td><code>exclude_archived</code></td><td>no</td><td>yes でアーカイブ済みを除外</td></tr>
					<tr><td><code>exclude</code></td><td></td><td>除外するリポジトリ名（カンマ区切り）</td></tr>
					<tr><td><code>language</code></td><td></td><td>指定した言語のみ表示（例: PHP）</td></tr>
					<tr><td><code>show_description</code> / <code>show_language</code> / <code>show_stars</code> / <code>show_forks</code> / <code>show_updated</code> / <code>show_header</code></td><td>yes</td><td>no で各項目を非表示</td></tr>
					<tr><td><code>show_topics</code></td><td>no</td><td>yes でトピックを表示</td></tr>
					<tr><td><code>new_tab</code></td><td>yes</td><td>no で同じタブで開く</td></tr>
				</tbody>
			</table>
		</div>
		<?php
	}
}

new GRS_GitHub_Repos_Shortcode();
