<?php
if (!defined('ABSPATH')) { exit; }

final class AccessDN_Admin {
    public static function boot() {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('admin_post_accessdn_settings', array(__CLASS__, 'save'));
        add_action('admin_post_accessdn_export', array(__CLASS__, 'export'));
        add_action('admin_post_accessdn_reset', array(__CLASS__, 'reset'));
        add_action('wp_ajax_accessdn_live', array(__CLASS__, 'live'));
        add_action('wp_dashboard_setup', array(__CLASS__, 'widget_setup'));
        add_filter('plugin_action_links_' . plugin_basename(ACCESSDN_FILE), array(__CLASS__, 'links'));
    }
    private static function guard() { if (!current_user_can('manage_options')) { wp_die('この操作には管理者権限が必要です。', '', array('response'=>403)); } }
    public static function menu() { add_menu_page('AccessDN アクセス解析','AccessDN','manage_options','accessdn',array(__CLASS__,'page'),'dashicons-chart-area',81); }
    public static function links($links) { array_unshift($links,'<a href="'.esc_url(admin_url('admin.php?page=accessdn')).'">アクセス解析</a>'); return $links; }
    public static function assets($hook) {
        if ($hook !== 'toplevel_page_accessdn') { return; }
        wp_enqueue_style('accessdn-admin',plugins_url('assets/admin.css',ACCESSDN_FILE),array(),ACCESSDN_VERSION);
        wp_enqueue_script('accessdn-admin',plugins_url('assets/admin.js',ACCESSDN_FILE),array(),ACCESSDN_VERSION,true);
        wp_add_inline_script('accessdn-admin','window.AccessDNAdmin='.wp_json_encode(array('endpoint'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('accessdn_live'))).';','before');
    }
    public static function live() { self::guard(); check_ajax_referer('accessdn_live','nonce'); nocache_headers(); wp_send_json_success(AccessDN::realtime()); }
    private static function form($action) {
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        echo '<input type="hidden" name="action" value="'.esc_attr($action).'">'; wp_nonce_field($action);
    }
    private static function redirect($notice) { wp_safe_redirect(admin_url('admin.php?page=accessdn&tab=settings&notice='.$notice)); exit; }
    public static function sanitize($raw) {
        $s=AccessDN::defaults();
        foreach(array('enabled','exclude_logged_in','exclude_bots','respect_dnt','consent','delete_on_uninstall') as $key) { $s[$key]=!empty($raw[$key]) ? 1 : 0; }
        $s['retention']=max(7,min(365,absint(is_scalar($raw['retention'] ?? null) ? $raw['retention'] : 90)));
        $lines=preg_split('/\r\n|\r|\n/',is_string($raw['exclude_paths'] ?? null) ? $raw['exclude_paths'] : ''); $paths=array();
        foreach(array_slice($lines,0,100) as $line) { $line=trim(sanitize_text_field($line)); if($line!=='' && substr($line,0,1)==='/') { $paths[]=substr($line,0,150); } }
        $s['exclude_paths']=implode("\n",array_unique($paths)); return $s;
    }
    public static function save() { self::guard(); check_admin_referer('accessdn_settings'); update_option('accessdn_settings',self::sanitize(wp_unslash($_POST)),false); self::redirect('saved'); }
    public static function reset() {
        self::guard(); check_admin_referer('accessdn_reset');
        if (!isset($_POST['confirm']) || !is_string($_POST['confirm']) || wp_unslash($_POST['confirm'])!=='DELETE') { self::redirect('confirm'); }
        global $wpdb; $result=$wpdb->query('DELETE FROM '.AccessDN::table());
        if ($result===false) { wp_die('削除できませんでした。データベースの状態を確認してください。'); }
        update_option('accessdn_secret',wp_generate_password(64,true,true),false); self::redirect('reset');
    }
    private static function query($key,$default='') { return isset($_GET[$key]) && is_string($_GET[$key]) ? sanitize_text_field(wp_unslash($_GET[$key])) : $default; }
    public static function csv_cell($value) {
        $value=(string)$value;
        // Neutralize formula evaluation, including whitespace-prefixed formulas.
        return preg_match('/^[\s\x00-\x1F]*[=+@-]/u',$value) || preg_match('/^[\t\r\n]/',$value) ? "'".$value : $value;
    }
    public static function export() {
        self::guard(); check_admin_referer('accessdn_export');
        list($from,$to)=AccessDN::range(self::query('from'),self::query('to'));
        $type=self::query('type','daily');
        if(!in_array($type,array('daily','pages','referrer','device','browser','os','hour','missing'),true)) { $type='daily'; }
        $report=AccessDN::report($from,$to,10000);
        nocache_headers(); header('Content-Type: text/csv; charset=UTF-8'); header('X-Content-Type-Options: nosniff');
        header('Content-Disposition: attachment; filename="accessdn-'.$type.'-'.$from.'-'.$to.'.csv"');
        $out=fopen('php://output','w'); fwrite($out,"\xEF\xBB\xBF");
        $has_uv=in_array($type,array('daily','pages'),true);
        $header=array('項目','PV'); if($has_uv) { $header[]='日別訪問者数（合計・推定）'; } if($type==='pages') { $header[]='タイトル'; }
        fputcsv($out,$header,',','"','');
        foreach($report[$type] as $row) {
            $values=array(self::csv_cell($row['label']),(int)$row['pv']); if($has_uv) { $values[]=(int)$row['uv']; } if($type==='pages') { $values[]=self::csv_cell($row['title']); }
            fputcsv($out,$values,',','"','');
        }
        fclose($out); exit;
    }
    public static function widget_setup() { if(current_user_can('manage_options')) { wp_add_dashboard_widget('accessdn_widget','AccessDN · アクセス概況',array(__CLASS__,'widget')); } }
    public static function widget() {
        self::guard(); $today=current_datetime()->format('Y-m-d'); $r=AccessDN::report($today,$today,5); $live=AccessDN::realtime();
        echo '<p>今日の閲覧数：<strong>'.esc_html(number_format_i18n($r['pv'])).' PV</strong>　訪問者：<strong>'.esc_html(number_format_i18n($r['uv'])).'</strong>（推定）</p><p>直近5分の閲覧数：'.esc_html(number_format_i18n($live['pv'])).' PV</p><p><a href="'.esc_url(admin_url('admin.php?page=accessdn')).'">詳しいアクセス解析を見る →</a></p>';
    }
    private static function card($label,$value,$note,$id='') {
        echo '<article class="adn-kpi"><span>'.esc_html($label).'</span><strong'.($id ? ' id="'.esc_attr($id).'"' : '').'>'.esc_html(number_format_i18n($value)).'</strong><small>'.esc_html($note).'</small></article>';
    }
    private static function table($title,$rows,$total=0,$uv=false) {
        echo '<section class="adn-panel"><h2>'.esc_html($title).'</h2>';
        if(!$rows) { echo '<p class="adn-empty">この期間の記録はまだありません。</p></section>'; return; }
        echo '<div class="adn-table-scroll"><table class="adn-table"><thead><tr><th scope="col">項目</th><th scope="col">PV</th>'.($uv ? '<th scope="col">日別訪問者の合計</th>' : '<th scope="col">割合</th>').'</tr></thead><tbody>';
        foreach($rows as $row) {
            $label=$row['label']; if($label==='(direct)') { $label='直接アクセス / 参照元不明'; } if($label==='(internal)') { $label='サイト内からの移動'; }
            $share=$total ? round(100*(int)$row['pv']/$total,1) : 0;
            echo '<tr><td>'; if(!empty($row['title'])) { echo '<b>'.esc_html($row['title']).'</b><br>'; }
            echo '<span class="adn-path">'.esc_html($label).'</span></td><td>'.esc_html(number_format_i18n($row['pv'])).'</td><td>'.esc_html($uv ? number_format_i18n($row['uv']) : $share.'%').'</td></tr>';
        }
        echo '</tbody></table></div></section>';
    }
    public static function page() {
        self::guard(); $s=AccessDN::settings(); $settings=self::query('tab')==='settings';
        echo '<div class="wrap adn-app"><header class="adn-header"><div><div class="adn-eyebrow">PRIVATE ANALYTICS · WORDPRESS</div><h1>Access<span>DN</span></h1><p>数字を、サイトの次の一歩に。</p></div><span class="adn-status">'.($s['enabled'] ? '● 計測オン' : '○ 計測停止中').'</span></header>';
        echo '<nav class="adn-nav" aria-label="AccessDN メニュー"><a '.(!$settings ? 'aria-current="page" ' : '').'href="'.esc_url(admin_url('admin.php?page=accessdn')).'">アクセス解析</a><a '.($settings ? 'aria-current="page" ' : '').'href="'.esc_url(admin_url('admin.php?page=accessdn&tab=settings')).'">計測設定・使い方</a><span>管理者専用</span></nav>';
        $notice=self::query('notice'); $notices=array('saved'=>'設定を保存しました。ページキャッシュ・CDNを使用している場合はキャッシュを削除してください。','reset'=>'計測データを削除しました。新しい記録は引き続き保存されます。','confirm'=>'データを削除するには確認欄に DELETE と入力してください。');
        if(isset($notices[$notice])) { echo '<div class="notice notice-info"><p>'.esc_html($notices[$notice]).'</p></div>'; }
        global $wpdb;
        if(get_option('accessdn_db_version')!==ACCESSDN_VERSION) { echo '<div class="notice notice-error"><p>計測テーブルを作成できていません。データベースの CREATE / ALTER 権限を確認してください。</p></div></div>'; return; }
        if($settings) { self::settings_page($s); } else { self::dashboard($s); }
        echo '<footer class="adn-footer">AccessDN 1.0.0 · サイト内保存 · 訪問者の画面への表示なし</footer></div>';
    }
    private static function dashboard($s) {
        list($from,$to)=AccessDN::range(self::query('from'),self::query('to')); $r=AccessDN::report($from,$to); $now=current_datetime(); $today=$now->format('Y-m-d');
        $today_report=AccessDN::report($today,$today,1); $yesterday=$now->modify('-1 day')->format('Y-m-d'); $yesterday_report=AccessDN::report($yesterday,$yesterday,1); $live=AccessDN::realtime();
        echo '<div class="adn-toolbar"><div><h2>アクセスの概要</h2><p>'.esc_html($from.' → '.$to).' <span>／ '.esc_html(wp_timezone_string()).'</span></p></div><form method="get"><input type="hidden" name="page" value="accessdn"><label>開始日 <input type="date" name="from" value="'.esc_attr($from).'" required></label><label>終了日 <input type="date" name="to" value="'.esc_attr($to).'" required></label><button class="button button-primary">適用</button></form></div>';
        echo '<div class="adn-quick">'; foreach(array(1=>'今日',7=>'7日間',30=>'30日間',90=>'90日間') as $days=>$label) { echo '<a href="'.esc_url(add_query_arg(array('page'=>'accessdn','from'=>$now->modify('-'.($days-1).' days')->format('Y-m-d'),'to'=>$today),admin_url('admin.php'))).'">'.esc_html($label).'</a>'; } echo '</div>';
        if(!$s['enabled']) { echo '<p class="adn-note">計測を停止しています。保存済みデータは閲覧できます。</p>'; }
        if($s['consent']) { echo '<p class="adn-note">同意連携モード：同意通知を受け取った訪問だけを計測します。</p>'; }
        echo '<div class="adn-kpis">';
        self::card('選択期間の閲覧数',$r['pv'],'PV / ページが表示された回数');
        self::card('日別訪問者数の合計',$r['uv'],'推定値 / 日をまたぐ重複を含みます');
        self::card('今日の閲覧数',$today_report['pv'],'昨日 '.number_format_i18n($yesterday_report['pv']).' PV');
        self::card('直近5分の閲覧数',$live['pv'],'30秒ごとに自動更新','adn-live-pv');
        echo '</div><p class="adn-live-text">直近5分の推定訪問者：<b id="adn-live-visitors">'.esc_html($live['visitors']).'</b>　<span id="adn-live-status" role="status">最新</span> <button type="button" class="button" id="adn-refresh">今すぐ更新</button></p>';
        echo '<section class="adn-panel"><div class="adn-section-head"><h2>日別のアクセス推移</h2><span>■ PV　<span class="adn-muted">薄色：訪問者数（推定）</span></span></div>';
        if(!$r['pv']) { echo '<div class="adn-welcome"><strong>最初のアクセスを待っています。</strong><p>ログアウトしたブラウザーで公開ページを開くと記録されます。<br>管理者の閲覧は常に集計から除外します。</p></div>'; }
        $max=max(1,max(array_column($r['daily'],'pv')));
        echo '<div class="adn-chart" role="img" aria-label="日別PVと推定訪問者数。数値一覧は直後の表から確認できます。">';
        foreach($r['daily'] as $row) { $pv=(int)$row['pv']; $uv=(int)$row['uv']; echo '<div class="adn-day" title="'.esc_attr($row['label'].'：'.$pv.' PV / '.$uv.' 訪問者').'" style="--pv:'.esc_attr(round(100*$pv/$max,2)).'%;--uv:'.esc_attr(round(100*$uv/$max,2)).'%"><div class="adn-columns"><i></i><i></i></div><span>'.esc_html(substr($row['label'],5)).'</span></div>'; }
        echo '</div><details class="adn-details"><summary>日別の数値一覧を表示</summary><div class="adn-table-scroll"><table class="adn-table"><thead><tr><th scope="col">日付</th><th scope="col">PV</th><th scope="col">訪問者数（推定）</th></tr></thead><tbody>';
        foreach($r['daily'] as $row) { echo '<tr><td>'.esc_html($row['label']).'</td><td>'.esc_html($row['pv']).'</td><td>'.esc_html($row['uv']).'</td></tr>'; }
        echo '</tbody></table></div></details></section><div class="adn-grid">';
        self::table('人気ページ · 上位20',$r['pages'],$r['pv'],true);
        self::table('参照元 · 上位20',$r['referrer'],$r['pv']);
        self::table('端末',$r['device'],$r['pv']);
        self::table('ブラウザー',$r['browser'],$r['pv']);
        self::table('OS',$r['os'],$r['pv']);
        self::table('404 ページ · 上位20',$r['missing'],$r['pv']); echo '</div>';
        // Hour distribution always displays all 24 hours, including zeroes.
        $hours=array_fill(0,24,0); foreach($r['hour'] as $hour) { $hours[(int)$hour['label']]=(int)$hour['pv']; }
        // Fetch all hours separately: default table limit is 20.
        global $wpdb; $hour_rows=$wpdb->get_results($wpdb->prepare('SELECT hour,COUNT(*) AS pv FROM '.AccessDN::table().' WHERE day BETWEEN %s AND %s GROUP BY hour',$from,$to),ARRAY_A);
        foreach($hour_rows as $hour) { $hours[(int)$hour['hour']]=(int)$hour['pv']; }
        echo '<section class="adn-panel"><h2>時間帯別の閲覧数</h2><div class="adn-hours">'; $hm=max(1,max($hours));
        foreach($hours as $hour=>$pv) { echo '<div title="'.esc_attr($hour.'時：'.$pv.' PV').'"><span>'.esc_html($pv).'</span><i style="height:'.esc_attr(max(1,round(70*$pv/$hm))).'px"></i><small>'.esc_html($hour).'時</small></div>'; }
        echo '</div></section><section class="adn-panel"><h2>CSV エクスポート</h2><form method="get" action="'.esc_url(admin_url('admin-post.php')).'" class="adn-export"><input type="hidden" name="action" value="accessdn_export"><input type="hidden" name="from" value="'.esc_attr($from).'"><input type="hidden" name="to" value="'.esc_attr($to).'">'; wp_nonce_field('accessdn_export');
        echo '<label>出力対象 <select name="type">'; foreach(array('daily'=>'日別推移','pages'=>'ページ別','referrer'=>'参照元','device'=>'端末','browser'=>'ブラウザー','os'=>'OS','hour'=>'時間帯','missing'=>'404ページ') as $key=>$label) { echo '<option value="'.esc_attr($key).'">'.esc_html($label).'</option>'; }
        echo '</select></label><button class="button button-primary">CSVをダウンロード</button></form><p class="adn-muted">選択期間のデータを UTF-8 / BOM付きで出力。各分類は最大10,000項目です。</p></section>';
        echo '<p class="adn-note">保存期間は今日を含む'.esc_html($s['retention']).'日間です。訪問者数は日替わり識別子による推定で、同一IP・同種端末はまとめられる場合があります。過去分の取得、検索エンジン等のJavaScriptを実行しないアクセス、完全なボット判別には対応していません。</p>';
    }
    private static function settings_page($s) {
        echo '<div class="adn-settings-grid"><section class="adn-panel"><h2>計測設定</h2>'; self::form('accessdn_settings');
        foreach(array('enabled'=>array('アクセスを計測する','オフにしても保存済みデータは維持します。'),'exclude_logged_in'=>array('ログイン中の訪問者を除外','管理者は、この設定にかかわらず常に除外します。'),'exclude_bots'=>array('既知のボットを除外','User-Agent のパターンによる簡易判定です。'),'respect_dnt'=>array('DNT / GPC の拒否信号を尊重','ブラウザーから拒否信号が届いたアクセスは記録しません。'),'consent'=>array('同意通知後だけ計測する','既存の同意管理ツールとの連携が必要です。下の例を参照してください。')) as $key=>$info) {
            echo '<label class="adn-switch"><input type="checkbox" name="'.esc_attr($key).'" value="1" '.checked($s[$key],1,false).'><span><b>'.esc_html($info[0]).'</b><small>'.esc_html($info[1]).'</small></span></label>';
        }
        echo '<label class="adn-field">保存期間（日）<input type="number" name="retention" min="7" max="365" value="'.esc_attr($s['retention']).'" required></label><p class="adn-muted">7〜365日。短くすると次の自動整理で古いデータが削除されます。WP-Cronで毎日整理します。</p>';
        echo '<label class="adn-field">計測から除外するパスの先頭<textarea name="exclude_paths" rows="6" spellcheck="false">'.esc_textarea($s['exclude_paths']).'</textarea></label><p class="adn-muted">1行に1つ、/ で始めます。例：/contact/、/members/。先頭一致で除外します。/ だけを指定すると全ページを除外します。</p>';
        echo '<label class="adn-switch"><input type="checkbox" name="delete_on_uninstall" value="1" '.checked($s['delete_on_uninstall'],1,false).'><span><b>プラグイン削除時に全データも削除する</b><small>通常はデータを保持します。有効化解除だけでは削除しません。</small></span></label>';
        submit_button('設定を保存'); echo '</form></section><aside><section class="adn-panel"><h2>はじめに</h2><ol><li>計測をオンにします。</li><li>ページキャッシュ・CDNがある場合は削除します。</li><li>ログアウトした別のブラウザーで公開ページを開きます。</li><li>「アクセス解析」で今日のPVを確認します。</li></ol><p>カウンター、バナー、数字などを訪問者の画面に追加しません。計測用JavaScriptと通信は開発者ツール等から確認できます。</p></section>';
        echo '<section class="adn-panel"><h2>データの扱い</h2><ul><li>外部の解析サービスへ送信しません。</li><li>Cookie・localStorage は使用しません。</li><li>IPアドレスの原文は保存しません。</li><li>参照元はホスト名だけを保存します。</li><li>URLのクエリーは p / page_id 以外を除去します。</li><li>管理画面とCSVは管理者権限が必要です。</li></ul><p>URLパスにメールアドレス等を含めるサイトでは、該当パスを除外してください。サイトのプライバシーポリシーに合わせて設定できます。</p></section></aside></div>';
        echo '<section class="adn-panel"><h2>同意管理ツールとの連携</h2><p>「同意通知後だけ計測する」をオンにし、計測スクリプトの読み込み後、同意が確認できたときに次を実行します。これだけで同意バナーが設置されるわけではありません。</p><pre><code>'.esc_html("window.dispatchEvent(new CustomEvent('accessdn:consent', { detail: { granted: true } }));").'</code></pre><p>同意を撤回した場合：</p><pre><code>'.esc_html("window.dispatchEvent(new CustomEvent('accessdn:optout')); ").'</code></pre><p class="adn-muted">撤回前に記録したデータは自動では消えません。同意状態は AccessDN 自体では保存せず、ページを開くたびに通知を受け取ります。</p></section>';
        echo '<details class="adn-panel adn-danger"><summary>計測データの全削除</summary><p>保存したアクセス記録をすべて削除します。元には戻せません。必要なCSVを先に保存してください。</p>'; self::form('accessdn_reset');
        echo '<label>確認のため DELETE と入力 <input type="text" name="confirm" autocomplete="off" required pattern="DELETE"></label> <button class="button" type="submit">全データを削除</button></form></details>';
    }
}
