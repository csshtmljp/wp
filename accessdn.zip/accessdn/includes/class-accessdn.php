<?php
if (!defined('ABSPATH')) { exit; }

final class AccessDN {
    public static function table() { global $wpdb; return $wpdb->prefix . 'accessdn_events'; }
    public static function defaults() {
        return array('enabled'=>1, 'exclude_logged_in'=>1, 'exclude_bots'=>1, 'respect_dnt'=>1, 'consent'=>0, 'retention'=>90, 'exclude_paths'=>"/wp-admin/\n/wp-login.php\n/wp-json/", 'delete_on_uninstall'=>0);
    }
    public static function settings() { return wp_parse_args((array)get_option('accessdn_settings', array()), self::defaults()); }
    public static function boot() {
        add_action('plugins_loaded', array(__CLASS__, 'maybe_install'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue'));
        add_action('wp_ajax_accessdn_hit', array(__CLASS__, 'collect'));
        add_action('wp_ajax_nopriv_accessdn_hit', array(__CLASS__, 'collect'));
        add_action('accessdn_cleanup', array(__CLASS__, 'cleanup'));
        add_action('admin_init', array(__CLASS__, 'privacy'));
    }
    public static function activate($network_wide = false) {
        if (is_multisite() && $network_wide) {
            wp_die('AccessDN は各サイトの管理画面から個別に有効化してください。ネットワーク一括有効化には対応していません。', '', array('back_link'=>true));
        }
        self::install();
    }
    public static function maybe_install() {
        if (get_option('accessdn_db_version') !== ACCESSDN_VERSION) { self::install(); }
    }
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table(); $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            occurred datetime NOT NULL,
            day date NOT NULL,
            hour tinyint(3) unsigned NOT NULL DEFAULT 0,
            visitor char(64) NOT NULL,
            event_key char(64) NOT NULL,
            path varchar(768) NOT NULL,
            path_key char(64) NOT NULL,
            title varchar(190) NOT NULL DEFAULT '',
            referrer varchar(190) NOT NULL DEFAULT '',
            device varchar(20) NOT NULL DEFAULT '',
            browser varchar(30) NOT NULL DEFAULT '',
            os varchar(30) NOT NULL DEFAULT '',
            status smallint(5) unsigned NOT NULL DEFAULT 200,
            PRIMARY KEY  (id),
            UNIQUE KEY event_key (event_key),
            KEY day_visitor (day,visitor),
            KEY occurred (occurred),
            KEY visitor_time (visitor,occurred),
            KEY day_path (day,path_key)
        ) $charset;");
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) === $table) {
            update_option('accessdn_db_version', ACCESSDN_VERSION, false);
        }
        add_option('accessdn_settings', self::defaults(), '', false);
        add_option('accessdn_secret', wp_generate_password(64, true, true), '', false);
        if (!wp_next_scheduled('accessdn_cleanup')) { wp_schedule_event(time()+HOUR_IN_SECONDS, 'daily', 'accessdn_cleanup'); }
    }
    public static function deactivate() { wp_clear_scheduled_hook('accessdn_cleanup'); }
    public static function cleanup() {
        global $wpdb;
        $settings = self::settings();
        $cutoff = current_datetime()->modify('-' . (max(7, min(365, (int)$settings['retention']))-1) . ' days')->format('Y-m-d');
        // Bounded batches avoid a single long DELETE on busy installations.
        for ($i=0; $i<20; $i++) {
            $n = $wpdb->query($wpdb->prepare('DELETE FROM ' . self::table() . ' WHERE day < %s LIMIT 5000', $cutoff));
            if (!$n || $n<5000) { break; }
        }
    }
    public static function enqueue() {
        $s = self::settings();
        if (!$s['enabled'] || is_admin() || is_feed() || is_preview() || is_customize_preview() || is_trackback()) { return; }
        if (current_user_can('manage_options') || ($s['exclude_logged_in'] && is_user_logged_in())) { return; }
        if (is_singular() && (post_password_required() || get_post_status() !== 'publish')) { return; }
        wp_enqueue_script('accessdn-tracker', plugins_url('assets/tracker.js', ACCESSDN_FILE), array(), ACCESSDN_VERSION, true);
        wp_add_inline_script('accessdn-tracker', 'window.AccessDNConfig=' . wp_json_encode(array(
            'endpoint'=>admin_url('admin-ajax.php'), 'postId'=>is_singular() ? get_queried_object_id() : 0,
            'notFound'=>is_404(), 'consentRequired'=>(bool)$s['consent'], 'respectDNT'=>(bool)$s['respect_dnt']
        )) . ';', 'before');
    }
    private static function origin($url) {
        $u = wp_parse_url($url);
        if (!is_array($u) || empty($u['scheme']) || empty($u['host']) || !in_array(strtolower($u['scheme']), array('http','https'), true)) { return ''; }
        $scheme = strtolower($u['scheme']); $port = isset($u['port']) ? (int)$u['port'] : ($scheme==='https' ? 443 : 80);
        return $scheme . '://' . strtolower($u['host']) . ':' . $port;
    }
    public static function same_origin($url) {
        $origin = self::origin($url);
        return $origin !== '' && in_array($origin, array(self::origin(home_url()),self::origin(site_url())), true);
    }
    public static function agent_info($ua) {
        $device = preg_match('/ipad|tablet|kindle|silk|android(?!.*mobile)/i', $ua) ? 'タブレット' : (preg_match('/mobi|iphone|ipod|android/i', $ua) ? 'スマートフォン' : 'パソコン');
        $browser = 'その他';
        foreach (array('Edge'=>'/Edg|Edge/i','Opera'=>'/OPR|Opera/i','Firefox'=>'/Firefox|FxiOS/i','Chrome'=>'/Chrome|CriOS/i','Safari'=>'/Safari/i') as $name=>$pattern) { if (preg_match($pattern, $ua)) { $browser=$name; break; } }
        $os = 'その他';
        foreach (array('iOS / iPadOS'=>'/iPhone|iPad|iPod/i','Android'=>'/Android/i','Windows'=>'/Windows/i','macOS'=>'/Macintosh|Mac OS X/i','Linux'=>'/Linux/i') as $name=>$pattern) { if (preg_match($pattern, $ua)) { $os=$name; break; } }
        return array($device,$browser,$os);
    }
    public static function normal_path($url) {
        if (!is_string($url) || strlen($url)>4096 || !self::same_origin($url)) { return false; }
        $path = wp_parse_url($url, PHP_URL_PATH); $path = $path ? $path : '/';
        $base = wp_parse_url(home_url('/'), PHP_URL_PATH);
        if ($base && $base !== '/' && strpos($path, rtrim($base,'/') . '/') !== 0 && $path !== rtrim($base,'/')) { return false; }
        if (strlen($path)>700 || preg_match('/[\x00-\x20<>"\\\\]/', $path) || strpos($path,'//')===0) { return false; }
        $query = array(); parse_str((string)wp_parse_url($url, PHP_URL_QUERY), $query);
        $allowed = array();
        foreach (array('p','page_id') as $key) { if (isset($query[$key]) && is_scalar($query[$key]) && ctype_digit((string)$query[$key])) { $allowed[$key] = absint($query[$key]); } }
        return $path . ($allowed ? '?' . http_build_query($allowed) : '');
    }
    public static function excluded_path($path) {
        $s = self::settings(); $decoded = rawurldecode((string)wp_parse_url($path, PHP_URL_PATH));
        foreach (preg_split('/\r\n|\r|\n/', $s['exclude_paths']) as $prefix) {
            $prefix = trim($prefix); if ($prefix !== '' && strpos($decoded,$prefix) === 0) { return true; }
        }
        return false;
    }
    // Public write-only endpoint. No nonce is embedded in cached public pages.
    // Same-origin checks reduce cross-site submissions; this is not fraud-proof analytics.
    public static function collect() {
        nocache_headers();
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { wp_send_json_error(array('reason'=>'method'),405); }
        if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0)>10000) { wp_send_json_error(array('reason'=>'size'),413); }
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? wp_unslash($_SERVER['HTTP_ORIGIN']) : wp_unslash($_SERVER['HTTP_REFERER'] ?? '');
        if (!self::same_origin($origin) || (isset($_SERVER['HTTP_SEC_FETCH_SITE']) && $_SERVER['HTTP_SEC_FETCH_SITE']==='cross-site')) { wp_send_json_error(array('reason'=>'origin'),403); }
        foreach (array('url','referrer','event','post_id','not_found','consent') as $key) {
            if (isset($_POST[$key]) && !is_scalar($_POST[$key])) { wp_send_json_error(array('reason'=>'format'),400); }
        }
        $s=self::settings(); $ua=substr(wp_unslash($_SERVER['HTTP_USER_AGENT'] ?? ''),0,1024);
        if (!$s['enabled'] || current_user_can('manage_options') || ($s['exclude_logged_in'] && is_user_logged_in()) || ($s['respect_dnt'] && (($_SERVER['HTTP_DNT'] ?? '')==='1' || ($_SERVER['HTTP_SEC_GPC'] ?? '')==='1')) || ($s['consent'] && ($_POST['consent'] ?? '')!=='1')) { wp_send_json_success(array('recorded'=>false)); }
        if ($s['exclude_bots'] && ($ua==='' || preg_match('/bot|crawl|spider|slurp|headless|lighthouse|preview|facebookexternalhit|pingdom|uptime|curl|wget|python|monitor/i',$ua))) { wp_send_json_success(array('recorded'=>false)); }
        $path=self::normal_path(wp_unslash($_POST['url'] ?? ''));
        $event=wp_unslash($_POST['event'] ?? '');
        if ($path===false || !preg_match('/^[a-zA-Z0-9_-]{16,80}$/D',$event)) { wp_send_json_error(array('reason'=>'input'),400); }
        if (self::excluded_path($path)) { wp_send_json_success(array('recorded'=>false)); }
        $post_id=absint($_POST['post_id'] ?? 0); $title='';
        if ($post_id) {
            $post=get_post($post_id);
            if (!$post || $post->post_status!=='publish' || $post->post_password!=='' || !is_post_type_viewable($post->post_type)) { wp_send_json_success(array('recorded'=>false)); }
            $title=get_the_title($post_id);
        }
        $ref=substr(wp_unslash($_POST['referrer'] ?? ''),0,2048);
        $ref_host=strtolower((string)wp_parse_url($ref,PHP_URL_HOST));
        if (self::same_origin($ref)) { $ref_host='(internal)'; }
        if (!$ref_host || !preg_match('/^[a-z0-9.:-]+$/D', $ref_host)) { $ref_host='(direct)'; }
        $now=current_datetime(); $day=$now->format('Y-m-d');
        list($device,$browser,$os)=self::agent_info($ua);
        // REMOTE_ADDR only: do not trust client-controlled forwarding headers.
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        if (!filter_var($ip,FILTER_VALIDATE_IP)) { wp_send_json_success(array('recorded'=>false)); }
        $visitor=hash_hmac('sha256',$day.'|'.$ip.'|'.$device.'|'.$browser.'|'.$os,(string)get_option('accessdn_secret'));
        global $wpdb; $table=self::table();
        $rate=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE visitor=%s AND occurred >= %s",$visitor,gmdate('Y-m-d H:i:s',time()-60)));
        if ($rate>=120) { wp_send_json_error(array('reason'=>'rate'),429); }
        $values=array(gmdate('Y-m-d H:i:s'),$day,(int)$now->format('G'),$visitor,hash('sha256',$day.'|'.$visitor.'|'.$event),$path,hash('sha256',$path),wp_html_excerpt(wp_strip_all_tags($title),190,''),substr($ref_host,0,190),$device,$browser,$os,empty($_POST['not_found']) ? 200 : 404);
        $sql=$wpdb->prepare("INSERT INTO $table (occurred,day,hour,visitor,event_key,path,path_key,title,referrer,device,browser,os,status) VALUES (%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d) ON DUPLICATE KEY UPDATE event_key=VALUES(event_key)",$values);
        $written=$wpdb->query($sql);
        if ($written===false) { wp_send_json_error(array('reason'=>'storage'),503); }
        wp_send_json_success(array('recorded'=>$written>0));
    }
    public static function realtime() {
        global $wpdb;
        $r=$wpdb->get_row($wpdb->prepare('SELECT COUNT(*) AS pv, COUNT(DISTINCT visitor) AS visitors FROM '.self::table().' WHERE occurred >= %s',gmdate('Y-m-d H:i:s',time()-300)),ARRAY_A);
        return array('pv'=>(int)($r['pv'] ?? 0),'visitors'=>(int)($r['visitors'] ?? 0));
    }
    public static function range($from,$to) {
        $today=current_datetime()->setTime(0,0);
        $parse=function($value) {
            if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/D',$value)) { return false; }
            $d=DateTimeImmutable::createFromFormat('!Y-m-d',$value,wp_timezone());
            return $d && $d->format('Y-m-d')===$value ? $d : false;
        };
        $end=$parse($to) ?: $today; if($end>$today) { $end=$today; }
        $start=$parse($from) ?: $end->modify('-29 days');
        if($start>$end) { $start=$end; }
        if($start<$end->modify('-364 days')) { $start=$end->modify('-364 days'); }
        return array($start->format('Y-m-d'),$end->format('Y-m-d'));
    }
    public static function report($from,$to,$limit=20) {
        global $wpdb; $t=self::table(); list($from,$to)=self::range($from,$to); $limit=max(1,min(10000,(int)$limit));
        $where=$wpdb->prepare(' WHERE day BETWEEN %s AND %s',$from,$to);
        $daily=$wpdb->get_results("SELECT day AS label,COUNT(*) AS pv,COUNT(DISTINCT visitor) AS uv FROM $t $where GROUP BY day ORDER BY day",ARRAY_A);
        $rows=array(); foreach($daily as $r) { $rows[$r['label']]=$r; }
        $filled=array(); $date=new DateTimeImmutable($from,wp_timezone()); $end=new DateTimeImmutable($to,wp_timezone());
        while($date<=$end) { $label=$date->format('Y-m-d'); $filled[]=isset($rows[$label]) ? $rows[$label] : array('label'=>$label,'pv'=>0,'uv'=>0); $date=$date->modify('+1 day'); }
        $r=array('daily'=>$filled,'pv'=>array_sum(array_column($filled,'pv')),'uv'=>array_sum(array_column($filled,'uv')));
        $r['pages']=$wpdb->get_results("SELECT path AS label,MAX(title) AS title,COUNT(*) AS pv,COUNT(DISTINCT visitor) AS uv FROM $t $where GROUP BY path_key,path ORDER BY pv DESC,label ASC LIMIT $limit",ARRAY_A);
        $r['missing']=$wpdb->get_results("SELECT path AS label,COUNT(*) AS pv FROM $t $where AND status=404 GROUP BY path_key,path ORDER BY pv DESC,label ASC LIMIT $limit",ARRAY_A);
        foreach(array('referrer','device','browser','os','hour') as $column) { $r[$column]=$wpdb->get_results("SELECT $column AS label,COUNT(*) AS pv FROM $t $where GROUP BY $column ORDER BY pv DESC,label ASC LIMIT $limit",ARRAY_A); }
        return $r;
    }
    public static function privacy() {
        if (function_exists('wp_add_privacy_policy_content')) {
            wp_add_privacy_policy_content('AccessDN','<p>当サイトは AccessDN によりページ閲覧数を計測します。閲覧ページのパス、時刻、参照元のホスト名、端末・ブラウザー・OSの大分類と、IPアドレス等から生成した日替わり識別子を当サイトのサーバーに保存します。AccessDN 自体は Cookie・ブラウザーの永続ストレージを使わず、IPアドレスの原文・完全な User-Agent・参照元URLのパスや検索語を保存しません。保存期間、同意取得、DNT/GPC対応はサイト設定に合わせて記載してください。</p>');
        }
    }
}
