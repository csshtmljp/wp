<?php
/**
 * Plugin Name: AccessDN — 管理者専用アクセスカウンター
 * Description: 訪問者の画面に表示を追加せず、PV・日別訪問者・人気ページ・参照元・端末を管理画面で分析します。
 * Version: 1.0.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: AccessDN
 * License: GPL-2.0-or-later
 * Text Domain: accessdn
 */
if (!defined('ABSPATH')) { exit; }
define('ACCESSDN_VERSION', '1.0.0');
define('ACCESSDN_FILE', __FILE__);
define('ACCESSDN_PATH', plugin_dir_path(__FILE__));
require_once ACCESSDN_PATH . 'includes/class-accessdn.php';
require_once ACCESSDN_PATH . 'includes/class-accessdn-admin.php';
register_activation_hook(__FILE__, array('AccessDN', 'activate'));
register_deactivation_hook(__FILE__, array('AccessDN', 'deactivate'));
AccessDN::boot();
AccessDN_Admin::boot();
