(function () {
    'use strict';
    var config = window.AccessDNAdmin, status = document.getElementById('adn-live-status');
    if (!config || !status) return;
    var busy = false;
    function update() {
        if (busy || document.hidden) return;
        busy = true;
        var button = document.getElementById('adn-refresh');
        button.disabled = true; status.textContent = '更新中…';
        fetch(config.endpoint, {method:'POST',credentials:'same-origin',cache:'no-store',
            body:new URLSearchParams({action:'accessdn_live',nonce:config.nonce})})
            .then(function (response) { if (!response.ok) throw new Error(); return response.json(); })
            .then(function (result) {
                if (!result.success) throw new Error();
                document.getElementById('adn-live-pv').textContent = Number(result.data.pv).toLocaleString('ja-JP');
                document.getElementById('adn-live-visitors').textContent = Number(result.data.visitors).toLocaleString('ja-JP');
                status.textContent = '更新 ' + new Date().toLocaleTimeString('ja-JP');
            }).catch(function () { status.textContent = '更新できませんでした。再読み込みで認証を更新できます。'; })
            .finally(function () { busy = false; button.disabled = false; });
    }
    document.getElementById('adn-refresh').addEventListener('click', update);
    window.setInterval(update, 30000);
})();
