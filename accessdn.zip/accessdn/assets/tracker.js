(function () {
    'use strict';
    if (window.__accessdnLoaded || !window.AccessDNConfig || typeof window.fetch !== 'function') return;
    window.__accessdnLoaded = true;
    var config = window.AccessDNConfig, sent = false, consent = !config.consentRequired;
    var endpoint;
    try { endpoint = new URL(config.endpoint, location.href); } catch (e) { return; }
    // Measurement is intentionally same-origin. Cross-domain admin URLs are unsupported.
    if (endpoint.origin !== location.origin) return;
    function permitted() {
        return !window.AccessDNDisabled && consent && !(config.respectDNT &&
            (navigator.doNotTrack === '1' || window.doNotTrack === '1' || navigator.globalPrivacyControl === true));
    }
    function eventId() {
        if (window.crypto && crypto.getRandomValues) {
            var bytes = new Uint8Array(16); crypto.getRandomValues(bytes);
            return Array.from(bytes, function (b) { return b.toString(16).padStart(2, '0'); }).join('');
        }
        return Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
    }
    function send() {
        if (sent || document.visibilityState === 'hidden' || !permitted()) return;
        sent = true;
        var url = new URL(location.href), clean = new URL(url.pathname, url.origin);
        ['p', 'page_id'].forEach(function (key) { var value = url.searchParams.get(key); if (value && /^\d+$/.test(value)) clean.searchParams.set(key, value); });
        var ref = '';
        try { if (document.referrer) ref = new URL(document.referrer).origin; } catch (e) {}
        var body = new URLSearchParams({ action: 'accessdn_hit', url: clean.href, referrer: ref,
            event: eventId(), post_id: String(config.postId || 0), not_found: config.notFound ? '1' : '0', consent: consent ? '1' : '0' });
        // Best effort: a measurement outage must never affect the page itself.
        fetch(endpoint.href, {method:'POST', credentials:'same-origin', body:body, keepalive:true, cache:'no-store'}).catch(function () {});
    }
    window.addEventListener('accessdn:consent', function (event) { consent = !!(event.detail && event.detail.granted); send(); });
    window.addEventListener('accessdn:optout', function () { window.AccessDNDisabled = true; consent = false; });
    document.addEventListener('visibilitychange', send);
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', send, {once:true}); else send();
})();
