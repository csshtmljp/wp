<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
function accessdn_uninstall_site() {
    $settings=get_option('accessdn_settings',array());
    wp_clear_scheduled_hook('accessdn_cleanup');
    if(empty($settings['delete_on_uninstall'])) { return; }
    global $wpdb;
    $wpdb->query('DROP TABLE IF EXISTS '.$wpdb->prefix.'accessdn_events');
    foreach(array('accessdn_settings','accessdn_db_version','accessdn_secret') as $key) { delete_option($key); }
}
if (is_multisite()) {
    $offset=0;
    do {
        $sites=get_sites(array('fields'=>'ids','number'=>100,'offset'=>$offset));
        foreach($sites as $site) { switch_to_blog((int)$site); accessdn_uninstall_site(); restore_current_blog(); }
        $offset+=100;
    } while(count($sites)===100);
} else { accessdn_uninstall_site(); }
