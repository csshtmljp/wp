<?php
/**
 * Plugin Name: Bulk Plugin ZIP Downloader
 * Description: インストール済みのプラグインを全選択（初期値）した状態で一覧表示し、チェックした分をプラグインごとの個別ZIPにして、まとめて1つのZIPでダウンロードします。
 * Version: 1.2.0
 * Requires PHP: 7.2
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BPZD_Bulk_Plugin_Zip_Downloader {

	const ACTION = 'bpzd_download';
	const SLUG   = 'bpzd-bulk-plugin-zip';

	/** @var string[] 後片付け用の一時ファイル */
	private $temp_files = array();

	/**
	 * 必要権限。マルチサイトでは各サイトの管理者ではなくネットワーク管理者に限定する。
	 */
	private function cap() {
		return is_multisite() ? 'manage_network_plugins' : 'activate_plugins';
	}

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle_download' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'action_links' ) );
	}

	public function add_menu() {
		add_management_page(
			'プラグイン一括ZIPダウンロード',
			'プラグイン一括ZIP',
			$this->cap(),
			self::SLUG,
			array( $this, 'render_page' )
		);
	}

	public function action_links( $links ) {
		$url = admin_url( 'tools.php?page=' . self::SLUG );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">ダウンロード画面</a>' );
		return $links;
	}

	private function get_all_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		return get_plugins();
	}

	public function render_page() {
		if ( ! current_user_can( $this->cap() ) ) {
			wp_die( 'このページを表示する権限がありません。' );
		}
		$plugins = $this->get_all_plugins();
		$total   = count( $plugins );
		?>
		<div class="wrap">
			<h1>プラグイン一括ZIPダウンロード</h1>

			<?php if ( ! class_exists( 'ZipArchive' ) ) : ?>
				<div class="notice notice-error"><p>このサーバーでは PHP の ZipArchive 拡張が無効のため、ZIPを作成できません。サーバー側で zip 拡張を有効にしてください。</p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="bpzd-form">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
				<?php wp_nonce_field( self::ACTION ); ?>

				<p>チェックしたプラグインを1つずつ個別のZIP（プラグイン名.zip）にして、まとめて1つのZIPでダウンロードします。各ZIPはそのまま「プラグインのアップロード」で再インストールできます。</p>

				<p>
					<button type="submit" class="button button-primary button-hero" id="bpzd-submit-top">選択したプラグインをZIPでダウンロード</button>
					<span id="bpzd-count" style="margin-left:12px;font-weight:600;"></span>
				</p>

				<table class="wp-list-table widefat striped">
					<thead>
						<tr>
							<td class="manage-column check-column" style="padding:8px 0 8px 10px;">
								<input type="checkbox" id="bpzd-all" checked aria-label="すべて選択">
							</td>
							<th>プラグイン</th>
							<th style="width:110px;">バージョン</th>
							<th style="width:90px;">状態</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $plugins as $file => $data ) : ?>
						<?php $active = is_plugin_active( $file ) || is_plugin_active_for_network( $file ); ?>
						<tr>
							<th scope="row" class="check-column" style="padding:8px 0 8px 10px;">
								<input type="checkbox" class="bpzd-item" name="bpzd_plugins[]" value="<?php echo esc_attr( $file ); ?>" checked>
							</th>
							<td>
								<strong><?php echo esc_html( $data['Name'] ); ?></strong><br>
								<code><?php echo esc_html( $file ); ?></code>
							</td>
							<td><?php echo esc_html( $data['Version'] ); ?></td>
							<td><?php echo $active ? '有効' : '無効'; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<p>
					<button type="submit" class="button button-primary">選択したプラグインをZIPでダウンロード</button>
				</p>
			</form>
		</div>

		<script>
		(function () {
			var all   = document.getElementById('bpzd-all');
			var items = Array.prototype.slice.call(document.querySelectorAll('.bpzd-item'));
			var count = document.getElementById('bpzd-count');
			var total = <?php echo (int) $total; ?>;
			var form  = document.getElementById('bpzd-form');

			function refresh() {
				var n = items.filter(function (i) { return i.checked; }).length;
				count.textContent = n + ' / ' + total + ' 件を選択中';
				all.checked = (n === total && total > 0);
				all.indeterminate = (n > 0 && n < total);
			}
			all.addEventListener('change', function () {
				items.forEach(function (i) { i.checked = all.checked; });
				refresh();
			});
			items.forEach(function (i) { i.addEventListener('change', refresh); });
			form.addEventListener('submit', function (e) {
				if (!items.some(function (i) { return i.checked; })) {
					e.preventDefault();
					count.textContent = 'プラグインを1つ以上選択してください';
					count.style.color = '#d63638';
				}
			});
			refresh();
		})();
		</script>
		<?php
	}

	public function handle_download() {
		if ( ! current_user_can( $this->cap() ) ) {
			wp_die( 'この操作を行う権限がありません。' );
		}
		if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
			wp_die( '不正なリクエストです。', '', array( 'response' => 405 ) );
		}
		check_admin_referer( self::ACTION );

		// タイムアウトや通信切断で処理が途中終了しても一時ファイルを残さない
		ignore_user_abort( true );
		register_shutdown_function( array( $this, 'cleanup' ) );

		if ( ! class_exists( 'ZipArchive' ) ) {
			wp_die( 'PHP の ZipArchive 拡張が無効のため、ZIPを作成できません。' );
		}

		$requested = ( isset( $_POST['bpzd_plugins'] ) && is_array( $_POST['bpzd_plugins'] ) ) ? wp_unslash( $_POST['bpzd_plugins'] ) : array();
		$requested = array_filter( $requested, 'is_string' );
		$installed = $this->get_all_plugins();
		// 実在するインストール済みプラグインだけに限定（任意パスの読み出し防止）
		$selected = array_values( array_intersect( array_keys( $installed ), $requested ) );

		if ( empty( $selected ) ) {
			wp_die( 'プラグインが選択されていません。', '', array( 'back_link' => true ) );
		}

		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 );
		}
		wp_raise_memory_limit( 'admin' );

		$main_path = $this->temp_file();
		$zip       = new ZipArchive();
		if ( true !== $zip->open( $main_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			$this->cleanup();
			wp_die( '一時ZIPファイルを作成できませんでした。', '', array( 'back_link' => true ) );
		}

		foreach ( $selected as $plugin_file ) {
			$dir = dirname( $plugin_file );

			$name     = ( '.' === $dir ) ? basename( $plugin_file, '.php' ) : $dir;
			$sub_path = $this->temp_file();
			$sub      = new ZipArchive();
			if ( true !== $sub->open( $sub_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
				continue;
			}
			$this->add_plugin( $sub, $plugin_file );
			$sub->close();
			if ( file_exists( $sub_path ) && filesize( $sub_path ) > 0 ) {
				$zip->addFile( $sub_path, $name . '.zip' );
				// 既に圧縮済みなので再圧縮しない
				if ( method_exists( $zip, 'setCompressionName' ) ) {
					$zip->setCompressionName( $name . '.zip', ZipArchive::CM_STORE );
				}
			}
		}

		$ok = $zip->close();
		if ( ! $ok || ! file_exists( $main_path ) ) {
			$this->cleanup();
			wp_die( 'ZIPの作成に失敗しました。ディスク容量や権限を確認してください。', '', array( 'back_link' => true ) );
		}

		$host     = sanitize_file_name( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$filename = 'plugins-' . ( $host ? $host . '-' : '' ) . wp_date( 'Ymd-His' ) . '.zip';

		if ( headers_sent() ) {
			$this->cleanup();
			wp_die( '出力が既に開始されているため、ダウンロードを開始できませんでした。', '', array( 'back_link' => true ) );
		}
		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}
		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . filesize( $main_path ) );
		header( 'X-Content-Type-Options: nosniff' );
		readfile( $main_path );

		$this->cleanup();
		exit;
	}

	/**
	 * プラグイン1つ分（フォルダ型 or 単一ファイル型）をZIPへ追加
	 */
	private function add_plugin( ZipArchive $zip, $plugin_file ) {
		$base = wp_normalize_path( WP_PLUGIN_DIR );
		$dir  = dirname( $plugin_file );

		// hello.php のような単一ファイルのプラグイン
		if ( '.' === $dir ) {
			$path = $base . '/' . $plugin_file;
			if ( ! is_link( $path ) && is_file( $path ) && is_readable( $path ) && $this->is_inside( $path, $base ) ) {
				$zip->addFile( $path, $plugin_file );
			}
			return;
		}

		$root = $base . '/' . $dir;
		if ( ! is_dir( $root ) ) {
			return;
		}
		// プラグインフォルダ自体がリンクの場合（開発環境など）は実体を基準にする
		$real_root = realpath( $root );
		if ( false === $real_root ) {
			return;
		}
		$real_root = wp_normalize_path( $real_root );
		$zip->addEmptyDir( $dir );

		// FOLLOW_SYMLINKS は付けない：リンク経由で wp-config.php 等の
		// プラグイン外ファイルが混入すること、循環リンクによる無限ループを防ぐ
		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $real_root, FilesystemIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::SELF_FIRST
		);
		foreach ( $iterator as $item ) {
			if ( $item->isLink() ) {
				continue;
			}
			$full = wp_normalize_path( $item->getPathname() );
			if ( ! $this->is_inside( $full, $real_root ) ) {
				continue;
			}
			$local = $dir . '/' . ltrim( substr( $full, strlen( $real_root ) ), '/' );
			if ( $item->isDir() ) {
				$zip->addEmptyDir( $local );
			} elseif ( $item->isFile() && $item->isReadable() ) {
				$zip->addFile( $full, $local );
			}
		}
	}

	/**
	 * $path の実体が $root 配下にあるかを realpath で確認
	 */
	private function is_inside( $path, $root ) {
		$real_path = realpath( $path );
		$real_root = realpath( $root );
		if ( false === $real_path || false === $real_root ) {
			return false;
		}
		$real_path = wp_normalize_path( $real_path );
		$real_root = rtrim( wp_normalize_path( $real_root ), '/' ) . '/';
		return 0 === strpos( $real_path . '/', $real_root );
	}

	private function temp_file() {
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$path               = wp_tempnam( 'bpzd' );
		$this->temp_files[] = $path;
		return $path;
	}

	public function cleanup() {
		foreach ( $this->temp_files as $f ) {
			if ( $f && file_exists( $f ) ) {
				@unlink( $f );
			}
		}
		$this->temp_files = array();
	}
}

new BPZD_Bulk_Plugin_Zip_Downloader();
