<?php
/**
 * Plugin Name:       Plugin Downloader
 * Description:       プラグイン一覧の各行に「ダウンロード」リンクを追加し、インストール済みのプラグインをZIPで保存できるようにします。複数選択での一括ダウンロードにも対応。
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Plugin Downloader
 * License:           GPL-2.0-or-later
 * Text Domain:       plugin-downloader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin_Downloader {

	const ACTION = 'pdl_download';
	const BULK   = 'pdl_bulk_download';

	public static function init() {
		$self = new self();
		add_filter( 'plugin_action_links', array( $self, 'add_link' ), 10, 2 );
		add_filter( 'network_admin_plugin_action_links', array( $self, 'add_link' ), 10, 2 );
		add_action( 'admin_post_' . self::ACTION, array( $self, 'handle_single' ) );

		foreach ( array( 'plugins', 'plugins-network' ) as $screen ) {
			add_filter( 'bulk_actions-' . $screen, array( $self, 'add_bulk_action' ) );
			add_filter( 'handle_bulk_actions-' . $screen, array( $self, 'handle_bulk' ), 10, 3 );
		}
	}

	/** ダウンロードを許可するか。プラグインのコードを持ち出せるため、管理権限に限定する。 */
	private function allowed() {
		$can = current_user_can( 'activate_plugins' );
		if ( is_multisite() ) {
			$can = current_user_can( 'manage_network_plugins' );
		}
		return (bool) apply_filters( 'pdl_user_can_download', $can );
	}

	/* ------------------------------------------------------------------
	 * 一覧への追加
	 * ---------------------------------------------------------------- */

	public function add_link( $links, $plugin_file ) {
		if ( ! $this->allowed() ) {
			return $links;
		}
		$url = wp_nonce_url(
			add_query_arg(
				array(
					'action' => self::ACTION,
					'plugin' => rawurlencode( $plugin_file ),
				),
				admin_url( 'admin-post.php' )
			),
			self::ACTION . '_' . $plugin_file
		);
		$links['pdl_download'] = '<a href="' . esc_url( $url ) . '">ダウンロード</a>';
		return $links;
	}

	public function add_bulk_action( $actions ) {
		if ( $this->allowed() ) {
			$actions[ self::BULK ] = 'ダウンロード';
		}
		return $actions;
	}

	/* ------------------------------------------------------------------
	 * ダウンロード処理
	 * ---------------------------------------------------------------- */

	public function handle_single() {
		$plugin = isset( $_GET['plugin'] ) ? wp_unslash( $_GET['plugin'] ) : '';
		$plugin = is_string( $plugin ) ? rawurldecode( $plugin ) : '';

		if ( ! $this->allowed() ) {
			$this->fail( 'プラグインをダウンロードする権限がありません。' );
		}
		check_admin_referer( self::ACTION . '_' . $plugin );

		$info = $this->resolve( $plugin );
		if ( is_wp_error( $info ) ) {
			$this->fail( $info->get_error_message() );
		}

		$this->prepare();
		$tmp    = $this->temp_file();
		$result = $this->zip_plugin( $info, $tmp );
		if ( is_wp_error( $result ) ) {
			@unlink( $tmp );
			$this->fail( $result->get_error_message() );
		}
		$this->send( $tmp, $info['zip_name'] );
	}

	public function handle_bulk( $sendback, $action, $plugins ) {
		if ( self::BULK !== $action ) {
			return $sendback;
		}
		if ( ! $this->allowed() ) {
			$this->fail( 'プラグインをダウンロードする権限がありません。' );
		}
		$plugins = array_values( array_unique( array_filter( (array) $plugins, 'is_string' ) ) );
		if ( ! $plugins ) {
			return $sendback;
		}

		$this->prepare();

		// 1件だけなら、そのプラグインのZIPをそのまま返す。
		if ( 1 === count( $plugins ) ) {
			$info = $this->resolve( $plugins[0] );
			if ( is_wp_error( $info ) ) {
				$this->fail( $info->get_error_message() );
			}
			$tmp    = $this->temp_file();
			$result = $this->zip_plugin( $info, $tmp );
			if ( is_wp_error( $result ) ) {
				@unlink( $tmp );
				$this->fail( $result->get_error_message() );
			}
			$this->send( $tmp, $info['zip_name'] );
		}

		// 複数の場合は、個別のZIPを1つのZIPにまとめる(中のZIPはそれぞれ単体でインストールできる)。
		$dir = trailingslashit( get_temp_dir() ) . 'pdl-' . wp_generate_password( 12, false );
		if ( ! wp_mkdir_p( $dir ) ) {
			$this->fail( '一時フォルダを作成できませんでした。サーバーの一時フォルダの書き込み権限を確認してください。' );
		}

		$parts = array();
		$error = null;
		foreach ( $plugins as $plugin ) {
			$info = $this->resolve( $plugin );
			if ( is_wp_error( $info ) ) {
				$error = $info;
				break;
			}
			$path   = $dir . '/' . $info['zip_name'];
			$result = $this->zip_plugin( $info, $path );
			if ( is_wp_error( $result ) ) {
				$error = $result;
				break;
			}
			$parts[] = $path;
		}

		$tmp = $this->temp_file();
		if ( ! $error ) {
			$result = $this->zip_files( $parts, $dir, $tmp );
			if ( is_wp_error( $result ) ) {
				$error = $result;
			}
		}

		foreach ( $parts as $path ) {
			@unlink( $path );
		}
		@rmdir( $dir );

		if ( $error ) {
			@unlink( $tmp );
			$this->fail( $error->get_error_message() );
		}
		$this->send( $tmp, 'plugins-' . gmdate( 'Ymd-His' ) . '.zip' );
	}

	/**
	 * 一覧に存在するプラグインかを確認し、圧縮対象のパスとZIP名を決める。
	 *
	 * @return array|WP_Error
	 */
	private function resolve( $plugin ) {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$all = get_plugins();
		if ( '' === $plugin || ! isset( $all[ $plugin ] ) || 0 !== validate_file( $plugin ) ) {
			return new WP_Error( 'pdl_unknown', '指定されたプラグインが見つかりません。' );
		}

		$base = wp_normalize_path( WP_PLUGIN_DIR );
		$file = wp_normalize_path( WP_PLUGIN_DIR . '/' . $plugin );
		if ( ! is_file( $file ) ) {
			return new WP_Error( 'pdl_missing', 'プラグインのファイルが見つかりません。' );
		}

		$folder = dirname( $plugin );
		if ( '.' === $folder ) {
			// フォルダを持たない、1ファイルだけのプラグイン。
			$source = $file;
			$slug   = basename( $plugin, '.php' );
		} else {
			$top    = strtok( $folder, '/' );
			$source = $base . '/' . $top;
			$slug   = $top;
		}

		$version = isset( $all[ $plugin ]['Version'] ) ? preg_replace( '/[^0-9A-Za-z.\-_]/', '', (string) $all[ $plugin ]['Version'] ) : '';
		$name    = sanitize_file_name( $slug . ( '' !== $version ? '.' . $version : '' ) . '.zip' );

		return array(
			'source'   => $source,
			'slug'     => $slug,
			'zip_name' => $name,
		);
	}

	private function prepare() {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 );
		}
		wp_raise_memory_limit( 'admin' );
	}

	private function temp_file() {
		$tmp = tempnam( get_temp_dir(), 'pdl' );
		if ( ! $tmp ) {
			$this->fail( '一時ファイルを作成できませんでした。サーバーの一時フォルダの書き込み権限を確認してください。' );
		}
		return $tmp;
	}

	/** 圧縮対象のファイル一覧(ZIP内のパス => 実ファイル)。フォルダ外を指すリンクは含めない。 */
	private function collect( $info ) {
		$source = $info['source'];
		if ( is_file( $source ) ) {
			return array( basename( $source ) => $source );
		}

		$root  = realpath( $source );
		$files = array();
		if ( false === $root ) {
			return $files;
		}
		$exclude  = (array) apply_filters( 'pdl_exclude_names', array( '.git', '.svn', '.DS_Store' ) );
		$iterator = new RecursiveIteratorIterator(
			new RecursiveCallbackFilterIterator(
				new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ),
				static function ( $current ) use ( $exclude ) {
					return ! in_array( $current->getFilename(), $exclude, true );
				}
			),
			RecursiveIteratorIterator::SELF_FIRST
		);

		foreach ( $iterator as $item ) {
			$real = realpath( $item->getPathname() );
			if ( false === $real || 0 !== strpos( $real, $root . DIRECTORY_SEPARATOR ) ) {
				continue;
			}
			$relative = str_replace( '\\', '/', substr( $item->getPathname(), strlen( $root ) + 1 ) );
			$inside   = $info['slug'] . '/' . $relative;
			$files[ $item->isDir() ? $inside . '/' : $inside ] = $item->getPathname();
		}
		return $files;
	}

	/** プラグイン1つをZIPにする */
	private function zip_plugin( $info, $dest ) {
		$files = $this->collect( $info );
		if ( ! $files ) {
			return new WP_Error( 'pdl_empty', '圧縮するファイルがありませんでした。' );
		}

		if ( class_exists( 'ZipArchive' ) ) {
			$zip = new ZipArchive();
			if ( true !== $zip->open( $dest, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
				return new WP_Error( 'pdl_zip', 'ZIPファイルを作成できませんでした。' );
			}
			foreach ( $files as $inside => $path ) {
				if ( '/' === substr( $inside, -1 ) ) {
					$zip->addEmptyDir( rtrim( $inside, '/' ) );
				} elseif ( is_readable( $path ) ) {
					$zip->addFile( $path, $inside );
				}
			}
			if ( ! $zip->close() ) {
				return new WP_Error( 'pdl_zip', 'ZIPファイルの書き込みに失敗しました。空き容量を確認してください。' );
			}
			return true;
		}

		// ZipArchive がないサーバーでは、WordPress同梱のPclZipを使う。
		require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
		$zip    = new PclZip( $dest );
		$source = $info['source'];
		$result = $zip->create( $source, PCLZIP_OPT_REMOVE_PATH, dirname( $source ) );
		if ( 0 === $result ) {
			return new WP_Error( 'pdl_zip', 'ZIPファイルを作成できませんでした: ' . $zip->errorInfo( true ) );
		}
		return true;
	}

	/** 複数のZIPを1つのZIPにまとめる */
	private function zip_files( $paths, $base_dir, $dest ) {
		if ( class_exists( 'ZipArchive' ) ) {
			$zip = new ZipArchive();
			if ( true !== $zip->open( $dest, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
				return new WP_Error( 'pdl_zip', 'ZIPファイルを作成できませんでした。' );
			}
			foreach ( $paths as $path ) {
				$zip->addFile( $path, basename( $path ) );
				if ( method_exists( $zip, 'setCompressionName' ) ) {
					// 中身はすでに圧縮済みなので、再圧縮しない。
					$zip->setCompressionName( basename( $path ), ZipArchive::CM_STORE );
				}
			}
			if ( ! $zip->close() ) {
				return new WP_Error( 'pdl_zip', 'ZIPファイルの書き込みに失敗しました。空き容量を確認してください。' );
			}
			return true;
		}

		require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
		$zip    = new PclZip( $dest );
		$result = $zip->create( $paths, PCLZIP_OPT_REMOVE_PATH, $base_dir, PCLZIP_OPT_NO_COMPRESSION );
		if ( 0 === $result ) {
			return new WP_Error( 'pdl_zip', 'ZIPファイルを作成できませんでした: ' . $zip->errorInfo( true ) );
		}
		return true;
	}

	/** 一時ファイルをブラウザに送り、削除して終了する */
	private function send( $tmp, $name ) {
		if ( ! is_file( $tmp ) || ! filesize( $tmp ) ) {
			@unlink( $tmp );
			$this->fail( 'ZIPファイルを作成できませんでした。' );
		}
		if ( headers_sent() ) {
			@unlink( $tmp );
			$this->fail( '出力がすでに始まっているため、ダウンロードを開始できませんでした。' );
		}
		while ( ob_get_level() ) {
			ob_end_clean();
		}

		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		header( 'X-Content-Type-Options: nosniff' );

		readfile( $tmp );
		@unlink( $tmp );
		exit;
	}

	private function fail( $message ) {
		wp_die(
			esc_html( $message ),
			'Plugin Downloader',
			array(
				'response'  => 403,
				'back_link' => true,
			)
		);
	}
}

Plugin_Downloader::init();
