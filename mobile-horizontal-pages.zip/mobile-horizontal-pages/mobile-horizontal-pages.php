<?php
/**
 * Plugin Name: Mobile Horizontal Pages
 * Description: 固定ページ内のカラムブロック・メディアとテキストブロックを、モバイルでも縦積みにせず横並びのまま表示します。
 * Version: 1.0.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: Claude
 * License: GPL-2.0-or-later
 * Text Domain: mobile-horizontal-pages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * このリクエストで横並びを適用するかどうか。
 * 既定では固定ページのみ。フィルター 'mhp_should_apply' で変更可能。
 * 例）投稿にも適用: add_filter( 'mhp_should_apply', fn() => is_singular() );
 */
function mhp_should_apply() {
	$apply = ! is_admin() && is_page();
	return (bool) apply_filters( 'mhp_should_apply', $apply );
}

/**
 * カラムブロックに「モバイルで縦積みしない」クラスを付与し、
 * メディアとテキストブロックからは「モバイルで縦積み」クラスを外す。
 */
function mhp_filter_block( $block_content, $block ) {
	if ( '' === $block_content || ! mhp_should_apply() ) {
		return $block_content;
	}

	$name = isset( $block['blockName'] ) ? $block['blockName'] : '';

	if ( 'core/columns' === $name ) {
		$p = new WP_HTML_Tag_Processor( $block_content );
		if ( $p->next_tag( array( 'class_name' => 'wp-block-columns' ) ) ) {
			$p->add_class( 'is-not-stacked-on-mobile' );
			$block_content = $p->get_updated_html();
		}
	} elseif ( 'core/media-text' === $name ) {
		$p = new WP_HTML_Tag_Processor( $block_content );
		if ( $p->next_tag( array( 'class_name' => 'wp-block-media-text' ) ) ) {
			$p->remove_class( 'is-stacked-on-mobile' );
			$block_content = $p->get_updated_html();
		}
	}

	return $block_content;
}
add_filter( 'render_block', 'mhp_filter_block', 10, 2 );

/**
 * 狭い画面でも崩れないようにする補助CSS。
 * テーマ側のCSSで折り返しが強制されている場合にも横並びを維持します。
 */
function mhp_enqueue_css() {
	if ( ! mhp_should_apply() ) {
		return;
	}

	$css = '
@media (max-width: 781px) {
	.wp-block-columns.is-not-stacked-on-mobile {
		flex-wrap: nowrap !important;
		gap: 0.75em;
	}
	.wp-block-columns.is-not-stacked-on-mobile > .wp-block-column {
		min-width: 0;
		overflow-wrap: anywhere;
	}
	.wp-block-columns.is-not-stacked-on-mobile > .wp-block-column:not([style*="flex-basis"]) {
		flex-basis: 0 !important;
		flex-grow: 1 !important;
	}
	.wp-block-columns.is-not-stacked-on-mobile img {
		max-width: 100%;
		height: auto;
	}
}';

	wp_register_style( 'mhp-style', false, array(), '1.0.0' );
	wp_enqueue_style( 'mhp-style' );
	wp_add_inline_style( 'mhp-style', $css );
}
add_action( 'wp_enqueue_scripts', 'mhp_enqueue_css', 20 );
