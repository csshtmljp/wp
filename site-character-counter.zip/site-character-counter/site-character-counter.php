<?php
/**
 * Plugin Name: サイト文字数カウンター (Site Character Counter)
 * Description: 投稿(記事)単体・投稿全体・固定ページ単体・固定ページ全体・サイト全体の文字数をそれぞれ集計して表示します。
 * Version:     1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SCC_Plugin {

	const META = '_scc_char_count';
	const OPT  = 'scc_settings';
	const SLUG = 'scc-character-counter';

	public static function init() {
		add_action( 'save_post', array( __CLASS__, 'on_save_post' ), 20, 2 );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_actions' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_columns' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'sort_by_count' ) );
		add_shortcode( 'scc_count', array( __CLASS__, 'shortcode' ) );
	}

	/* ---------------------------------------------------------------------
	 * 設定
	 * ------------------------------------------------------------------- */

	public static function settings() {
		$defaults = array(
			'include_title' => 0,                 // タイトルを文字数に含める
			'count_spaces'  => 0,                 // 空白を文字数に含める
			'statuses'      => array( 'publish' ), // 集計対象のステータス
			'include_cpt'   => 0,                 // カスタム投稿タイプをサイト全体に含める
		);
		$opt = get_option( self::OPT, array() );
		$opt = wp_parse_args( is_array( $opt ) ? $opt : array(), $defaults );
		if ( empty( $opt['statuses'] ) || ! is_array( $opt['statuses'] ) ) {
			$opt['statuses'] = array( 'publish' );
		}
		return $opt;
	}

	public static function available_statuses() {
		return array(
			'publish' => '公開済み',
			'future'  => '予約済み',
			'private' => '非公開',
			'pending' => 'レビュー待ち',
			'draft'   => '下書き',
		);
	}

	/** サイト全体の集計対象となる投稿タイプ */
	public static function site_types() {
		$s = self::settings();
		if ( ! empty( $s['include_cpt'] ) ) {
			$types = get_post_types( array( 'public' => true ), 'names' );
			unset( $types['attachment'] );
			return array_values( $types );
		}
		return array( 'post', 'page' );
	}

	/* ---------------------------------------------------------------------
	 * 文字数の計算
	 * ------------------------------------------------------------------- */

	public static function count_raw( $title, $content ) {
		$s    = self::settings();
		$text = (string) $content;
		$text = strip_shortcodes( $text );
		$text = wp_strip_all_tags( $text ); // HTMLタグ・ブロックコメント・script/style を除去
		if ( ! empty( $s['include_title'] ) ) {
			$text = wp_strip_all_tags( (string) $title ) . $text;
		}
		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

		if ( ! empty( $s['count_spaces'] ) ) {
			$text = preg_replace( '/[\r\n\t]+/u', '', $text ); // 改行とタブのみ除外
		} else {
			$text = preg_replace( '/[\s\x{00A0}\x{3000}]+/u', '', $text ); // 全角スペース含め空白を除外
		}
		if ( null === $text ) {
			return 0;
		}
		if ( function_exists( 'mb_strlen' ) ) {
			return (int) mb_strlen( $text, 'UTF-8' );
		}
		return (int) preg_match_all( '/./us', $text );
	}

	/** 単体の文字数(キャッシュがなければ計算して保存) */
	public static function get_count( $post_id ) {
		$meta = get_post_meta( $post_id, self::META, true );
		if ( '' !== $meta ) {
			return (int) $meta;
		}
		$post = get_post( $post_id );
		if ( ! $post ) {
			return 0;
		}
		$count = self::count_raw( $post->post_title, $post->post_content );
		update_post_meta( $post_id, self::META, $count );
		return $count;
	}

	public static function on_save_post( $post_id, $post ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, self::META, self::count_raw( $post->post_title, $post->post_content ) );
	}

	private static function in_placeholders( $items ) {
		return implode( ',', array_fill( 0, count( $items ), '%s' ) );
	}

	/** まだ文字数が保存されていない投稿を計算して埋める */
	public static function fill_missing( $types ) {
		global $wpdb;
		$types = array_values( (array) $types );
		if ( ! $types ) {
			return;
		}
		$statuses = array_keys( self::available_statuses() );
		$sql      = "SELECT p.ID FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = %s
			WHERE m.post_id IS NULL
			AND p.post_type IN (" . self::in_placeholders( $types ) . ')
			AND p.post_status IN (' . self::in_placeholders( $statuses ) . ')';
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$ids = $wpdb->get_col( $wpdb->prepare( $sql, array_merge( array( self::META ), $types, $statuses ) ) );
		if ( ! $ids ) {
			return;
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore
		}
		foreach ( array_chunk( array_map( 'intval', $ids ), 200 ) as $chunk ) {
			$list = implode( ',', $chunk );
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$rows = $wpdb->get_results( "SELECT ID, post_title, post_content FROM {$wpdb->posts} WHERE ID IN ($list)" );
			foreach ( $rows as $row ) {
				update_post_meta( (int) $row->ID, self::META, self::count_raw( $row->post_title, $row->post_content ) );
			}
		}
	}

	/** 指定投稿タイプの件数と合計文字数 */
	public static function totals( $types ) {
		global $wpdb;
		$types = array_values( (array) $types );
		if ( ! $types ) {
			return array( 'items' => 0, 'chars' => 0 );
		}
		self::fill_missing( $types );
		$s        = self::settings();
		$statuses = array_values( $s['statuses'] );
		$sql      = "SELECT COUNT(*) AS items, COALESCE(SUM(CAST(m.meta_value AS UNSIGNED)),0) AS chars
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = %s
			WHERE p.post_type IN (" . self::in_placeholders( $types ) . ')
			AND p.post_status IN (' . self::in_placeholders( $statuses ) . ')';
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( $sql, array_merge( array( self::META ), $types, $statuses ) ) );
		return array(
			'items' => $row ? (int) $row->items : 0,
			'chars' => $row ? (int) $row->chars : 0,
		);
	}

	/* ---------------------------------------------------------------------
	 * 投稿一覧・固定ページ一覧の「文字数」列
	 * ------------------------------------------------------------------- */

	public static function register_columns() {
		foreach ( self::site_types() as $type ) {
			add_filter( "manage_{$type}_posts_columns", array( __CLASS__, 'add_column' ) );
			add_action( "manage_{$type}_posts_custom_column", array( __CLASS__, 'render_column' ), 10, 2 );
			add_filter( "manage_edit-{$type}_sortable_columns", array( __CLASS__, 'sortable_column' ) );
		}
	}

	public static function add_column( $columns ) {
		$columns['scc_count'] = '文字数';
		return $columns;
	}

	public static function render_column( $column, $post_id ) {
		if ( 'scc_count' === $column ) {
			echo esc_html( number_format_i18n( self::get_count( $post_id ) ) );
		}
	}

	public static function sortable_column( $columns ) {
		$columns['scc_count'] = 'scc_count';
		return $columns;
	}

	public static function sort_by_count( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || 'scc_count' !== $query->get( 'orderby' ) ) {
			return;
		}
		$type = $query->get( 'post_type' );
		self::fill_missing( $type ? (array) $type : array( 'post' ) );
		$query->set( 'meta_key', self::META );
		$query->set( 'orderby', 'meta_value_num' );
	}

	/* ---------------------------------------------------------------------
	 * 管理画面
	 * ------------------------------------------------------------------- */

	public static function admin_menu() {
		add_menu_page(
			'文字数カウンター',
			'文字数カウンター',
			'edit_posts',
			self::SLUG,
			array( __CLASS__, 'render_page' ),
			'dashicons-editor-spellcheck',
			81
		);
	}

	public static function handle_actions() {
		if ( empty( $_POST['scc_action'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( 'scc_action' );
		$action = sanitize_key( wp_unslash( $_POST['scc_action'] ) );

		if ( 'save' === $action ) {
			$allowed  = array_keys( self::available_statuses() );
			$statuses = isset( $_POST['statuses'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['statuses'] ) ) : array();
			$statuses = array_values( array_intersect( $allowed, $statuses ) );
			update_option(
				self::OPT,
				array(
					'include_title' => empty( $_POST['include_title'] ) ? 0 : 1,
					'count_spaces'  => empty( $_POST['count_spaces'] ) ? 0 : 1,
					'include_cpt'   => empty( $_POST['include_cpt'] ) ? 0 : 1,
					'statuses'      => $statuses ? $statuses : array( 'publish' ),
				)
			);
		}
		// 設定変更時・再集計時は保存済みの文字数を破棄して計算し直す
		delete_post_meta_by_key( self::META );

		wp_safe_redirect( add_query_arg( array( 'page' => self::SLUG, 'scc_done' => $action ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function render_page() {
		global $wpdb;
		$s          = self::settings();
		$site_types = self::site_types();

		$post_total = self::totals( array( 'post' ) );
		$page_total = self::totals( array( 'page' ) );
		$site_total = self::totals( $site_types );

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'post';
		if ( ! in_array( $tab, $site_types, true ) ) {
			$tab = 'post';
		}
		$orderby = isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : 'chars';
		$order   = ( isset( $_GET['order'] ) && 'asc' === strtolower( sanitize_key( wp_unslash( $_GET['order'] ) ) ) ) ? 'ASC' : 'DESC';
		$paged   = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
		$done    = isset( $_GET['scc_done'] ) ? sanitize_key( wp_unslash( $_GET['scc_done'] ) ) : '';
		// phpcs:enable

		$order_cols = array(
			'chars' => 'chars',
			'title' => 'p.post_title',
			'date'  => 'p.post_date',
		);
		if ( ! isset( $order_cols[ $orderby ] ) ) {
			$orderby = 'chars';
		}
		$per_page = 50;
		$offset   = ( $paged - 1 ) * $per_page;
		$statuses = array_values( $s['statuses'] );

		$tab_total = self::totals( array( $tab ) );
		$sql       = "SELECT p.ID, p.post_title, p.post_status, p.post_date, CAST(m.meta_value AS UNSIGNED) AS chars
			FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = %s
			WHERE p.post_type = %s AND p.post_status IN (" . self::in_placeholders( $statuses ) . ")
			ORDER BY {$order_cols[ $orderby ]} {$order}, p.ID DESC
			LIMIT %d OFFSET %d";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( array( self::META, $tab ), $statuses, array( $per_page, $offset ) ) ) );

		$base_url    = add_query_arg( array( 'page' => self::SLUG, 'tab' => $tab ), admin_url( 'admin.php' ) );
		$total_pages = (int) ceil( $tab_total['items'] / $per_page );
		$status_lbl  = self::available_statuses();
		?>
		<div class="wrap">
			<h1>文字数カウンター</h1>

			<?php if ( 'save' === $done ) : ?>
				<div class="notice notice-success is-dismissible"><p>設定を保存し、文字数を再集計しました。</p></div>
			<?php elseif ( 'recount' === $done ) : ?>
				<div class="notice notice-success is-dismissible"><p>文字数を再集計しました。</p></div>
			<?php endif; ?>

			<style>
				.scc-cards{display:flex;flex-wrap:wrap;gap:16px;margin:16px 0 24px}
				.scc-card{background:#fff;border:1px solid #c3c4c7;border-left:4px solid #2271b1;padding:16px 20px;min-width:220px;flex:1}
				.scc-card h2{margin:0 0 8px;font-size:14px;color:#50575e}
				.scc-card .scc-num{font-size:28px;font-weight:600;line-height:1.2}
				.scc-card .scc-sub{color:#646970;margin-top:6px}
				.scc-card.scc-site{border-left-color:#00a32a}
				.scc-table .column-chars{width:140px;text-align:right}
				.scc-table .column-status{width:120px}
				.scc-table .column-date{width:160px}
				.scc-settings{background:#fff;border:1px solid #c3c4c7;padding:4px 20px 16px;margin-top:28px;max-width:760px}
			</style>

			<div class="scc-cards">
				<?php
				self::card( '投稿(記事)全体', $post_total, '' );
				self::card( '固定ページ全体', $page_total, '' );
				self::card( 'サイト全体', $site_total, 'scc-site' );
				?>
			</div>

			<h2 class="nav-tab-wrapper">
				<?php
				foreach ( $site_types as $type ) :
					$obj   = get_post_type_object( $type );
					$label = $obj ? $obj->labels->name : $type;
					$url   = add_query_arg( array( 'page' => self::SLUG, 'tab' => $type ), admin_url( 'admin.php' ) );
					?>
					<a class="nav-tab <?php echo $tab === $type ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>">
						<?php echo esc_html( $label ); ?>(単体)
					</a>
				<?php endforeach; ?>
			</h2>

			<p>
				<?php
				printf(
					'%s 件 / 合計 %s 文字 / 平均 %s 文字',
					esc_html( number_format_i18n( $tab_total['items'] ) ),
					esc_html( number_format_i18n( $tab_total['chars'] ) ),
					esc_html( number_format_i18n( $tab_total['items'] ? round( $tab_total['chars'] / $tab_total['items'] ) : 0 ) )
				);
				?>
			</p>

			<table class="wp-list-table widefat fixed striped scc-table">
				<thead>
					<tr>
						<th><?php self::sort_link( 'タイトル', 'title', $orderby, $order, $base_url ); ?></th>
						<th class="column-status">状態</th>
						<th class="column-date"><?php self::sort_link( '日付', 'date', $orderby, $order, $base_url ); ?></th>
						<th class="column-chars"><?php self::sort_link( '文字数', 'chars', $orderby, $order, $base_url ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="4">対象のコンテンツがありません。</td></tr>
				<?php endif; ?>
				<?php foreach ( $rows as $row ) : ?>
					<?php
					$title = '' !== $row->post_title ? $row->post_title : '(タイトルなし)';
					$edit  = get_edit_post_link( (int) $row->ID );
					?>
					<tr>
						<td>
							<?php if ( $edit ) : ?>
								<a href="<?php echo esc_url( $edit ); ?>"><strong><?php echo esc_html( $title ); ?></strong></a>
							<?php else : ?>
								<strong><?php echo esc_html( $title ); ?></strong>
							<?php endif; ?>
						</td>
						<td class="column-status"><?php echo esc_html( isset( $status_lbl[ $row->post_status ] ) ? $status_lbl[ $row->post_status ] : $row->post_status ); ?></td>
						<td class="column-date"><?php echo esc_html( mysql2date( 'Y/m/d H:i', $row->post_date ) ); ?></td>
						<td class="column-chars"><?php echo esc_html( number_format_i18n( (int) $row->chars ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $total_pages > 1 ) : ?>
				<div class="tablenav bottom"><div class="tablenav-pages">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'    => add_query_arg( array( 'paged' => '%#%', 'orderby' => $orderby, 'order' => strtolower( $order ) ), $base_url ),
								'format'  => '',
								'current' => $paged,
								'total'   => $total_pages,
							)
						)
					);
					?>
				</div></div>
			<?php endif; ?>

			<?php if ( current_user_can( 'manage_options' ) ) : ?>
			<div class="scc-settings">
				<h2>設定</h2>
				<form method="post">
					<?php wp_nonce_field( 'scc_action' ); ?>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row">数え方</th>
							<td>
								<label><input type="checkbox" name="include_title" value="1" <?php checked( $s['include_title'], 1 ); ?>> タイトルを文字数に含める</label><br>
								<label><input type="checkbox" name="count_spaces" value="1" <?php checked( $s['count_spaces'], 1 ); ?>> 空白(半角・全角スペース)を文字数に含める</label>
								<p class="description">HTMLタグ・ショートコード・改行は常に除外されます。</p>
							</td>
						</tr>
						<tr>
							<th scope="row">集計対象の状態</th>
							<td>
								<?php foreach ( $status_lbl as $key => $label ) : ?>
									<label style="margin-right:12px"><input type="checkbox" name="statuses[]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $s['statuses'], true ) ); ?>> <?php echo esc_html( $label ); ?></label>
								<?php endforeach; ?>
							</td>
						</tr>
						<tr>
							<th scope="row">サイト全体の範囲</th>
							<td>
								<label><input type="checkbox" name="include_cpt" value="1" <?php checked( $s['include_cpt'], 1 ); ?>> 公開カスタム投稿タイプもサイト全体に含める</label>
								<p class="description">オフの場合、サイト全体 = 投稿全体 + 固定ページ全体 です。</p>
							</td>
						</tr>
					</table>
					<p>
						<button type="submit" name="scc_action" value="save" class="button button-primary">設定を保存</button>
						<button type="submit" name="scc_action" value="recount" class="button">全件を再集計</button>
					</p>
				</form>
				<p class="description">
					ショートコード: <code>[scc_count]</code>(表示中の記事・ページ単体) /
					<code>[scc_count scope="posts"]</code>(投稿全体) /
					<code>[scc_count scope="pages"]</code>(固定ページ全体) /
					<code>[scc_count scope="site"]</code>(サイト全体)
				</p>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function card( $title, $total, $class ) {
		?>
		<div class="scc-card <?php echo esc_attr( $class ); ?>">
			<h2><?php echo esc_html( $title ); ?></h2>
			<div class="scc-num"><?php echo esc_html( number_format_i18n( $total['chars'] ) ); ?> 文字</div>
			<div class="scc-sub">
				<?php echo esc_html( number_format_i18n( $total['items'] ) ); ?> 件 /
				平均 <?php echo esc_html( number_format_i18n( $total['items'] ? round( $total['chars'] / $total['items'] ) : 0 ) ); ?> 文字
			</div>
		</div>
		<?php
	}

	private static function sort_link( $label, $key, $orderby, $order, $base_url ) {
		$next  = ( $orderby === $key && 'DESC' === $order ) ? 'asc' : 'desc';
		$arrow = $orderby === $key ? ( 'DESC' === $order ? ' ▼' : ' ▲' ) : '';
		printf(
			'<a href="%s">%s%s</a>',
			esc_url( add_query_arg( array( 'orderby' => $key, 'order' => $next ), $base_url ) ),
			esc_html( $label ),
			esc_html( $arrow )
		);
	}

	/* ---------------------------------------------------------------------
	 * ショートコード
	 * ------------------------------------------------------------------- */

	public static function shortcode( $atts ) {
		$atts = shortcode_atts( array( 'scope' => 'current' ), $atts, 'scc_count' );
		switch ( $atts['scope'] ) {
			case 'posts':
				$n = self::totals( array( 'post' ) )['chars'];
				break;
			case 'pages':
				$n = self::totals( array( 'page' ) )['chars'];
				break;
			case 'site':
				$n = self::totals( self::site_types() )['chars'];
				break;
			default:
				$id = get_the_ID();
				$n  = $id ? self::get_count( $id ) : 0;
		}
		return esc_html( number_format_i18n( $n ) );
	}

	/* ---------------------------------------------------------------------
	 * アンインストール
	 * ------------------------------------------------------------------- */

	public static function uninstall() {
		delete_post_meta_by_key( self::META );
		delete_option( self::OPT );
	}
}

SCC_Plugin::init();
register_uninstall_hook( __FILE__, array( 'SCC_Plugin', 'uninstall' ) );
