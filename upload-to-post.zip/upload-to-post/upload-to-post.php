<?php
/**
 * Plugin Name:       Upload to Post
 * Description:       投稿・固定ページの編集画面からファイル(Markdown / HTML / テキスト)をアップロードして、タイトルと本文に反映します。複数ファイルからの一括作成にも対応。
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Upload to Post
 * License:           GPL-2.0-or-later
 * Text Domain:       upload-to-post
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Upload_To_Post {

	const VERSION   = '1.0.0';
	const NONCE     = 'utp_upload';
	const MAX_BYTES = 2097152; // 2MB
	const MAX_FILES = 50;

	public static function init() {
		$self = new self();
		add_action( 'add_meta_boxes', array( $self, 'add_meta_box' ) );
		add_action( 'admin_enqueue_scripts', array( $self, 'enqueue' ) );
		add_action( 'wp_ajax_utp_apply', array( $self, 'ajax_apply' ) );
		add_action( 'admin_menu', array( $self, 'add_menus' ) );
	}

	/** 対象の投稿タイプ(フィルターで追加可能) */
	private static function post_types() {
		return (array) apply_filters( 'utp_post_types', array( 'post', 'page' ) );
	}

	private static function extensions() {
		return array( 'md', 'markdown', 'txt', 'html', 'htm' );
	}

	/* ------------------------------------------------------------------
	 * 編集画面のメタボックス
	 * ---------------------------------------------------------------- */

	public function add_meta_box() {
		foreach ( self::post_types() as $type ) {
			add_meta_box(
				'utp-box',
				'ファイルから反映',
				array( $this, 'render_meta_box' ),
				$type,
				'side',
				'high'
			);
		}
	}

	public function render_meta_box() {
		$accept = '.' . implode( ',.', self::extensions() );
		?>
		<div id="utp-wrap">
			<p style="margin-top:0">Markdown・HTML・テキストのファイルを選ぶと、この<?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ); ?>に内容を反映します。</p>
			<p><input type="file" id="utp-file" accept="<?php echo esc_attr( $accept ); ?>" style="max-width:100%"></p>
			<p>
				<label><input type="radio" class="utp-mode" value="replace" checked> 本文を置き換える</label><br>
				<label><input type="radio" class="utp-mode" value="append"> 本文の末尾に追加する</label>
			</p>
			<p><label><input type="checkbox" id="utp-title" checked> タイトルも反映する</label></p>
			<p><button type="button" class="button button-primary" id="utp-apply">アップロードして反映</button></p>
			<p id="utp-msg" role="status" style="margin-bottom:0"></p>
			<p class="description">反映すると画面を再読み込みします。保存していない編集内容は失われます。反映前の内容はリビジョンから戻せます。</p>
		</div>
		<?php
	}

	public function enqueue( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->post_type, self::post_types(), true ) ) {
			return;
		}
		global $post;
		if ( ! $post ) {
			return;
		}

		wp_register_script( 'utp-admin', false, array(), self::VERSION, true );
		wp_enqueue_script( 'utp-admin' );
		wp_add_inline_script(
			'utp-admin',
			'var UTP=' . wp_json_encode(
				array(
					'ajax'   => admin_url( 'admin-ajax.php' ),
					'nonce'  => wp_create_nonce( self::NONCE ),
					'postId' => (int) $post->ID,
				)
			) . ';' . $this->script()
		);
	}

	private function script() {
		return <<<'JS'
(function(){
	function ready(fn){ if(document.readyState!=='loading'){fn();} else {document.addEventListener('DOMContentLoaded',fn);} }
	ready(function(){
		document.addEventListener('change',function(e){
			if(!e.target.classList||!e.target.classList.contains('utp-mode')){return;}
			var all=document.querySelectorAll('.utp-mode');
			for(var i=0;i<all.length;i++){ all[i].checked=(all[i]===e.target); }
		});
		document.addEventListener('click',function(e){
			var btn=e.target.closest?e.target.closest('#utp-apply'):null;
			if(!btn){return;}
			var file=document.getElementById('utp-file');
			var msg=document.getElementById('utp-msg');
			var title=document.getElementById('utp-title');
			var modeEl=document.querySelector('.utp-mode:checked');
			function say(t,err){ msg.textContent=t; msg.style.color=err?'#b32d2e':''; }
			if(!file||!file.files.length){ say('ファイルを選択してください。',true); return; }
			var fd=new FormData();
			fd.append('action','utp_apply');
			fd.append('_wpnonce',UTP.nonce);
			fd.append('post_id',UTP.postId);
			fd.append('mode',modeEl?modeEl.value:'replace');
			fd.append('use_title',title&&title.checked?'1':'0');
			fd.append('utp_file',file.files[0]);
			btn.disabled=true;
			say('反映しています…');
			fetch(UTP.ajax,{method:'POST',body:fd,credentials:'same-origin'})
				.then(function(r){ return r.json(); })
				.then(function(r){
					if(r&&r.success){
						say('反映しました。画面を再読み込みします…');
						window.location.href=r.data.url;
					}else{
						btn.disabled=false;
						say((r&&r.data&&r.data.message)||'反映できませんでした。',true);
					}
				})
				.catch(function(){
					btn.disabled=false;
					say('通信に失敗しました。ファイルサイズとログイン状態を確認して、もう一度試してください。',true);
				});
		});
	});
})();
JS;
	}

	public function ajax_apply() {
		check_ajax_referer( self::NONCE );

		$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		$post    = $post_id ? get_post( $post_id ) : null;

		if ( ! $post || ! in_array( $post->post_type, self::post_types(), true ) ) {
			wp_send_json_error( array( 'message' => '対象の投稿が見つかりません。' ) );
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => 'この投稿を編集する権限がありません。' ) );
		}
		if ( empty( $_FILES['utp_file'] ) ) {
			wp_send_json_error( array( 'message' => 'ファイルが送信されていません。' ) );
		}

		$parsed = $this->read_upload( $_FILES['utp_file'] );
		if ( is_wp_error( $parsed ) ) {
			wp_send_json_error( array( 'message' => $parsed->get_error_message() ) );
		}

		$mode    = ( isset( $_POST['mode'] ) && 'append' === $_POST['mode'] ) ? 'append' : 'replace';
		$content = $parsed['content'];
		if ( 'append' === $mode && '' !== trim( $post->post_content ) ) {
			$content = $post->post_content . "\n\n" . $content;
		}

		$data = array(
			'ID'           => $post_id,
			'post_content' => $content,
		);
		if ( ! empty( $_POST['use_title'] ) && '' !== $parsed['title'] ) {
			$data['post_title'] = $parsed['title'];
		}
		if ( ! empty( $parsed['meta']['excerpt'] ) ) {
			$data['post_excerpt'] = $parsed['meta']['excerpt'];
		}
		if ( ! empty( $parsed['meta']['slug'] ) ) {
			$data['post_name'] = sanitize_title( $parsed['meta']['slug'] );
		}
		// 新規作成画面(自動下書き)の場合は下書きとして確定させる。
		if ( 'auto-draft' === $post->post_status ) {
			$data['post_status'] = 'draft';
			if ( empty( $data['post_title'] ) ) {
				$data['post_title'] = $parsed['title'];
			}
		}

		$result = wp_update_post( wp_slash( $data ), true );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => '保存に失敗しました: ' . $result->get_error_message() ) );
		}

		// 古い自動保存が残っていると、再読み込み後に復元を促されるため削除する。
		$autosave = wp_get_post_autosave( $post_id, get_current_user_id() );
		if ( $autosave ) {
			wp_delete_post_revision( $autosave->ID );
		}

		wp_send_json_success(
			array(
				'url' => add_query_arg(
					array(
						'post'   => $post_id,
						'action' => 'edit',
					),
					admin_url( 'post.php' )
				),
			)
		);
	}

	/* ------------------------------------------------------------------
	 * 一括作成ページ
	 * ---------------------------------------------------------------- */

	public function add_menus() {
		foreach ( self::post_types() as $type ) {
			$obj = get_post_type_object( $type );
			if ( ! $obj ) {
				continue;
			}
			$parent = ( 'post' === $type ) ? 'edit.php' : 'edit.php?post_type=' . $type;
			add_submenu_page(
				$parent,
				'アップロードで作成',
				'アップロードで作成',
				$obj->cap->edit_posts,
				'utp-bulk-' . $type,
				array( $this, 'render_bulk_page' )
			);
		}
	}

	public function render_bulk_page() {
		$page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		$type = substr( $page, strlen( 'utp-bulk-' ) );
		$obj  = in_array( $type, self::post_types(), true ) ? get_post_type_object( $type ) : null;

		if ( ! $obj || ! current_user_can( $obj->cap->edit_posts ) ) {
			wp_die( 'このページを表示する権限がありません。' );
		}

		$can_publish = current_user_can( $obj->cap->publish_posts );
		$results     = null;

		if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset( $_POST['utp_bulk'] ) ) {
			check_admin_referer( self::NONCE );
			$status = ( $can_publish && isset( $_POST['utp_status'] ) && 'publish' === $_POST['utp_status'] ) ? 'publish' : 'draft';
			$results = $this->handle_bulk( $type, $status );
		}

		$accept = '.' . implode( ',.', self::extensions() );
		?>
		<div class="wrap">
			<h1><?php echo esc_html( $obj->labels->name ); ?>をアップロードで作成</h1>
			<p>ファイル1つにつき1件作成します。対応形式は Markdown(.md)、HTML(.html)、テキスト(.txt)で、1ファイル2MBまで、一度に<?php echo (int) self::MAX_FILES; ?>件までです。</p>

			<?php if ( is_array( $results ) ) : ?>
				<div class="notice notice-info"><p>
					作成 <?php echo (int) count( $results['ok'] ); ?> 件、失敗 <?php echo (int) count( $results['ng'] ); ?> 件
				</p></div>
				<?php if ( $results['ok'] ) : ?>
					<h2>作成したもの</h2>
					<ul class="ul-disc">
						<?php foreach ( $results['ok'] as $row ) : ?>
							<li><a href="<?php echo esc_url( get_edit_post_link( $row['id'], 'raw' ) ); ?>"><?php echo esc_html( $row['title'] ); ?></a>(<?php echo esc_html( $row['file'] ); ?>)</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<?php if ( $results['ng'] ) : ?>
					<h2>反映できなかったもの</h2>
					<ul class="ul-disc">
						<?php foreach ( $results['ng'] as $row ) : ?>
							<li><?php echo esc_html( $row['file'] ); ?>: <?php echo esc_html( $row['message'] ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			<?php endif; ?>

			<form method="post" enctype="multipart/form-data">
				<?php wp_nonce_field( self::NONCE ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="utp-files">ファイル</label></th>
						<td><input type="file" id="utp-files" name="utp_files[]" multiple accept="<?php echo esc_attr( $accept ); ?>" required></td>
					</tr>
					<tr>
						<th scope="row"><label for="utp-status">作成後の状態</label></th>
						<td>
							<select id="utp-status" name="utp_status">
								<option value="draft">下書き</option>
								<?php if ( $can_publish ) : ?>
									<option value="publish">公開</option>
								<?php endif; ?>
							</select>
						</td>
					</tr>
				</table>
				<?php submit_button( 'アップロードして作成', 'primary', 'utp_bulk' ); ?>
			</form>

			<h2>ファイルの書き方</h2>
			<p>Markdownとテキストは、先頭に次のような設定欄を書くと反映されます(省略可)。設定欄がない場合、タイトルは最初の見出し、なければファイル名になります。</p>
			<pre style="background:#fff;border:1px solid #c3c4c7;padding:12px;max-width:520px;overflow:auto">---
title: 記事のタイトル
slug: my-post
excerpt: 抜粋の文章
tags: タグ1, タグ2
categories: カテゴリー1
---

# 見出し

本文をここに書きます。</pre>
		</div>
		<?php
	}

	private function handle_bulk( $type, $status ) {
		$out = array(
			'ok' => array(),
			'ng' => array(),
		);
		if ( empty( $_FILES['utp_files'] ) || ! is_array( $_FILES['utp_files']['name'] ) ) {
			return $out;
		}

		$files = $_FILES['utp_files'];
		$count = min( count( $files['name'] ), self::MAX_FILES );

		for ( $i = 0; $i < $count; $i++ ) {
			$file = array(
				'name'     => $files['name'][ $i ],
				'tmp_name' => $files['tmp_name'][ $i ],
				'error'    => $files['error'][ $i ],
				'size'     => $files['size'][ $i ],
			);
			$label  = sanitize_file_name( $file['name'] );
			$parsed = $this->read_upload( $file );
			if ( is_wp_error( $parsed ) ) {
				$out['ng'][] = array(
					'file'    => $label,
					'message' => $parsed->get_error_message(),
				);
				continue;
			}

			$data = array(
				'post_type'    => $type,
				'post_status'  => $status,
				'post_title'   => $parsed['title'],
				'post_content' => $parsed['content'],
				'post_author'  => get_current_user_id(),
			);
			if ( ! empty( $parsed['meta']['excerpt'] ) ) {
				$data['post_excerpt'] = $parsed['meta']['excerpt'];
			}
			if ( ! empty( $parsed['meta']['slug'] ) ) {
				$data['post_name'] = sanitize_title( $parsed['meta']['slug'] );
			}

			$id = wp_insert_post( wp_slash( $data ), true );
			if ( is_wp_error( $id ) ) {
				$out['ng'][] = array(
					'file'    => $label,
					'message' => $id->get_error_message(),
				);
				continue;
			}

			if ( 'post' === $type ) {
				$this->assign_terms( $id, $parsed['meta'] );
			}

			$out['ok'][] = array(
				'id'    => $id,
				'title' => $parsed['title'],
				'file'  => $label,
			);
		}
		return $out;
	}

	private function assign_terms( $post_id, $meta ) {
		if ( ! empty( $meta['tags'] ) && current_user_can( 'assign_post_tags' ) ) {
			wp_set_post_tags( $post_id, $this->split_list( $meta['tags'] ) );
		}
		if ( ! empty( $meta['categories'] ) && current_user_can( 'assign_categories' ) ) {
			$ids = array();
			foreach ( $this->split_list( $meta['categories'] ) as $name ) {
				$term = get_term_by( 'name', $name, 'category' );
				if ( $term ) {
					$ids[] = (int) $term->term_id;
				} elseif ( current_user_can( 'manage_categories' ) ) {
					$new = wp_insert_term( $name, 'category' );
					if ( ! is_wp_error( $new ) ) {
						$ids[] = (int) $new['term_id'];
					}
				}
			}
			if ( $ids ) {
				wp_set_post_categories( $post_id, $ids );
			}
		}
	}

	private function split_list( $value ) {
		$items = preg_split( '/[,、]/u', trim( $value, " \t[]" ) );
		$items = array_map(
			static function ( $v ) {
				return sanitize_text_field( trim( $v, " \t\"'" ) );
			},
			(array) $items
		);
		return array_values( array_filter( $items, 'strlen' ) );
	}

	/* ------------------------------------------------------------------
	 * ファイルの読み取りと変換
	 * ---------------------------------------------------------------- */

	/**
	 * アップロードされたファイルを検証して、タイトル・本文・設定欄に分解する。
	 *
	 * @return array|WP_Error
	 */
	private function read_upload( $file ) {
		$name = isset( $file['name'] ) ? (string) $file['name'] : '';

		if ( ! empty( $file['error'] ) ) {
			if ( in_array( (int) $file['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ) {
				return new WP_Error( 'utp_size', 'ファイルが大きすぎます。2MB以下にしてください。' );
			}
			return new WP_Error( 'utp_upload', 'アップロードに失敗しました。もう一度試してください。' );
		}
		if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'utp_upload', 'アップロードされたファイルを確認できませんでした。' );
		}
		if ( (int) $file['size'] > self::MAX_BYTES ) {
			return new WP_Error( 'utp_size', 'ファイルが大きすぎます。2MB以下にしてください。' );
		}

		$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, self::extensions(), true ) ) {
			return new WP_Error( 'utp_ext', '対応していない形式です。.md / .html / .txt のファイルを選んでください。' );
		}

		$raw = file_get_contents( $file['tmp_name'] );
		if ( false === $raw || '' === trim( $raw ) ) {
			return new WP_Error( 'utp_empty', 'ファイルの中身が空です。' );
		}

		$text     = $this->to_utf8( $raw );
		$fallback = sanitize_text_field( pathinfo( $name, PATHINFO_FILENAME ) );
		$meta     = array();
		$title    = '';

		if ( in_array( $ext, array( 'html', 'htm' ), true ) ) {
			list( $title, $content ) = $this->parse_html( $text );
		} else {
			list( $meta, $text ) = $this->split_front_matter( $text );
			if ( 'txt' === $ext ) {
				$content = wpautop( esc_html( trim( $text ) ) );
			} else {
				list( $title, $content ) = $this->parse_markdown( $text );
			}
			if ( ! empty( $meta['title'] ) ) {
				$title = $meta['title'];
			}
		}

		$title = sanitize_text_field( $title );
		if ( '' === $title ) {
			$title = $fallback;
		}
		if ( ! current_user_can( 'unfiltered_html' ) ) {
			$content = wp_kses_post( $content );
		}
		if ( isset( $meta['excerpt'] ) ) {
			$meta['excerpt'] = sanitize_textarea_field( $meta['excerpt'] );
		}

		return array(
			'title'   => $title,
			'content' => trim( $content ),
			'meta'    => $meta,
		);
	}

	private function to_utf8( $raw ) {
		// BOMを除去
		if ( 0 === strncmp( $raw, "\xEF\xBB\xBF", 3 ) ) {
			$raw = substr( $raw, 3 );
		}
		if ( function_exists( 'mb_check_encoding' ) && ! mb_check_encoding( $raw, 'UTF-8' ) ) {
			$enc = mb_detect_encoding( $raw, array( 'SJIS-win', 'EUC-JP', 'JIS', 'UTF-16' ), true );
			$raw = mb_convert_encoding( $raw, 'UTF-8', $enc ? $enc : 'SJIS-win' );
		}
		return str_replace( array( "\r\n", "\r" ), "\n", $raw );
	}

	/** 先頭の「--- ... ---」を設定欄として取り出す */
	private function split_front_matter( $text ) {
		$meta = array();
		if ( preg_match( '/\A---\n(.*?)\n---\n?/s', $text, $m ) ) {
			foreach ( explode( "\n", $m[1] ) as $line ) {
				if ( preg_match( '/^([A-Za-z_]+)\s*:\s*(.*)$/', trim( $line ), $kv ) ) {
					$meta[ strtolower( $kv[1] ) ] = trim( $kv[2], " \t\"'" );
				}
			}
			$text = (string) substr( $text, strlen( $m[0] ) );
		}
		return array( $meta, $text );
	}

	private function parse_html( $html ) {
		$title = '';
		if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $html, $m ) ) {
			$title = html_entity_decode( wp_strip_all_tags( $m[1] ), ENT_QUOTES, 'UTF-8' );
		}
		if ( preg_match( '/<body[^>]*>(.*)<\/body>/is', $html, $m ) ) {
			$html = $m[1];
		}
		// スクリプトとスタイルは反映しない。
		$html = preg_replace( '/<(script|style)\b[^>]*>.*?<\/\1>/is', '', $html );
		$html = preg_replace( '/<!DOCTYPE[^>]*>|<\/?(html|head|body)[^>]*>|<meta[^>]*>|<link[^>]*>|<title[^>]*>.*?<\/title>/is', '', $html );

		if ( '' === $title && preg_match( '/<h1[^>]*>(.*?)<\/h1>/is', $html, $m ) ) {
			$title = html_entity_decode( wp_strip_all_tags( $m[1] ), ENT_QUOTES, 'UTF-8' );
			$html  = preg_replace( '/<h1[^>]*>.*?<\/h1>/is', '', $html, 1 );
		}
		return array( $title, trim( $html ) );
	}

	/** 基本的なMarkdownをHTMLに変換する。最初の「# 見出し」はタイトルとして扱う。 */
	private function parse_markdown( $text ) {
		$lines = explode( "\n", $text );
		$html  = array();
		$para  = array();
		$title = '';
		$n     = count( $lines );

		$flush = function () use ( &$para, &$html ) {
			if ( $para ) {
				$html[] = '<p>' . implode( "<br />\n", array_map( array( $this, 'inline' ), $para ) ) . '</p>';
				$para   = array();
			}
		};

		for ( $i = 0; $i < $n; $i++ ) {
			$line = rtrim( $lines[ $i ] );

			// コードブロック
			if ( preg_match( '/^\s*(```|~~~)/', $line, $m ) ) {
				$flush();
				$code = array();
				for ( $i++; $i < $n && ! preg_match( '/^\s*' . preg_quote( $m[1], '/' ) . '\s*$/', $lines[ $i ] ); $i++ ) {
					$code[] = $lines[ $i ];
				}
				$html[] = '<pre><code>' . esc_html( implode( "\n", $code ) ) . '</code></pre>';
				continue;
			}
			// 空行
			if ( '' === trim( $line ) ) {
				$flush();
				continue;
			}
			// 見出し
			if ( preg_match( '/^(#{1,6})\s+(.+?)\s*#*$/', $line, $m ) ) {
				$flush();
				$level = strlen( $m[1] );
				if ( 1 === $level && '' === $title && ! $html ) {
					$title = wp_strip_all_tags( $this->inline( $m[2] ) );
					$title = html_entity_decode( $title, ENT_QUOTES, 'UTF-8' );
					continue;
				}
				$html[] = sprintf( '<h%1$d>%2$s</h%1$d>', $level, $this->inline( $m[2] ) );
				continue;
			}
			// 区切り線
			if ( preg_match( '/^\s*([-*_])(\s*\1){2,}\s*$/', $line ) ) {
				$flush();
				$html[] = '<hr />';
				continue;
			}
			// 引用
			if ( preg_match( '/^\s*>/', $line ) ) {
				$flush();
				$quote = array();
				for ( ; $i < $n && preg_match( '/^\s*>\s?(.*)$/', $lines[ $i ], $q ); $i++ ) {
					$quote[] = $this->inline( $q[1] );
				}
				$i--;
				$html[] = '<blockquote><p>' . implode( "<br />\n", $quote ) . '</p></blockquote>';
				continue;
			}
			// 表
			if ( false !== strpos( $line, '|' ) && $i + 1 < $n && preg_match( '/^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/', $lines[ $i + 1 ] ) ) {
				$flush();
				$head = $this->table_cells( $line );
				$rows = array();
				for ( $i += 2; $i < $n && false !== strpos( $lines[ $i ], '|' ) && '' !== trim( $lines[ $i ] ); $i++ ) {
					$rows[] = $this->table_cells( $lines[ $i ] );
				}
				$i--;
				$t = '<table><thead><tr>';
				foreach ( $head as $cell ) {
					$t .= '<th>' . $this->inline( $cell ) . '</th>';
				}
				$t .= '</tr></thead><tbody>';
				foreach ( $rows as $row ) {
					$t .= '<tr>';
					foreach ( $row as $cell ) {
						$t .= '<td>' . $this->inline( $cell ) . '</td>';
					}
					$t .= '</tr>';
				}
				$html[] = $t . '</tbody></table>';
				continue;
			}
			// 箇条書き・番号つきリスト
			if ( preg_match( '/^\s*([-*+]|\d+[.)])\s+/', $line, $m ) ) {
				$flush();
				$ordered = (bool) preg_match( '/\d/', $m[1] );
				$pattern = $ordered ? '/^\s*\d+[.)]\s+(.*)$/' : '/^\s*[-*+]\s+(.*)$/';
				$items   = array();
				for ( ; $i < $n && preg_match( $pattern, $lines[ $i ], $li ); $i++ ) {
					$items[] = '<li>' . $this->inline( $li[1] ) . '</li>';
				}
				$i--;
				$tag    = $ordered ? 'ol' : 'ul';
				$html[] = "<$tag>\n" . implode( "\n", $items ) . "\n</$tag>";
				continue;
			}

			$para[] = trim( $line );
		}
		$flush();

		return array( $title, implode( "\n\n", $html ) );
	}

	private function table_cells( $line ) {
		$line = trim( $line );
		$line = preg_replace( '/^\||\|$/', '', $line );
		return array_map( 'trim', explode( '|', $line ) );
	}

	/** 行内の装飾(コード・画像・リンク・太字・斜体・打ち消し線) */
	private function inline( $text ) {
		$codes = array();
		$text  = preg_replace_callback(
			'/`([^`]+)`/',
			function ( $m ) use ( &$codes ) {
				$codes[] = '<code>' . esc_html( $m[1] ) . '</code>';
				return "\x1A" . ( count( $codes ) - 1 ) . "\x1A";
			},
			$text
		);

		$text = esc_html( $text );

		$url = static function ( $raw ) {
			return esc_url( html_entity_decode( $raw, ENT_QUOTES, 'UTF-8' ) );
		};
		$text = preg_replace_callback(
			'/!\[([^\]]*)\]\(([^)\s]+)\)/',
			static function ( $m ) use ( $url ) {
				return '<img src="' . $url( $m[2] ) . '" alt="' . esc_attr( html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' ) ) . '" />';
			},
			$text
		);
		$text = preg_replace_callback(
			'/\[([^\]]+)\]\(([^)\s]+)\)/',
			static function ( $m ) use ( $url ) {
				return '<a href="' . $url( $m[2] ) . '">' . $m[1] . '</a>';
			},
			$text
		);
		$text = preg_replace( '/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $text );
		$text = preg_replace( '/__(.+?)__/s', '<strong>$1</strong>', $text );
		$text = preg_replace( '/(?<![*\w])\*(?!\s)(.+?)(?<!\s)\*(?![*\w])/s', '<em>$1</em>', $text );
		$text = preg_replace( '/~~(.+?)~~/s', '<del>$1</del>', $text );

		return preg_replace_callback(
			'/\x1A(\d+)\x1A/',
			static function ( $m ) use ( $codes ) {
				return $codes[ (int) $m[1] ];
			},
			$text
		);
	}
}

Upload_To_Post::init();
