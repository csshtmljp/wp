<?php
/**
 * Plugin Name: 新着情報ティッカーdn
 * Description: 最新投稿・専用のお知らせを横に流して表示。自動更新、カテゴリ指定、一時停止、一覧表示、上部・下部への設置に対応します。
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: dn
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: news-ticker-dn
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class News_Ticker_Dn {
    const VERSION = '1.0.0';
    const OPTION = 'news_ticker_dn_options';
    const TYPE = 'news_notice_dn';
    private static $auto_done = false;

    public static function boot() {
        add_action( 'init', array( __CLASS__, 'register_content' ) );
        add_action( 'init', array( __CLASS__, 'shortcode' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_assets' ) );
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_init', array( __CLASS__, 'settings' ) );
        add_action( 'rest_api_init', array( __CLASS__, 'route' ) );
        add_action( 'wp_body_open', array( __CLASS__, 'auto_top' ), 20 );
        add_action( 'wp_footer', array( __CLASS__, 'auto_bottom' ), 5 );
        add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'links' ) );
    }
    public static function defaults() {
        return array( 'source' => 'posts', 'count' => 8, 'category' => 0, 'speed' => 55, 'direction' => 'left',
            'refresh' => 60, 'date' => true, 'new_days' => 7, 'theme' => 'navy', 'label' => '新着情報', 'placement' => 'manual' );
    }
    private static function integer( $value, $min, $max, $default ) {
        return is_numeric( $value ) && is_scalar( $value ) ? max( $min, min( $max, (int) $value ) ) : $default;
    }
    public static function normalize( $input ) {
        $d = self::defaults();
        $v = is_array( $input ) ? array_merge( $d, $input ) : $d;
        foreach ( array( 'source' => array( 'posts', 'notices', 'both' ), 'theme' => array( 'navy', 'emerald', 'gold' ),
            'direction' => array( 'left', 'right' ), 'placement' => array( 'manual', 'top', 'bottom' ) ) as $key => $allowed ) {
            $v[ $key ] = in_array( $v[ $key ], $allowed, true ) ? $v[ $key ] : $d[ $key ];
        }
        $v['count'] = self::integer( $v['count'], 1, 20, 8 );
        $v['category'] = self::integer( $v['category'], 0, 2147483647, 0 );
        $v['speed'] = self::integer( $v['speed'], 20, 180, 55 );
        $v['new_days'] = self::integer( $v['new_days'], 0, 30, 7 );
        $v['refresh'] = self::integer( $v['refresh'], 0, 3600, 60 );
        if ( $v['refresh'] > 0 ) { $v['refresh'] = max( 30, $v['refresh'] ); }
        $v['date'] = ! in_array( strtolower( is_scalar( $v['date'] ) ? (string) $v['date'] : '' ), array( '', '0', 'no', 'false', 'off' ), true );
        $v['label'] = wp_html_excerpt( sanitize_text_field( is_scalar( $v['label'] ) ? (string) $v['label'] : '' ), 40, '' );
        if ( '' === $v['label'] ) { $v['label'] = $d['label']; }
        return array_intersect_key( $v, $d );
    }
    public static function options() { return self::normalize( get_option( self::OPTION, array() ) ); }
    public static function sanitize_options( $input ) {
        $input = is_array( $input ) ? $input : array();
        $input['date'] = isset( $input['date'] ) && is_scalar( $input['date'] ) && '1' === (string) $input['date'];
        return self::normalize( $input );
    }
    public static function register_content() {
        register_post_type( self::TYPE, array(
            'labels' => array( 'name' => 'お知らせdn', 'singular_name' => 'お知らせdn', 'add_new_item' => 'お知らせdnを追加',
                'edit_item' => 'お知らせdnを編集', 'new_item' => '新しいお知らせdn', 'view_item' => 'お知らせdnを表示', 'search_items' => 'お知らせdnを検索' ),
            'public' => true, 'show_in_rest' => true, 'has_archive' => false, 'menu_icon' => 'dashicons-megaphone',
            'supports' => array( 'title', 'editor', 'revisions' ), 'taxonomies' => array( 'category' ),
            'rewrite' => array( 'slug' => 'news-dn', 'with_front' => false ),
        ) );
    }
    public static function activate() { self::register_content(); flush_rewrite_rules( false ); }
    public static function deactivate() {
        if ( post_type_exists( self::TYPE ) ) { unregister_post_type( self::TYPE ); }
        flush_rewrite_rules( false );
    }
    public static function shortcode() { add_shortcode( 'news_ticker_dn', array( __CLASS__, 'render' ) ); }
    public static function assets() {
        $base = plugin_dir_url( __FILE__ ) . 'assets/';
        wp_enqueue_style( 'news-ticker-dn', $base . 'news-ticker-dn.css', array(), self::VERSION );
        wp_enqueue_script( 'news-ticker-core-dn', $base . 'news-ticker-core-dn.js', array(), self::VERSION, true );
        wp_enqueue_script( 'news-ticker-dn', $base . 'news-ticker-dn.js', array( 'news-ticker-core-dn' ), self::VERSION, true );
    }
    public static function admin_assets( $hook ) { if ( 'settings_page_news-ticker-dn' === $hook ) { self::assets(); } }
    public static function menu() { add_options_page( '新着情報ティッカーdn', '新着情報ティッカーdn', 'manage_options', 'news-ticker-dn', array( __CLASS__, 'admin_page' ) ); }
    public static function settings() {
        register_setting( 'news_ticker_dn_group', self::OPTION, array( 'type' => 'array', 'sanitize_callback' => array( __CLASS__, 'sanitize_options' ), 'default' => self::defaults() ) );
    }
    public static function links( $links ) {
        array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=news-ticker-dn' ) ) . '">設定・使い方</a>' );
        return $links;
    }
    public static function items( $input ) {
        $v = self::normalize( $input );
        $types = 'posts' === $v['source'] ? array( 'post' ) : ( 'notices' === $v['source'] ? array( self::TYPE ) : array( 'post', self::TYPE ) );
        $args = array( 'post_type' => $types, 'post_status' => 'publish', 'has_password' => false, 'posts_per_page' => $v['count'],
            'orderby' => array( 'date' => 'DESC', 'ID' => 'DESC' ), 'ignore_sticky_posts' => true, 'no_found_rows' => true,
            'update_post_meta_cache' => false, 'update_post_term_cache' => false,
            'date_query' => array( array( 'before' => current_time( 'mysql' ), 'inclusive' => true ) ),
        );
        if ( $v['category'] ) { $args['cat'] = $v['category']; }
        $query = new WP_Query( $args );
        $items = array();
        foreach ( $query->posts as $post ) {
            // Guard even if another plugin changes the query results.
            if ( 'publish' !== $post->post_status || '' !== $post->post_password || ! in_array( $post->post_type, $types, true ) || ! is_post_publicly_viewable( $post ) ) { continue; }
            $timestamp = (int) get_post_timestamp( $post, 'date' );
            if ( $timestamp <= 0 || $timestamp > time() ) { continue; }
            $url = esc_url_raw( get_permalink( $post ), array( 'http', 'https' ) );
            if ( ! $url ) { continue; }
            $title = html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' );
            $title = wp_html_excerpt( sanitize_text_field( $title ), 180, '…' );
            $items[] = array( 'id' => (int) $post->ID, 'title' => $title ? $title : '（タイトルなし）', 'url' => $url,
                'date' => wp_date( 'Y.m.d', $timestamp ), 'dateIso' => gmdate( 'c', $timestamp ), 'timestamp' => $timestamp );
            if ( count( $items ) >= $v['count'] ) { break; }
        }
        return $items;
    }
    public static function route() {
        register_rest_route( 'news-ticker-dn/v1', '/items', array(
            'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => array( __CLASS__, 'rest_items' ),
            'args' => array(
                'source' => array( 'type' => 'string', 'enum' => array( 'posts', 'notices', 'both' ), 'default' => 'posts' ),
                'count' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 20, 'default' => 8 ),
                'category' => array( 'type' => 'integer', 'minimum' => 0, 'maximum' => 2147483647, 'default' => 0 ),
            ),
        ) );
    }
    public static function rest_items( $request ) {
        $data = self::items( array( 'source' => $request->get_param( 'source' ), 'count' => $request->get_param( 'count' ), 'category' => $request->get_param( 'category' ) ) );
        $response = new WP_REST_Response( array( 'items' => $data, 'generatedAt' => time() ), 200 );
        $response->header( 'Cache-Control', 'no-store' );
        return $response;
    }
    public static function auto_top() { self::auto_place( 'top' ); }
    public static function auto_bottom() { self::auto_place( 'bottom' ); }
    private static function auto_place( $where ) {
        if ( is_admin() || is_feed() || self::$auto_done || self::options()['placement'] !== $where ) { return; }
        self::$auto_done = true;
        echo '<div class="ntdn-auto ntdn-auto--' . esc_attr( $where ) . '">' . self::render() . '</div>'; // Escaped by render().
    }
    public static function render( $atts = array() ) {
        $v = self::normalize( shortcode_atts( self::options(), $atts, 'news_ticker_dn' ) );
        $id = wp_unique_id( 'news-ticker-dn-' );
        $items = self::items( $v );
        $config = array( 'source' => $v['source'], 'count' => $v['count'], 'category' => $v['category'], 'speed' => $v['speed'],
            'direction' => $v['direction'], 'refresh' => $v['refresh'], 'showDate' => $v['date'], 'newDays' => $v['new_days'],
            'endpoint' => rest_url( 'news-ticker-dn/v1/items' ) );
        ob_start(); ?>
        <section class="news-ticker-dn ntdn-theme-<?php echo esc_attr( $v['theme'] ); ?>" data-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>" aria-label="<?php echo esc_attr( $v['label'] ); ?>" data-static="no">
            <div class="ntdn-bar">
                <div class="ntdn-label"><span class="ntdn-dot" aria-hidden="true"></span><span><?php echo esc_html( $v['label'] ); ?></span></div>
                <div class="ntdn-viewport" id="<?php echo esc_attr( $id ); ?>-items">
                    <div class="ntdn-track"><ul class="ntdn-group">
                        <?php foreach ( $items as $item ) : ?>
                            <li><a href="<?php echo esc_url( $item['url'] ); ?>" data-id="<?php echo esc_attr( $item['id'] ); ?>" data-timestamp="<?php echo esc_attr( $item['timestamp'] ); ?>">
                                <?php if ( $v['date'] ) : ?><time datetime="<?php echo esc_attr( $item['dateIso'] ); ?>"><?php echo esc_html( $item['date'] ); ?></time><?php endif; ?>
                                <?php if ( $v['new_days'] && $item['timestamp'] >= time() - $v['new_days'] * DAY_IN_SECONDS ) : ?><span class="ntdn-new">NEW</span><?php endif; ?>
                                <span class="ntdn-title"><?php echo esc_html( $item['title'] ); ?></span>
                            </a></li>
                        <?php endforeach; ?>
                    </ul></div>
                    <p class="ntdn-empty" <?php echo $items ? 'hidden' : ''; ?>>公開された新着情報はまだありません。</p>
                </div>
                <div class="ntdn-controls" hidden>
                    <button type="button" data-action="pause" aria-pressed="false" aria-label="自動スクロールを一時停止" title="一時停止">Ⅱ</button>
                    <button type="button" data-action="list" aria-expanded="false" aria-controls="<?php echo esc_attr( $id ); ?>-items">一覧</button>
                    <button type="button" data-action="refresh" aria-label="新着情報を確認" title="新着情報を確認">↻</button>
                </div>
            </div>
            <span class="ntdn-status ntdn-sr" role="status" aria-live="polite"></span>
        </section>
        <?php return ob_get_clean();
    }
    public static function admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $v = self::options(); ?>
        <div class="wrap ntdn-admin">
            <h1>新着情報ティッカーdn</h1>
            <p>最新の投稿・お知らせを横に流します。設定を保存してから、プレビューまたは公開ページで確認してください。</p>
            <?php settings_errors(); ?>
            <div class="ntdn-admin-preview"><h2>現在の設定のプレビュー</h2><?php echo self::render(); // Escaped in renderer. ?></div>
            <form method="post" action="options.php">
                <?php settings_fields( 'news_ticker_dn_group' ); ?>
                <table class="form-table" role="presentation"><tbody>
                    <?php
                    $selects = array(
                        'placement' => array( '設置場所', array( 'manual' => 'ショートコードで個別設置', 'top' => 'サイト上部に自動設置', 'bottom' => 'サイト下部に自動設置' ) ),
                        'source' => array( '表示する情報', array( 'posts' => '通常の投稿', 'notices' => 'お知らせdn', 'both' => '投稿とお知らせdnの両方' ) ),
                        'theme' => array( '配色', array( 'navy' => 'ネイビー', 'emerald' => 'エメラルド', 'gold' => 'ゴールド' ) ),
                        'direction' => array( '流れる方向', array( 'left' => '左へ', 'right' => '右へ' ) ),
                    );
                    foreach ( $selects as $key => $row ) : ?>
                        <tr><th><label for="ntdn-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $row[0] ); ?></label></th><td><select id="ntdn-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( self::OPTION . '[' . $key . ']' ); ?>">
                            <?php foreach ( $row[1] as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $v[ $key ], $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?>
                        </select></td></tr>
                    <?php endforeach; ?>
                    <tr><th><label for="ntdn-label">見出し</label></th><td><input type="text" class="regular-text" id="ntdn-label" name="news_ticker_dn_options[label]" value="<?php echo esc_attr( $v['label'] ); ?>" maxlength="40"></td></tr>
                    <tr><th><label for="ntdn-category">カテゴリ</label></th><td><?php wp_dropdown_categories( array( 'show_option_all' => 'すべてのカテゴリ', 'hide_empty' => false, 'name' => 'news_ticker_dn_options[category]', 'id' => 'ntdn-category', 'selected' => $v['category'] ) ); ?><p class="description">投稿・お知らせdnのどちらにも適用します。子カテゴリも対象です。</p></td></tr>
                    <?php
                    $numbers = array(
                        'count' => array( '表示件数', 1, 20, '1〜20件。公開日時の新しい順です。' ),
                        'speed' => array( '流れる速度', 20, 180, '20〜180 px/秒。大きい数値ほど速くなります。' ),
                        'refresh' => array( '自動更新の間隔', 0, 3600, '秒単位。0で停止。1〜29を指定した場合は30秒に調整します。初期値は60秒です。' ),
                        'new_days' => array( 'NEWを付ける日数', 0, 30, '公開後0〜30日。0でNEW表示を無効にします。' ),
                    );
                    foreach ( $numbers as $key => $row ) : ?>
                        <tr><th><label for="ntdn-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $row[0] ); ?></label></th><td><input type="number" id="ntdn-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( self::OPTION . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $v[ $key ] ); ?>" min="<?php echo esc_attr( $row[1] ); ?>" max="<?php echo esc_attr( $row[2] ); ?>" step="1"><p class="description"><?php echo esc_html( $row[3] ); ?></p></td></tr>
                    <?php endforeach; ?>
                    <tr><th>日付の表示</th><td><label><input type="checkbox" name="news_ticker_dn_options[date]" value="1" <?php checked( $v['date'] ); ?>> 公開日を表示する</label></td></tr>
                </tbody></table>
                <?php submit_button( '設定を保存' ); ?>
            </form>
            <div class="ntdn-admin-guide">
                <h2>個別に設置する</h2><p>投稿・固定ページの「ショートコード」ブロックに以下を貼り付けてください。</p><p><code>[news_ticker_dn]</code></p>
                <p>例：お知らせだけを、ゴールドで10件表示する場合</p><p><code>[news_ticker_dn source="notices" theme="gold" count="10" label="お知らせ"]</code></p>
                <p>例：特定のカテゴリ・速度・更新間隔を指定する場合</p><p><code>[news_ticker_dn category="3" speed="40" refresh="120" date="no"]</code></p>
                <h2>専用のお知らせを追加する</h2><p>管理画面の「お知らせdn → 新規追加」でタイトルと本文を入力し、公開します。表示する情報を「お知らせdn」または「両方」に切り替えてください。タイトルのリンクから本文ページへ移動できます。</p>
                <p>下書き・予約・非公開・パスワード保護の記事は表示しません。外部サイトのニュース収集は行いません。</p>
                <h2>動きと自動更新</h2><p>マウスを重ねると停止し、キーボードでリンクを選ぶと静止した一覧になります。「Ⅱ」で一時停止、「一覧」で常時一覧表示に切り替えられます。端末で動きを減らす設定が有効な場合は、自動スクロールしません。</p>
                <p>閲覧中は指定間隔で新着を確認します。操作中の内容差し替えは保留し、操作が終わってから反映します。バックグラウンドのタブ・画面外のティッカーでは定期確認を控えます。即時配信ではありません。</p>
                <p>サイト上部への自動設置にはテーマの <code>wp_body_open()</code> 対応が必要です。自動設置とショートコードを併用すると複数表示になります。会員限定プラグインなど独自の閲覧制限との互換性は個別確認が必要です。</p>
                <p>このプラグインを削除しても、お知らせの記事と保存した設定は保持します。</p>
            </div>
        </div>
        <?php
    }
}
News_Ticker_Dn::boot();
register_activation_hook( __FILE__, array( 'News_Ticker_Dn', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'News_Ticker_Dn', 'deactivate' ) );
