/* 新着情報ティッカーdn 1.0.0 | GPL-2.0-or-later */
(function(root,factory){'use strict';var api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.NewsTickerCoreDn=api;}(typeof globalThis!=='undefined'?globalThis:this,function(){
    'use strict';
    function bound(value,min,max,fallback){var n=Number(value);return Number.isFinite(n)?Math.min(max,Math.max(min,Math.trunc(n))):fallback;}
    function config(raw){
        if(!raw||typeof raw!=='object')raw={};
        var refresh=bound(raw.refresh,0,3600,60);
        return {source:['posts','notices','both'].includes(raw.source)?raw.source:'posts',count:bound(raw.count,1,20,8),category:bound(raw.category,0,2147483647,0),
            speed:bound(raw.speed,20,180,55),direction:raw.direction==='right'?'right':'left',refresh:refresh===0?0:Math.max(30,refresh),
            showDate:raw.showDate!==false,newDays:bound(raw.newDays,0,30,7),endpoint:typeof raw.endpoint==='string'?raw.endpoint:''};
    }
    function url(value,base){try{var u=new URL(value,base);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password?u.href:null;}catch(_){return null;}}
    function items(rows,base,count){
        if(!Array.isArray(rows))throw new Error('invalid-response');
        var seen=new Set(),result=[];
        rows.slice(0,20).forEach(function(row){
            if(!row||typeof row!=='object'||!Number.isInteger(row.id)||row.id<1||typeof row.title!=='string'||typeof row.url!=='string')return;
            var link=url(row.url,base),timestamp=Number(row.timestamp);
            if(!link||seen.has(row.id)||!Number.isFinite(timestamp)||timestamp<=0)return;
            seen.add(row.id);result.push({id:row.id,title:row.title.slice(0,200)||'（タイトルなし）',url:link,date:typeof row.date==='string'?row.date.slice(0,32):'',
                dateIso:typeof row.dateIso==='string'&&Number.isFinite(Date.parse(row.dateIso))?row.dateIso:'',timestamp:timestamp});
        });
        return result.slice(0,bound(count,1,20,8));
    }
    function isNew(timestamp,days,now){return days>0&&Number.isFinite(timestamp)&&timestamp<=now&&timestamp>=now-days*86400;}
    function endpoint(cfg,base){var address=url(cfg.endpoint,base);if(!address)throw new Error('invalid-endpoint');var target=new URL(address),origin=new URL(base).origin;
        if(target.origin!==origin)throw new Error('cross-origin-endpoint');
        target.searchParams.set('source',cfg.source);target.searchParams.set('count',String(cfg.count));target.searchParams.set('category',String(cfg.category));return target.href;}
    function signature(rows,days,now){return JSON.stringify(rows.map(function(row){return [row.id,row.title,row.url,row.date,row.dateIso,isNew(row.timestamp,days,now)];}));}
    return Object.freeze({bound:bound,config:config,items:items,isNew:isNew,endpoint:endpoint,signature:signature,url:url});
}));
