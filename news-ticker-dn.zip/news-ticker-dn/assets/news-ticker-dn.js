/* 新着情報ティッカーdn 1.0.0 | GPL-2.0-or-later */
(function(){
    'use strict';
    var core=window.NewsTickerCoreDn;if(!core)return;
    var feeds=new Map();
    function fetchFeed(address,force){
        var existing=feeds.get(address),now=Date.now();
        if(existing&&existing.promise)return existing.promise;
        if(!force&&existing&&existing.data&&now-existing.at<5000)return Promise.resolve(existing.data);
        var entry={data:existing&&existing.data,at:existing?existing.at:0,promise:null};
        var controller=typeof AbortController==='function'?new AbortController():null;
        entry.promise=new Promise(function(resolve,reject){
            var timer=window.setTimeout(function(){if(controller)controller.abort();reject(new Error('timeout'));},10000);
            Promise.resolve().then(function(){
                return window.fetch(address,{credentials:'omit',cache:'no-store',headers:{Accept:'application/json'},signal:controller?controller.signal:undefined});
            }).then(function(response){if(!response.ok)throw new Error('http');return response.json();}).then(function(data){
                if(!data||!Array.isArray(data.items))throw new Error('invalid-response');
                entry.data=data;entry.at=Date.now();resolve(data);
            }).catch(reject).finally(function(){window.clearTimeout(timer);});
        }).finally(function(){entry.promise=null;});
        feeds.set(address,entry);return entry.promise;
    }
    function init(root){
        if(root.dataset.ready==='yes')return;
        var cfg;try{cfg=core.config(JSON.parse(root.dataset.config));}catch(_){return;}
        root.dataset.ready='yes';
        var viewport=root.querySelector('.ntdn-viewport'),track=root.querySelector('.ntdn-track'),group=track.querySelector('.ntdn-group');
        var controls=root.querySelector('.ntdn-controls'),pauseButton=root.querySelector('[data-action="pause"]'),listButton=root.querySelector('[data-action="list"]'),refreshButton=root.querySelector('[data-action="refresh"]');
        var status=root.querySelector('.ntdn-status'),empty=root.querySelector('.ntdn-empty');
        var media=window.matchMedia?window.matchMedia('(prefers-reduced-motion: reduce)'):null;
        var rows=Array.from(group.querySelectorAll('a')).map(function(a){var date=a.querySelector('time');return {id:Number(a.dataset.id),title:a.querySelector('.ntdn-title').textContent,url:a.href,date:date?date.textContent:'',dateIso:date?date.dateTime:'',timestamp:Number(a.dataset.timestamp)};});
        var paused=false,hover=false,focused=false,focusLink=false,pointerMode=false,list=false,inView=true,pending=null,fetching=false,failures=0;
        var timer=null,frame=null,lastCheck=0,address='',destroyed=false,resizeObserver=null,intersectionObserver=null;
        var now=Math.floor(Date.now()/1000),lastSignature=core.signature(rows,cfg.newDays,now);
        try{address=core.endpoint(cfg,window.location.href);}catch(_){address='';}
        controls.hidden=false;root.dataset.direction=cfg.direction;
        function announce(text,error){status.textContent=text;status.classList.toggle('ntdn-sr',!error);root.classList.toggle('ntdn-error',!!error);}
        function reduced(){return !!(media&&media.matches);}
        function occupied(){return paused||hover||focused||list;}
        function rebuild(){
            if(destroyed||root.dataset.static==='yes')return;
            var old=track.querySelector('.ntdn-clone');if(old)old.remove();
            group.style.minWidth=Math.ceil(viewport.clientWidth)+'px';
            var width=Math.max(group.scrollWidth,group.getBoundingClientRect().width,viewport.clientWidth,1);
            track.style.setProperty('--ntdn-distance',width+'px');track.style.setProperty('--ntdn-duration',(width/cfg.speed).toFixed(3)+'s');
            if(rows.length>1){var clone=group.cloneNode(true);clone.classList.add('ntdn-clone');clone.setAttribute('aria-hidden','true');clone.removeAttribute('id');
                clone.querySelectorAll('[id]').forEach(function(node){node.removeAttribute('id');});
                clone.querySelectorAll('a').forEach(function(a){a.tabIndex=-1;});track.appendChild(clone);}
        }
        function queueRebuild(){if(frame!==null)window.cancelAnimationFrame(frame);frame=window.requestAnimationFrame(function(){frame=null;rebuild();});}
        function state(){
            var wasStatic=root.dataset.static;
            root.dataset.static=(list||focusLink||reduced()||rows.length<2)?'yes':'no';
            root.dataset.paused=(paused||hover||focused||document.hidden||!inView)?'yes':'no';
            pauseButton.disabled=reduced()||rows.length<2;
            pauseButton.textContent=reduced()?'静止':paused?'▶':'Ⅱ';
            pauseButton.setAttribute('aria-pressed',paused?'true':'false');
            pauseButton.setAttribute('aria-label',reduced()?'端末設定により自動スクロールを停止中':paused?'自動スクロールを再開':'自動スクロールを一時停止');
            pauseButton.title=reduced()?'端末の「動きを減らす」設定を優先しています':paused?'再開':'一時停止';
            listButton.setAttribute('aria-expanded',list?'true':'false');listButton.textContent=list?'閉じる':'一覧';
            if(wasStatic!==root.dataset.static&&root.dataset.static==='no')queueRebuild();
            if(!occupied()&&pending){var data=pending;pending=null;apply(data);}
        }
        function apply(data){
            var serverNow=typeof data.generatedAt==='number'&&Number.isFinite(data.generatedAt)?data.generatedAt:Math.floor(Date.now()/1000);
            var updated=core.items(data.items,window.location.href,cfg.count),sig=core.signature(updated,cfg.newDays,serverNow);
            if(sig===lastSignature){announce('最新の情報を確認しました。');return;}
            if(occupied()){pending=data;announce('新着情報があります。操作が終わってから表示に反映します。');return;}
            rows=updated;lastSignature=sig;group.textContent='';
            var clone=track.querySelector('.ntdn-clone');if(clone)clone.remove();
            rows.forEach(function(item){
                var li=document.createElement('li'),a=document.createElement('a');a.href=item.url;a.dataset.id=String(item.id);a.dataset.timestamp=String(item.timestamp);
                if(cfg.showDate){var date=document.createElement('time');date.textContent=item.date;if(item.dateIso)date.dateTime=item.dateIso;a.appendChild(date);}
                if(core.isNew(item.timestamp,cfg.newDays,serverNow)){var badge=document.createElement('span');badge.className='ntdn-new';badge.textContent='NEW';a.appendChild(badge);}
                var title=document.createElement('span');title.className='ntdn-title';title.textContent=item.title;a.appendChild(title);li.appendChild(a);group.appendChild(li);
            });
            empty.hidden=rows.length>0;state();queueRebuild();announce(rows.length?'新着情報を更新しました。':'公開された新着情報はまだありません。');
        }
        function schedule(delay){if(timer!==null)window.clearTimeout(timer);if(cfg.refresh>0&&!destroyed)timer=window.setTimeout(function(){timer=null;update(false);},delay);}
        function update(force){
            if(!root.isConnected){destroy();return;}
            if(!address||typeof window.fetch!=='function'){announce('自動更新は利用できません。ページの再読み込みで情報を更新できます。',true);return;}
            if(fetching)return;
            if(!force&&(document.hidden||!inView)){schedule(cfg.refresh*1000);return;}
            fetching=true;refreshButton.disabled=true;
            fetchFeed(address,force).then(function(data){
                if(destroyed)return;
                failures=0;lastCheck=Date.now();apply(data);
            }).catch(function(){if(!destroyed){failures++;announce('更新を確認できませんでした。表示中の情報はそのままご覧いただけます。',true);}}).finally(function(){
                fetching=false;refreshButton.disabled=!address||typeof window.fetch!=='function';
                schedule(Math.min(Math.max(cfg.refresh,600),cfg.refresh*Math.pow(2,Math.min(failures,4)))*1000);
            });
        }
        function onVisibility(){state();if(!document.hidden&&cfg.refresh>0&&Date.now()-lastCheck>=cfg.refresh*1000)update(false);}
        function onMotion(){state();queueRebuild();}
        function onResize(){queueRebuild();}
        function onKeyMode(event){if(event.key==='Tab'){pointerMode=false;if(root.contains(document.activeElement)){focusLink=!!document.activeElement.closest('.ntdn-group');state();}}}
        function destroy(){
            destroyed=true;if(timer!==null)window.clearTimeout(timer);if(frame!==null)window.cancelAnimationFrame(frame);
            if(resizeObserver)resizeObserver.disconnect();if(intersectionObserver)intersectionObserver.disconnect();
            document.removeEventListener('visibilitychange',onVisibility);document.removeEventListener('keydown',onKeyMode,true);window.removeEventListener('resize',onResize);
            if(media){if(media.removeEventListener)media.removeEventListener('change',onMotion);else if(media.removeListener)media.removeListener(onMotion);}
        }
        root.addEventListener('mouseenter',function(){hover=true;state();});root.addEventListener('mouseleave',function(){hover=false;state();});
        root.addEventListener('pointerdown',function(){pointerMode=true;});
        root.addEventListener('mousedown',function(){pointerMode=true;});
        root.addEventListener('focusin',function(event){focused=true;focusLink=!pointerMode&&!!event.target.closest('.ntdn-group');state();});
        root.addEventListener('focusout',function(){window.setTimeout(function(){focused=root.contains(document.activeElement);focusLink=focused&&!pointerMode&&!!document.activeElement.closest('.ntdn-group');state();},0);});
        root.addEventListener('click',function(event){
            var button=event.target.closest('button[data-action]');if(!button||!root.contains(button)||button.disabled)return;
            if(button.dataset.action==='pause'){paused=!paused;state();}
            if(button.dataset.action==='list'){list=!list;state();}
            if(button.dataset.action==='refresh')update(true);
            if(event.detail>0)button.blur();
        });
        document.addEventListener('visibilitychange',onVisibility);document.addEventListener('keydown',onKeyMode,true);
        if(media){if(media.addEventListener)media.addEventListener('change',onMotion);else if(media.addListener)media.addListener(onMotion);}
        if(window.ResizeObserver){resizeObserver=new ResizeObserver(queueRebuild);resizeObserver.observe(viewport);}else window.addEventListener('resize',onResize);
        if(window.IntersectionObserver){intersectionObserver=new IntersectionObserver(function(entries){entries.forEach(function(entry){inView=entry.isIntersecting;state();if(inView&&cfg.refresh>0&&Date.now()-lastCheck>=cfg.refresh*1000)update(false);});});intersectionObserver.observe(root);}
        root.classList.add('ntdn-ready');state();queueRebuild();
        if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){if(!destroyed)queueRebuild();});
        refreshButton.disabled=!address||typeof window.fetch!=='function';
        if(cfg.refresh>0)schedule(250);
    }
    function boot(){document.querySelectorAll('.news-ticker-dn').forEach(init);}
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
}());
