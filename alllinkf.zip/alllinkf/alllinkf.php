<?php
/**
 * Plugin Name: alllinkf
 * Author: dn
 * Description: 任意のURLを、カテゴリ・タグ・サムネイル付きのリンク集として管理・表示します。サイト名は自動でタグに追加されます。ショートコード [alllinkf] で表示できます（[gss_links] [gemini_share_shots] も利用可）。
 * Version: 2.1.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: alllinkf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Alllinkf {

	const VER     = '2.1.0';
	const CPT     = 'gss_item';
	const TAX_CAT = 'gss_cat';
	const TAX_TAG = 'gss_tag';
	const NONCE   = 'gss_action';
	const SLUG    = 'alllinkf';

	private static $printed_assets = false;
	private static $instance_count = 0;

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'admin_init', array( __CLASS__, 'upgrade' ) );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_post_gss', array( __CLASS__, 'handle_post' ) );
		add_action( 'before_delete_post', array( __CLASS__, 'cleanup_attachment' ) );
		add_filter( 'parent_file', array( __CLASS__, 'menu_highlight' ) );
		add_shortcode( 'gemini_share_shots', array( __CLASS__, 'shortcode' ) );
		add_shortcode( 'gss_links', array( __CLASS__, 'shortcode' ) );
		add_shortcode( 'alllinkf', array( __CLASS__, 'shortcode' ) );
		register_activation_hook( __FILE__, array( __CLASS__, 'register' ) );
		register_deactivation_hook( __FILE__, array( __CLASS__, 'clear_legacy_cron' ) );
	}

	/* ---------- 登録 ---------- */

	public static function register() {
		register_post_type(
			self::CPT,
			array(
				'label'    => 'リンク集',
				'public'   => false,
				'show_ui'  => false,
				'supports' => array( 'title', 'excerpt', 'thumbnail' ),
			)
		);
		register_taxonomy(
			self::TAX_CAT,
			self::CPT,
			array(
				'labels'            => array(
					'name'          => 'リンクカテゴリ',
					'singular_name' => 'リンクカテゴリ',
					'add_new_item'  => '新規カテゴリを追加',
					'edit_item'     => 'カテゴリを編集',
					'search_items'  => 'カテゴリを検索',
					'parent_item'   => '親カテゴリ',
				),
				'hierarchical'      => true,
				'public'            => false,
				'show_ui'           => true,
				'show_in_menu'      => false,
				'show_admin_column' => false,
				'rewrite'           => false,
			)
		);
		register_taxonomy(
			self::TAX_TAG,
			self::CPT,
			array(
				'labels'       => array(
					'name'          => 'リンクタグ',
					'singular_name' => 'リンクタグ',
					'add_new_item'  => '新規タグを追加',
					'edit_item'     => 'タグを編集',
					'search_items'  => 'タグを検索',
				),
				'hierarchical' => false,
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => false,
				'rewrite'      => false,
			)
		);
	}

	public static function clear_legacy_cron() {
		wp_clear_scheduled_hook( 'gss_process_queue' );
		wp_clear_scheduled_hook( 'gss_scheduled_refresh' );
	}

	/** 旧バージョン（撮影機能あり）からの移行：cron停止・旧設定削除・既存項目へサイト名タグを付与。 */
	public static function upgrade() {
		if ( get_option( 'gss_version' ) === self::VER ) {
			return;
		}
		self::clear_legacy_cron();
		delete_option( 'gss_settings' );
		$ids = get_posts(
			array(
				'post_type'   => self::CPT,
				'post_status' => 'publish',
				'numberposts' => -1,
				'fields'      => 'ids',
			)
		);
		foreach ( $ids as $id ) {
			self::sync_site_tag( $id );
		}
		update_option( 'gss_version', self::VER );
	}

	/* ---------- URL・サイト名 ---------- */

	/** http/https のURLのみ通す。不正なら空文字。 */
	public static function normalize_url( $raw ) {
		$url = esc_url_raw( trim( (string) $raw ), array( 'http', 'https' ) );
		if ( '' === $url ) {
			return '';
		}
		$p = wp_parse_url( $url );
		return empty( $p['host'] ) ? '' : $url;
	}

	public static function host_of( $url ) {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		return preg_replace( '/^www\./', '', $host );
	}

	/** URLからサイト名を決める。既知のサイトは名称、それ以外はドメイン名。 */
	public static function site_name( $url ) {
		$host = self::host_of( $url );
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		$map  = array(
			'share.gemini.google' => 'Gemini',
			'gemini.google.com'   => 'Gemini',
			'chatgpt.com'         => 'ChatGPT',
			'chat.openai.com'     => 'ChatGPT',
			'claude.ai'           => 'Claude',
			'youtube.com'         => 'YouTube',
			'm.youtube.com'       => 'YouTube',
			'youtu.be'            => 'YouTube',
			'x.com'               => 'X',
			'twitter.com'         => 'X',
			'github.com'          => 'GitHub',
			'note.com'            => 'note',
			'instagram.com'       => 'Instagram',
			'facebook.com'        => 'Facebook',
			'amazon.co.jp'        => 'Amazon',
			'ja.wikipedia.org'    => 'Wikipedia',
			'en.wikipedia.org'    => 'Wikipedia',
		);
		if ( 'g.co' === $host && 0 === strpos( $path, '/gemini' ) ) {
			$name = 'Gemini';
		} elseif ( isset( $map[ $host ] ) ) {
			$name = $map[ $host ];
		} else {
			$name = $host;
		}
		return (string) apply_filters( 'gss_site_name', $name, $host, $url );
	}

	/** サイト名タグを項目に付ける。URL変更時は古いサイト名タグを外す。 */
	public static function sync_site_tag( $id ) {
		$url = get_post_meta( $id, '_gss_url', true );
		if ( ! $url ) {
			return;
		}
		$new = self::site_name( $url );
		$old = (string) get_post_meta( $id, '_gss_site_tag', true );
		if ( '' !== $old && $old !== $new ) {
			$term = get_term_by( 'name', $old, self::TAX_TAG );
			if ( $term ) {
				wp_remove_object_terms( $id, (int) $term->term_id, self::TAX_TAG );
			}
		}
		if ( '' !== $new ) {
			wp_set_object_terms( $id, array( $new ), self::TAX_TAG, true );
			update_post_meta( $id, '_gss_site_tag', $new );
		}
	}

	/* ---------- 項目の保存 ---------- */

	public static function find_by_url( $url ) {
		$ids = get_posts(
			array(
				'post_type'   => self::CPT,
				'post_status' => 'any',
				'numberposts' => 1,
				'fields'      => 'ids',
				'meta_key'    => '_gss_url',
				'meta_value'  => $url,
			)
		);
		return $ids ? (int) $ids[0] : 0;
	}

	private static function parse_tags( $text ) {
		$tags = preg_split( '/[,、\n]+/u', (string) $text );
		$tags = array_map( 'sanitize_text_field', $tags );
		return array_values( array_unique( array_filter( $tags, 'strlen' ) ) );
	}

	/** カテゴリ指定（既存ID or 新規名）からterm_idを返す。なければ0。 */
	private static function resolve_cat( $cat_id, $new_name ) {
		$new_name = sanitize_text_field( (string) $new_name );
		if ( '' !== $new_name ) {
			$exists = term_exists( $new_name, self::TAX_CAT );
			if ( $exists ) {
				return (int) ( is_array( $exists ) ? $exists['term_id'] : $exists );
			}
			$made = wp_insert_term( $new_name, self::TAX_CAT );
			return is_wp_error( $made ) ? 0 : (int) $made['term_id'];
		}
		$cat_id = absint( $cat_id );
		return ( $cat_id && term_exists( $cat_id, self::TAX_CAT ) ) ? $cat_id : 0;
	}

	/**
	 * 項目を作成/更新する。$id=0で新規。戻り値は項目ID（失敗時0）。
	 * $tags=null のときはタグを変更しない。
	 */
	public static function save_item( $id, $url, $title, $memo, $cat_id, $tags ) {
		$data = array(
			'post_type'    => self::CPT,
			'post_status'  => 'publish',
			'post_title'   => '' !== $title ? $title : $url,
			'post_excerpt' => $memo,
		);
		if ( $id ) {
			$data['ID'] = $id;
			$id         = wp_update_post( $data, true );
		} else {
			$id = wp_insert_post( $data, true );
		}
		if ( ! $id || is_wp_error( $id ) ) {
			return 0;
		}
		update_post_meta( $id, '_gss_url', $url );
		wp_set_object_terms( $id, $cat_id ? array( (int) $cat_id ) : array(), self::TAX_CAT );
		if ( null !== $tags ) {
			wp_set_object_terms( $id, $tags, self::TAX_TAG );
		}
		self::sync_site_tag( $id ); // サイト名タグは常に自動で付く
		return (int) $id;
	}

	/** アップロード画像をサムネイルに設定。成功時は空文字、失敗時はエラーメッセージ。 */
	private static function set_thumbnail( $id, $key ) {
		if ( ! current_user_can( 'upload_files' ) ) {
			return 'ファイルをアップロードする権限がありません。';
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$att_id = media_handle_upload(
			$key,
			$id,
			array( 'post_title' => get_the_title( $id ) ),
			array(
				'test_form' => false,
				'mimes'     => array(
					'jpg|jpeg' => 'image/jpeg',
					'png'      => 'image/png',
					'gif'      => 'image/gif',
					'webp'     => 'image/webp',
				),
			)
		);
		if ( is_wp_error( $att_id ) ) {
			return $att_id->get_error_message();
		}
		$old = (int) get_post_thumbnail_id( $id );
		set_post_thumbnail( $id, $att_id );
		if ( $old && $old !== (int) $att_id ) {
			wp_delete_attachment( $old, true );
		}
		return '';
	}

	private static function remove_thumbnail( $id ) {
		$att = (int) get_post_thumbnail_id( $id );
		if ( $att ) {
			delete_post_thumbnail( $id );
			wp_delete_attachment( $att, true );
		}
	}

	public static function cleanup_attachment( $post_id ) {
		if ( self::CPT === get_post_type( $post_id ) ) {
			$att = (int) get_post_thumbnail_id( $post_id );
			if ( $att ) {
				wp_delete_attachment( $att, true );
			}
		}
	}

	/* ---------- 管理画面 ---------- */

	public static function admin_menu() {
		add_menu_page( 'リンク集', 'リンク集', 'manage_options', self::SLUG, array( __CLASS__, 'render_admin' ), 'dashicons-admin-links', 58 );
		add_submenu_page( self::SLUG, 'リンク一覧', 'リンク一覧', 'manage_options', self::SLUG, array( __CLASS__, 'render_admin' ) );
		add_submenu_page( self::SLUG, 'カテゴリ', 'カテゴリ', 'manage_options', 'edit-tags.php?taxonomy=' . self::TAX_CAT . '&post_type=' . self::CPT );
		add_submenu_page( self::SLUG, 'タグ', 'タグ', 'manage_options', 'edit-tags.php?taxonomy=' . self::TAX_TAG . '&post_type=' . self::CPT );
	}

	/** カテゴリ・タグ管理画面でも「リンク集」メニューを開いた状態にする。 */
	public static function menu_highlight( $parent_file ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && in_array( $screen->taxonomy, array( self::TAX_CAT, self::TAX_TAG ), true ) ) {
			return self::SLUG;
		}
		return $parent_file;
	}

	public static function handle_post() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '権限がありません。' );
		}
		check_admin_referer( self::NONCE );

		$in  = wp_unslash( $_POST );
		$do  = isset( $in['do'] ) ? sanitize_key( $in['do'] ) : '';
		$id  = isset( $in['item'] ) ? absint( $in['item'] ) : 0;
		$msg = '';
		$back = array( 'page' => self::SLUG );

		if ( $id && self::CPT !== get_post_type( $id ) ) {
			$id = 0;
		}

		$cat  = self::resolve_cat( isset( $in['cat'] ) ? $in['cat'] : 0, isset( $in['new_cat'] ) ? $in['new_cat'] : '' );
		$tags = self::parse_tags( isset( $in['tags'] ) ? $in['tags'] : '' );

		switch ( $do ) {
			case 'add': // まとめて追加
				$added   = 0;
				$skipped = 0;
				$text    = isset( $in['urls'] ) ? sanitize_textarea_field( $in['urls'] ) : '';
				foreach ( preg_split( '/\r\n|\r|\n/', $text ) as $line ) {
					$line = trim( $line );
					if ( '' === $line ) {
						continue;
					}
					$parts = preg_split( '/\s+/u', $line, 2 );
					$url   = self::normalize_url( $parts[0] );
					if ( '' === $url || self::find_by_url( $url ) ) {
						$skipped++;
						continue;
					}
					$title = isset( $parts[1] ) ? sanitize_text_field( $parts[1] ) : '';
					self::save_item( 0, $url, $title, '', $cat, $tags ) ? $added++ : $skipped++;
				}
				$msg = sprintf( '%d件を登録しました（重複・不正なURLのスキップ %d件）。', $added, $skipped );
				break;

			case 'add_one':
			case 'update':
				$url   = self::normalize_url( isset( $in['url'] ) ? $in['url'] : '' );
				$title = isset( $in['title'] ) ? sanitize_text_field( $in['title'] ) : '';
				$memo  = isset( $in['memo'] ) ? sanitize_textarea_field( $in['memo'] ) : '';
				if ( 'update' === $do ) {
					if ( ! $id ) {
						$msg = '項目が見つかりません。';
						break;
					}
					$back['edit'] = $id;
				}
				if ( '' === $url ) {
					$msg = 'URLが正しくありません。';
					break;
				}
				$dup = self::find_by_url( $url );
				if ( $dup && $dup !== $id ) {
					$msg = 'このURLは登録済みです。';
					break;
				}
				$saved = self::save_item( 'update' === $do ? $id : 0, $url, $title, $memo, $cat, $tags );
				if ( ! $saved ) {
					$msg = '保存に失敗しました。';
					break;
				}
				$msg = 'update' === $do ? '更新しました。' : '登録しました。';
				if ( ! empty( $in['remove_thumb'] ) ) {
					self::remove_thumbnail( $saved );
				}
				if ( ! empty( $_FILES['thumb']['name'] ) ) {
					$err = self::set_thumbnail( $saved, 'thumb' );
					if ( '' !== $err ) {
						$msg .= ' ただし画像は保存できませんでした: ' . $err;
					}
				}
				break;

			case 'delete':
				if ( $id ) {
					wp_delete_post( $id, true );
					$msg = '削除しました。';
				}
				break;
		}

		$back['gss_msg'] = rawurlencode( $msg );
		wp_safe_redirect( add_query_arg( $back, admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function form_open( $do, $item = 0, $multipart = false, $inline = false ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $inline ? ' style="display:inline"' : '' ) . ( $multipart ? ' enctype="multipart/form-data"' : '' ) . '>';
		echo '<input type="hidden" name="action" value="gss">';
		echo '<input type="hidden" name="do" value="' . esc_attr( $do ) . '">';
		if ( $item ) {
			echo '<input type="hidden" name="item" value="' . esc_attr( $item ) . '">';
		}
		wp_nonce_field( self::NONCE );
	}

	/** カテゴリ選択＋新規カテゴリ＋タグ入力の共通フィールド。 */
	private static function tax_fields( $cat_id = 0, $tags_value = '', $site_tag = '' ) {
		echo '<p><label>カテゴリ　';
		wp_dropdown_categories(
			array(
				'taxonomy'        => self::TAX_CAT,
				'name'            => 'cat',
				'selected'        => $cat_id,
				'hide_empty'      => false,
				'hierarchical'    => true,
				'show_option_none' => '（未分類）',
				'option_none_value' => 0,
			)
		);
		echo '</label>　または新規作成 <input type="text" name="new_cat" class="regular-text" placeholder="新しいカテゴリ名"></p>';
		echo '<p><label>タグ　<input type="text" name="tags" value="' . esc_attr( $tags_value ) . '" class="regular-text" placeholder="カンマ区切り（例: 調査, AI, メモ）"></label> ';
		echo '<span class="description">サイト名のタグ' . ( '' !== $site_tag ? '（' . esc_html( $site_tag ) . '）' : '' ) . 'は自動で追加されます。</span></p>';
	}

	private static function notice() {
		if ( ! empty( $_GET['gss_msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['gss_msg'] ) ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
		}
	}

	public static function render_admin() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$edit = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		if ( $edit && self::CPT === get_post_type( $edit ) ) {
			self::render_edit( get_post( $edit ) );
			return;
		}
		$items = get_posts(
			array(
				'post_type'   => self::CPT,
				'post_status' => 'publish',
				'numberposts' => -1,
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		);
		$thumb_accept = 'image/jpeg,image/png,image/gif,image/webp';
		?>
		<div class="wrap">
			<h1>リンク集</h1>
			<?php self::notice(); ?>
			<p>表示用ショートコード: <code>[alllinkf]</code>　（例: <code>[alllinkf category="カテゴリ名" layout="grid" columns="3"]</code>）</p>

			<h2>まとめて追加</h2>
			<?php self::form_open( 'add' ); ?>
				<p>1行に1件。「URL」のみ、または「URL タイトル」（空白区切り）で入力します。下のカテゴリとタグは全行に付きます。</p>
				<textarea name="urls" rows="5" class="large-text code" placeholder="https://share.gemini.google/xxxxxxxx 調査メモ&#10;https://example.com/page 参考ページ"></textarea>
				<?php self::tax_fields(); ?>
				<?php submit_button( 'まとめて登録', 'primary', 'submit', true ); ?>
			</form>

			<h2>1件追加（サムネイル・メモ付き）</h2>
			<?php self::form_open( 'add_one', 0, true ); ?>
				<p><input type="url" name="url" class="large-text code" placeholder="https://..." required></p>
				<p><input type="text" name="title" class="large-text" placeholder="タイトル（省略するとURLがタイトルになります）"></p>
				<p><textarea name="memo" rows="2" class="large-text" placeholder="メモ・説明（省略可）"></textarea></p>
				<?php self::tax_fields(); ?>
				<p><label>サムネイル画像　<input type="file" name="thumb" accept="<?php echo esc_attr( $thumb_accept ); ?>"></label> <span class="description">JPEG / PNG / GIF / WebP（省略可）</span></p>
				<?php submit_button( '登録', 'secondary', 'submit', true ); ?>
			</form>

			<h2>リンク一覧（<?php echo count( $items ); ?>件）</h2>
			<table class="widefat striped">
				<thead><tr><th style="width:110px">サムネイル</th><th>タイトル / URL</th><th style="width:160px">カテゴリ</th><th style="width:220px">タグ</th><th style="width:130px">操作</th></tr></thead>
				<tbody>
				<?php if ( ! $items ) : ?>
					<tr><td colspan="5">まだ登録がありません。</td></tr>
				<?php endif; ?>
				<?php
				foreach ( $items as $p ) :
					$url  = get_post_meta( $p->ID, '_gss_url', true );
					$cats = wp_get_object_terms( $p->ID, self::TAX_CAT, array( 'fields' => 'names' ) );
					$tgs  = wp_get_object_terms( $p->ID, self::TAX_TAG, array( 'fields' => 'names' ) );
					?>
					<tr>
						<td><?php echo has_post_thumbnail( $p->ID ) ? get_the_post_thumbnail( $p->ID, array( 96, 96 ) ) : '—'; ?></td>
						<td>
							<strong><?php echo esc_html( $p->post_title ); ?></strong><br>
							<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $url ); ?></a>
							<?php if ( $p->post_excerpt ) : ?><br><small><?php echo esc_html( $p->post_excerpt ); ?></small><?php endif; ?>
						</td>
						<td><?php echo ( ! is_wp_error( $cats ) && $cats ) ? esc_html( implode( ', ', $cats ) ) : '（未分類）'; ?></td>
						<td><?php echo ( ! is_wp_error( $tgs ) && $tgs ) ? esc_html( implode( ', ', $tgs ) ) : '—'; ?></td>
						<td>
							<a class="button button-small" href="<?php echo esc_url( add_query_arg( array( 'page' => self::SLUG, 'edit' => $p->ID ), admin_url( 'admin.php' ) ) ); ?>">編集</a>
							<?php self::form_open( 'delete', $p->ID, false, true ); ?><button class="button button-small button-link-delete" onclick="return confirm('削除しますか？');">削除</button></form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	private static function render_edit( $p ) {
		$url      = get_post_meta( $p->ID, '_gss_url', true );
		$site_tag = (string) get_post_meta( $p->ID, '_gss_site_tag', true );
		$cats     = wp_get_object_terms( $p->ID, self::TAX_CAT, array( 'fields' => 'ids' ) );
		$tgs      = wp_get_object_terms( $p->ID, self::TAX_TAG, array( 'fields' => 'names' ) );
		$cat_id   = ( ! is_wp_error( $cats ) && $cats ) ? (int) $cats[0] : 0;
		$tgs      = is_wp_error( $tgs ) ? array() : array_values( array_diff( $tgs, array( $site_tag ) ) );
		?>
		<div class="wrap">
			<h1>リンクを編集</h1>
			<?php self::notice(); ?>
			<p><a href="<?php echo esc_url( add_query_arg( 'page', self::SLUG, admin_url( 'admin.php' ) ) ); ?>">← 一覧に戻る</a></p>
			<?php self::form_open( 'update', $p->ID, true ); ?>
				<p><label>URL<br><input type="url" name="url" value="<?php echo esc_attr( $url ); ?>" class="large-text code" required></label></p>
				<p><label>タイトル<br><input type="text" name="title" value="<?php echo esc_attr( $p->post_title ); ?>" class="large-text"></label></p>
				<p><label>メモ・説明<br><textarea name="memo" rows="3" class="large-text"><?php echo esc_textarea( $p->post_excerpt ); ?></textarea></label></p>
				<?php self::tax_fields( $cat_id, implode( ', ', $tgs ), $site_tag ); ?>
				<p>サムネイル<br>
					<?php if ( has_post_thumbnail( $p->ID ) ) : ?>
						<?php echo get_the_post_thumbnail( $p->ID, 'medium' ); ?><br>
						<label><input type="checkbox" name="remove_thumb" value="1"> 画像を削除する</label><br>
					<?php endif; ?>
					<input type="file" name="thumb" accept="image/jpeg,image/png,image/gif,image/webp"> <span class="description">選ぶと差し替えます。</span>
				</p>
				<?php submit_button( '更新' ); ?>
			</form>
		</div>
		<?php
	}

	/* ---------- ショートコード（リンク集表示） ---------- */

	private static function term_ids_from_names( $value, $taxonomy ) {
		$ids = array();
		foreach ( array_filter( array_map( 'trim', explode( ',', (string) $value ) ), 'strlen' ) as $name ) {
			$term = get_term_by( 'name', $name, $taxonomy );
			if ( ! $term ) {
				$term = get_term_by( 'slug', $name, $taxonomy );
			}
			$ids[] = $term ? (int) $term->term_id : 0; // 存在しない名前は0（=該当なし）
		}
		return $ids;
	}

	public static function shortcode( $atts ) {
		$a = shortcode_atts(
			array(
				'category' => '',      // カテゴリ名（カンマ区切り可）
				'tag'      => '',      // タグ名（カンマ区切り可）
				'layout'   => 'list',  // list | grid
				'columns'  => 3,       // grid時の列数
				'group'    => 1,       // カテゴリごとに見出しで分ける
				'filter'   => 1,       // タグ絞り込みボタンを出す
				'thumb'    => 1,       // サムネイルを出す
				'limit'    => -1,
				'order'    => 'DESC',
			),
			$atts,
			'gss_links'
		);

		$query = array(
			'post_type'   => self::CPT,
			'post_status' => 'publish',
			'numberposts' => (int) $a['limit'],
			'orderby'     => 'date',
			'order'       => 'ASC' === strtoupper( $a['order'] ) ? 'ASC' : 'DESC',
		);
		$tax_query = array();
		if ( '' !== trim( $a['category'] ) ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_CAT,
				'field'    => 'term_id',
				'terms'    => self::term_ids_from_names( $a['category'], self::TAX_CAT ),
			);
		}
		if ( '' !== trim( $a['tag'] ) ) {
			$tax_query[] = array(
				'taxonomy' => self::TAX_TAG,
				'field'    => 'term_id',
				'terms'    => self::term_ids_from_names( $a['tag'], self::TAX_TAG ),
			);
		}
		if ( $tax_query ) {
			$query['tax_query'] = $tax_query;
		}
		$items = get_posts( $query );
		if ( ! $items ) {
			return '';
		}

		$grid     = 'grid' === $a['layout'];
		$show_img = (bool) (int) $a['thumb'];
		$groups   = array(); // カテゴリ名 => HTML配列
		$all_tags = array(); // term_id => name

		foreach ( $items as $p ) {
			$url  = get_post_meta( $p->ID, '_gss_url', true );
			$cats = wp_get_object_terms( $p->ID, self::TAX_CAT );
			$tgs  = wp_get_object_terms( $p->ID, self::TAX_TAG );
			$cats = is_wp_error( $cats ) ? array() : $cats;
			$tgs  = is_wp_error( $tgs ) ? array() : $tgs;
			$key  = ( (int) $a['group'] && $cats ) ? $cats[0]->name : '';

			$tag_ids  = array();
			$tag_html = '';
			foreach ( $tgs as $t ) {
				$tag_ids[]                = (int) $t->term_id;
				$all_tags[ $t->term_id ] = $t->name;
				$tag_html                .= '<button type="button" class="gss-tag" data-gss-tag="' . (int) $t->term_id . '">#' . esc_html( $t->name ) . '</button>';
			}

			$link = 'href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer"';
			$html = '<li class="gss-item" data-tags="' . esc_attr( implode( ' ', $tag_ids ) ) . '">';
			if ( $show_img && has_post_thumbnail( $p->ID ) ) {
				$html .= '<a class="gss-thumb" ' . $link . '>' . get_the_post_thumbnail(
					$p->ID,
					$grid ? 'medium_large' : 'thumbnail',
					array(
						'loading' => 'lazy',
						'alt'     => '',
					)
				) . '</a>';
			}
			$html .= '<div class="gss-body">';
			$html .= '<a class="gss-title" ' . $link . '>' . esc_html( $p->post_title ) . '</a>';
			$html .= '<span class="gss-site">' . esc_html( self::host_of( $url ) ) . '</span>';
			if ( $p->post_excerpt ) {
				$html .= '<p class="gss-memo">' . nl2br( esc_html( $p->post_excerpt ) ) . '</p>';
			}
			if ( $tag_html ) {
				$html .= '<div class="gss-tags">' . $tag_html . '</div>';
			}
			$html .= '</div></li>';

			$groups[ $key ][] = $html;
		}

		// カテゴリ名順。未分類（キーが空）は最後。
		$uncat = isset( $groups[''] ) ? $groups[''] : null;
		unset( $groups[''] );
		ksort( $groups, SORT_NATURAL | SORT_FLAG_CASE );
		if ( null !== $uncat ) {
			$groups[''] = $uncat;
		}

		self::$instance_count++;
		$cols = min( 6, max( 1, (int) $a['columns'] ) );
		$out  = self::assets();
		$out .= '<div class="gss-links gss-' . ( $grid ? 'grid' : 'list' ) . '" id="gss-links-' . self::$instance_count . '" style="--gss-cols:' . $cols . '">';

		if ( (int) $a['filter'] && count( $all_tags ) > 1 ) {
			asort( $all_tags, SORT_NATURAL | SORT_FLAG_CASE );
			$out .= '<div class="gss-tagbar"><button type="button" class="gss-tag is-active" data-gss-tag="">すべて</button>';
			foreach ( $all_tags as $tid => $name ) {
				$out .= '<button type="button" class="gss-tag" data-gss-tag="' . (int) $tid . '">#' . esc_html( $name ) . '</button>';
			}
			$out .= '</div>';
		}

		$multi = count( $groups ) > 1 || ( 1 === count( $groups ) && '' !== key( $groups ) );
		foreach ( $groups as $name => $rows ) {
			$out .= '<section class="gss-group">';
			if ( (int) $a['group'] && $multi ) {
				$out .= '<h3 class="gss-cat">' . esc_html( '' !== (string) $name ? $name : '未分類' ) . '</h3>';
			}
			$out .= '<ul class="gss-items">' . implode( '', $rows ) . '</ul></section>';
		}
		return $out . '</div>';
	}

	/** CSSとタグ絞り込みJS。ページ内で1回だけ出力。 */
	private static function assets() {
		if ( self::$printed_assets ) {
			return '';
		}
		self::$printed_assets = true;
		$css = '
.gss-links{margin:1.5em 0}
.gss-tagbar{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:1.2em}
.gss-links .gss-tag{font:inherit;font-size:.8em;line-height:1.6;padding:1px 10px;border:1px solid currentColor;border-radius:999px;background:transparent;color:inherit;opacity:.65;cursor:pointer}
.gss-links .gss-tag:hover,.gss-links .gss-tag.is-active{opacity:1}
.gss-links .gss-tag.is-active{font-weight:700;box-shadow:inset 0 0 0 1px currentColor}
.gss-cat{margin:1.4em 0 .5em;padding-bottom:.3em;border-bottom:2px solid currentColor;font-size:1.15em}
.gss-links .gss-items{list-style:none;margin:0;padding:0}
.gss-item{margin:0}
.gss-item[hidden],.gss-group[hidden]{display:none!important}
.gss-title{font-weight:600;word-break:break-word}
.gss-site{display:inline-block;margin-left:.6em;font-size:.8em;opacity:.6}
.gss-memo{margin:.3em 0 0;font-size:.9em;opacity:.85}
.gss-tags{display:flex;flex-wrap:wrap;gap:4px;margin-top:.4em}
.gss-thumb img{display:block;width:100%;height:100%;object-fit:cover}
.gss-list .gss-item{display:flex;gap:12px;align-items:flex-start;padding:12px 0;border-bottom:1px solid rgba(128,128,128,.3)}
.gss-list .gss-thumb{flex:0 0 72px;width:72px;height:72px;border-radius:6px;overflow:hidden}
.gss-list .gss-body{flex:1;min-width:0}
.gss-grid .gss-items{display:grid;gap:16px;grid-template-columns:repeat(var(--gss-cols,3),minmax(0,1fr))}
.gss-grid .gss-item{border:1px solid rgba(128,128,128,.35);border-radius:8px;overflow:hidden}
.gss-grid .gss-thumb{display:block;aspect-ratio:16/10}
.gss-grid .gss-body{padding:10px 12px}
.gss-grid .gss-site{display:block;margin:.2em 0 0}
@media(max-width:782px){.gss-grid .gss-items{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:480px){.gss-grid .gss-items{grid-template-columns:1fr}}
';
		$js = "
document.addEventListener('click',function(e){
var b=e.target.closest('[data-gss-tag]');if(!b)return;
var root=b.closest('.gss-links');if(!root)return;
var tag=b.getAttribute('data-gss-tag');
root.querySelectorAll('.gss-tag').forEach(function(x){x.classList.toggle('is-active',x.getAttribute('data-gss-tag')===tag);});
root.querySelectorAll('.gss-item').forEach(function(li){
var has=!tag||(' '+li.getAttribute('data-tags')+' ').indexOf(' '+tag+' ')>-1;li.hidden=!has;});
root.querySelectorAll('.gss-group').forEach(function(g){g.hidden=!g.querySelector('.gss-item:not([hidden])');});
});
";
		return '<style>' . $css . '</style><script>' . $js . '</script>';
	}
}

Alllinkf::init();
